"""Entry point for the Streamlit coach admin application.

This script ties together user authentication and the coach admin
interface. When launched via ``streamlit run``, it first ensures
that both the user table and coach tables exist and seed some
default accounts. Users can then log in using a simple form. Only
users with the ``admin`` role will be allowed to manage coaches;
other users will see an access denied message.

The user session persists across reruns by storing flags in
``st.session_state``. A logout button clears these flags and
returns the app to the login screen.
"""

from __future__ import annotations

import streamlit as st

from . import auth, coach_ui, db


def ensure_session_state() -> None:
    """Initialise session state variables if they do not exist."""
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False
    if "user" not in st.session_state:
        st.session_state.user = None


def login_screen() -> None:
    """Render the login screen.

    This page allows a user to enter their username and password. If
    credentials are valid, the session state is updated and the app
    automatically reruns, showing the admin interface to authorized
    users. Invalid credentials are reported via an error message.
    """
    st.title("Coach Admin Login")
    st.write("Enter your username and password.")
    with st.form("login_form"):
        username = st.text_input("Username")
        password = st.text_input("Password", type="password")
        submitted = st.form_submit_button("Login")
    if submitted:
        user = auth.get_user_by_username(username.strip())
        if not user:
            st.error("Invalid username or password.")
            return
        if not auth.verify_password(password, user["salt_hex"], user["hash_hex"], user["iterations"]):
            st.error("Invalid username or password.")
            return
        # Successful login
        st.session_state.logged_in = True
        st.session_state.user = user
        st.success(f"Logged in as {user['username']}")
        # Rerun to show next page
        st.experimental_rerun()


def main() -> None:
    """Main entry point for the app."""
    # Ensure DB and users are set up on every run
    db.init_db()
    auth.init_user_table()
    # Seed default users if missing
    auth.seed_default_users()

    st.set_page_config(page_title="Coach Admin", layout="wide")
    ensure_session_state()

    # If not logged in, show login page
    if not st.session_state.logged_in:
        login_screen()
        return

    # Logged in: show logout and content
    user = st.session_state.user
    st.sidebar.write(f"Logged in as: **{user['username']}** ({user['role']})")
    if st.sidebar.button("Logout"):
        st.session_state.logged_in = False
        st.session_state.user = None
        # Clear coach UI session state variables to avoid leaking old state
        for key in ["selected_coach", "coach_mode"]:
            if key in st.session_state:
                del st.session_state[key]
        st.experimental_rerun()
        return

    # Authorisation: only admins can manage coaches
    if user.get("role") != "admin":
        st.error("You do not have permission to view this page.")
        return

    # Admin page
    coach_ui.admin_coach_page()


if __name__ == "__main__":
    main()