"""Streamlit UI components for managing coaches.

This module defines a single function, ``admin_coach_page``, which
renders a dashboard for listing, viewing, creating and editing
coaches. The page is intended for administrative users only. It uses
two columns to mimic the layout shown by the user: a narrow column
on the left listing all coaches and a larger column on the right
showing details and instructions for the selected coach. All
modifications are persisted via functions in ``db.py``.
"""

from __future__ import annotations

import streamlit as st

from . import db


def admin_coach_page() -> None:
    """Render the admin interface for managing coaches.

    The page automatically initialises the database and instruction
    directory. It displays a sidebar with all coaches and a button for
    creating new ones. Selecting a coach loads its details and
    instructions for editing. Adding a new coach opens an empty form.
    All changes are saved back to the database or Markdown files when
    the user clicks the submit button on a form.
    """
    # Ensure the database and instruction directory are ready
    db.init_db()

    st.title("Coach Management")

    # Retrieve all coaches from the database
    coaches = db.get_all_coaches()

    # Sidebar navigation: list of coaches and add new button
    with st.sidebar:
        st.header("Coaches")
        # Add new coach button toggles the session state
        if st.button("➕ Add New Coach"):
            st.session_state["coach_mode"] = "add"
        # Build a radio list of coach IDs for selection
        if coaches:
            # Preselect the first coach by default if none selected
            if "selected_coach" not in st.session_state:
                st.session_state["selected_coach"] = coaches[0]["coach_id"]
            selected_id = st.radio(
                label="Select Coach",
                options=[c["coach_id"] for c in coaches],
                format_func=lambda cid: next((c["name"] for c in coaches if c["coach_id"] == cid), cid),
                index=[i for i, c in enumerate(coaches) if c["coach_id"] == st.session_state.get("selected_coach")].pop(0) if st.session_state.get("selected_coach") else 0,
            )
            st.session_state["selected_coach"] = selected_id
        else:
            st.info("No coaches exist yet. Use the button above to add the first coach.")

    # Determine page mode: view/edit existing or add new
    mode = st.session_state.get("coach_mode", "view")

    # Two columns for layout: list already in sidebar, details occupy full width
    # We still use a container here for clarity
    if mode == "add":
        st.subheader("Add New Coach")
        # Display a form for adding a coach
        with st.form(key="add_coach_form"):
            name = st.text_input("Name", help="Enter the coach's full name")
            tags_str = st.text_input(
                "Tags",
                help="Comma‑separated keywords describing this coach's speciality (e.g. strength, running)",
            )
            min_minutes = st.number_input(
                "Min session minutes",
                min_value=10,
                max_value=180,
                value=30,
                step=5,
                help="Minimum workout duration this coach is comfortable with",
            )
            max_minutes = st.number_input(
                "Max session minutes",
                min_value=min_minutes,
                max_value=180,
                value=60,
                step=5,
                help="Maximum workout duration this coach is comfortable with",
            )
            instructions_md = st.text_area(
                "Instructions (Markdown)",
                height=300,
                help="Write the detailed coaching instructions in Markdown format.",
            )
            submitted = st.form_submit_button("Save Coach")
        if submitted:
            # Split tags string into list
            tags = [t.strip() for t in tags_str.split(",") if t.strip()]
            # Insert into DB and write instructions
            coach_id = db.insert_coach(name, tags, int(min_minutes), int(max_minutes))
            db.write_instruction(coach_id, instructions_md)
            st.success(f"Coach '{name}' added with ID {coach_id}.")
            # Switch back to view mode and select new coach
            st.session_state["coach_mode"] = "view"
            st.session_state["selected_coach"] = coach_id
            st.experimental_rerun()
    else:
        # View or edit existing coach
        coach_id = st.session_state.get("selected_coach")
        if not coach_id:
            st.info("Select a coach from the sidebar or add a new one.")
            return
        coach = db.get_coach(coach_id)
        if coach is None:
            st.error("The selected coach could not be found.")
            return
        st.subheader(f"Coach – {coach['name']} ({coach_id})")
        # Build an edit form
        with st.form(key="edit_coach_form"):
            name = st.text_input("Name", value=coach["name"], help="Update the coach's name")
            tags_str = st.text_input(
                "Tags",
                value=", ".join(coach["tags"]),
                help="Comma‑separated keywords for this coach",
            )
            min_minutes = st.number_input(
                "Min session minutes",
                min_value=10,
                max_value=180,
                value=coach["min_session_minutes"] or 30,
                step=5,
                help="Update minimum workout duration",
            )
            max_minutes = st.number_input(
                "Max session minutes",
                min_value=min_minutes,
                max_value=180,
                value=coach["max_session_minutes"] or 60,
                step=5,
                help="Update maximum workout duration",
            )
            instructions_md = st.text_area(
                "Instructions (Markdown)",
                value=db.read_instruction(coach_id),
                height=300,
                help="Edit the coaching instructions in Markdown format.",
            )
            submitted = st.form_submit_button("Save Changes")
        if submitted:
            # Process updates
            tags = [t.strip() for t in tags_str.split(",") if t.strip()]
            db.update_coach(coach_id, name, tags, int(min_minutes), int(max_minutes))
            db.write_instruction(coach_id, instructions_md)
            st.success("Changes saved.")
            # Reload page to reflect updates in list
            st.experimental_rerun()
        # Show a preview of the current instructions
        st.markdown("### Current Instructions")
        # Use a container to avoid reflow when editing
        with st.expander("Preview", expanded=True):
            markdown_text = db.read_instruction(coach_id)
            if markdown_text:
                st.markdown(markdown_text)
            else:
                st.write("No instructions have been written yet.")
