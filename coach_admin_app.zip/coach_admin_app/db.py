"""Database operations for the coach admin app.

This module provides a small wrapper around SQLite for storing
coach metadata. Each coach has an auto‑generated ID (e.g. ``C001``),
a human readable name, optional tags, and minimum/maximum session
duration settings. Instructions for each coach are not stored in
the database. Instead, they are persisted as Markdown files on
disk. This keeps the database focused on structured data while
allowing rich, editable text instructions to live alongside the
codebase.

Functions in this module are intentionally simple; they expose
basic CRUD operations and handle JSON encoding/decoding for list
columns. See ``coach_ui.py`` for the Streamlit interface that
invokes these helpers.
"""

from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional


# The SQLite database file lives alongside this module. A single
# database is used for both user accounts (handled in auth.py) and
# coach metadata. Keeping it in the same directory makes the app
# self contained and easy to move around. If you change this path
# remember to update DB_PATH in auth.py as well.
DB_PATH = os.path.join(os.path.dirname(__file__), "local_coaches.db")

# Instructions are stored as Markdown files in this directory. One
# file per coach ID. The directory is created on first use.
INSTR_DIR = os.path.join(os.path.dirname(__file__), "coach_instructions")


def init_db() -> None:
    """Initialise the database and create the coaches table if needed.

    This function is idempotent and safe to call multiple times.
    It also ensures that the instruction directory exists.
    """
    os.makedirs(INSTR_DIR, exist_ok=True)
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    # A minimal coaches table. More fields can be added over time.
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS coaches (
            coach_id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            tags_json TEXT,
            min_session_minutes INTEGER,
            max_session_minutes INTEGER,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        """
    )
    conn.commit()
    conn.close()


def get_conn() -> sqlite3.Connection:
    """Return a new SQLite connection. Foreign keys are enabled by default."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def get_all_coaches() -> List[Dict[str, Any]]:
    """Retrieve all coaches from the database ordered by their name.

    Returns
    -------
    List[dict]
        A list of dictionaries representing each coach. Tags are decoded
        from JSON into Python lists. If no coaches exist an empty list
        is returned.
    """
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT coach_id, name, tags_json, min_session_minutes, max_session_minutes FROM coaches ORDER BY name;"
    )
    rows = cur.fetchall()
    conn.close()
    coaches: List[Dict[str, Any]] = []
    for row in rows:
        coach_id, name, tags_json, min_minutes, max_minutes = row
        tags = json.loads(tags_json) if tags_json else []
        coaches.append(
            {
                "coach_id": coach_id,
                "name": name,
                "tags": tags,
                "min_session_minutes": min_minutes,
                "max_session_minutes": max_minutes,
            }
        )
    return coaches


def get_coach(coach_id: str) -> Optional[Dict[str, Any]]:
    """Return a single coach by its ID.

    Parameters
    ----------
    coach_id : str
        The ID of the coach (e.g. ``C001``).

    Returns
    -------
    dict or None
        A dictionary of coach information or ``None`` if not found.
    """
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT coach_id, name, tags_json, min_session_minutes, max_session_minutes FROM coaches WHERE coach_id = ?;",
        (coach_id,),
    )
    row = cur.fetchone()
    conn.close()
    if row is None:
        return None
    coach_id, name, tags_json, min_minutes, max_minutes = row
    tags = json.loads(tags_json) if tags_json else []
    return {
        "coach_id": coach_id,
        "name": name,
        "tags": tags,
        "min_session_minutes": min_minutes,
        "max_session_minutes": max_minutes,
    }


def _generate_next_coach_id(conn: sqlite3.Connection) -> str:
    """Generate the next coach ID in sequence.

    Coach IDs are strings like ``C001``, ``C002``, etc. The numeric
    portion increments with each new coach. This helper is internal
    and expects an open connection.
    """
    cur = conn.cursor()
    cur.execute("SELECT coach_id FROM coaches ORDER BY coach_id DESC LIMIT 1;")
    row = cur.fetchone()
    if row:
        last_id = row[0]
        try:
            last_num = int(last_id[1:])
        except ValueError:
            last_num = 0
        new_num = last_num + 1
    else:
        new_num = 1
    return f"C{new_num:03d}"


def insert_coach(name: str, tags: List[str], min_minutes: int, max_minutes: int) -> str:
    """Insert a new coach into the database and return its generated ID.

    Parameters
    ----------
    name : str
        The coach's name.
    tags : List[str]
        A list of tags describing the coach's specialities. These will
        be encoded to JSON for storage.
    min_minutes : int
        The minimum session length the coach typically supports.
    max_minutes : int
        The maximum session length the coach typically supports.

    Returns
    -------
    str
        The new coach ID (e.g. ``C006``).
    """
    conn = get_conn()
    cur = conn.cursor()
    coach_id = _generate_next_coach_id(conn)
    now = datetime.utcnow().isoformat()
    cur.execute(
        """
        INSERT INTO coaches (coach_id, name, tags_json, min_session_minutes, max_session_minutes, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?);
        """,
        (
            coach_id,
            name,
            json.dumps([t.strip() for t in tags if t.strip()]),
            min_minutes,
            max_minutes,
            now,
            now,
        ),
    )
    conn.commit()
    conn.close()
    return coach_id


def update_coach(coach_id: str, name: str, tags: List[str], min_minutes: int, max_minutes: int) -> None:
    """Update an existing coach's metadata.

    Parameters
    ----------
    coach_id : str
        The coach ID to update.
    name : str
        The updated coach name.
    tags : List[str]
        Updated list of speciality tags.
    min_minutes : int
        Updated minimum session length.
    max_minutes : int
        Updated maximum session length.
    """
    conn = get_conn()
    cur = conn.cursor()
    now = datetime.utcnow().isoformat()
    cur.execute(
        """
        UPDATE coaches
        SET name = ?, tags_json = ?, min_session_minutes = ?, max_session_minutes = ?, updated_at = ?
        WHERE coach_id = ?;
        """,
        (
            name,
            json.dumps([t.strip() for t in tags if t.strip()]),
            min_minutes,
            max_minutes,
            now,
            coach_id,
        ),
    )
    conn.commit()
    conn.close()


def instruction_filepath(coach_id: str) -> str:
    """Return the absolute path for a coach's Markdown instruction file."""
    return os.path.join(INSTR_DIR, f"{coach_id}.md")


def read_instruction(coach_id: str) -> str:
    """Read the instruction Markdown file for a coach.

    Parameters
    ----------
    coach_id : str
        The ID of the coach.

    Returns
    -------
    str
        The contents of the Markdown file or an empty string if the file
        does not exist.
    """
    path = instruction_filepath(coach_id)
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as fh:
            return fh.read()
    return ""


def write_instruction(coach_id: str, markdown_text: str) -> None:
    """Write the instruction Markdown for a coach to disk.

    Leading and trailing whitespace is stripped and a trailing newline
    is ensured. The instruction directory is created on demand.
    """
    os.makedirs(INSTR_DIR, exist_ok=True)
    path = instruction_filepath(coach_id)
    with open(path, "w", encoding="utf-8") as fh:
        text = markdown_text.strip() + "\n"
        fh.write(text)
