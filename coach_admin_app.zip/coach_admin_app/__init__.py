"""Coach admin app package.

This package bundles database helpers, authentication and a
Streamlit interface for managing coaching data. See ``main.py`` for
the Streamlit entry point.
"""