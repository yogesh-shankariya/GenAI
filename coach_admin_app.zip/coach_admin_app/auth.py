"""User authentication and management for the coach admin app.

This module encapsulates the logic around storing and verifying
credentials. It uses the same SQLite database as ``db.py`` (via
importing ``DB_PATH``) and defines a simple ``users`` table. Each
user record stores a username, a salted PBKDF2 hash of the
password, the number of iterations used to derive the hash, and the
role of the user (e.g. ``admin`` or ``client``). The module also
provides convenience functions to seed a few default accounts and to
retrieve user records by username.

Passwords are never stored in plain text and are compared using
``hmac.compare_digest`` to avoid timing attacks.
"""

from __future__ import annotations

import hashlib
import hmac
import os
import sqlite3
from datetime import datetime
from typing import Any, Dict, Optional

from .db import DB_PATH  # Reuse the same database file


def get_conn() -> sqlite3.Connection:
    """Get a new SQLite connection with foreign keys enabled."""
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_user_table() -> None:
    """Create the users table if it does not exist.

    The table has a unique ``username`` column and stores a random salt
    alongside the password hash. The ``role`` column can be used to
    distinguish administrators from regular clients. All timestamps are
    stored in ISO format.
    """
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            salt_hex TEXT NOT NULL,
            hash_hex TEXT NOT NULL,
            iterations INTEGER NOT NULL,
            role TEXT NOT NULL DEFAULT 'client',
            created_at TEXT NOT NULL
        );
        """
    )
    conn.commit()
    conn.close()


def _hash_password(password: str, salt: bytes, iterations: int = 200_000) -> bytes:
    """Derive a PBKDF2 hash for a password using the given salt.

    The number of iterations is fixed to 200k by default to strike a
    balance between security and performance. Adjust this if you need
    stronger or weaker hashing depending on your environment.
    """
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)


def create_password_record(password: str) -> Dict[str, Any]:
    """Create a salted hash record for a given password.

    Returns a dictionary containing the salt (hex), hash (hex) and
    iterations used. The salt is generated randomly for each record.
    """
    salt = os.urandom(16)
    iterations = 200_000
    pw_hash = _hash_password(password, salt, iterations)
    return {
        "salt_hex": salt.hex(),
        "hash_hex": pw_hash.hex(),
        "iterations": iterations,
    }


def verify_password(password: str, salt_hex: str, hash_hex: str, iterations: int) -> bool:
    """Verify a password against a stored hash record.

    Parameters
    ----------
    password : str
        The plain text password to verify.
    salt_hex : str
        The salt used when generating the stored hash, encoded as hex.
    hash_hex : str
        The stored password hash encoded as hex.
    iterations : int
        The number of iterations that were used during hashing.

    Returns
    -------
    bool
        True if the password matches the stored hash, otherwise False.
    """
    salt = bytes.fromhex(salt_hex)
    expected = bytes.fromhex(hash_hex)
    actual = _hash_password(password, salt, iterations)
    return hmac.compare_digest(actual, expected)


def seed_user(username: str, password: str, role: str = "client") -> None:
    """Insert a user into the database if they do not already exist.

    This helper will create a new user with the provided password and
    role. If a user with the same username already exists the
    function silently returns without modifying the record.
    """
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT user_id FROM users WHERE username = ?;", (username,))
    row = cur.fetchone()
    if row:
        conn.close()
        return
    record = create_password_record(password)
    now = datetime.utcnow().isoformat()
    cur.execute(
        """
        INSERT INTO users (username, salt_hex, hash_hex, iterations, role, created_at)
        VALUES (?, ?, ?, ?, ?, ?);
        """,
        (
            username,
            record["salt_hex"],
            record["hash_hex"],
            record["iterations"],
            role,
            now,
        ),
    )
    conn.commit()
    conn.close()


def seed_default_users() -> None:
    """Create default admin and a few sample client accounts.

    These accounts are intended for demonstration and testing. In a
    production environment you'd manage users through your own
    registration or provisioning mechanism.
    """
    # Ensure tables exist before inserting
    init_user_table()
    # Admin user
    seed_user("admin", "Admin@12345", role="admin")
    # Demo clients (optional)
    seed_user("client01", "Client01@123", role="client")
    seed_user("client02", "Client02@123", role="client")
    seed_user("client03", "Client03@123", role="client")
    seed_user("client04", "Client04@123", role="client")
    seed_user("client05", "Client05@123", role="client")
    seed_user("client06", "Client06@123", role="client")
    seed_user("client07", "Client07@123", role="client")
    seed_user("client08", "Client08@123", role="client")
    seed_user("client09", "Client09@123", role="client")
    seed_user("client10", "Client10@123", role="client")


def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    """Retrieve a user record by username.

    Returns
    -------
    dict or None
        A dictionary containing user fields or None if the user does not
        exist.
    """
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        "SELECT user_id, username, salt_hex, hash_hex, iterations, role FROM users WHERE username = ?;",
        (username,),
    )
    row = cur.fetchone()
    conn.close()
    if not row:
        return None
    return {
        "user_id": row[0],
        "username": row[1],
        "salt_hex": row[2],
        "hash_hex": row[3],
        "iterations": row[4],
        "role": row[5],
    }