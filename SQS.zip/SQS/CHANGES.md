# CHANGES.md — Complete Original vs Current Comparison

Date: 2026-07-15 · Companion documents: [REVIEW_FINDINGS.md](REVIEW_FINDINGS.md) (severity-ranked findings), [README.md](README.md) (how to run).

Every change below states **what the original code was, what it is now, and why** — with code excerpts where the difference matters. Changes were driven by an adversarially-verified review (~45 confirmed defects) plus the requirement to ingest ≥100 test messages that the Kubernetes consumer can actually process.

---

## 0. File inventory

| File | Status |
|------|--------|
| `sqs_service/sqs_sevice.py` | **DELETED** (dead duplicate `SQSClient` — see §1.1) |
| `sqs_service/__init__.py` | Rewritten (§1) |
| `sqs_service/_logging.py` | **NEW** (§1.3) |
| `sqs_service/mps_manager.py` | Rewritten (§2) |
| `sqs_service/sqs_idempotent_processor.py` | Rewritten (§3) |
| `sqs_service/sqs_parallel_processor.py` | Rewritten (§4) |
| `main.py` | Rewritten (§5) |
| `constant.py` | Rewritten (§6) |
| `test/message_factory.py` | **NEW** (§7.1) |
| `test/ingest_messages.py` | **NEW** — the 100-message harness (§7.2) |
| `test/conftest.py` | **NEW** (§7.3) |
| `test/test_mps_manager.py` | **NEW** — 12 tests (§7.4) |
| `test/test_sqs_client_moto.py` | **NEW** — 14 tests (§7.4) |
| `test/test_sqs_idempotency.py` | Repaired (§8) |
| `test/purge_queue.py` | Rewritten (§9) |
| `test/test.py` | Safety-gated (§10) |
| `requirements.txt`, `requirements-dev.txt`, `.env.example`, `README.md`, `REVIEW_FINDINGS.md`, `CHANGES.md` | **NEW** (§11) |

---

## 1. Package structure — `sqs_service/__init__.py` + deleted `sqs_sevice.py`

### 1.1 The package could not be imported at all (BLOCKER)

**Original:**
```python
from .sqs_service import SQSClient            # line 1
from .sqs_parallel_processor import ParallelSQSProcessor
from .sqs_idempotent_processor import (
    SQSClient,                                 # silently SHADOWS line 1
    ...
)
```
The file on disk was named **`sqs_sevice.py`** (missing "r"), so line 1 raised `ModuleNotFoundError: No module named 'sqs_service.sqs_service'` — **every** `import sqs_service` failed: `main.py`, all tests, `purge_queue.py`. Nothing in the repo could run anywhere, including the client environment.

Even if the typo were fixed, line 4 re-imported a *different* class also named `SQSClient` from `sqs_idempotent_processor.py`, silently replacing the first. The entire simple client in `sqs_sevice.py` (203 lines) was unreachable dead code.

**Current:** `sqs_sevice.py` deleted; `__init__.py` exports one canonical `SQSClient` (the idempotent one — a strict superset: batch send/delete, purge, attributes, idempotency). Since the shadowing already made this the effective class, **runtime behavior is unchanged** for any code that previously worked.

```python
from .sqs_idempotent_processor import (
    SQSClient, SQSMessage, ProcessingResult, logger,
    MDCContext, MDCMarker, log_lifecycle_marker,
    ProcessingError, ValidationError, ProcessingTimeoutError, PublishError,
)
from .mps_manager import (
    MPSManager, MPSInfo, DuplicateCheckResult, check_duplicate_status, MPSType,
)
from .sqs_parallel_processor import ParallelSQSProcessor, process_messages_parallel
```

### 1.2 `TimeoutError` renamed to `ProcessingTimeoutError`

**Original** exported a custom `TimeoutError`, shadowing Python's builtin for any `from sqs_service import *` consumer. `logger` was also listed twice in `__all__`.
**Current:** `ProcessingTimeoutError` (all imports updated); `__all__` deduplicated; `MPSInfo` and `process_messages_parallel` now exported.

### 1.3 NEW `sqs_service/_logging.py` — logging shim

**Original:** every module did, at import time:
```python
from log_util import logger
logger = logger.setup_logger(config_path="logger_config.yaml")
```
`log_util` and `logger_config.yaml` exist **only in the client environment** → the library was un-importable on any dev machine, so nothing could ever be tested locally.

**Current:** all modules use `from ._logging import get_logger`, which tries `log_util` first and falls back to a plain stdlib logger. **In the client environment behavior is identical** (log_util wins); locally the package imports and logs to stderr.

---

## 2. `sqs_service/mps_manager.py` — the idempotency layer

### 2.1 Marker filename format vs parser vs glob: three mutually incompatible formats (BLOCKER)

This is the reason **idempotency never worked at all** — markers were written but could never be found again.

**Original — write, parse, and search each used a different format:**
```python
SEPARATOR = "__"

# WRITE: wraps every separator in literal '--'
return (f"{trace_id}--{self.SEPARATOR}--"
        f"{queue_name}--{self.SEPARATOR}--"
        f"{mps_type.value}--{self.SEPARATOR}--"
        f"{retry_count}--{self.SEPARATOR}--{ts}")
# produces: T1--__--Q1--__--start--__--0--__--1752561000.123

# PARSE: splits on bare '__'
parts = filename.split(self.SEPARATOR)
# -> ['T1--', '--Q1--', '--start--', '--0--', '--1752561000.123']
# MPSType('--start--') raises ValueError -> parse returns None. ALWAYS.

# SEARCH: glob pattern ends '--__--__*'  (extra separator, no retry/ts slot)
# -> matches NOTHING that WRITE ever produced. ALWAYS empty.
```
Consequences: `has_end_marker()` always `False` → duplicate suppression never engaged; crash takeover never engaged; cleanup could never match files. Every message would be reprocessed on redelivery, silently.

**Current — one canonical format used by write, parse, glob, and the lock file:**
```python
# WRITE
return self.SEPARATOR.join(
    [trace_id, queue_name, mps_type.value, str(retry_count), str(ts)]
)  # -> T1__Q1__start__0__1752561000.123

# PARSE (tolerates queue names that themselves contain '__')
parts = filename.split(self.SEPARATOR)
if len(parts) < 5: return None
trace_id  = parts[0]
queue_name = self.SEPARATOR.join(parts[1:-3])
type_str, retry_str, ts_str = parts[-3:]

# SEARCH
self.SEPARATOR.join([trace_id, queue_name, type_pattern, "*"])
```
Proven by round-trip tests including a queue named `dev__weird__queue`.

### 2.2 `get_start_marker` crashed on every call (BLOCKER)

**Original:**
```python
def get_start_marker(start, trace_id, queue_name):   # first param 'start', not 'self'
    files = self.find_mps_files(...)                  # NameError: 'self' not defined
```
This sits on the exported `check_duplicate_status()` path — every duplicate check would have crashed.
**Current:** `def get_start_marker(self, trace_id, queue_name)`.

### 2.3 `cleanup_old_markers` crashed on every call

**Original:** line 380 was the bare expression `removed` (no `= 0`) → `NameError`; periodic cleanup always crashed and marker storage grew forever.
**Current:** `removed = 0`, and the sweep also removes orphaned lock files (§2.4).

### 2.4 Orphaned lock files deadlocked a message forever (NEW protection)

**Original:** if a pod died between creating the lock file and the `finally` cleanup, the lock remained. Every later `create_start_marker` for that trace_id hit `FileExistsError` → `return False, ""` — no TTL, no sweeper could parse the lock name. One crash at the wrong instant = that message can never be processed again.

**Current:** `LOCK_TIMEOUT_SECONDS = 60`; a lock older than that is treated as an orphan, removed, and creation is retried once. `cleanup_old_markers` also sweeps stale `*__lock` files.

### 2.5 Crashed-pod takeover could never acquire ownership

**Original:** `check_duplicate_status` correctly said "stale START → takeover, reprocess", but `create_start_marker` refused whenever **any** START marker existed — stale or not — so the takeover it promised was impossible. The helper meant to clear stale markers (`cleanup_start_markers`) was never called anywhere.

**Current:** `_live_start_marker_exists()` removes stale START markers (crashed pod) as it checks, so a new pod can take over; fresh markers still block correctly. Covered by `test_stale_start_marker_allows_takeover`.

### 2.6 Smaller fixes
- `import fcntl` removed (unused, POSIX-only).
- `MPSInfo` added to `__all__` (it's returned by public methods).
- Defensive `None` guards where `get_start_marker` could race with a concurrent delete.

---

## 3. `sqs_service/sqs_idempotent_processor.py` — the SQS client

### 3.1 `mark_processing_end` guard was inverted (BLOCKER)

**Original:**
```python
if not self.enable_idempotency or not self.mps_manager:
    return self.mps_manager.create_end_marker(...)   # mps_manager is None here!
# (when idempotency IS enabled: falls through, only logs — never writes END marker)
```
Two failures in one: idempotency **disabled** → `AttributeError` on `None`; idempotency **enabled** → the END marker was **never written**, so `check_duplicates()` could never return `True`. Combined with §2.1, duplicate detection was doubly dead.

**Current:**
```python
if not self.enable_idempotency or not self.mps_manager:
    return
self.mps_manager.create_end_marker(trace_id, self.queue_name, retry_count, success=success)
# ...then logs MESSAGE_SUCCESS/FAILED + MESSAGE_END markers
```
Proven by `test_full_idempotent_lifecycle`: start → second start refused → end → duplicate detected.

### 3.2 `_publish_with_retry` was broken four ways (BLOCKER)

**Original:**
```python
def _publish_with_retry(self, message, trace_id, target_queue_url):
    ...
    self.client.send_message(QueueUrl=self.queue_url, ...)   # (1) target ignored:
                                                             #     publishes back to the SOURCE queue
    logger.info(f"Published ... to {target_queue_name}")     # (2) NameError: undefined
    ...
    time.sleep(retry_delays[attempt])                        # (3) 'from time import time' ->
                                                             #     time is a FUNCTION; AttributeError
    raise PublishError(f"...{self, max_retries + 1}...")     # (4) tuple typo + undefined name
```
**Current:** sends to `target_queue_url or self.queue_url`; logs the real queue URL; uses `sleep(...)`; raises `PublishError(f"...{self.max_retries + 1}...")`; retry-delay index clamped so `max_retries > 2` can't over-index.

### 3.3 `_delete_with_retry` could never delete (BLOCKER)

**Original:** `ReceiptHandle=rreceipt_handle` (double-r typo, undefined) → `NameError` on first use; plus the same `time.sleep` bug in its retry path.
**Current:** `receipt_handle`, `sleep(...)`.

### 3.4 `send_message_batch` — AWS limits and silent failures

**Original:**
```python
entries.append({"Id": msg.get("Id", str(messages.index(msg))), ...})
response = self.client.send_message_batch(QueueUrl=..., Entries=entries)  # ALL entries at once
return response
```
- No chunking: **SQS rejects any batch > 10 entries** (`TooManyEntriesInBatchRequest`) — sending 100 messages would fail wholesale.
- `messages.index(msg)` is O(n²) and returns the *first* matching element → **duplicate Ids** for equal bodies → `BatchEntryIdsNotDistinct` rejection.
- `Failed` entries in the response were returned unexamined — partial failures invisible to callers.
- `_validate_message_size` existed but was never called (dead code).

**Current:** chunks of `MAX_BATCH_ENTRIES = 10`; Ids from `enumerate`; per-message size validation; SQS-reported `Failed` entries **retried once**, then aggregated and logged; returns `{"Successful": [...], "Failed": [...]}` across all chunks. Covered by `test_send_message_batch_chunks_beyond_aws_limit` (100 messages → 10 requests) and a mocked 25-message → 3-request test.

### 3.5 `delete_msg_batch` — same class of problems

**Original:** no `_ensure_queue_url()` call (a client built from `queue_name` crashed with `QueueUrl=None` if this was its first operation); no 10-entry chunking; `Failed` discarded (messages believed deleted would silently redeliver).
**Current:** URL ensured, chunked, `Failed` aggregated + logged with an explicit redelivery warning.

### 3.6 `receive_messages` — three fixes

**Original:**
```python
response = self.client.receive_message(
    QueueUrl=self.queue_url,
    MaxNumberOfMessages=max_messages,          # >10 -> ClientError, no clamp
    WaitTimeSeconds=wait_time_seconds,         # >20 -> ClientError, no clamp
    VisibilityTimeout=visibility_timeout or 300,   # explicit 0 silently becomes 300
    MessageAttributeNames=["All"],             # system attributes NEVER requested
)
```
Because `AttributeNames` was never sent, `ApproximateReceiveCount` was never returned → `SQSMessage.retry_count` was **always 0**, silently defeating any retry-count-based logic.

**Current:** `max_messages` clamped to 1–10, `wait_time_seconds` to 0–20; `VisibilityTimeout=300 if visibility_timeout is None else visibility_timeout` (explicit `0` honored — needed to make a message immediately re-receivable); `AttributeNames=["All"]` added. Covered by `test_receive_clamps_max_messages_to_aws_limit`, `test_visibility_timeout_zero_is_honored`, `test_retry_count_from_system_attributes`.

### 3.7 `SQSMessage.from_sqs_response` — trace_id extraction

**Original:** `body = msg.get("Body", {})` (violates the declared `body: str`); trace_id read only from top-level `trace_id`/`traceId` in the body JSON, then fell straight back to `MessageId`; the `trace_id` **message attribute** — which `send_message_with_idempotency` itself writes — was never read (so a producer-side retry duplicate got a fresh MessageId and was treated as new: exactly the case idempotency exists for); dead line `queue_name = queue_name`.

**Current:** default `""`; lookup order = body top-level → `body["metadata"]["traceId"]` (matches the real message shape) → `MessageAttributes["trace_id"]["StringValue"]` → `MessageId`. Covered by `test_trace_id_falls_back_to_message_attribute`.

### 3.8 Constructor
| Aspect | Original | Current | Why |
|---|---|---|---|
| `queue_name` when built from URL | stayed `None` (the `_extract_queue_name` call was commented out) → MPS markers keyed on the string `"None"` | derived from the URL | correct idempotency keys |
| `region_name` default | hardcoded `"us-east-2"` (and the deleted twin client said `"us-east-1"`) | `None` → boto3 default chain; explicit value wins | one source of truth, no silent cross-region resolution |
| `aws_access_key_id`/`aws_secret_access_key`/`profile_name` | accepted but **silently ignored** — callers passing a dedicated profile actually ran as whatever ambient identity existed | passed into `boto3.Session` | passing credentials must mean using them |
| `enable_idempotency=True` without `mps_storage_path` | silently left `mps_manager=None` → dedup off with **no warning** | `raise ValueError` | fail loud, not silently unsafe |
| `except ImportError` around `MPSManager()` | caught an exception the constructor can never raise; real `OSError`s propagated confusingly | removed — real errors fail fast | honest failure modes |
| validation order | queue check after attribute assignment | `ValueError` raised first | no half-constructed objects |

### 3.9 Error propagation

**Original:** every wrapper did `raise Exception(f"Error ...: {e}")`, destroying `ClientError.response["Error"]["Code"]` — callers could not distinguish retryable throttling from fatal `AccessDenied`, and `purge_queue.py` had to string-match `"PurgeQueueInProgress"` inside the message text.
**Current:** operations log and **re-raise the original `ClientError`**; `purge_queue.py` now branches on the error code properly.

### 3.10 `_format_message_attributes` — bytes were sent illegally

**Original:** `bytes` → `{"DataType": "String", "BinaryValue": ...}` — real SQS rejects a String-typed attribute carrying `BinaryValue` (`InvalidParameterValue`).
**Current:** `bytes` → `{"DataType": "Binary", "BinaryValue": ...}`. Strings/numbers intentionally stay `DataType="String"` to preserve the original wire format for downstream consumers. Covered by `test_message_attributes_roundtrip`.

### 3.11 `log_lifecycle_marker` — ambient context overrode explicit arguments

**Original:** `log_data = {"marker":…, "trace_id": trace_id, …, **context, **extra}` — a leaked thread-local MDC `trace_id` **overwrote** the explicit function argument in the emitted log line (surfaced the moment the tests could actually run).
**Current:** context is spread first; explicit `marker`/`trace_id`/`queue_name` and caller `extra` win.

### 3.12 Misc
- `receive_messages_as_objects(queue_name=...)` parameter removed — it was accepted and **ignored** (messages always came from `self.queue_url`).
- Dead `_get_sqs_client()` helper removed (the idempotent client already held `self.client`; the helper created throwaway un-used clients).
- `_ensure_queue_url()` no longer takes an ignored `client` parameter.
- Class constants added: `MAX_BATCH_ENTRIES = 10`, `MAX_RECEIVE_MESSAGES = 10`, `MAX_WAIT_TIME_SECONDS = 20`.
- Unused imports removed (`ABC/abstractmethod`, `Callable`, …).

---

## 4. `sqs_service/sqs_parallel_processor.py`

### 4.1 The thread path never processed a single message (BLOCKER)

**Original:**
```python
for record in message:                      # 'message' is ONE dict -> iterates its string KEYS
    receipt_handle = record["ReceiptHandle"]  # indexing a str -> TypeError
    body = record.get("Body", "")
    result = self.processing_function(body)
```
Every call raised `TypeError`, was caught, and returned `{"success": False}` — the default parallel mode was 100% failure, silently.

**Current:**
```python
result = self.processing_function(message.get("Body", ""))
if self.delete_on_success and receipt_handle:
    self.client.delete_msg(receipt_handle)
```

### 4.2 Deletes never happened despite `delete_on_success=True`

**Original:** every delete call in all three modes (threads / asyncio / multiprocess) was **commented out** — `_process_message_multiprocess` even constructed an `SQSClient` and then did nothing with it. Every "successfully processed" message redelivered after the visibility timeout → guaranteed duplicate processing.
**Current:** deletes implemented in all three modes; the multiprocess helper now also receives and uses `region_name` (before, a worker-side client silently fell back to a class-default region that could differ from the parent's).

### 4.3 Result-schema and key bugs
| Original | Current | Why |
|---|---|---|
| empty-queue path returned `{"succesful": []}` (typo) in 2 of 3 modes | `"successful"` everywhere | callers doing `results["successful"]` got `KeyError` on any empty poll |
| async/multiprocess failures used key `"result"`, threads used `"error"` | uniform `{"success", "message_id", "error"/"result"}` | downstream failure handling keyed on one name |
| async `except` logged undefined `message_id` (its assignment was commented out) → `NameError` **inside** the error handler | `message_id` captured up front | error handling must not throw |
| logs like `f"Processed message "` (empty placeholder) | include `message_id` | traceability |

### 4.4 Concurrency & imports
- asyncio mode ran `asyncio.gather` **unbounded** while logging "with {max_workers} processes" — now bounded by `asyncio.Semaphore(max_workers)` with an accurate log line.
- `from sqs_service import SQSClient` (an absolute import of the package **mid-initialization** — worked only by accident of import ordering) → relative `from .sqs_idempotent_processor import SQSClient`.
- Dead imports/vars removed: `sys`, `pathlib`, `importlib`, `functools.partial`, `PROJECT_DIR`, unused `results =` assignment.

---

## 5. `main.py` — the Kubernetes consumer

### 5.1 The production branch was unreachable (BLOCKER)

**Original:**
```python
MODE = "TEST"                        # hardcoded at module level
TESTQUEUE = "dev-HOSSYTH_rallm"      # hardcoded dev queue
```
As shipped, the pod would **always** run the TEST path (generate one message, post it, poll forever). And even the non-TEST branch consumed `TESTQUEUE` with hardcoded `"us-east-2"`, not the configured input queue — while *logging* `Constant.SQS_INPUT_QUEUE_NAME`, making the misdirection invisible in logs.

**Current:**
```python
MODE = os.environ.get("MODE", "PROD")
TESTQUEUE = os.environ.get("SQS_TEST_QUEUE_NAME", "dev-HOSSYTH_rallm")
...
input_client = SQSClient(queue_name=Constant.SQS_INPUT_QUEUE_NAME,
                         region_name=Constant.SQS_AWS_REGION)
```

### 5.2 Queue NAMES were passed as URLs (BLOCKER)

**Original:**
```python
output_client = SQSClient(queue_url=Constant.SQS_OUTPUT_QUEUE_NAME, ...)  # env var holds a NAME
# and in post_message_to_SQS_test:
test_output_client = SQSClient(queue_url=queue_name, region_name="us-east-2")
```
boto3 requires a real URL in `QueueUrl` — every downstream post and every test post would fail. The failure was then swallowed by §5.6.
**Current:** `queue_name=` everywhere; regions come from `Constant.SQS_AWS_REGION` (the old code used `Constant.AWS_REGION`, which is optional and could be `None` → `NoRegionError` at import).

### 5.3 Producer/consumer message-contract mismatch (BLOCKER — would have failed all 100 test messages)

**Original test-message generator:**
```python
full_message_dict = {
    "message": f"Message Body : {message_body_str}",   # lowercase key, NOT valid JSON value
    ...
}
# metadata contained: rawFileLocation, EDL_TNNT_ID, EDL_CLNT_ID ... 
# but NOT: file_path, RA_MNEMONIC, TNNT_ID, CLNT_ID
```
**The consumer reads:**
```python
data = json.loads(body["Message"]) if "Message" in body else body   # capital-M "Message"
s3_key      = data["metadata"]["file_path"]      # KeyError with old generator
ra_mnemonic = data["metadata"]["RA_MNEMONIC"]    # KeyError
...          data["metadata"]["TNNT_ID"]         # KeyError
...          data["metadata"]["CLNT_ID"]         # KeyError
```
Every generated message would have crashed the k8s consumer with `KeyError` — the 100-message test would have shown 100 failures that look like pipeline bugs.

**Current:** `main.generate_full_message()` and the ingest harness both use **`test/message_factory.build_message()`** (§7.1) — the body is sent as plain JSON (taking the consumer's `else body` path) and contains *every* key the consumer reads. The factory's `extract_consumer_fields()` mirrors the consumer's key accesses, and tests assert 100/100 messages pass it.

### 5.4 Messages were deleted even when processing failed (BLOCKER — data loss)

**Original:**
```python
process_sqs_message(message)          # swallows ALL exceptions, returns None
input_client.delete_msg(receipt_handle)   # unconditional delete
```
At-most-once semantics: any failed document was **permanently lost** — no retry, no error queue (the required `SQS_ERROR_QUEUE_NAME` env var was used **nowhere** in the code).

**Current:** `process_sqs_message` returns `True/False`; the loop deletes **only on success**; on failure `_route_to_error_queue()` posts the original body to `SQS_ERROR_QUEUE_NAME` and *then* deletes (poison messages can't loop forever); if the error post itself fails, the message is left for redelivery after the visibility timeout.

### 5.5 The consumer loop died on any transient error

**Original:** the `while True` had **no** try/except — one network blip in `receive_messages()` propagated out of `main()` and killed the pod. It also polled with defaults (`max_messages=1`, `wait_time_seconds=0`) + `sleep(5)`: max ~0.2 msg/s and busy-polling.
**Current:** loop body wrapped in try/except (`sleep(5)` back-off, `KeyboardInterrupt` exits cleanly); long polling `max_messages=10, wait_time_seconds=20`.

### 5.6 `process_sqs_message` internals
| Original | Current | Why |
|---|---|---|
| outer `except` referenced `context_map` — undefined if the failure happened before it was built → `NameError` **inside the error handler**, crashing the loop | `context_map = None` up front; the Kafka FAIL log only fires `if context_map is not None` | error handlers must not throw |
| `QUEUE_PATH = ctx["queuePath"].append(...)` → `append` returns `None`; outgoing `metadata.queuePath` serialized as `null` | `queue_path = list(ctx["queuePath"] or []); queue_path.append(...)` | downstream services receive the real path |
| `ctx["RA_MNEMONIC"] = metadata_dict["sourceType"]` (wrong field) | `= metadata_dict["RA_MNEMONIC"]` | correct value propagated |
| `ctx["xrequestID"] = "dbc3650aa9f6e3a89370e91e68a197fa"` (hardcoded hex, dead) | removed — the real id flows via `ctx["X-REQUEST-ID"]` from the message | no fake ids in logs |
| `logger.info("Error : {e} ...")` — missing `f` prefix, logs the literal `{e}` at INFO | `logger.error(f"...{e}...")` + re-raise in `post_message_to_SQS_test` | real errors, visible |
| status≠200 path had `# To do: post to SQS error queue` | failure path returns `False` → loop routes to the error queue | TODO implemented |

### 5.7 Branch handling in `main()`
| Original | Current |
|---|---|
| KAFKA branch used `KafkaProcessor` whose import was commented out → `NameError` at startup | `try: from pykafka import KafkaProcessor / except ImportError: raise RuntimeError("INPUT_QUEUE_TYPE=KAFKA but pykafka is unavailable")` — works in the client env if pykafka exists, fails with a *clear* message otherwise |
| unknown `INPUT_QUEUE_TYPE` (e.g. `"sqs "` with a space) → logs one line, **exits 0** — looks like a clean exit to Kubernetes | `logger.error(...)` + `sys.exit(1)` |
| `from marshmallow.fields import Constant` — immediately shadowed by `from constant import Constant`; a confusing dead import adding a spurious hard dependency | removed |

### 5.8 `poll_from_sqs` (TEST-mode poller)
Long polling (`max_messages=10, wait_time_seconds=10`) instead of default short-poll; the artificial `sleep(5)` per message removed; unparseable (JSON-decode-error) messages are now routed to the error queue and deleted instead of redelivering every 300 s forever.

---

## 6. `constant.py`

**Original:** importing the module **required ~15 unrelated env vars** or crashed:
```python
S3_FETCH_FILE_URL = os.environ['S3_FETCH_FILE_URL']            # KeyError if unset
KAFKA_BROKER = os.environ.get("KAFKA_BROKER").split(",")       # AttributeError on None
KERBEROS_RENEWAL_INTERVAL = int(os.environ.get("KERBEROS_RENEWAL_INTERVAL"))  # TypeError on None
SQS_TEST_MSG_TO_SPAWN = os.environ.get("SQS_TEST_MSG_TO_SPAWN", 10000)  # str when set, int when not
```
So pure SQS testing couldn't even import the constants module without a full Kafka/S3/OCR configuration.

**Current:**
- Kafka/S3/OCR vars are optional (`os.environ.get(...)` with safe defaults; `KAFKA_BROKER` guarded with `or ""` before `.split`; `KERBEROS_RENEWAL_INTERVAL` defaults to 3600).
- SQS vars remain **required** but go through `_require_env()`, which raises `EnvironmentError("Required environment variable SQS_... is not set (see .env.example)")` instead of a bare `KeyError`.
- `SQS_TEST_MSG_TO_SPAWN` is always `int` (default **100**, matching the task).

---

## 7. New files — the 100-message ingestion capability

### 7.1 `test/message_factory.py` — single source of truth for the message contract
`build_message(trace_id, s3_key, ra_mnemonic, tnnt_id, clnt_id, ...)` produces the exact body `main.process_sqs_message` parses; `extract_consumer_fields(body)` re-performs the consumer's key accesses and raises `KeyError` on any drift. Used by `main.py`, the ingest harness, and the tests — the contract can no longer silently fork (the moto test `test_ingest_100_contract_valid_messages` catches drift in CI).

### 7.2 `test/ingest_messages.py` — the harness for the manager's task
- `--count` (default `SQS_TEST_MSG_TO_SPAWN` or 100), `--queue`, `--region`, `--s3-key/--ra-mnemonic/--tnnt-id/--clnt-id`.
- Sends in batches of 10 with unique trace_ids; SQS-reported failures retried; progress + throughput printed.
- Verifies queue depth via `ApproximateNumberOfMessages(+NotVisible)`.
- Writes `test/reports/ingest_report_<ts>.json` with **all trace_ids** (correlate with k8s logs/Datadog) and a PASS/FAIL result; exit code follows.
- **`--mode mock` (default):** forces fake AWS credentials into the environment *before any boto3 session exists*, creates the queue in in-process moto, sends 100, then **drains them back and validates every payload with `extract_consumer_fields`** — local proof the k8s consumer can parse them. Zero real AWS traffic is possible.
- **`--mode live`:** refuses to run unless **both** `RUN_LIVE=1` and `--yes-live` are given. This is the mode the team runs from the client environment.

Verified run: `--mode mock --count 100` → **PASS — 100 sent, 100 drained, 100 contract-valid**.

### 7.3 `test/conftest.py`
Forces fake AWS credentials (`AWS_ACCESS_KEY_ID=testing`, …, removes `AWS_PROFILE`) for the entire pytest session and puts the repo root on `sys.path`; sets default SQS env vars so `constant.py` imports during collection. **No test can ever authenticate against real AWS.**

### 7.4 New test suites (all local, moto-backed, no AWS)
- `test/test_mps_manager.py` (12 tests): filename build/parse round-trip (incl. `__` in queue names), END-marker detection, start-marker atomicity, stale-marker takeover, orphaned-lock TTL, fresh-lock blocking, old-marker + stale-lock cleanup, all four `check_duplicate_status` scenarios.
- `test/test_sqs_client_moto.py` (14 tests): send/receive/delete round-trip; **100-message batch chunking**; 25-handle delete chunking; receive clamping; attribute round-trip incl. bytes→Binary; `retry_count` from `ApproximateReceiveCount`; trace_id fallback to message attribute; 256 KB size validation; `visibility_timeout=0` honored; queue-name derivation from URL; idempotency `ValueError` guard; **full idempotent lifecycle**; purge; and the end-to-end **100-message contract test**.

---

## 8. `test/test_sqs_idempotency.py` (repaired, structure preserved)

| # | Original | Current |
|---|---|---|
| 1 | `sleep(400)` called with only `import time` present → `NameError`, silently swallowed per message; if "fixed" naively, 400 s × 100 messages ≈ 11 hours | `SQS_TEST_PROCESSING_LAG` env (default 0) |
| 2 | `message = client.receive_messages(...)` then `if messages:` (different, undefined name) → `NameError` | fixed |
| 3 | `rate = ... else o` — undefined name `o` (typo for `0`) | fixed |
| 4 | `except ClientError` with `ClientError` never imported | imported (and the dead `_get_queue_url`/`_get_sqs_client` helpers removed) |
| 5 | "10K messages" test hardcoded `total_messages = 10`; `Constant.SQS_TEST_MSG_TO_SPAWN` imported but unused | volume = `SQS_TEST_MSG_TO_SPAWN` |
| 6 | batch entries used duplicate Ids (`"0"`, `"0"`) — real SQS rejects with `BatchEntryIdsNotDistinct` (only passed because boto3 was mocked) | unique Ids |
| 7 | integration tests + cleanup ran **unconditionally against the real shared dev queue** (destructive receive+delete loops) | both live classes gated: `@unittest.skipUnless(RUN_LIVE, ...)` → skip locally |
| 8 | `_cleanup_mps_files` did `shutil.rmtree` on `SQS_MPS_PATH` — default **`/data/main_resources/runtime_files_space`**, a shared system path | MPS path is a `tempfile.mkdtemp()` per run |
| 9 | drain loops stopped at the **first empty receive** — in-flight (invisible) messages reappeared minutes later and polluted the next run | drain continues until `ApproximateNumberOfMessages` **and** `...NotVisible` are both 0 |
| 10 | `from log_util.logger import setup_logger` (client-env-only) → un-importable locally | `sqs_service._logging.get_logger()` |
| 11 | patched `sqs_service.logger` — which is **not** the name `log_lifecycle_marker` actually uses, so the mock never intercepted (latent test bug) | patches `sqs_service.sqs_idempotent_processor.logger` |
| 12 | messages built from a local copy of the (contract-violating) generator | built via `message_factory.build_message` |
| 13 | `TimeoutError` import; `receive_messages_as_objects(queue_name=...)` | `ProcessingTimeoutError`; updated signature |
| 14 | MDC context leaked between test classes (marker test failed once runnable) | `TestMDCMarker.setUp` clears context |
| — | new test added | 25-message batch → asserts exactly 3 chunked requests, each ≤ 10 entries |

## 9. `test/purge_queue.py`

**Original:** purged `dev-HOSSYTH_rallm` **unconditionally** (`main()` defined a `queue_name` variable and then ignored it, passing the literal again); printed "Queue purged" immediately although AWS purges are async (≤ 60 s, and messages sent during the window may also be deleted — running it right before an ingest could silently eat part of the 100); detected the purge-cooldown case by string-matching the exception text.

**Current:** gated behind `RUN_LIVE=1`; queue/region from argv or env; branches on `e.response["Error"]["Code"] == "AWS.SimpleQueueService.PurgeQueueInProgress"`; polls queue attributes (visible + not-visible + delayed) until 0; prints an explicit warning about the 60 s purge window before returning.

## 10. `test/test.py`

**Original:** uploaded a local PDF to the client **PHI S3 bucket at module import time** (the upload ran before the `if __name__ == "__main__"` guard — merely importing/collecting the file triggered a real AWS write). It also called `run_pipeline_in_process(s3_key, trace_id, ra_mnemonic)` — but that function requires six arguments → `TypeError` even if it got that far.

**Current:** all side effects moved inside `main()`, gated behind `RUN_LIVE=1`, input-file existence checked, and the pipeline call passes all required arguments.

## 11. New project scaffolding

- **`requirements.txt`** (`boto3`, `python-dotenv`) / **`requirements-dev.txt`** (+ `moto`, `pytest`) — there was previously no dependency manifest at all.
- **`.env.example`** — documents required (SQS) vs optional (Kafka/S3/OCR) configuration; the repo previously required undocumented env vars to even import.
- **`README.md`** — layout, local setup, the exact 100-message commands for mock and client-env runs, consumer configuration table, failure semantics, contract-maintenance rule.
- **`REVIEW_FINDINGS.md`** — severity-ranked findings table + the four open architecture decisions (DLQ/redrive, visibility-timeout heartbeat, DynamoDB dedup vs shared-volume MPS, Standard-vs-FIFO confirmation).

---

## 12. Verification evidence (all local, zero real AWS calls)

```
$ python -c "import sqs_service"          # previously: ModuleNotFoundError
import OK

$ pytest test/
39 passed, 7 skipped (skips = live-queue tests, correctly gated)

$ python test/ingest_messages.py --mode mock --count 100
  sent 100/100
  queue depth: 100 visible, 0 in flight
  drained 100, contract-valid 100, missing 0
Result: PASS - sent 100/100, failed 0
```

## 13. Intentionally NOT changed

- **Numeric message attributes stay `DataType="String"`** — preserves the original wire format for existing downstream consumers (only the genuinely illegal bytes case was fixed).
- **Kafka pipeline internals** (`pykafka` lives only in the client env) — guarded with a clear error instead of a `NameError`.
- **`doc_extract_app` pipeline** — client-environment code, out of scope.
- **Queue infrastructure** (DLQ/RedrivePolicy, FIFO confirmation, visibility-timeout sizing, DynamoDB-based dedup) — documented as team decisions in REVIEW_FINDINGS.md §3; they require client AWS access or architecture sign-off and were not changed silently.
- **`main.py`'s client-env imports** (`schema`, `log_util`, `ddtrace`, `doc_extract_app`) — untouched; `main.py` still runs only on the cluster. One review note for deployment: it now also imports `test.message_factory`, which works when the repo root is on `sys.path` (already true wherever `doc_extract_app` imports resolve).
