# SQS Repo — Production-Readiness Review Findings

Date: 2026-07-15. Every finding below was confirmed by an adversarial
multi-agent verification pass (per-file verifiers + completeness critic)
before being fixed. Severity: **blocker** = crashes or silently corrupts
the main path; **major** = wrong behavior on common paths; **minor** =
robustness/log quality.

Legend: ✅ fixed in this change · 📋 documented decision for the team
(needs client AWS access or an architecture call — intentionally not
changed silently).

## 1. Blockers (would have failed the 100-message test outright)

| # | Where | Defect | Status |
|---|-------|--------|--------|
| 1 | `sqs_service/__init__.py` | Imported `.sqs_service` but the file was named `sqs_sevice.py` (typo) → `ModuleNotFoundError`: **nothing in the repo could be imported at all** (main.py, all tests, purge_queue). | ✅ dead duplicate client removed; package exports the canonical `SQSClient` |
| 2 | producer ↔ consumer | Message contract mismatch: `process_sqs_message` requires `metadata.file_path`, `RA_MNEMONIC`, `TNNT_ID`, `CLNT_ID` and parses `body["Message"]`; the old generators produced none of these and wrapped the body as non-JSON `"Message Body : {...}"` under lowercase `"message"`. **Every generated message would KeyError on the k8s consumer.** | ✅ shared `test/message_factory.py` is now the single source of truth; validated by tests + mock ingest |
| 3 | `mps_manager.py` | Marker filenames written as `{t}--__--{q}--__--…` but parsed by splitting on `__` and globbed with a pattern that could never match → **markers written were never found again; idempotency/duplicate suppression never worked at all**. | ✅ one canonical format `{trace}__{queue}__{type}__{retry}__{ts}` everywhere; round-trip tested |
| 4 | `sqs_idempotent_processor.py` `mark_processing_end` | Guard inverted: with idempotency **enabled** it never wrote the END marker (dedup never engages); with it disabled it dereferenced `None`. | ✅ un-inverted; lifecycle test proves duplicate detection fires |
| 5 | `mps_manager.py` `get_start_marker` | First parameter named `start` instead of `self`, body used `self` → `NameError` on every duplicate check. | ✅ |
| 6 | `sqs_idempotent_processor.py` retry helpers | `_publish_with_retry`: undefined `target_queue_name`, ignored `target_queue_url` (published back to the **source** queue), `time.sleep` on a function object, `f"{self, max_retries+1}"` NameError. `_delete_with_retry`: undefined `rreceipt_handle` → could never delete. | ✅ all four |
| 7 | `sqs_parallel_processor.py` `_process_single_message` | `for record in message:` iterated dict **keys** then indexed a string → `TypeError`; thread path never processed anything. | ✅ |
| 8 | `main.py` | `MODE="TEST"` hardcoded → the production consumer branch was unreachable as shipped; non-TEST branch also consumed the hardcoded dev queue instead of `SQS_INPUT_QUEUE_NAME`. | ✅ `MODE` env (default `PROD`), queue from config |
| 9 | `main.py` | `output_client` built with `queue_url=<queue NAME>` → every downstream post would fail. Same in `post_message_to_SQS_test`. | ✅ `queue_name=` everywhere; region from `SQS_AWS_REGION` |
| 10 | `main.py` | Messages deleted unconditionally after `process_sqs_message`, which swallowed all failures → **failed messages permanently lost** (at-most-once). | ✅ returns success; delete only on success, failures routed to `SQS_ERROR_QUEUE_NAME` then deleted (poison-message escape) |
| 11 | `main.py` outer `except` | Referenced `context_map` before assignment → `NameError` inside the error handler crashed the consumer loop. | ✅ initialized + guarded |
| 12 | `main.py` | `QUEUE_PATH = ctx["queuePath"].append(...)` → `append` returns `None`; outgoing `queuePath` serialized as `null`. | ✅ |
| 13 | `constant.py` | Required Kafka/S3/OCR env vars at import (`os.environ[...]`, `.get().split()`, `int(.get())` with no default) → importing crashed for SQS-only use. | ✅ non-SQS vars optional with safe defaults; SQS vars still required with a clear error |
| 14 | `test/test_sqs_idempotency.py` | `sleep` not imported (`NameError` swallowed per message), `message`/`messages` typo, `else o` typo, `ClientError` never imported, `sleep(400)`/message (~11 h for 100 msgs), "10K" test hardcoded to 10 messages. | ✅ all fixed; volume wired to `SQS_TEST_MSG_TO_SPAWN` |

## 2. Major (wrong behavior in production)

| # | Where | Defect | Status |
|---|-------|--------|--------|
| 15 | `send_message_batch` / `delete_msg_batch` | No chunking to the AWS 10-entry limit (>10 → whole request rejected); `Failed` entries silently discarded; `messages.index()` produced duplicate ids. | ✅ chunked, unique ids, `Failed` surfaced + retried once |
| 16 | `receive_messages` | `max_messages`/`wait_time_seconds` not clamped to AWS limits (10/20); system attributes never requested → `retry_count` always 0; explicit `visibility_timeout=0` silently replaced by 300. | ✅ all three |
| 17 | idempotency keying | Producer wrote `trace_id` to MessageAttributes but the consumer never read it (fell back to MessageId → producer-retry duplicates undetected); client constructed from URL had `queue_name=None` → markers keyed on `None`. | ✅ attribute fallback added; queue name derived from URL |
| 18 | constructor | `aws_access_key_id`/`profile_name` accepted but silently ignored → could run as the wrong AWS identity; `enable_idempotency=True` without a storage path silently disabled dedup. | ✅ honored / hard `ValueError` |
| 19 | `mps_manager.py` | Orphaned lock file (pod crash mid-create) blocked that message **forever**; stale START markers blocked the documented crashed-pod takeover; `cleanup_old_markers` crashed (`removed` uninitialized) and could never remove unparseable files. | ✅ lock TTL, stale-marker takeover, cleanup fixed + sweeps locks |
| 20 | `sqs_parallel_processor.py` | All deletes commented out (guaranteed redelivery); `"succesful"` key typo on empty path (caller `KeyError`); `message_id` NameError in async error handler; failure-record schema differed per mode; asyncio ignored `max_workers`. | ✅ all |
| 21 | `main.py` consumer loop | No exception handling → one transient AWS error killed the pod; short-poll busy loop (no long polling). | ✅ try/except + `wait_time_seconds=20`, `max_messages=10` |
| 22 | `main.py` | KAFKA branch used `KafkaProcessor` whose import was commented out (`NameError`); unknown `INPUT_QUEUE_TYPE` exited 0 silently; `ctx["RA_MNEMONIC"]` filled from `sourceType`. | ✅ guarded import with clear error / `sys.exit(1)` / fixed |
| 23 | `test/test.py` | Uploaded a file to the client **PHI S3 bucket at import time**. | ✅ gated behind `__main__` + `RUN_LIVE=1` |
| 24 | tests | Integration tests + `purge_queue.py` ran destructive operations on the real shared dev queue unconditionally; drain loops stopped at first empty receive (in-flight messages leak into the next run). | ✅ `RUN_LIVE=1` gates; drains check queue attributes |
| 25 | error propagation | `ClientError` re-wrapped as bare `Exception(str)` → callers couldn't branch on error codes (purge script string-matched message text). | ✅ original `ClientError` propagates; purge script branches on code |
| 26 | `log_lifecycle_marker` | Ambient MDC context overrode the explicit `trace_id`/`queue_name` arguments in log output. | ✅ explicit args take precedence |

## 3. Architecture decisions for the team 📋 (not silently changed)

These need client AWS access or a design call. They matter **after** the
100-message ingest, when real traffic flows:

1. **No DLQ / redrive policy anywhere.** The consumer now routes
   failures to `SQS_ERROR_QUEUE_NAME` (previously required-but-unused),
   but the queues themselves should get an AWS RedrivePolicy
   (`maxReceiveCount` 3–5) as defense in depth. Needs infra access.
2. **Visibility timeout vs processing time.** Receives default to 300 s
   visibility while doc-extract/OCR can run for minutes. There is no
   `ChangeMessageVisibility` heartbeat, so a slow message redelivers
   mid-processing and only MPS dedup prevents double work. Recommend:
   size the timeout to worst-case processing + margin, or add a
   heartbeat thread.
3. **MPS markers live on a local filesystem path.** Cross-pod dedup
   only works if every pod mounts the same shared volume, and state is
   lost on volume loss. The standard AWS pattern is DynamoDB conditional
   writes. Recommend for production hardening; verify the k8s volume is
   actually shared (`SQS_MPS_PATH`) in the meantime.
4. **Standard vs FIFO queues unconfirmed.** No send path sets
   `MessageGroupId`, so the library only works with Standard queues
   (at-least-once, unordered). If any prod queue is `.fifo`, sends will
   fail — confirm queue types with the client.
5. **Purge window.** `PurgeQueue` deletes messages sent up to 60 s after
   the call. The purge script now waits and warns, but never purge
   immediately before ingesting.

## 4. How this was verified

- 39 unit/integration tests pass locally against **moto** (in-process
  fake SQS; fake credentials forced — zero real AWS calls). 7 live-queue
  tests correctly skip without `RUN_LIVE=1`.
- `python test/ingest_messages.py --mode mock --count 100` →
  **PASS: 100 sent, 100 drained, 100 contract-valid**, report JSON with
  all trace_ids written.
- Every changed file AST-parses; `import sqs_service` succeeds locally.

## 5. Running the 100-message test in the client environment

See README.md. Short version:

```bash
RUN_LIVE=1 python test/ingest_messages.py --mode live --count 100 \
    --queue dev-HOSSYTH_rallm --region us-east-2 --yes-live \
    --s3-key <s3 key of a real test PDF>
```

Then correlate the trace_ids from the generated
`test/reports/ingest_report_*.json` with the k8s consumer logs/Datadog.
Note: without a real `--s3-key`, messages will parse correctly but the
doc-extract pipeline will fail at the S3 download step — that exercises
the error-queue path, not the happy path.
