"""
Unit tests for the MPS (Message Processing State) idempotency layer.

Pure filesystem tests - no AWS, no mocks needed.
"""

import os
import time
import uuid

import pytest

from sqs_service.mps_manager import (
    MPSManager,
    MPSType,
    check_duplicate_status,
)


QUEUE = "dev-HOSSYTH_rallm"


@pytest.fixture
def manager(tmp_path):
    return MPSManager(storage_path=str(tmp_path))


def test_build_and_parse_roundtrip(manager):
    trace_id = str(uuid.uuid4())
    ts = time.time()

    filename = manager._build_filename(
        trace_id, QUEUE, MPSType.START, 2, ts
    )
    info = manager._parse_filename(filename)

    assert info is not None
    assert info.trace_id == trace_id
    assert info.queue_name == QUEUE
    assert info.mps_type == MPSType.START
    assert info.retry_count == 2
    assert info.timestamp == pytest.approx(ts)


def test_parse_queue_name_containing_separator(manager):
    trace_id = str(uuid.uuid4())
    queue = "dev__weird__queue"

    filename = manager._build_filename(
        trace_id, queue, MPSType.END, 0, time.time()
    )
    info = manager._parse_filename(filename)

    assert info is not None
    assert info.queue_name == queue


def test_end_marker_detected(manager):
    trace_id = str(uuid.uuid4())

    assert not manager.has_end_marker(trace_id, QUEUE)

    manager.create_end_marker(trace_id, QUEUE, success=True)

    assert manager.has_end_marker(trace_id, QUEUE)


def test_start_marker_created_and_found(manager):
    trace_id = str(uuid.uuid4())

    created, filepath = manager.create_start_marker(trace_id, QUEUE)

    assert created
    assert os.path.exists(filepath)

    marker = manager.get_start_marker(trace_id, QUEUE)

    assert marker is not None
    assert marker.trace_id == trace_id


def test_second_start_marker_refused(manager):
    trace_id = str(uuid.uuid4())

    created_first, _ = manager.create_start_marker(trace_id, QUEUE)
    created_second, _ = manager.create_start_marker(trace_id, QUEUE)

    assert created_first
    assert not created_second


def test_stale_start_marker_allows_takeover(tmp_path):
    # 0-second timeout: every START marker is immediately stale
    manager = MPSManager(storage_path=str(tmp_path), timeout_seconds=0)
    trace_id = str(uuid.uuid4())

    created_first, _ = manager.create_start_marker(trace_id, QUEUE)
    assert created_first

    # Crashed-pod takeover: stale marker must not block a new owner
    created_second, _ = manager.create_start_marker(trace_id, QUEUE)
    assert created_second


def test_orphaned_lock_does_not_block_forever(manager, tmp_path):
    trace_id = str(uuid.uuid4())

    # Simulate a pod that died between lock creation and cleanup
    lock_path = manager._lock_filepath(trace_id, QUEUE)
    lock_path.touch()
    old = time.time() - manager.LOCK_TIMEOUT_SECONDS - 10
    os.utime(lock_path, (old, old))

    created, _ = manager.create_start_marker(trace_id, QUEUE)

    assert created


def test_fresh_lock_blocks_concurrent_creation(manager):
    trace_id = str(uuid.uuid4())

    lock_path = manager._lock_filepath(trace_id, QUEUE)
    lock_path.touch()  # another pod holds a fresh lock

    created, _ = manager.create_start_marker(trace_id, QUEUE)

    assert not created


def test_cleanup_old_markers(manager):
    trace_id = str(uuid.uuid4())

    old_ts = time.time() - 8 * 24 * 60 * 60  # 8 days old
    old_file = manager.storage_path / manager._build_filename(
        trace_id, QUEUE, MPSType.END, 0, old_ts
    )
    old_file.write_text("success")

    fresh_trace = str(uuid.uuid4())
    manager.create_end_marker(fresh_trace, QUEUE)

    removed = manager.cleanup_old_markers()

    assert removed == 1
    assert not old_file.exists()
    assert manager.has_end_marker(fresh_trace, QUEUE)


def test_cleanup_old_markers_sweeps_stale_locks(manager):
    trace_id = str(uuid.uuid4())

    lock_path = manager._lock_filepath(trace_id, QUEUE)
    lock_path.touch()
    old = time.time() - manager.LOCK_TIMEOUT_SECONDS - 10
    os.utime(lock_path, (old, old))

    removed = manager.cleanup_old_markers()

    assert removed == 1
    assert not lock_path.exists()


def test_check_duplicate_status_scenarios(tmp_path):
    manager = MPSManager(storage_path=str(tmp_path))
    trace_id = str(uuid.uuid4())

    # Scenario D: no markers -> process
    result = check_duplicate_status(manager, trace_id, QUEUE)
    assert result.should_process
    assert not result.is_takeover

    # Scenario B: live START -> skip
    manager.create_start_marker(trace_id, QUEUE)
    result = check_duplicate_status(manager, trace_id, QUEUE)
    assert not result.should_process

    # Scenario A: END exists -> skip
    manager.create_end_marker(trace_id, QUEUE)
    result = check_duplicate_status(manager, trace_id, QUEUE)
    assert not result.should_process
    assert "MPS_END" in result.reason


def test_check_duplicate_status_stale_start_is_takeover(tmp_path):
    manager = MPSManager(storage_path=str(tmp_path), timeout_seconds=0)
    trace_id = str(uuid.uuid4())

    manager.create_start_marker(trace_id, QUEUE)

    result = check_duplicate_status(manager, trace_id, QUEUE)

    assert result.should_process
    assert result.is_takeover
