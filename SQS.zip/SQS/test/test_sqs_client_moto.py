"""
SQSClient integration tests against moto (in-process fake SQS).

No AWS calls leave the machine: conftest.py forces fake credentials
and every test runs inside mock_aws().
"""

import json
import uuid

import boto3
import pytest
from moto import mock_aws

from sqs_service import SQSClient, ValidationError
from test.message_factory import (
    build_message,
    extract_consumer_fields,
)


REGION = "us-east-2"
QUEUE = "dev-HOSSYTH_rallm"


@pytest.fixture
def sqs_client():
    with mock_aws():
        boto3.client("sqs", region_name=REGION).create_queue(
            QueueName=QUEUE
        )
        yield SQSClient(queue_name=QUEUE, region_name=REGION)


def _drain(client, expected, max_polls=50):
    messages = []

    for _ in range(max_polls):
        batch = client.receive_messages(max_messages=10)

        if not batch:
            if len(messages) >= expected:
                break
            continue

        messages.extend(batch)

    return messages


def test_send_and_receive_roundtrip(sqs_client):
    body = {"data": "roundtrip", "trace_id": str(uuid.uuid4())}

    response = sqs_client.send_message(body)
    assert "MessageId" in response

    messages = sqs_client.receive_messages(max_messages=1)

    assert len(messages) == 1
    assert json.loads(messages[0]["Body"]) == body

    sqs_client.delete_msg(messages[0]["ReceiptHandle"])
    assert sqs_client.receive_messages(max_messages=1) == []


def test_send_message_batch_chunks_beyond_aws_limit(sqs_client):
    # 100 messages in one call: must be split into 10-entry chunks
    messages = [
        {"MessageBody": {"index": i}} for i in range(100)
    ]

    response = sqs_client.send_message_batch(messages)

    assert len(response["Successful"]) == 100
    assert response["Failed"] == []

    attrs = sqs_client.get_queue_attributes(
        ["ApproximateNumberOfMessages"]
    )
    assert int(attrs["ApproximateNumberOfMessages"]) == 100


def test_delete_msg_batch_chunks_beyond_aws_limit(sqs_client):
    sqs_client.send_message_batch(
        [{"MessageBody": {"index": i}} for i in range(25)]
    )

    handles = [
        m["ReceiptHandle"] for m in _drain(sqs_client, expected=25)
    ]
    assert len(handles) == 25

    response = sqs_client.delete_msg_batch(handles)

    assert len(response["Successful"]) == 25
    assert response["Failed"] == []


def test_receive_clamps_max_messages_to_aws_limit(sqs_client):
    sqs_client.send_message_batch(
        [{"MessageBody": {"index": i}} for i in range(15)]
    )

    # 100 > AWS limit of 10: must be clamped, not raise
    messages = sqs_client.receive_messages(max_messages=100)

    assert 1 <= len(messages) <= 10


def test_message_attributes_roundtrip(sqs_client):
    attributes = {
        "trace_id": str(uuid.uuid4()),
        "priority": 1,
        "payload": b"binary-data",
    }

    sqs_client.send_message(
        {"data": "with attributes"},
        message_attributes=attributes,
    )

    messages = sqs_client.receive_messages(max_messages=1)
    received = messages[0]["MessageAttributes"]

    assert received["trace_id"]["StringValue"] == attributes["trace_id"]
    assert received["priority"]["StringValue"] == "1"
    assert received["payload"]["DataType"] == "Binary"
    assert received["payload"]["BinaryValue"] == b"binary-data"


def test_retry_count_from_system_attributes(sqs_client):
    trace_id = str(uuid.uuid4())
    sqs_client.send_message({"trace_id": trace_id, "data": "x"})

    # First receive: ApproximateReceiveCount=1 -> retry_count 0
    first = sqs_client.receive_messages_as_objects(
        max_messages=1, visibility_timeout=0
    )
    assert first[0].retry_count == 0
    assert first[0].trace_id == trace_id

    # Second receive (visibility 0 made it immediately available):
    # ApproximateReceiveCount=2 -> retry_count 1
    second = sqs_client.receive_messages_as_objects(
        max_messages=1, visibility_timeout=0
    )
    assert second[0].retry_count == 1


def test_trace_id_falls_back_to_message_attribute(sqs_client):
    trace_id = str(uuid.uuid4())

    # Body has no trace_id; only the message attribute carries it
    sqs_client.send_message_with_idempotency(
        {"data": "no trace in body"},
        trace_id=trace_id,
    )

    messages = sqs_client.receive_messages_as_objects(max_messages=1)

    assert messages[0].trace_id == trace_id


def test_message_size_validation(sqs_client):
    with pytest.raises(ValidationError):
        sqs_client.send_message("x" * (256 * 1024 + 1))


def test_visibility_timeout_zero_is_honored(sqs_client):
    sqs_client.send_message({"data": "visible again"})

    first = sqs_client.receive_messages(
        max_messages=1, visibility_timeout=0
    )
    assert len(first) == 1

    # visibility_timeout=0 means the message is immediately
    # re-receivable (the old code silently replaced 0 with 300)
    second = sqs_client.receive_messages(max_messages=1)
    assert len(second) == 1


def test_client_constructed_from_url_derives_queue_name():
    with mock_aws():
        queue_url = boto3.client(
            "sqs", region_name=REGION
        ).create_queue(QueueName=QUEUE)["QueueUrl"]

        client = SQSClient(queue_url=queue_url, region_name=REGION)

        assert client.queue_name == QUEUE


def test_idempotency_requires_storage_path():
    with pytest.raises(ValueError):
        SQSClient(
            queue_name=QUEUE,
            region_name=REGION,
            enable_idempotency=True,
        )


def test_full_idempotent_lifecycle(tmp_path):
    with mock_aws():
        boto3.client("sqs", region_name=REGION).create_queue(
            QueueName=QUEUE
        )

        client = SQSClient(
            queue_name=QUEUE,
            region_name=REGION,
            enable_idempotency=True,
            mps_storage_path=str(tmp_path),
        )

        trace_id = str(uuid.uuid4())

        assert not client.check_duplicates(trace_id)
        assert client.mark_processing_start(trace_id)

        # A second worker must not acquire the same message
        assert not client.mark_processing_start(trace_id)

        client.mark_processing_end(trace_id, success=True)

        # Now the duplicate check must fire (END marker written)
        assert client.check_duplicates(trace_id)


def test_purge_queue(sqs_client):
    sqs_client.send_message_batch(
        [{"MessageBody": {"index": i}} for i in range(5)]
    )

    sqs_client.purge_queue()

    attrs = sqs_client.get_queue_attributes(
        ["ApproximateNumberOfMessages"]
    )
    assert int(attrs["ApproximateNumberOfMessages"]) == 0


def test_ingest_100_contract_valid_messages(sqs_client):
    """
    End-to-end mirror of the 100-message ingestion test: send 100
    factory-built messages, receive them all back, and prove every one
    satisfies the consumer contract of main.process_sqs_message.
    """
    trace_ids = [str(uuid.uuid4()) for _ in range(100)]

    response = sqs_client.send_message_batch(
        [
            {
                "Id": str(i),
                "MessageBody": build_message(trace_id=t),
                "MessageAttributes": {"trace_id": t},
            }
            for i, t in enumerate(trace_ids)
        ]
    )

    assert len(response["Successful"]) == 100

    messages = _drain(sqs_client, expected=100)
    assert len(messages) == 100

    seen = set()

    for msg in messages:
        fields = extract_consumer_fields(json.loads(msg["Body"]))
        seen.add(fields["trace_id"])

    assert seen == set(trace_ids)

    delete_response = sqs_client.delete_msg_batch(
        [m["ReceiptHandle"] for m in messages]
    )
    assert len(delete_response["Successful"]) == 100
