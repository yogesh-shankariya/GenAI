import os
from enum import Enum
from pathlib import Path
from typing import Final

from dotenv import load_dotenv


cwd = Path(__file__).parent.resolve()
env_path = cwd.joinpath(".env")
load_dotenv(env_path)


def _require_env(name: str) -> str:
    value = os.environ.get(name)

    if value is None:
        raise EnvironmentError(
            f"Required environment variable {name} is not set "
            f"(see .env.example)"
        )

    return value


class Constant:
    SERVICE_NAME: Final[str] = "cdi-docextract-py-service"
    DEBUG_MODE: bool = bool(int(os.environ.get('DEBUG_MODE', 0)))
    MAX_SPAWN_PROCESSES: Final[int] = int(
        os.environ.get('MAX_SPAWN_PROCESSES', 4)
    )
    MAX_SPAWN_THREADS: Final[int] = int(
        os.environ.get('MAX_SPAWN_THREADS', 5)
    )
    MAX_QUEUE_SIZE: Final[int] = int(
        os.environ.get('MAX_QUEUE_SIZE', 50)
    )

    # S3 (required only by the doc-extract pipeline, not the SQS layer)
    S3_FETCH_FILE_URL: Final[str] = os.environ.get('S3_FETCH_FILE_URL')
    S3_DECRYPT: Final[str] = os.environ.get('S3_DECRYPT', 'true')

    COMMON_HEADERS = {
        "accept": "application/json",
        "Content-Type": "application/json",
    }

    # Kafka (optional - only required when INPUT_QUEUE_TYPE=KAFKA)
    KAFKA_URL: Final[str] = os.environ.get("KAFKA_URL")
    KAFKA_TOPIC_EXTR: Final[str] = os.environ.get("KAFKA_TOPIC_EXTR")
    KAFKA_TOPIC_ERR: Final[str] = os.environ.get("KAFKA_TOPIC_ERR")
    KAFKA_TOPIC_OUTPUT: Final[str] = os.environ.get("KAFKA_TOPIC_OUTPUT")
    KAFKA_TOPIC_OUTPUT_ERR: Final[str] = os.environ.get(
        "KAFKA_TOPIC_OUTPUT_ERR"
    )
    KAFKA_API_TIME_OUT: Final[int] = int(
        os.environ.get("KAFKA_API_TIME_OUT", 120)
    )
    KAFKA_KEYTAB: Final[str] = os.environ.get("KAFKA_KEYTAB")
    KAFKA_CA_CERT: Final[str] = os.environ.get("KAFKA_CA_CERT")
    KAFKA_SECURITY_PRINCIPAL: Final[str] = os.environ.get(
        "KAFKA_SECURITY_PRINCIPAL"
    )
    KAFKA_SECURITY_PROTOCOL: Final[str] = os.environ.get(
        "KAFKA_SECURITY_PROTOCOL"
    )
    KAFKA_BROKER: Final[list] = (
        os.environ.get("KAFKA_BROKER") or ""
    ).split(",")
    KERBEROS_PRINCIPAL: Final[str] = os.environ.get(
        "KERBEROS_PRINCIPAL"
    )
    KERBEROS_SERVICE_NAME: Final[str] = os.environ.get(
        "KERBEROS_SERVICE_NAME"
    )
    KERBEROS_KEYTAB: Final[str] = os.environ.get("KERBEROS_KEYTAB")
    KERBEROS_RENEWAL_INTERVAL: Final[int] = int(
        os.environ.get("KERBEROS_RENEWAL_INTERVAL", 3600)
    )
    KERBEROS_DOMAIN_NAME: Final[str] = os.environ.get(
        "KERBEROS_DOMAIN_NAME"
    )
    KAFKA_SASL: Final[str] = os.environ.get("KAFKA_SASL")
    KAFKA_GROUP_ID: Final[str] = os.environ.get("KAFKA_GROUP_ID")
    KAFKA_BOOTSTRAP_SERVERS: Final[str] = os.environ.get(
        "KAFKA_BOOTSTRAP_SERVERS"
    )
    DOCUMENT_EXTRACT_KAFKA_CONSUMER_GROUP: Final[str] = os.environ.get(
        "DOCUMENT_EXTRACT_KAFKA_CONSUMER_GROUP"
    )
    PROVIDER_KAFKA_CONSUMER_GROUP: Final[str] = os.environ.get(
        "PROVIDER_KAFKA_CONSUMER_GROUP"
    )

    #OCR (required only by the doc-extract pipeline)
    HORIZON_CLIENT_ID: Final[str] = os.environ.get("CLIENT_ID")
    HORIZON_CLIENT_SECRET: Final[str] = os.environ.get("CLIENT_SECRET")
    OPENAI_API_KEY: Final[str] = os.environ.get("OPENAI_API_KEY")

    #AWS
    AWS_REGION: Final[str] = os.environ.get("AWS_REGION")

    #SQS (required)
    SQS_INPUT_QUEUE_NAME: Final[str] = _require_env(
        "SQS_INPUT_QUEUE_NAME"
    )
    SQS_OUTPUT_QUEUE_NAME: Final[str] = _require_env(
        "SQS_OUTPUT_QUEUE_NAME"
    )
    SQS_ERROR_QUEUE_NAME: Final[str] = _require_env(
        "SQS_ERROR_QUEUE_NAME"
    )
    SQS_AWS_REGION: Final[str] = _require_env("SQS_AWS_REGION")
    SQS_MPS_PATH: Final[str] = os.environ.get(
        "SQS_MPS_PATH",
        "/data/main_resources/runtime_files_space",
    )

    # Only for testing
    SQS_TEST_MSG_TO_SPAWN: Final[int] = int(
        os.environ.get("SQS_TEST_MSG_TO_SPAWN", 100)
    )

    #Input Queue Type
    INPUT_QUEUE_TYPE: Final[str] = _require_env("INPUT_QUEUE_TYPE")

    @classmethod
    def get_s3_file_url(cls, file_path: str):
        return (
            cls.S3_FETCH_FILE_URL
            + f"?decrypt={cls.S3_DECRYPT}"
            + "&filePath="
            + file_path
        )


class ErrorCodes(Enum):
    INTERNAL_SERVER_ERROR = 500
    S3_DOWNLOAD_FAILED = 501
    LLM_EXECUTION_FAILED = 502
    LLM_RESPONSE_PROCESSING_FAILED = 503
    JAVA_API_FAILED = 504
    BAD_FILE_NAME = 505
