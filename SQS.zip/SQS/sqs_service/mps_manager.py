"""
MPS (Message Processing State) Manager
=====================================

Handles creation and querying of marker files for idempotency control.

MPS files are the source of truth for message lifecycle:
- MPS_START : Processing has begun
- MPS_END : Processing completed (success or Failure)
"""

import os
import glob
import time
from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple, List
from pathlib import Path

from ._logging import get_logger


logger = get_logger()

# Public API
__all__ = [
    "MPSManager",
    "MPSInfo",
    "DuplicateCheckResult",
    "check_duplicate_status",
    "MPSType",
]


class MPSType(Enum):
    START = "start"
    END = "end"


@dataclass
class MPSInfo:
    """
    Parsed information from an MPS filename.
    """

    trace_id: str
    queue_name: str
    mps_type: MPSType
    retry_count: int
    timestamp: float
    filepath: str


class MPSManager:
    """
    Manages MPS files for idempotency

    File Pattern :
    {traceId}__{queueName}__{start|end}__{retryCount}__{timestamp}

    trace_id must not contain the separator ("__"); queue names may
    (the parser rejoins the middle segments).

    These marker files enforce:
    - Duplicate suppression (skip if MPS_END exists)
    - Ownership tracking (skip if another pod owns via MPS_START)
    - Crash recovery (reprocess if MPS_START is stale)
    - Lifecycle completion (MPS_END marks done)
    """

    SEPARATOR = "__"
    LOCK_SUFFIX = "lock"
    # A lock only guards the few filesystem operations inside
    # create_start_marker; anything older than this is an orphan
    # left by a crashed pod.
    LOCK_TIMEOUT_SECONDS = 60

    def __init__(
        self,
        storage_path: str = "/main_resources/runtime_files_space",
        timeout_seconds: float = 4 * 60 * 60,  # 4 hours
    ):
        self.storage_path = Path(storage_path)
        self.timeout_seconds = timeout_seconds
        self._ensure_storage_exists()

    def _ensure_storage_exists(self) -> None:
        """
        Create storage_directory if it doesn't exists.
        """
        self.storage_path.mkdir(parents=True, exist_ok=True)

    def _build_filename(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: MPSType,
        retry_count: int,
        timestamp: Optional[float] = None,
    ) -> str:
        """
        Build MPS filename from components.
        """
        ts = timestamp if timestamp is not None else time.time()

        return self.SEPARATOR.join(
            [
                trace_id,
                queue_name,
                mps_type.value,
                str(retry_count),
                str(ts),
            ]
        )

    def _parse_filename(self, filepath: str) -> Optional[MPSInfo]:
        """
        Parse MPS filename into components.

        trace_id is the first segment and type/retry/timestamp the last
        three; the middle segments are rejoined so queue names containing
        the separator still parse.
        """
        try:
            filename = os.path.basename(filepath)
            parts = filename.split(self.SEPARATOR)

            if len(parts) < 5:
                logger.info(f"Invalid MPS filename format: {filename}")
                return None

            trace_id = parts[0]
            queue_name = self.SEPARATOR.join(parts[1:-3])
            type_str, retry_str, ts_str = parts[-3:]

            return MPSInfo(
                trace_id=trace_id,
                queue_name=queue_name,
                mps_type=MPSType(type_str),
                retry_count=int(retry_str),
                timestamp=float(ts_str),
                filepath=filepath,
            )

        except (ValueError, KeyError) as e:
            logger.info(f"Failed to parse MPS filename {filepath}: {e}")
            return None

    def _get_pattern(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: Optional[MPSType] = None,
    ) -> str:
        """
        Build glob pattern for finding MPS files.
        """
        type_pattern = mps_type.value if mps_type else "*"

        return str(
            self.storage_path
            / self.SEPARATOR.join(
                [trace_id, queue_name, type_pattern, "*"]
            )
        )

    def find_mps_files(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: Optional[MPSType] = None,
    ) -> List[MPSInfo]:
        """
        Find all MPS files matching the criteria.
        """
        pattern = self._get_pattern(trace_id, queue_name, mps_type)
        files = glob.glob(pattern)
        parsed = []

        for f in files:
            info = self._parse_filename(f)

            if info:
                parsed.append(info)

        # Sort by timestamp descending (most recent first)
        parsed.sort(key=lambda x: x.timestamp, reverse=True)

        return parsed

    def has_end_marker(self, trace_id: str, queue_name: str) -> bool:
        """
        Check if MPS_END exists (message already completed).
        """
        files = self.find_mps_files(trace_id, queue_name, MPSType.END)
        return len(files) > 0

    def get_start_marker(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Optional[MPSInfo]:
        """
        Get the most recent MPS_START file if it exists.
        """
        files = self.find_mps_files(trace_id, queue_name, MPSType.START)
        return files[0] if files else None

    def is_start_marker_stale(self, start_info: MPSInfo) -> bool:
        """
        Check if MPS_START is older than the configured_timeout.
        """
        age = time.time() - start_info.timestamp
        return age > self.timeout_seconds

    def _lock_filepath(self, trace_id: str, queue_name: str) -> Path:
        return self.storage_path / self.SEPARATOR.join(
            [trace_id, queue_name, self.LOCK_SUFFIX]
        )

    def _remove_stale_lock(self, lock_filepath: Path) -> bool:
        """
        Remove a lock file left behind by a crashed pod.

        Returns True if a stale lock was removed.
        """
        try:
            age = time.time() - os.path.getmtime(lock_filepath)
        except OSError:
            return False

        if age <= self.LOCK_TIMEOUT_SECONDS:
            return False

        try:
            os.remove(lock_filepath)
            logger.info(f"Removed stale lock file: {lock_filepath}")
            return True
        except OSError:
            return False

    def create_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
    ) -> Tuple[bool, str]:
        """
        Atomically create MPS_START marker

        Uses a lock file pattern to enforce that only one pod can create
        the start marked:

        1. Check if a live (non-stale) START marker already exists for
           this trace_id + queue_name; stale markers from crashed pods
           are removed so takeover can proceed
        2. If not, atomically create a lock file
        3. Create the actual START marker
        """
        # First, check for existing START markers. Stale ones belong to
        # a crashed pod and must not block takeover.
        if self._live_start_marker_exists(trace_id, queue_name):
            marker = self.get_start_marker(trace_id, queue_name)
            return False, marker.filepath if marker else ""

        # Use a lock file for atomic coordination
        lock_filepath = self._lock_filepath(trace_id, queue_name)

        try:
            # Atomically create lock_file - only one pod can succeed
            fd = os.open(
                str(lock_filepath),
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                0o644,
            )
            os.close(fd)

        except FileExistsError:
            # Another pod is creating the START marker, unless the lock
            # is an orphan from a crash - then clear it and retry once.
            if not self._remove_stale_lock(lock_filepath):
                logger.info(
                    "Lock file exists - another pod is creating "
                    f"MPS_START for {trace_id}"
                )
                return False, ""

            try:
                fd = os.open(
                    str(lock_filepath),
                    os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                    0o644,
                )
                os.close(fd)
            except OSError:
                return False, ""

        except OSError as e:
            logger.info(f"Failed to create lock file for {trace_id}: {e}")
            raise

        try:
            # Now that the lock is owned, ensure no live START marker was
            # created in the meantime
            if self._live_start_marker_exists(trace_id, queue_name):
                logger.info(
                    f"MPS_START was created by another pod for {trace_id}"
                )
                marker = self.get_start_marker(trace_id, queue_name)
                return False, marker.filepath if marker else ""

            # Create the actual START marker with timestamp
            filename = self._build_filename(
                trace_id,
                queue_name,
                MPSType.START,
                retry_count,
            )
            filepath = self.storage_path / filename

            with open(filepath, "w") as f:
                f.write("")

            logger.info(f"Created MPS_START: {filename}")
            return True, str(filepath)

        finally:
            # Always clean up lock_file
            try:
                os.remove(lock_filepath)
            except OSError:
                pass

    def _live_start_marker_exists(
        self,
        trace_id: str,
        queue_name: str,
    ) -> bool:
        """
        True if a non-stale START marker exists. Stale markers
        (crashed pod) are removed as a side effect so the caller
        can take over.
        """
        existing = self.find_mps_files(
            trace_id,
            queue_name,
            MPSType.START,
        )

        live = False

        for info in existing:
            if self.is_start_marker_stale(info):
                try:
                    os.remove(info.filepath)
                    logger.info(
                        f"Removed stale MPS_START for takeover: "
                        f"{info.filepath}"
                    )
                except OSError:
                    pass
            else:
                live = True

        if live:
            logger.info(f"MPS_START already exists for {trace_id}")

        return live

    def create_end_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
        success: bool = True,
    ) -> str:
        """
        Create MPS_END marker to signal processing completion.

        Args:
            trace_id: Message trace ID
            queue_name: Queue name
            retry_count: Current retry attempt
            success: Whether processing

        Returns:
            Path to created marker file
        """
        # Include success/failure indicator in a way that's querytable
        filename = self._build_filename(
            trace_id,
            queue_name,
            MPSType.END,
            retry_count,
        )
        filepath = self.storage_path / filename

        try:
            # Write status to file content
            with open(filepath, "w") as f:
                f.write("success" if success else "failed")

            logger.info(
                f"Created MPS_END: {filename} (success={success})"
            )
            return str(filepath)

        except OSError as e:
            logger.info(f"Failed to create MPS_END {filename}: {e}")
            raise

    def cleanup_start_markers(
        self,
        trace_id: str,
        queue_name: str,
    ) -> int:
        """
        Remove stale MPS_START markers for a message.

        Called when taking over from a crashed pod.
        """
        files = self.find_mps_files(
            trace_id,
            queue_name,
            MPSType.START,
        )
        removed = 0

        for info in files:
            if self.is_start_marker_stale(info):
                try:
                    os.remove(info.filepath)
                    logger.info(
                        f"Removed stale MPS_START: {info.filepath}"
                    )
                    removed += 1

                except OSError as e:
                    logger.info(
                        f"Failed to remove stale marker "
                        f"{info.filepath}: {e}"
                    )

        return removed

    def cleanup_old_markers(
        self,
        max_age_seconds: float = 7 * 24 * 60 * 60,
    ) -> int:
        """
        Cleanup markers older than max_age_seconds (default 7 days)

        Also sweeps orphaned lock files past LOCK_TIMEOUT_SECONDS.

        Run periodically to prevent storage bloat.
        """
        cutoff = time.time() - max_age_seconds
        removed = 0

        for filepath in glob.glob(str(self.storage_path / "*")):
            if filepath.endswith(self.SEPARATOR + self.LOCK_SUFFIX):
                if self._remove_stale_lock(Path(filepath)):
                    removed += 1
                continue

            info = self._parse_filename(filepath)

            if info and info.timestamp < cutoff:
                try:
                    os.remove(filepath)
                    removed += 1

                except OSError as e:
                    logger.info(
                        f"Failed to cleanup old marker {filepath}: {e}"
                    )

        logger.info(f"Cleaned up {removed} old MPS markers")
        return removed


@dataclass
class DuplicateCheckResult:
    """
    Result of duplicate check operation
    """

    should_process: bool
    reason: str
    existing_marker: Optional[MPSInfo] = None
    is_takeover: bool = False  # True id pod crashed and taking over


def check_duplicate_status(
    mps_manager: MPSManager,
    trace_id: str,
    queue_name: str,
) -> DuplicateCheckResult:
    """
    Perform duplicate check per stage 2 of the flow.

    Scenarios:
    A. MPS_END exists -> skip (already completed)
    B. MPS_START exists within timeout -> skip (another pod owns it)
    C. MPS_START exists but stale -> Reprocess (takeover from crashed pod)
    D. No markers -> Process (new message)
    """
    # Scenario A: Check for completion marker
    if mps_manager.has_end_marker(trace_id, queue_name):
        return DuplicateCheckResult(
            should_process=False,
            reason="MPS_END exists - message already completed",
        )

    # Check for start marker
    start_marker = mps_manager.get_start_marker(trace_id, queue_name)

    if start_marker:
        # Scenario B: Another pod is actively processing
        if not mps_manager.is_start_marker_stale(start_marker):
            return DuplicateCheckResult(
                should_process=False,
                reason=(
                    "MPS_START exists within timeout - "
                    "another pod is processing"
                ),
                existing_marker=start_marker,
            )

        # Scenario C: Stale marker - previous pod likely crashed
        return DuplicateCheckResult(
            should_process=True,
            reason=(
                "MPS_START is stale - taking over from crashed pod"
            ),
            existing_marker=start_marker,
            is_takeover=True,
        )

    # Scenario D: No markers - new message
    return DuplicateCheckResult(
        should_process=True,
        reason="No MPS markers - new message",
    )
