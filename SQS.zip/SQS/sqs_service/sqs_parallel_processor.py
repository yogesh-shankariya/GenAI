"""
Parallel SQS Message Processing Module

Provides utilities for processing SQS messages in parallel using:
- ThreadPoolExecutor for I/O-bound tasks
- ProcessPoolExecutor for CPU bound tasks
- AsyncIO for async operations
"""

import asyncio
from concurrent.futures import (
    ThreadPoolExecutor,
    ProcessPoolExecutor,
    as_completed,
)
from typing import Callable, List, Dict, Any, Optional
import time

from .sqs_idempotent_processor import SQSClient
from ._logging import get_logger


logger = get_logger()


class ParallelSQSProcessor:
    """
    Process SQS messages in parallel

    Args:
        client: SQSClient instance
        processing_function: Function to process each message
        max_workers: Maximum number of parallel workers
        delete_on_success: Whether to delete messages after successful
            processing
        visibility_timeout: Message visibility timeout in seconds
    """

    def __init__(
        self,
        client: SQSClient,
        processing_function: Callable,
        max_workers: int = 10,
        delete_on_success: bool = False,
        visibility_timeout: int = 60,
    ):
        self.client = client
        self.processing_function = processing_function
        self.max_workers = max_workers
        self.delete_on_success = delete_on_success
        self.visibility_timeout = visibility_timeout

    def process_with_threads(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
    ) -> Dict[str, List]:
        """
        Process message using ThreadPoolExector ( for I/O- bound tasks).

        Args:
            max_messages: Maximum messages to receive
            wait_time_seconds: Long polling wait time

        Returns:
            dict: Results with 'successful' and 'failed' message lists
        """
        messages = self.client.receive_messages(
            max_messages=max_messages,
            wait_time_seconds=wait_time_seconds,
            visibility_timeout=self.visibility_timeout,
        )

        if not messages:
            logger.info("No message received!")
            return {"successful": [], "failed": []}

        logger.info(
            f"Processing {len(messages)} messages with "
            f"{self.max_workers} threads"
        )

        results = {
            "successful": [],
            "failed": [],
        }

        with ThreadPoolExecutor(
            max_workers=self.max_workers
        ) as executor:
            # Submit all tasks
            future_to_message = {
                executor.submit(
                    self._process_single_message,
                    msg,
                ): msg
                for msg in messages
            }

            #Collect results as they complete
            for future in as_completed(future_to_message):
                message = future_to_message[future]
                message_id = message.get("MessageId")

                try:
                    result = future.result()

                    if result["success"]:
                        results["successful"].append(result)
                        logger.info(
                            f"Processed message {message_id}"
                        )
                    else:
                        results["failed"].append(result)
                        logger.info(
                            f"Failed to process message {message_id}: "
                            f"{result.get('error')}"
                        )

                except Exception as e:
                    logger.info(
                        f"Exception processing message "
                        f"{message_id}: {e}"
                    )
                    results["failed"].append(
                        {
                            "success": False,
                            "message_id": message_id,
                            "error": str(e),
                        }
                    )

        logger.info(
            f"Completed: {len(results['successful'])} successful, "
            f"{len(results['failed'])} failed"
        )

        return results

    def process_with_multiprocessing(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
    ) -> Dict[str, List]:
        """
        Process messages using ProcessPoolExecutor
        (best for CPU bound tasks)

        Note : Lambda functions cannot be used

        Args:
            max_messages : Maximum messages to receive
            wait_time_seconds: Long polling wait time

        Returns:
            dict: Results with 'successful' and 'failed' message lists
        """
        messages = self.client.receive_messages(
            max_messages=max_messages,
            wait_time_seconds=wait_time_seconds,
            visibility_timeout=self.visibility_timeout,
        )

        if not messages:
            logger.info("No messages received")
            return {"successful": [], "failed": []}

        logger.info(
            f"Processing {len(messages)} messages with "
            f"{self.max_workers} processes"
        )

        results = {
            "successful": [],
            "failed": [],
        }

        with ProcessPoolExecutor(
            max_workers=self.max_workers
        ) as executor:
            # Submit all tasks
            future_to_message = {
                executor.submit(
                    _process_message_multiprocess,
                    msg,
                    self.processing_function,
                    self.client.queue_url,
                    self.client.region_name,
                    self.delete_on_success,
                ): msg
                for msg in messages
            }

            # Collect results as they complete
            for future in as_completed(future_to_message):
                message = future_to_message[future]
                message_id = message.get("MessageId")

                try:
                    result = future.result()

                    if result["success"]:
                        results["successful"].append(result)
                        logger.info(
                            f"Processed message {message_id}"
                        )
                    else:
                        results["failed"].append(result)
                        logger.info(
                            f"Failed to process message {message_id}: "
                            f"{result.get('error')}"
                        )

                except Exception as e:
                    logger.info(
                        f"Exception processing message "
                        f"{message_id}: {e}"
                    )
                    results["failed"].append(
                        {
                            "success": False,
                            "message_id": message_id,
                            "error": str(e),
                        }
                    )

        logger.info(
            f"Completed: {len(results['successful'])} successful, "
            f"{len(results['failed'])} failed"
        )

        return results

    async def process_with_asyncio(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
    ) -> Dict[str, List]:
        """
        Process messages using AsyncIO - for async I/O operations

        Args:
            max_messages : Maximum messages to receive
            wait_time_seconds: Long polling wait time

        Returns:
            dict: Results with 'successful' and 'failed' message lists
        """
        # Receive messages (sync operation)
        messages = self.client.receive_messages(
            max_messages=max_messages,
            wait_time_seconds=wait_time_seconds,
            visibility_timeout=self.visibility_timeout,
        )

        if not messages:
            logger.info("No messages received")
            return {"successful": [], "failed": []}

        logger.info(
            f"Processing {len(messages)} messages with "
            f"{self.max_workers} concurrent tasks"
        )

        # Process all messages concurrently, bounded by max_workers
        semaphore = asyncio.Semaphore(self.max_workers)

        async def bounded_process(msg):
            async with semaphore:
                return await self._process_single_message_async(msg)

        tasks = [bounded_process(msg) for msg in messages]

        results_list = await asyncio.gather(
            *tasks,
            return_exceptions=True,
        )

        results = {
            "successful": [],
            "failed": [],
        }

        for i, result in enumerate(results_list):
            message_id = messages[i].get("MessageId")

            if isinstance(result, Exception):
                logger.info(
                    f"Exception processing message "
                    f"{message_id}: {result}"
                )
                results["failed"].append(
                    {
                        "success": False,
                        "message_id": message_id,
                        "error": str(result),
                    }
                )

            elif result["success"]:
                results["successful"].append(result)
                logger.info(f"Processed message {message_id}")

            else:
                results["failed"].append(result)
                logger.info(
                    f"Failed to process message {message_id}: "
                    f"{result.get('error')}"
                )

        logger.info(
            f"Completed: {len(results['successful'])} successful, "
            f"{len(results['failed'])} failed"
        )

        return results

    def continuous_processing_with_threads(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
        poll_interval: float = 0,
    ):
        """
        Continuously poll and process messages with threads

        Args:
            max_messages: Maximum messages per poll
            wait_time_seconds: Long polling wait time
            poll_interval: Additional sleep time between polls (seconds)
        """
        logger.info("Starting continuous processing with threads... ")

        try:
            while True:
                self.process_with_threads(
                    max_messages,
                    wait_time_seconds,
                )

                if poll_interval > 0:
                    time.sleep(poll_interval)

        except KeyboardInterrupt:
            logger.info("Stopping continuous processing")

    def _process_single_message(
        self,
        message: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Process single message and optionally delete it

        Args:
            message: SQS message dictionary

        Returns:
            dict: Result with success status and details
        """
        message_id = message.get("MessageId")
        receipt_handle = message.get("ReceiptHandle")

        try:
            result = self.processing_function(
                message.get("Body", "")
            )

            # Delete if successful
            if self.delete_on_success and receipt_handle:
                self.client.delete_msg(receipt_handle)

            return {
                "success": True,
                "message_id": message_id,
                "result": result,
            }

        except Exception as e:
            logger.info(
                f"Error processing message {message_id}: {e}"
            )

            return {
                "success": False,
                "message_id": message_id,
                "error": str(e),
            }

    async def _process_single_message_async(
        self,
        message: Dict[str, Any],
    ) -> Dict[str, Any]:
        """
        Asynchronously process single message.

        Args:
            message: SQS message dictionary

        Returns:
            dict: Result with success status and details
        """
        message_id = message.get("MessageId")
        receipt_handle = message.get("ReceiptHandle")

        try:
            # Check if processing function is async
            if asyncio.iscoroutinefunction(self.processing_function):
                result = await self.processing_function(
                    message.get("Body", "")
                )
            else:
                #Run sync function in executor
                loop = asyncio.get_event_loop()
                result = await loop.run_in_executor(
                    None,
                    self.processing_function,
                    message.get("Body", ""),
                )

            # Delete if successful
            if self.delete_on_success and receipt_handle:
                loop = asyncio.get_event_loop()
                await loop.run_in_executor(
                    None,
                    self.client.delete_msg,
                    receipt_handle,
                )

            return {
                "success": True,
                "message_id": message_id,
                "result": result,
            }

        except Exception as e:
            logger.info(
                f"Error processing message {message_id} : {e}"
            )

            return {
                "success": False,
                "message_id": message_id,
                "error": str(e),
            }


def _process_message_multiprocess(
    message: Dict[str, Any],
    processing_function: Callable,
    queue_url: str,
    region_name: Optional[str] = None,
    delete_on_success: bool = False,
) -> Dict[str, Any]:
    """
    Helper function for multiprocessing

    Args:
        message: SQS message dictionary
        processing_function: Function to process message
        queue_url: SQS queue URL
        region_name: AWS region of the queue
        delete_on_success: Whether to delete on success

    Returns:
        dict: Result with success status and details
    """
    message_id = message.get("MessageId")
    receipt_handle = message.get("ReceiptHandle")

    try:
        result = processing_function(message.get("Body", ""))

        # Delete if successful
        if delete_on_success and receipt_handle:
            client = SQSClient(
                queue_url=queue_url,
                region_name=region_name,
            )
            client.delete_msg(receipt_handle)

        return {
            "success": True,
            "message_id": message_id,
            "result": result,
        }

    except Exception as e:
        return {
            "success": False,
            "message_id": message_id,
            "error": str(e),
        }


#Method for simple use cases
def process_messages_parallel(
    client: SQSClient,
    processing_function: Callable,
    max_messages: int = 10,
    max_workers: int = 10,
    method: str = "threads",
) -> Dict[str, List]:
    """
    Quick helper function for messages in parallel

    Args:
        client: SQSClient instance
        processing_function: Function to process
        max_messages: Maximum messages to receive
        max_workers: Number of parallel workers
        method: 'threads' , 'processes', or 'asyncio'

    Returns:
        dict: Results with 'successful' or 'failed' list
    """
    processor = ParallelSQSProcessor(
        client=client,
        processing_function=processing_function,
        max_workers=max_workers,
    )

    if method == "threads":
        return processor.process_with_threads(max_messages)

    elif method == "processes":
        return processor.process_with_multiprocessing(max_messages)

    elif method == "asyncio":
        return asyncio.run(
            processor.process_with_asyncio(max_messages)
        )

    else:
        raise ValueError(
            f"Unknown method: {method}. "
            "Use 'threads', 'processes' or 'asyncio'"
        )
