"""
Logging helper for the sqs_service package.

Prefers the client environment's log_util (which configures logging from
logger_config.yaml). Outside the client environment (local development,
mock testing) it falls back to a plain stdlib logger so the package stays
importable everywhere.
"""

import logging


def get_logger():
    try:
        from log_util import logger as _log_util

        return _log_util.setup_logger(config_path="logger_config.yaml")
    except Exception:
        logger = logging.getLogger("sqs_service")

        if not logger.handlers:
            handler = logging.StreamHandler()
            handler.setFormatter(
                logging.Formatter(
                    "%(asctime)s %(levelname)s %(name)s %(message)s"
                )
            )
            logger.addHandler(handler)
            logger.setLevel(logging.INFO)

        return logger
