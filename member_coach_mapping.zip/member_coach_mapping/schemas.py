"""Pydantic models for the FastAPI service."""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class UserIntake(BaseModel):
    # public_user_id is optional because Streamlit might not know it yet
    user_id: Optional[str] = None
    height_cm: int
    weight_kg: int
    primary_goal: str
    primary_goal_other: Optional[str] = None
    goal_text: str
    constraints: List[str] = Field(default_factory=list)
    session_minutes: int
    days_per_week: int
    equipment: str
    equipment_other: Optional[str] = None
    experience_level: str
    preferences: Dict[str, Any] = Field(default_factory=dict)


class CoachProfile(BaseModel):
    coach_id: str
    coach_name: str
    tags: List[str] = Field(default_factory=list)
    min_session_minutes: int = 10
    max_session_minutes: int = 180


class RecommendRequest(BaseModel):
    user_intake: UserIntake
    coach_catalog: Optional[List[CoachProfile]] = None


class RecommendResponse(BaseModel):
    Coach_name: List[str]
    Coach_ID: List[str]