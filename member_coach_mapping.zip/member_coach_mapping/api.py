"""FastAPI service for coach recommendation.

Streamlit will call this service to get recommended coach IDs/names.
Today this is implemented as a simple deterministic scoring stub.

You will replace `recommend_coaches()` with your LLM logic later.
The only requirement is to return:

  {"Coach_name": [..], "Coach_ID": [..]}

Where:
 - Coach_name length is 1 or 2
 - Coach_ID length matches Coach_name
 - Primary coach is always at index 0
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from fastapi import FastAPI, HTTPException

from . import db
from .schemas import CoachProfile, RecommendRequest, RecommendResponse


app = FastAPI(title="Member→Coach Mapping API", version="1.0")


def _normalize(s: str) -> str:
    return (s or "").strip().lower()


def _load_catalog_from_db() -> List[CoachProfile]:
    coaches = db.list_enabled_coaches()
    catalog = []
    for c in coaches:
        catalog.append(
            CoachProfile(
                coach_id=c["coach_id"],
                coach_name=c["name"],
                tags=list(c.get("tags", [])),
                min_session_minutes=int(c.get("min_session_minutes", 10)),
                max_session_minutes=int(c.get("max_session_minutes", 180)),
            )
        )
    return catalog


def recommend_coaches(payload: RecommendRequest) -> RecommendResponse:
    """Stub recommendation (replace with LLM later)."""
    intake = payload.user_intake
    catalog = payload.coach_catalog or _load_catalog_from_db()
    if not catalog:
        raise HTTPException(status_code=400, detail="No enabled coaches available")

    tags = [t for t in _normalize(intake.primary_goal).replace(" ", "_").split() if t]
    # allow standard goal keys like running_5k
    goal_key = _normalize(intake.primary_goal)
    if goal_key in {"running_5k", "running_10k", "endurance"}:
        tags = ["running", goal_key.replace("running_", "")]
    if goal_key in {"fat_loss", "habits"}:
        tags = [goal_key]
    if goal_key in {"nutrition_only"}:
        tags = ["nutrition"]

    constraints = [_normalize(c) for c in intake.constraints]
    mins = int(intake.session_minutes)

    scored: List[Tuple[float, CoachProfile]] = []
    for coach in catalog:
        score = 0.0
        coach_tags = set(_normalize(t).replace(" ", "_") for t in coach.tags)

        # tag match
        for t in tags:
            if t in coach_tags:
                score += 5.0

        # constraints heuristic
        if any(x in constraints for x in ["knee pain", "back pain", "shoulder pain", "low impact only", "no jumping", "stress / anxiety", "poor sleep"]):
            if "mobility" in coach_tags or "yoga" in coach_tags or "low_impact" in coach_tags:
                score += 3.0

        # minutes fit
        if mins < coach.min_session_minutes or mins > coach.max_session_minutes:
            score -= 3.0
        else:
            score += 0.5

        # fat loss often benefits from nutrition as secondary
        if goal_key == "fat_loss" and "nutrition" in coach_tags:
            score += 1.5

        scored.append((score, coach))

    scored.sort(key=lambda x: x[0], reverse=True)
    primary = scored[0][1]

    # choose secondary if meaningful
    secondary: Optional[CoachProfile] = None
    primary_score = scored[0][0]
    for s, c in scored[1:]:
        if c.coach_id == primary.coach_id:
            continue
        if s >= max(4.0, primary_score - 2.0):
            secondary = c
            break

    coach_names = [primary.coach_name]
    coach_ids = [primary.coach_id]
    if secondary:
        coach_names.append(secondary.coach_name)
        coach_ids.append(secondary.coach_id)

    # enforce max 2
    coach_names = coach_names[:2]
    coach_ids = coach_ids[:2]

    return RecommendResponse(Coach_name=coach_names, Coach_ID=coach_ids)


@app.get("/health")
def health() -> Dict[str, Any]:
    return {"status": "ok"}


@app.post("/recommend_coaches", response_model=RecommendResponse)
def recommend_endpoint(req: RecommendRequest) -> RecommendResponse:
    return recommend_coaches(req)


@app.post("/resolve_coaches", response_model=RecommendResponse)
def resolve_endpoint(payload: Dict[str, Any]) -> RecommendResponse:
    """Utility endpoint:

    If your LLM returns only IDs (or IDs+names), this normalizes and returns
    Coach_name and Coach_ID arrays.

    Expected input examples:
      {"Coach_ID": ["C001", "C005"]}
      {"Coach_ID": ["C001"], "Coach_name": ["Some Name"]}
    """
    ids = payload.get("Coach_ID")
    if not isinstance(ids, list) or len(ids) == 0:
        raise HTTPException(status_code=400, detail="Coach_ID must be a non-empty list")
    ids = [str(x).strip() for x in ids if str(x).strip()]
    ids = ids[:2]
    names: List[str] = []
    for cid in ids:
        nm = db.coach_name_by_id(cid)
        if not nm:
            raise HTTPException(status_code=400, detail=f"Unknown coach_id: {cid}")
        names.append(nm)
    return RecommendResponse(Coach_name=names, Coach_ID=ids)
