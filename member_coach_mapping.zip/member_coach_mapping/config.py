"""Shared configuration.

This app reuses the same SQLite database that stores coaches.
You can override the DB path using the environment variable APP_DB_PATH.
"""

from __future__ import annotations

import os
from pathlib import Path


DB_PATH = os.getenv("APP_DB_PATH", "local_coaches.db")

# Optional: where coach instruction markdowns live (not required for mapping UI)
COACH_INSTRUCTIONS_DIR = Path(os.getenv("COACH_INSTRUCTIONS_DIR", "coach_instructions"))
