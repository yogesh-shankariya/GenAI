"""Authentication helpers (signup + login).

This uses the same users table as the coach admin app.
"""

from __future__ import annotations

import hashlib
import hmac
import os
from datetime import datetime
from typing import Any, Dict, Optional

from .db import get_conn


def _hash_password(password: str, salt: bytes, iterations: int = 200_000) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)


def create_password_record(password: str) -> tuple[str, str, int]:
    salt = os.urandom(16)
    iterations = 200_000
    pw_hash = _hash_password(password, salt, iterations)
    return salt.hex(), pw_hash.hex(), iterations


def verify_password(password: str, salt_hex: str, hash_hex: str, iterations: int) -> bool:
    salt = bytes.fromhex(salt_hex)
    expected = bytes.fromhex(hash_hex)
    actual = _hash_password(password, salt, iterations)
    return hmac.compare_digest(actual, expected)


def get_user_by_username(username: str) -> Optional[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT user_id, username, salt_hex, hash_hex, iterations, role
        FROM users
        WHERE username = ?
        """,
        (username,),
    )
    row = cur.fetchone()
    conn.close()
    if not row:
        return None
    return {
        "user_id": row[0],
        "username": row[1],
        "salt_hex": row[2],
        "hash_hex": row[3],
        "iterations": row[4],
        "role": row[5],
    }


def create_user(username: str, password: str, role: str = "client") -> Dict[str, Any]:
    username = username.strip()
    if not username:
        raise ValueError("Username is required")
    if len(password) < 6:
        raise ValueError("Password must be at least 6 characters")

    salt_hex, hash_hex, iterations = create_password_record(password)
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        INSERT INTO users (username, salt_hex, hash_hex, iterations, role, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (username, salt_hex, hash_hex, iterations, role, datetime.utcnow().isoformat()),
    )
    conn.commit()
    user_id = cur.lastrowid
    conn.close()
    return {"user_id": user_id, "username": username, "role": role}


def authenticate(username: str, password: str) -> Optional[Dict[str, Any]]:
    user = get_user_by_username(username.strip())
    if not user:
        return None
    if not verify_password(password, user["salt_hex"], user["hash_hex"], user["iterations"]):
        return None
    return {"user_id": user["user_id"], "username": user["username"], "role": user["role"]}
