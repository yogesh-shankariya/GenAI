# Production-Readiness Review — `sqs_service/` (2026-07-27)

**Question asked:** *"Can we use this library in production as-is?"*
**Scope:** the whole `sqs_service/` package (`mps_manager.py`, `sqs_idempotent_processor.py`, `sqs_parallel_processor.py`, `_logging.py`, `__init__.py`) plus the operational surface it ships with (`constant.py`, `main.py` logging, `requirements*.txt`).
**Method:** 6 independent adversarial review passes (concurrency/crash-safety, filesystem semantics and input hygiene, AWS API correctness, the idempotency contract end-to-end, parallel-module re-check + cross-module composition, operational readiness), findings deduplicated against the two prior reviews, then every non-suggestion finding independently verified by a skeptical refuter pass (one finding was confirmed by an actual runtime reproduction, not just code reading). Prior reviews — [REVIEW_FINDINGS.md](REVIEW_FINDINGS.md) (2026-07-15) and [PARALLEL_REVIEW.md](PARALLEL_REVIEW.md) (2026-07-24) — are not re-litigated here.

---

## 1. Verdict

**As it stood at the start of this review: no.** The review confirmed 34 findings, including one **runtime-reproduced double-processing race** in the idempotency lock (two workers could both "win" the same message — the exact failure the library exists to prevent), a **poison-by-failure** semantic (one failed run permanently suppressed all retries of that message), **unsanitized external input** used in file paths and glob patterns, and **PHI-bearing payloads logged at INFO** in a healthcare pipeline.

**After this review's fixes — all applied; the behavioral library fixes are pinned by 18 net-new regression tests and the operational-surface fixes (#29–#33) verified by inspection: yes, conditionally.** The library layers (client, idempotency, parallel) are production-usable **provided the adoption checklist in §6 is followed** — most critically: the MPS volume must be a shared POSIX filesystem with working NFSv4 byte-range locks (e.g. EFS), the marker GC must actually be scheduled, and the five open architecture decisions from REVIEW_FINDINGS.md §3 (DLQ, visibility/heartbeat, DynamoDB, FIFO, purge window) still need team sign-off. Nothing in this review changes the standing fact that `main.py` does not yet enable idempotency or parallelism — wiring remains the first roadmap step.

Suite before this review: 56 passed, 7 live-gated skips. After: **74 passed, 7 skipped** (18 net-new regression tests; no existing test regressed — 2 were updated because the locking semantics they pinned were themselves the defect).

---

## 2. Fixed findings

**Accounting** (so the numbers reconcile when counting table rows): the review produced 55 raw reports → 41 unique after dedupe → **34 verified findings** (every one confirmed by the refuter pass; 0 refuted) **+ 7 unverified suggestions**; a further 9 reports were duplicates of already-documented decisions (§5). Of the 34 verified findings, **32 are fixed in the tables below** — across 29 rows, because #4 merges the two glob-injection reports and #21 merges three hook-contract reports — and **2 are documented-only** (§3: the glob-scan cost and the KAFKA-mode env coupling). (Table-row arithmetic: 33 rows total = 29 verified-finding rows + suggestion rows #18/#23 + implementation-found rows #3/#10.) Four of the suggestions are also fixed (#18, and the three merged into #23); the rest are documented in §3. Rows **#3 and #10 are extra defects discovered during implementation**, on top of the review's 34.

Severities are post-verification (the refuter pass corrected several severities and details; no finding was refuted outright). "Pre-fix" line numbers refer to the code before this change; current line numbers are given for the fix.

### 2.1 `mps_manager.py` — idempotency ledger

| # | Sev | Defect (pre-fix) | Fix applied | Why it matters in prod |
|---|-----|------------------|-------------|------------------------|
| 1 | **Major** | **Lock-steal race (TOCTOU), runtime-reproduced:** `_remove_stale_lock` aged a lock with `stat` then `unlink`ed the path without re-checking identity (pre-fix :228/:236). Two pods contending over a crashed pod's orphan lock could interleave so the loser unlinked the winner's *fresh* lock; both then held "the" mutex, both passed the pre-write check, and both wrote START — verified by a deterministic repro: two workers, both `created=True`, two START markers on disk | Replaced TTL-based lock stealing with a **kernel-held `fcntl.lockf(LOCK_EX \| LOCK_NB)`** on a per-message lock file (`create_start_marker`, mps_manager.py:254-362). The kernel releases the lock on crash (NFSv4 lease on EFS), so there is no TTL, no stealing, and no `_remove_stale_lock` at all — the lock file is never unlinked by contenders | Two pods double-processing one message is the exact failure this library exists to prevent — double OCR/LLM spend and duplicate downstream messages in a regulated pipeline |
| 2 | Minor | **Lock ownership never re-validated:** a pod paused >60s mid-critical-section (cgroup throttling, VM migration) resumed to write START and unlink a lock that had been legitimately stolen and re-acquired by another pod — cascading loss of mutual exclusion | Same root fix as #1: a kernel lock cannot expire while its holder is alive, however slow; a paused holder still owns it on resume | A single >60s stall of one pod no longer breaks exclusion for everyone |
| 3 | **Major** | **Found during implementation** (not by the review): POSIX record locks do **not** conflict between file descriptors of the *same process*, so `fcntl` alone gives cross-pod but not cross-thread exclusion — two threads in one consumer could both acquire | Added a per-lock-path in-process `threading.Lock` registry layered under the fcntl lock (`_INTRAPROCESS_LOCKS`, mps_manager.py:43-49; acquisition in `create_start_marker`) | A future threaded consumer (the pipelined mode's whole point) would have silently lost intra-pod dedup |
| 4 | **Major** | **Glob metacharacter injection:** `trace_id`/`queue_name` — external input from message bodies — were interpolated raw into glob patterns (pre-fix `_get_pattern` :149-165). A trace_id containing `*`, `?` or `[` could match *foreign* markers (false "already processed" → message skipped and lost) or be matched by others | `glob.escape()` on both components in `_get_pattern` (mps_manager.py:153-181) + input validation | An attacker-controlled or merely unlucky trace_id could suppress processing of other messages |
| 5 | **Major** | **Path traversal:** a trace_id like `../../etc/x` was joined into `storage_path / filename`, writing and globbing outside the storage directory (pre-fix `_build_filename` :313-319) | `_validate_id` (since the storage-port refactor it lives in marker_store.py:127-155, shared by every backend) rejects path separators, NUL, `.`/`..` in trace_id and queue_name at every filename/pattern/lockpath entry point | Marker files written outside the volume; ledger corruption from externally-supplied ids |
| 6 | Minor | The documented contract "trace_id must not contain `__`" (the filename separator) was never enforced — such an id silently mis-parsed into wrong trace/queue fields | Same `_validate_id`: separator in trace_id now raises `ValueError` | Silent mis-keying of the dedup ledger becomes a loud, attributable error |
| 7 | **Major** | **Poison-by-failure:** `create_end_marker(success=False)` wrote an END marker, and `has_end_marker` checked only *existence* — one failed run permanently suppressed every future retry of that message (Scenario A skip forever). Latent (nothing writes failed ENDs in prod today) but fatal once wired | `has_end_marker` (mps_manager.py:207-230) now reads marker content: only non-`"failed"` ENDs suppress. `create_end_marker` (mps_manager.py:400+) additionally removes the message's START markers so a failed message redelivers straight into Scenario D (immediate retry) instead of Scenario B (4h lease wait) | A transient failure (S3 blip) no longer condemns a message to permanent silent skipping |
| 8 | Minor | END markers were written without flush/fsync — "MPS_END will prevent reprocessing" was not crash-durable | `flush()` + `os.fsync()` before close in `create_end_marker` | The dedup record survives a crash/power loss immediately after processing |
| 9 | Minor | Constructor default `storage_path="/main_resources/runtime_files_space"` disagreed with `Constant.SQS_MPS_PATH` (`/data/main_resources/...`) and silently `mkdir`'d a root-level directory | `storage_path` is now a **required** parameter | Two halves of the system can no longer silently write ledgers to two different directories |
| 10 | Minor | `cleanup_old_markers` swept lock files on a 60s TTL — unsafe against live holders | Lock files are now removed only when **disused past the GC cutoff AND their fcntl lock is acquirable** (`_cleanup_lock_file`, mps_manager.py:529-572); `create_start_marker` touches mtime on every acquisition | GC can no longer delete a lock out from under a live holder |

### 2.2 `sqs_idempotent_processor.py` — SQS client + idempotency hooks

| # | Sev | Defect (pre-fix) | Fix applied | Why it matters in prod |
|---|-----|------------------|-------------|------------------------|
| 11 | **Major** | Module docstring prescribed **publish → delete → MPS_END** — writing the dedup record only *after* the delete reopens the crash-between-publish-and-delete duplicate window the library exists to close. (This wrong order had propagated into IDEMPOTENT_SQS_PROCESSING.md) | Docstring corrected to **publish → MPS_END → delete** with the ordering invariant spelled out (sqs_idempotent_processor.py:7-20); system doc corrected to match | Anyone wiring the hooks by following the docs would have rebuilt the §2 duplicate window |
| 12 | **Major** | `send_message_batch` chunked by the 10-entry count only, never by the per-request payload limit — 10 large messages in one request would be rejected wholesale by SQS | Size-aware chunking against `MAX_BATCH_PAYLOAD_SIZE = 1 MiB` (current AWS/moto limit), counting body + attribute bytes (sqs_idempotent_processor.py:304, :578-600) | Bulk sends of large documents no longer fail as a whole request |
| 13 | Minor | `_validate_message_size` counted only the body; SQS counts **body + message attributes** — attribute-heavy messages passed validation then got rejected by the API | Validation now includes formatted attribute bytes (`_attributes_size` + `_validate_message_size`, sqs_idempotent_processor.py:877-933), applied in `send_message` and the batch path | The size guard now guards the thing SQS actually enforces |
| 14 | Minor | Trace-id attribute inconsistency: `_publish_with_retry` wrote `"TraceId"` while `SQSMessage.from_sqs_response` reads `"trace_id"` — the consumer-side attribute fallback could never fire for these messages | Key changed to `"trace_id"` (sqs_idempotent_processor.py:962) + a moto publish→receive round-trip test | Dedup keying survives for messages whose body carries no trace_id |
| 15 | Minor | `_delete_with_retry` swallowed terminal failure returning `{}` behind the comment "MPS_END will prevent reprocessing" — **false when idempotency is disabled** (the default) | Terminal failure now raises when idempotency is disabled; logs at ERROR (not INFO) in all cases; non-retryable codes fail fast (sqs_idempotent_processor.py:1002-1064) | A swallowed delete failure was a silently *guaranteed* duplicate reprocess |
| 16 | Sugg. | Both retry helpers retried every `ClientError`, including ones that fail identically forever (bad receipt handle, nonexistent queue, access denied) | `NON_RETRYABLE_ERROR_CODES` short-circuit in both helpers (sqs_idempotent_processor.py:311-319) | No pointless retry-sleep latency in front of certain failure |
| 17 | Minor | `send_message_batch` mixed explicit and index-default entry Ids — an explicit `Id="1"` colliding with another entry's default made SQS reject the request and the aggregated result ambiguous | Global Id-uniqueness validation up front, raising `ValidationError` naming the duplicates (sqs_idempotent_processor.py:569-576) | Fail fast with a clear message instead of a whole-request API error |
| 18 | Sugg. | Batch retry re-sent `SenderFault` entries (malformed by us) that deterministically fail again | Retry now skips SenderFault entries; they go straight to the `Failed` aggregate | The single retry is spent only where it can help |
| 19 | Minor | `delete_msg_batch` used chunk-relative entry Ids (`0..9` per chunk) — beyond 10 handles, `Failed`/`Successful` Ids were ambiguous | Global caller-list indexes as Ids + a 25-handle test asserting them | Callers can map failures back to specific handles |
| 20 | Minor | With `region_name` omitted and only a `queue_url` given, the session fell back to the default-chain region — a mismatch fails every call | Region is derived from the queue URL host when unset (`_region_from_queue_url`, sqs_idempotent_processor.py:452) | URL-constructed clients work without ambient region config |
| 21 | Minor | Hook contract traps undocumented: `check_duplicates` covers Scenario A only; `mark_processing_start`'s `False` means *skip but do NOT delete*; disabled-idempotency hooks silently return protection-shaped no-op values | All three docstrings now state the exact contract (sqs_idempotent_processor.py:1149-1210); the constructor logs an INFO notice when idempotency is disabled | Consumers wiring the hooks can no longer plausibly mis-order or half-use them |
| 22 | Minor | `mark_processing_end` raised `OSError` after side effects (publish) were committed — inverting a *successful* message into a failure | Catches `OSError`, logs at ERROR, returns `bool` ("False = dedup memory lost; still ack the message") — sqs_idempotent_processor.py:1193-1245 | A marker-write blip no longer sends an already-published message to the error path |
| 23 | Sugg. | `send_message_with_idempotency` mutated the caller's `message_attributes` dict (leaked `trace_id` into reused dicts); unused idempotency imports misled reviewers; explicit `visibility_timeout` unclamped | Copies the dict; dead imports removed (package exports unaffected — `__init__.py` imports from `mps_manager` directly); visibility clamped to the 12h SQS max | Hygiene: no caller-visible side effects, no misleading dead code |

### 2.3 `sqs_parallel_processor.py`

| # | Sev | Defect (pre-fix) | Fix applied | Why it matters in prod |
|---|-----|------------------|-------------|------------------------|
| 24 | **Major** | **Handler starvation of idempotency:** the handler received only the Body *string*, so it could not read `MessageId`, `ReceiptHandle`, message attributes (the trace_id fallback!) or `ApproximateReceiveCount` — idempotent parallel consumption was structurally impossible, and the contract also mismatched `main.process_sqs_message` (expects the dict) | Opt-in `message_arg="message"` constructor flag passes the full boto3 message dict in all four execution paths (threads/asyncio/processes/pipelined); default `"body"` preserves the existing contract (sqs_parallel_processor.py:72-116) | Unblocks composing parallelism with the idempotency hooks, and wiring `main.py` needs only `message_arg="message"` plus its existing function |
| 25 | **Major** | Pipelined mode with `wait_time_seconds=0`: `min(1, 0) == 0` produced zero-wait receives — a hot loop hammering the SQS API when idle | Busy-path wait is now a flat 1s; an idle empty receive with wait 0 sleeps 100ms (sqs_parallel_processor.py:782, :802) | No CPU burn and no per-request SQS API cost explosion on a quiet queue |
| 26 | Minor | Asyncio mode ran the blocking long-poll receive on the *same* thread pool as sync handlers — a pool full of slow/abandoned handlers starves the receive itself | Dedicated single-thread `sqs-receive` executor (sqs_parallel_processor.py:123-136), shut down in `close()` | Receive latency is independent of handler behavior |
| 27 | Minor | Broken-process-pool detection read the private CPython attribute `_broken` only | Exception-driven `except BrokenProcessPool` around submit with a one-shot pool rebuild and retry; the attribute check remains as best-effort post-collect (sqs_parallel_processor.py:39, :474-489) | Survives CPython internals changing; a crashed worker pool heals in-call |
| 28 | Minor | Drain-timeout expiry `cancel()`ed still-running futures, counted them failed, and logged "it will redeliver" — but a running handler may still complete *and delete* | Branches on `future.cancel()`: cancelled-before-start → "will redeliver"; still-running → logged as abandoned/unreported (sqs_parallel_processor.py:848-868) | Shutdown logs no longer promise redelivery for messages that may in fact complete |

### 2.4 Operational surface

| # | Sev | Defect | Fix applied | Why it matters in prod |
|---|-----|--------|-------------|------------------------|
| 29 | **Major** | **PHI in logs:** `main.py` logged full message bodies and pipeline outputs at INFO (`Message Body`, `Final output`, `Posting {payload}`, `Response from Doc-Extract`) — patient document data into the log platform of a healthcare pipeline | INFO now logs identifiers only (trace_id, status_code, err_msg); full payloads moved to DEBUG level *and* gated behind `Constant.DEBUG_MODE` (main.py:92, :220, :326, :344, :394). Residual: the Kafka lifecycle-marker messages still embed payloads — flagged for the team, not changed (client-env log topic contract) | Log-platform PHI exposure is an audit finding on its own, independent of any code correctness |
| 30 | **Major** | Unpinned `>=` requirements, no lockfile, no declared Python constraint — on a Python 3.9 runtime that is EOL (Oct 2025) and that boto3 stops supporting 2026-04-29 | Added `requirements.lock.txt` (exact pins captured from the verified venv); `requirements.txt` now documents the lock and the required runtime migration. **The Python ≥ 3.10 migration itself is an ops action this review cannot perform** — see checklist §6 | Reproducible builds; a dated, explicit runway off an EOL runtime |
| 31 | Minor | `Constant.DEBUG_MODE = bool(int(env))` crashed the whole process at import when ops set `DEBUG_MODE=true` | Tolerant parse: `1/true/yes/on` (any case) → True (constant.py:28-34) | A logging toggle can no longer take down the consumer at startup |
| 32 | Minor | `_logging.get_logger()` caught bare `Exception` — a *misconfigured* `log_util` silently downgraded prod to stdlib logging | `ImportError` (expected outside client env) still falls back silently; any other failure emits a loud WARNING that structured logging is not active (_logging.py) | Losing the structured logging config in prod is now visible |
| 33 | Minor | No `__version__`, no way to identify a deployed build | `sqs_service.__version__ = "1.1.0"` (\_\_init\_\_.py:4). Full packaging metadata (pyproject) remains a recommendation | "Which build is running?" has an answer |

---

## 3. Documented decisions (deliberately NOT fixed in code)

| Item | Why documented instead of fixed |
|---|---|
| O(directory) glob scan per duplicate check (~4 scans/message over up to 7 days of markers) | A sharded on-disk layout is a migration-bearing format change that the open **DynamoDB decision** (REVIEW_FINDINGS.md §3.3) would supersede entirely. Fix it by deciding §3.3, not by entrenching the filesystem backend |
| `constant.py` requires all four `SQS_*` env vars at import even when `INPUT_QUEUE_TYPE=KAFKA` | The verified fix requires restructuring `main.py`'s module-scope `SQSClient` construction, not just lazy env validation — a consumer-app refactor outside this library review's boundary |
| `KeyboardInterrupt` in pipelined mode skips the drain (documented behavior: in-flight work finishes in the background or redelivers) | Intentional operator-facing semantics; `stop_event` is the graceful path |
| Kafka lifecycle-marker messages still embed full payloads | Client-environment log-topic contract; changing it unilaterally could break their tooling. Flagged to the team alongside finding #29 |
| Python ≥ 3.10 runtime migration | Infrastructure action; the code and lockfile are ready, the runtime swap is the team's |

## 4. Refuter-pass corrections (no findings refuted)

Every one of the 34 verified findings was confirmed (0 refuted) — but the refuter pass materially *corrected* several, and those corrections are reflected above; notably: EFS clock skew makes lock-stealing likely but not "systematic" double-processing (the post-lock re-check still guards); the batch payload limit is 1 MiB (2025 AWS change), not 256 KiB; `_delete_with_retry` and `_publish_with_retry` were dead code with no in-repo callers (their defects were latent, fixed for when they are wired); the poison-by-failure and handler-contract findings are latent until idempotency/parallelism are wired into `main.py`.

## 5. Carried forward (already documented, unchanged)

The 9 carried-forward items live where they were: REVIEW_FINDINGS.md §3 (no DLQ/redrive; visibility timeout vs processing time — including the hardcoded 300s receive default and the 60s parallel default; shared-volume vs DynamoDB; Standard-vs-FIFO; purge window) and IDEMPOTENT_SQS_PROCESSING.md (trace_id fallback silently exempting messages from dedup — §4.3/§8.1; no metrics, logs only — §8.8; GC has no shipped entrypoint — §7b Gap 6; the `main.py` wiring gap itself — §7b Gap 1).

## 6. Production adoption checklist

Before pointing this at production traffic:

1. **Wire idempotency in `main.py`**: construct the input client with `enable_idempotency=True, mps_storage_path=Constant.SQS_MPS_PATH`; call `check_duplicates` → `mark_processing_start` → process → publish → `mark_processing_end` → delete (that order — §2.2 #11).
2. **MPS volume**: a shared POSIX filesystem mounted by all pods, with working NFSv4 byte-range locks (EFS qualifies). Single-pod local disk also works. Anything else (e.g. per-pod disks) silently voids cross-pod dedup.
3. **Schedule the GC**: a daily K8s CronJob invoking `MPSManager(storage_path=...).cleanup_old_markers()` — nothing in the repo runs it.
4. **Visibility timeout**: size above worst-case doc-extract time (there is no heartbeat — REVIEW_FINDINGS.md §3.2); note `receive_messages` defaults to 300s when not passed explicitly.
5. **Runtime**: install from `requirements.lock.txt`; plan the Python ≥ 3.10 migration before 2026-04-29 (boto3 support cutoff).
6. **Decide the five §3 architecture items** — DLQ + redrive first (it also fixes the delete-on-failure retry gap in `main.py`).
7. For parallel consumption later: `ParallelSQSProcessor(..., message_arg="message")` gives handlers the full message dict; `main.process_sqs_message` is then directly compatible.

## 7. How this was verified

- Full suite in `SQS/venv` (moto only, zero live AWS): **74 passed, 7 skipped** (live-gated) — up from 56/7, a net gain of 18 test functions. The behavioral fixes are pinned by: the two-worker race single-winner test, failed-END retry, END-removes-START, separator rejection + traversal rejection + glob-metachar isolation (three functions), payload-size chunking (with request counting), attribute-inclusive size validation, duplicate batch Ids, trace_id publish round-trip, global delete-batch Ids, non-retryable fail-fast, no caller-dict mutation, URL region derivation, pinned disabled-hook returns, END-write-failure reporting, `message_arg="message"`, and `message_arg` validation — plus the two *updated* lock tests described below (held-lock blocking via a real child process; disused-lock GC safety).
- Two pre-existing tests were *updated*, not deleted: `test_fresh_lock_blocks_concurrent_creation` → `test_held_lock_blocks_concurrent_creation` (a lock *file* no longer blocks — only a *held* lock does, which is the fix working as intended) and the lock-sweep test (60s TTL → GC-cutoff semantics).
- Every changed file passes `python -m py_compile`.
- This document's claims were fact-checked against the final source before delivery.

(A follow-up change added the MarkerStore storage-port abstraction with config-driven backend selection and 31 further contract/factory tests; the suite now stands at 105 passed, 7 skipped.)

## 8. Related documents

- [IDEMPOTENT_SQS_PROCESSING.md](IDEMPOTENT_SQS_PROCESSING.md) — full system documentation (updated in this change to match the new locking and END semantics)
- [REVIEW_FINDINGS.md](REVIEW_FINDINGS.md) — 2026-07-15 review; §3 holds the five open architecture decisions
- [PARALLEL_REVIEW.md](PARALLEL_REVIEW.md) — 2026-07-24 parallel-module review (20 findings, all fixed)
- [CHANGES.md](CHANGES.md) — original defect-fix log
