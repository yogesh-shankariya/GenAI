"""
local_call_main_test.py

Run the doc-extract pipeline once with hard-coded parameters.
Kafka is NOT required.

CLIENT ENVIRONMENT ONLY: this uploads a file to the client S3 bucket
and calls the real pipeline, so it is gated behind RUN_LIVE=1 and does
nothing at import time.

1. Make sure you can run doc_extract_app/main.py manually first
   (AWS creds etc. must be available).
2. Adjust the configuration values below.
3. RUN_LIVE=1 python test/test.py
"""

import os
import pathlib
import sys
import uuid

sys.path.insert(
    0,
    str(pathlib.Path(__file__).resolve().parents[1]),
)


# ====== Configuration ======
PROJECT_DIR = pathlib.Path(__file__).resolve().parent
LOCAL_INPUT_PATH = (
    PROJECT_DIR / "small_fil_test.pdf"
)  # <-- adjust
DOCBINARY_FILE = None  # Optional, set if needed
OUTPUT_FILE = "final_output.json"
S3_BUCKET = (
    "eai-praas-prdint-ramcre-dv-nogbd-"
    "s3-bucket-codez-phi-us-east-1"
)
S3_REGION = "us-east-1"  # Change to your region
RA_MNEMONIC = "abc"  # Update based on your processor config


def main():
    if os.environ.get("RUN_LIVE") != "1":
        print(
            "REFUSING to run: this uploads to a real client S3 bucket "
            "and invokes the live pipeline. Set RUN_LIVE=1 to confirm "
            "(client environment only)."
        )
        sys.exit(2)

    if not LOCAL_INPUT_PATH.exists():
        print(f"Input file not found: {LOCAL_INPUT_PATH}")
        sys.exit(1)

    import boto3

    # Imports client-environment-only modules (log_util, ddtrace, ...)
    from main import run_pipeline_in_process

    s3_client = boto3.client("s3", region_name=S3_REGION)

    # ====== Upload to S3 ======
    s3_key = f"test_inputs/{os.path.basename(LOCAL_INPUT_PATH)}"

    print(
        f"Uploading {LOCAL_INPUT_PATH} to "
        f"s3://{S3_BUCKET}/{s3_key} ..."
    )

    with open(LOCAL_INPUT_PATH, "rb") as f:
        s3_client.upload_fileobj(f, S3_BUCKET, s3_key)

    print("Upload complete.")

    # ====== Call and show result ======
    trace_id = str(uuid.uuid4())

    os.environ["AWS_S3_BUCKET"] = S3_BUCKET
    os.environ["AWS_S3_REGION"] = S3_REGION

    import logging

    out = run_pipeline_in_process(
        s3_key=s3_key,
        trace_id=trace_id,
        ra_mnemonic=RA_MNEMONIC,
        base_location=f"test/{trace_id}/",
        doc_binary_path=DOCBINARY_FILE,
        logger_=logging.getLogger(__name__),
    )

    print("\nReturned JSON:")
    print(out)


if __name__ == "__main__":
    main()
