"""
ParallelSQSProcessor tests against moto (in-process fake SQS).

No AWS calls leave the machine: conftest.py forces fake credentials
and every test runs inside mock_aws(). The multiprocessing tests work
under moto because worker processes perform no AWS calls at all -
deletes happen in the parent (see _delete_in_parent).
"""

import asyncio
import json
import threading
import time
from unittest import mock

import boto3
import pytest
from botocore.exceptions import ClientError
from moto import mock_aws

from sqs_service import (
    ParallelSQSProcessor,
    SQSClient,
    process_messages_parallel,
)


REGION = "us-east-2"
QUEUE = "test-parallel-queue"


# ----------------------------------------------------------------------
# Module-level processing functions (picklable for the 'processes' mode)
# ----------------------------------------------------------------------

_BLOCK_EVENT = threading.Event()


def _echo(body):
    return json.loads(body)["index"]


def _boom(body):
    raise ValueError("boom")


def _return_false(body):
    return False


def _block_until_released(body):
    _BLOCK_EVENT.wait(10)
    return "done"


async def _async_echo(body):
    await asyncio.sleep(0)
    return json.loads(body)["index"]


# ----------------------------------------------------------------------
# Fixtures / helpers
# ----------------------------------------------------------------------


@pytest.fixture
def sqs_client():
    with mock_aws():
        boto3.client("sqs", region_name=REGION).create_queue(
            QueueName=QUEUE
        )
        yield SQSClient(queue_name=QUEUE, region_name=REGION)


def _send(client, count):
    for i in range(count):
        client.send_message({"index": i})


def _client_error(operation="DeleteMessage"):
    return ClientError(
        {"Error": {"Code": "Throttling", "Message": "slow down"}},
        operation,
    )


# ----------------------------------------------------------------------
# Thread mode
# ----------------------------------------------------------------------


def test_threads_processes_and_deletes_on_success(sqs_client):
    _send(sqs_client, 5)

    with ParallelSQSProcessor(
        sqs_client, _echo, max_workers=5, delete_on_success=True
    ) as processor:
        results = processor.process_with_threads(
            max_messages=5, wait_time_seconds=0
        )

    assert len(results["successful"]) == 5
    assert results["failed"] == []

    for entry in results["successful"]:
        assert entry["receipt_handle"]
        assert entry["deleted"] is True
        assert entry["message_id"]

    assert sqs_client.receive_messages(max_messages=10) == []


def test_threads_default_keeps_messages_and_returns_receipt_handles(
    sqs_client,
):
    _send(sqs_client, 3)

    with ParallelSQSProcessor(
        sqs_client, _echo, max_workers=3, visibility_timeout=0
    ) as processor:
        results = processor.process_with_threads(
            max_messages=3, wait_time_seconds=0
        )

    assert len(results["successful"]) == 3

    for entry in results["successful"]:
        assert entry["deleted"] is False
        assert entry["receipt_handle"]

    # visibility_timeout=0: undeleted messages are immediately
    # re-receivable - proof nothing was deleted
    assert len(sqs_client.receive_messages(max_messages=10)) == 3


def test_delete_failure_reported_as_success_not_deleted(sqs_client):
    _send(sqs_client, 1)

    with ParallelSQSProcessor(
        sqs_client, _echo, max_workers=1, delete_on_success=True
    ) as processor:
        with mock.patch.object(
            processor.client,
            "delete_msg",
            side_effect=_client_error(),
        ):
            results = processor.process_with_threads(
                max_messages=1, wait_time_seconds=0
            )

    assert len(results["successful"]) == 1
    entry = results["successful"][0]
    assert entry["success"] is True
    assert entry["deleted"] is False
    assert "Throttling" in entry["delete_error"]
    assert results["failed"] == []


def test_returning_false_is_failure_and_message_not_deleted(sqs_client):
    _send(sqs_client, 1)

    with ParallelSQSProcessor(
        sqs_client,
        _return_false,
        max_workers=1,
        delete_on_success=True,
        visibility_timeout=0,
    ) as processor:
        results = processor.process_with_threads(
            max_messages=1, wait_time_seconds=0
        )

    assert results["successful"] == []
    assert len(results["failed"]) == 1
    assert (
        results["failed"][0]["error"]
        == "processing_function returned False"
    )

    # Not deleted despite delete_on_success=True
    assert len(sqs_client.receive_messages(max_messages=10)) == 1


def test_exception_is_failure_with_receipt_handle(sqs_client):
    _send(sqs_client, 1)

    with ParallelSQSProcessor(
        sqs_client, _boom, max_workers=1
    ) as processor:
        results = processor.process_with_threads(
            max_messages=1, wait_time_seconds=0
        )

    assert len(results["failed"]) == 1
    entry = results["failed"][0]
    assert entry["success"] is False
    assert "boom" in entry["error"]
    assert entry["receipt_handle"]


def test_receive_accumulates_beyond_sqs_10_message_cap(sqs_client):
    _send(sqs_client, 25)

    with ParallelSQSProcessor(
        sqs_client, _echo, max_workers=25, delete_on_success=True
    ) as processor:
        results = processor.process_with_threads(
            max_messages=25, wait_time_seconds=0
        )

    assert len(results["successful"]) == 25
    assert sqs_client.receive_messages(max_messages=10) == []


def test_receive_capped_at_max_workers(sqs_client):
    _send(sqs_client, 10)

    with ParallelSQSProcessor(
        sqs_client, _echo, max_workers=3, delete_on_success=True
    ) as processor:
        results = processor.process_with_threads(
            max_messages=10, wait_time_seconds=0
        )

    # Only max_workers messages received - the rest keep their
    # visibility timeout intact instead of burning it in a queue
    assert (
        len(results["successful"]) + len(results["failed"]) == 3
    )


def test_batch_timeout_records_pending_as_failed(sqs_client):
    _BLOCK_EVENT.clear()
    _send(sqs_client, 2)

    processor = ParallelSQSProcessor(
        sqs_client,
        _block_until_released,
        max_workers=2,
    )

    try:
        results = processor.process_with_threads(
            max_messages=2,
            wait_time_seconds=0,
            batch_timeout=0.5,
        )

        assert len(results["failed"]) == 2
        for entry in results["failed"]:
            assert "batch_timeout" in entry["error"]
    finally:
        _BLOCK_EVENT.set()
        processor.close()


# ----------------------------------------------------------------------
# Continuous / pipelined modes
# ----------------------------------------------------------------------


def test_continuous_loop_survives_transient_client_error(sqs_client):
    processor = ParallelSQSProcessor(sqs_client, _echo)

    receive = mock.patch.object(
        processor.client,
        "receive_messages",
        side_effect=[_client_error("ReceiveMessage"), KeyboardInterrupt()],
    )

    with receive as mocked:
        # Must NOT raise: the ClientError is absorbed with backoff,
        # the KeyboardInterrupt exits cleanly
        processor.continuous_processing_with_threads(
            wait_time_seconds=0, error_backoff_seconds=0
        )

    assert mocked.call_count == 2
    processor.close()


def test_continuous_stop_event_exits_without_polling(sqs_client):
    processor = ParallelSQSProcessor(sqs_client, _echo)
    stop = threading.Event()
    stop.set()

    with mock.patch.object(
        processor.client, "receive_messages"
    ) as mocked:
        processor.continuous_processing_with_threads(stop_event=stop)

    mocked.assert_not_called()
    processor.close()


def test_pipelined_processes_everything_and_stops_gracefully(
    sqs_client,
):
    _send(sqs_client, 25)

    processor = ParallelSQSProcessor(
        sqs_client, _echo, max_workers=5, delete_on_success=True
    )
    stop = threading.Event()
    collected = []

    runner = threading.Thread(
        target=lambda: collected.append(
            processor.process_pipelined_with_threads(
                wait_time_seconds=0,
                stop_event=stop,
                on_result=lambda r: collected.append(r),
            )
        )
    )
    runner.start()

    deadline = time.time() + 15
    while time.time() < deadline:
        per_message = [c for c in collected if "success" in c]
        if len(per_message) >= 25:
            break
        time.sleep(0.05)

    stop.set()
    runner.join(timeout=15)
    assert not runner.is_alive()

    counts = collected[-1]
    assert counts["successful_count"] == 25
    assert counts["failed_count"] == 0
    assert sqs_client.receive_messages(max_messages=10) == []
    processor.close()


# ----------------------------------------------------------------------
# Multiprocessing mode
# ----------------------------------------------------------------------


def test_multiprocessing_deletes_in_parent(sqs_client):
    _send(sqs_client, 3)

    with ParallelSQSProcessor(
        sqs_client, _echo, max_workers=3, delete_on_success=True
    ) as processor:
        results = processor.process_with_multiprocessing(
            max_messages=3, wait_time_seconds=0
        )

    assert len(results["successful"]) == 3

    for entry in results["successful"]:
        assert entry["deleted"] is True
        assert entry["receipt_handle"]

    # Deleted via the PARENT's client (workers do no AWS calls -
    # this passing under moto is itself the proof)
    assert sqs_client.receive_messages(max_messages=10) == []


def test_multiprocessing_rejects_unpicklable_function(sqs_client):
    with ParallelSQSProcessor(
        sqs_client, lambda body: body, max_workers=1
    ) as processor:
        with pytest.raises(TypeError, match="picklable"):
            processor.process_with_multiprocessing(max_messages=1)


# ----------------------------------------------------------------------
# Asyncio mode
# ----------------------------------------------------------------------


def test_asyncio_mode_with_sync_function(sqs_client):
    _send(sqs_client, 4)

    with ParallelSQSProcessor(
        sqs_client, _echo, max_workers=4, delete_on_success=True
    ) as processor:
        results = asyncio.run(
            processor.process_with_asyncio(
                max_messages=4, wait_time_seconds=0
            )
        )

    assert len(results["successful"]) == 4
    assert all(e["deleted"] for e in results["successful"])
    assert sqs_client.receive_messages(max_messages=10) == []


def test_asyncio_mode_with_async_function(sqs_client):
    _send(sqs_client, 3)

    with ParallelSQSProcessor(
        sqs_client, _async_echo, max_workers=3, delete_on_success=True
    ) as processor:
        results = asyncio.run(
            processor.process_with_asyncio(
                max_messages=3, wait_time_seconds=0
            )
        )

    assert len(results["successful"]) == 3
    assert sqs_client.receive_messages(max_messages=10) == []


# ----------------------------------------------------------------------
# Quick helper
# ----------------------------------------------------------------------


def test_helper_plumbs_delete_on_success(sqs_client):
    _send(sqs_client, 5)

    results = process_messages_parallel(
        sqs_client,
        _echo,
        max_messages=5,
        max_workers=5,
        delete_on_success=True,
        wait_time_seconds=0,
    )

    assert len(results["successful"]) == 5
    assert sqs_client.receive_messages(max_messages=10) == []


def test_helper_rejects_unknown_method(sqs_client):
    with pytest.raises(ValueError, match="Unknown method"):
        process_messages_parallel(
            sqs_client, _echo, method="fibers"
        )


# ----------------------------------------------------------------------
# Production-readiness review regression tests (2026-07-27)
# ----------------------------------------------------------------------


def test_message_arg_message_passes_full_dict(sqs_client):
    _send(sqs_client, 3)
    seen = []

    def handler(payload):
        seen.append(payload)
        return True

    with ParallelSQSProcessor(
        client=sqs_client,
        processing_function=handler,
        max_workers=3,
        delete_on_success=True,
        message_arg="message",
    ) as processor:
        results = processor.process_with_threads(max_messages=3)

    assert len(results["successful"]) == 3
    assert all(isinstance(p, dict) for p in seen)
    # The full dict exposes what idempotent consumption needs
    # (MessageId, ReceiptHandle, attributes) - the Body string alone
    # could not support attribute-keyed trace ids
    assert all("MessageId" in p and "Body" in p for p in seen)


def test_message_arg_rejects_unknown_value(sqs_client):
    with pytest.raises(ValueError, match="message_arg"):
        ParallelSQSProcessor(
            client=sqs_client,
            processing_function=_echo,
            message_arg="raw",
        )
