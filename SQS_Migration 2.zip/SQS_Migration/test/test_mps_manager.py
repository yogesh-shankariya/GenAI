"""
Unit tests for the MPS (Message Processing State) idempotency layer.

Pure filesystem tests - no AWS, no mocks needed.
"""

import fcntl
import os
import subprocess
import sys
import threading
import time
import uuid

import pytest

from sqs_service.mps_manager import (
    MPSManager,
    MPSType,
    check_duplicate_status,
)


QUEUE = "dev-HOSSYTH_rallm"


@pytest.fixture
def manager(tmp_path):
    return MPSManager(storage_path=str(tmp_path))


_HOLD_LOCK_SCRIPT = (
    "import fcntl, os, sys, time\n"
    "fd = os.open(sys.argv[1], os.O_CREAT | os.O_WRONLY, 0o644)\n"
    "fcntl.lockf(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)\n"
    "print('locked', flush=True)\n"
    "time.sleep(30)\n"
)


def _hold_lock_in_child_process(lock_path):
    """
    Start a child process that fcntl-locks lock_path (POSIX record
    locks only conflict ACROSS processes, so an in-test lock would
    not block the code under test).
    """
    proc = subprocess.Popen(
        [sys.executable, "-c", _HOLD_LOCK_SCRIPT, str(lock_path)],
        stdout=subprocess.PIPE,
        text=True,
    )
    assert proc.stdout.readline().strip() == "locked"
    return proc


def test_build_and_parse_roundtrip(manager):
    trace_id = str(uuid.uuid4())
    ts = time.time()

    filename = manager._build_filename(
        trace_id, QUEUE, MPSType.START, 2, ts
    )
    info = manager._parse_filename(filename)

    assert info is not None
    assert info.trace_id == trace_id
    assert info.queue_name == QUEUE
    assert info.mps_type == MPSType.START
    assert info.retry_count == 2
    assert info.timestamp == pytest.approx(ts)


def test_parse_queue_name_containing_separator(manager):
    trace_id = str(uuid.uuid4())
    queue = "dev__weird__queue"

    filename = manager._build_filename(
        trace_id, queue, MPSType.END, 0, time.time()
    )
    info = manager._parse_filename(filename)

    assert info is not None
    assert info.queue_name == queue


def test_end_marker_detected(manager):
    trace_id = str(uuid.uuid4())

    assert not manager.has_end_marker(trace_id, QUEUE)

    manager.create_end_marker(trace_id, QUEUE, success=True)

    assert manager.has_end_marker(trace_id, QUEUE)


def test_start_marker_created_and_found(manager):
    trace_id = str(uuid.uuid4())

    created, filepath = manager.create_start_marker(trace_id, QUEUE)

    assert created
    assert os.path.exists(filepath)

    marker = manager.get_start_marker(trace_id, QUEUE)

    assert marker is not None
    assert marker.trace_id == trace_id


def test_second_start_marker_refused(manager):
    trace_id = str(uuid.uuid4())

    created_first, _ = manager.create_start_marker(trace_id, QUEUE)
    created_second, _ = manager.create_start_marker(trace_id, QUEUE)

    assert created_first
    assert not created_second


def test_stale_start_marker_allows_takeover(tmp_path):
    # 0-second timeout: every START marker is immediately stale
    manager = MPSManager(storage_path=str(tmp_path), timeout_seconds=0)
    trace_id = str(uuid.uuid4())

    created_first, _ = manager.create_start_marker(trace_id, QUEUE)
    assert created_first

    # Crashed-pod takeover: stale marker must not block a new owner
    created_second, _ = manager.create_start_marker(trace_id, QUEUE)
    assert created_second


def test_orphaned_lock_does_not_block_forever(manager, tmp_path):
    trace_id = str(uuid.uuid4())

    # Simulate a pod that died mid-create: its lock FILE remains but
    # the kernel released its fcntl lock at crash, so a new pod
    # acquires immediately - no TTL wait, no stale-lock stealing.
    lock_path = manager._lock_filepath(trace_id, QUEUE)
    lock_path.touch()

    created, _ = manager.create_start_marker(trace_id, QUEUE)

    assert created


def test_held_lock_blocks_concurrent_creation(manager):
    trace_id = str(uuid.uuid4())

    # Another pod (child process) holds the fcntl lock mid-create
    lock_path = manager._lock_filepath(trace_id, QUEUE)
    proc = _hold_lock_in_child_process(lock_path)

    try:
        created, _ = manager.create_start_marker(trace_id, QUEUE)
        assert not created
    finally:
        proc.kill()
        proc.wait()

    # Once the holder releases (or crashes), creation proceeds
    created, _ = manager.create_start_marker(trace_id, QUEUE)
    assert created


def test_concurrent_start_creation_single_winner(manager):
    # The TOCTOU regression test: two workers race through
    # create_start_marker from an existing orphan lock file; exactly
    # one may win, in every interleaving.
    trace_id = str(uuid.uuid4())
    manager._lock_filepath(trace_id, QUEUE).touch()  # orphan lock

    barrier = threading.Barrier(2)
    results = []

    def contender():
        barrier.wait()
        created, _ = manager.create_start_marker(trace_id, QUEUE)
        results.append(created)

    threads = [threading.Thread(target=contender) for _ in range(2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert sorted(results) == [False, True]
    start_markers = manager.find_mps_files(trace_id, QUEUE, MPSType.START)
    assert len(start_markers) == 1


def test_cleanup_old_markers(manager):
    trace_id = str(uuid.uuid4())

    old_ts = time.time() - 8 * 24 * 60 * 60  # 8 days old
    old_file = manager.storage_path / manager._build_filename(
        trace_id, QUEUE, MPSType.END, 0, old_ts
    )
    old_file.write_text("success")

    fresh_trace = str(uuid.uuid4())
    manager.create_end_marker(fresh_trace, QUEUE)

    removed = manager.cleanup_old_markers()

    assert removed == 1
    assert not old_file.exists()
    assert manager.has_end_marker(fresh_trace, QUEUE)


def test_cleanup_old_markers_sweeps_disused_locks(manager):
    trace_id = str(uuid.uuid4())

    # A lock file not used since the cleanup cutoff is removed...
    lock_path = manager._lock_filepath(trace_id, QUEUE)
    lock_path.touch()
    old = time.time() - 8 * 24 * 60 * 60
    os.utime(lock_path, (old, old))

    removed = manager.cleanup_old_markers()

    assert removed == 1
    assert not lock_path.exists()

    # ...but never while a pod is holding it, however old the mtime
    held_trace = str(uuid.uuid4())
    held_path = manager._lock_filepath(held_trace, QUEUE)
    proc = _hold_lock_in_child_process(held_path)
    os.utime(held_path, (old, old))

    try:
        assert manager.cleanup_old_markers() == 0
        assert held_path.exists()
    finally:
        proc.kill()
        proc.wait()


def test_check_duplicate_status_scenarios(tmp_path):
    manager = MPSManager(storage_path=str(tmp_path))
    trace_id = str(uuid.uuid4())

    # Scenario D: no markers -> process
    result = check_duplicate_status(manager, trace_id, QUEUE)
    assert result.should_process
    assert not result.is_takeover

    # Scenario B: live START -> skip
    manager.create_start_marker(trace_id, QUEUE)
    result = check_duplicate_status(manager, trace_id, QUEUE)
    assert not result.should_process

    # Scenario A: END exists -> skip
    manager.create_end_marker(trace_id, QUEUE)
    result = check_duplicate_status(manager, trace_id, QUEUE)
    assert not result.should_process
    assert "MPS_END" in result.reason


def test_check_duplicate_status_stale_start_is_takeover(tmp_path):
    manager = MPSManager(storage_path=str(tmp_path), timeout_seconds=0)
    trace_id = str(uuid.uuid4())

    manager.create_start_marker(trace_id, QUEUE)

    result = check_duplicate_status(manager, trace_id, QUEUE)

    assert result.should_process
    assert result.is_takeover


def test_failed_end_marker_does_not_suppress_retry(manager):
    # Poison-by-failure regression: one failed run must not
    # permanently block the message from ever being retried.
    trace_id = str(uuid.uuid4())

    manager.create_start_marker(trace_id, QUEUE)
    manager.create_end_marker(trace_id, QUEUE, success=False)

    assert not manager.has_end_marker(trace_id, QUEUE)

    # The failed END also removed the START, so redelivery lands in
    # Scenario D (fresh processing), not Scenario B (4h lease wait)
    result = check_duplicate_status(manager, trace_id, QUEUE)
    assert result.should_process
    assert not result.is_takeover

    # A subsequent SUCCESSFUL run then suppresses duplicates
    manager.create_end_marker(trace_id, QUEUE, success=True)
    assert manager.has_end_marker(trace_id, QUEUE)


def test_end_marker_removes_start_markers(manager):
    trace_id = str(uuid.uuid4())

    manager.create_start_marker(trace_id, QUEUE)
    manager.create_end_marker(trace_id, QUEUE, success=True)

    assert manager.get_start_marker(trace_id, QUEUE) is None
    assert manager.has_end_marker(trace_id, QUEUE)


def test_trace_id_with_separator_rejected(manager):
    # The docstring contract ("trace_id must not contain __") is now
    # enforced instead of silently corrupting filename parsing.
    with pytest.raises(ValueError):
        manager.create_start_marker("bad__trace", QUEUE)

    with pytest.raises(ValueError):
        manager.has_end_marker("bad__trace", QUEUE)


def test_trace_id_with_path_separator_rejected(manager):
    # trace_id comes from message bodies (external input); a path in
    # it must never escape the storage directory.
    for hostile in ("../../etc/pwned", "a/b", "..", "\\evil"):
        with pytest.raises(ValueError):
            manager.create_end_marker(hostile, QUEUE)


def test_glob_metacharacters_do_not_cross_match(manager):
    # A trace_id containing glob metacharacters must match only
    # itself - in both directions.
    manager.create_end_marker("jobX", QUEUE, success=True)
    assert not manager.has_end_marker("job*", QUEUE)
    assert not manager.has_end_marker("job?", QUEUE)

    manager.create_end_marker("job*", QUEUE, success=True)
    assert manager.has_end_marker("job*", QUEUE)
    assert not manager.has_end_marker("jobY", QUEUE)
