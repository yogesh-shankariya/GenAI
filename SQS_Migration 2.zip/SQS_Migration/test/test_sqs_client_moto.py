"""
SQSClient integration tests against moto (in-process fake SQS).

No AWS calls leave the machine: conftest.py forces fake credentials
and every test runs inside mock_aws().
"""

import json
import uuid

import boto3
import pytest
from moto import mock_aws

from sqs_service import SQSClient, ValidationError
from test.message_factory import (
    build_message,
    extract_consumer_fields,
)


REGION = "us-east-2"
QUEUE = "dev-HOSSYTH_rallm"


@pytest.fixture
def sqs_client():
    with mock_aws():
        boto3.client("sqs", region_name=REGION).create_queue(
            QueueName=QUEUE
        )
        yield SQSClient(queue_name=QUEUE, region_name=REGION)


def _drain(client, expected, max_polls=50):
    messages = []

    for _ in range(max_polls):
        batch = client.receive_messages(max_messages=10)

        if not batch:
            if len(messages) >= expected:
                break
            continue

        messages.extend(batch)

    return messages


def test_send_and_receive_roundtrip(sqs_client):
    body = {"data": "roundtrip", "trace_id": str(uuid.uuid4())}

    response = sqs_client.send_message(body)
    assert "MessageId" in response

    messages = sqs_client.receive_messages(max_messages=1)

    assert len(messages) == 1
    assert json.loads(messages[0]["Body"]) == body

    sqs_client.delete_msg(messages[0]["ReceiptHandle"])
    assert sqs_client.receive_messages(max_messages=1) == []


def test_send_message_batch_chunks_beyond_aws_limit(sqs_client):
    # 100 messages in one call: must be split into 10-entry chunks
    messages = [
        {"MessageBody": {"index": i}} for i in range(100)
    ]

    response = sqs_client.send_message_batch(messages)

    assert len(response["Successful"]) == 100
    assert response["Failed"] == []

    attrs = sqs_client.get_queue_attributes(
        ["ApproximateNumberOfMessages"]
    )
    assert int(attrs["ApproximateNumberOfMessages"]) == 100


def test_delete_msg_batch_chunks_beyond_aws_limit(sqs_client):
    sqs_client.send_message_batch(
        [{"MessageBody": {"index": i}} for i in range(25)]
    )

    handles = [
        m["ReceiptHandle"] for m in _drain(sqs_client, expected=25)
    ]
    assert len(handles) == 25

    response = sqs_client.delete_msg_batch(handles)

    assert len(response["Successful"]) == 25
    assert response["Failed"] == []


def test_receive_clamps_max_messages_to_aws_limit(sqs_client):
    sqs_client.send_message_batch(
        [{"MessageBody": {"index": i}} for i in range(15)]
    )

    # 100 > AWS limit of 10: must be clamped, not raise
    messages = sqs_client.receive_messages(max_messages=100)

    assert 1 <= len(messages) <= 10


def test_message_attributes_roundtrip(sqs_client):
    attributes = {
        "trace_id": str(uuid.uuid4()),
        "priority": 1,
        "payload": b"binary-data",
    }

    sqs_client.send_message(
        {"data": "with attributes"},
        message_attributes=attributes,
    )

    messages = sqs_client.receive_messages(max_messages=1)
    received = messages[0]["MessageAttributes"]

    assert received["trace_id"]["StringValue"] == attributes["trace_id"]
    assert received["priority"]["StringValue"] == "1"
    assert received["payload"]["DataType"] == "Binary"
    assert received["payload"]["BinaryValue"] == b"binary-data"


def test_retry_count_from_system_attributes(sqs_client):
    trace_id = str(uuid.uuid4())
    sqs_client.send_message({"trace_id": trace_id, "data": "x"})

    # First receive: ApproximateReceiveCount=1 -> retry_count 0
    first = sqs_client.receive_messages_as_objects(
        max_messages=1, visibility_timeout=0
    )
    assert first[0].retry_count == 0
    assert first[0].trace_id == trace_id

    # Second receive (visibility 0 made it immediately available):
    # ApproximateReceiveCount=2 -> retry_count 1
    second = sqs_client.receive_messages_as_objects(
        max_messages=1, visibility_timeout=0
    )
    assert second[0].retry_count == 1


def test_trace_id_falls_back_to_message_attribute(sqs_client):
    trace_id = str(uuid.uuid4())

    # Body has no trace_id; only the message attribute carries it
    sqs_client.send_message_with_idempotency(
        {"data": "no trace in body"},
        trace_id=trace_id,
    )

    messages = sqs_client.receive_messages_as_objects(max_messages=1)

    assert messages[0].trace_id == trace_id


def test_message_size_validation(sqs_client):
    with pytest.raises(ValidationError):
        sqs_client.send_message("x" * (256 * 1024 + 1))


def test_visibility_timeout_zero_is_honored(sqs_client):
    sqs_client.send_message({"data": "visible again"})

    first = sqs_client.receive_messages(
        max_messages=1, visibility_timeout=0
    )
    assert len(first) == 1

    # visibility_timeout=0 means the message is immediately
    # re-receivable (the old code silently replaced 0 with 300)
    second = sqs_client.receive_messages(max_messages=1)
    assert len(second) == 1


def test_client_constructed_from_url_derives_queue_name():
    with mock_aws():
        queue_url = boto3.client(
            "sqs", region_name=REGION
        ).create_queue(QueueName=QUEUE)["QueueUrl"]

        client = SQSClient(queue_url=queue_url, region_name=REGION)

        assert client.queue_name == QUEUE


def test_idempotency_requires_storage_path():
    with pytest.raises(ValueError):
        SQSClient(
            queue_name=QUEUE,
            region_name=REGION,
            enable_idempotency=True,
        )


def test_full_idempotent_lifecycle(tmp_path):
    with mock_aws():
        boto3.client("sqs", region_name=REGION).create_queue(
            QueueName=QUEUE
        )

        client = SQSClient(
            queue_name=QUEUE,
            region_name=REGION,
            enable_idempotency=True,
            mps_storage_path=str(tmp_path),
        )

        trace_id = str(uuid.uuid4())

        assert not client.check_duplicates(trace_id)
        assert client.mark_processing_start(trace_id)

        # A second worker must not acquire the same message
        assert not client.mark_processing_start(trace_id)

        client.mark_processing_end(trace_id, success=True)

        # Now the duplicate check must fire (END marker written)
        assert client.check_duplicates(trace_id)


def test_purge_queue(sqs_client):
    sqs_client.send_message_batch(
        [{"MessageBody": {"index": i}} for i in range(5)]
    )

    sqs_client.purge_queue()

    attrs = sqs_client.get_queue_attributes(
        ["ApproximateNumberOfMessages"]
    )
    assert int(attrs["ApproximateNumberOfMessages"]) == 0


def test_ingest_100_contract_valid_messages(sqs_client):
    """
    End-to-end mirror of the 100-message ingestion test: send 100
    factory-built messages, receive them all back, and prove every one
    satisfies the consumer contract of main.process_sqs_message.
    """
    trace_ids = [str(uuid.uuid4()) for _ in range(100)]

    response = sqs_client.send_message_batch(
        [
            {
                "Id": str(i),
                "MessageBody": build_message(trace_id=t),
                "MessageAttributes": {"trace_id": t},
            }
            for i, t in enumerate(trace_ids)
        ]
    )

    assert len(response["Successful"]) == 100

    messages = _drain(sqs_client, expected=100)
    assert len(messages) == 100

    seen = set()

    for msg in messages:
        fields = extract_consumer_fields(json.loads(msg["Body"]))
        seen.add(fields["trace_id"])

    assert seen == set(trace_ids)

    delete_response = sqs_client.delete_msg_batch(
        [m["ReceiptHandle"] for m in messages]
    )
    assert len(delete_response["Successful"]) == 100


# ----------------------------------------------------------------------
# Production-readiness review regression tests (2026-07-27)
# ----------------------------------------------------------------------

from botocore.exceptions import ClientError  # noqa: E402


def test_batch_chunks_by_payload_size(sqs_client, monkeypatch):
    # 5 x 250KB bodies = ~1.25MB total: over the 1MiB per-request
    # limit, so the client must split by SIZE, not just the 10-entry
    # count. moto enforces the limit - without size-aware chunking
    # this request errors.
    calls = []
    real_send = sqs_client.client.send_message_batch

    def counting_send(**kwargs):
        calls.append(len(kwargs["Entries"]))
        return real_send(**kwargs)

    monkeypatch.setattr(
        sqs_client.client, "send_message_batch", counting_send
    )

    messages = [
        {"MessageBody": "x" * (250 * 1024)} for _ in range(5)
    ]
    result = sqs_client.send_message_batch(messages)

    assert len(result["Successful"]) == 5
    assert result["Failed"] == []
    assert len(calls) == 2  # size forced a second request


def test_message_size_includes_attributes(sqs_client):
    # Body alone fits; body + attribute bytes does not. SQS counts
    # both, so the client-side validation must too.
    body = "x" * (256 * 1024 - 100)

    with pytest.raises(ValidationError):
        sqs_client.send_message(
            body, message_attributes={"meta": "y" * 200}
        )


def test_duplicate_batch_ids_rejected(sqs_client):
    # Explicit Id "1" collides with the second entry's index default
    messages = [
        {"Id": "1", "MessageBody": "a"},
        {"MessageBody": "b"},
    ]

    with pytest.raises(ValidationError, match="Duplicate batch"):
        sqs_client.send_message_batch(messages)


def test_publish_with_retry_trace_id_roundtrip(sqs_client):
    # The publish helper must write the SAME attribute key the
    # consumer-side fallback reads ("trace_id", not "TraceId")
    trace_id = str(uuid.uuid4())

    assert sqs_client._publish_with_retry("no-json-body", trace_id)

    received = sqs_client.receive_messages_as_objects(max_messages=1)

    assert len(received) == 1
    assert received[0].trace_id == trace_id


def test_delete_batch_ids_are_global(sqs_client):
    for i in range(25):
        sqs_client.send_message({"n": i})

    handles = [
        m["ReceiptHandle"] for m in _drain(sqs_client, expected=25)
    ]
    result = sqs_client.delete_msg_batch(handles)

    # Ids must be the caller's global indexes, not per-chunk 0..9
    ids = {e["Id"] for e in result["Successful"]}
    assert ids == {str(i) for i in range(len(handles))}


def test_non_retryable_client_error_fails_fast(sqs_client, monkeypatch):
    # A ReceiptHandleIsInvalid will fail identically on every retry -
    # the client must not sleep/retry through it, and with idempotency
    # disabled the terminal failure must RAISE, not be swallowed.
    attempts = []

    def failing_delete(**kwargs):
        attempts.append(1)
        raise ClientError(
            {
                "Error": {
                    "Code": "ReceiptHandleIsInvalid",
                    "Message": "bad handle",
                }
            },
            "DeleteMessage",
        )

    monkeypatch.setattr(
        sqs_client.client, "delete_message", failing_delete
    )

    with pytest.raises(ClientError):
        sqs_client._delete_with_retry("bogus-handle")

    assert len(attempts) == 1


def test_send_with_idempotency_does_not_mutate_caller_attrs(sqs_client):
    attrs = {"kind": "test"}

    sqs_client.send_message_with_idempotency(
        {"data": 1}, trace_id="t-1", message_attributes=attrs
    )

    assert "trace_id" not in attrs


def test_region_derived_from_queue_url():
    client = SQSClient(
        queue_url="https://sqs.us-west-1.amazonaws.com/123456/some-q"
    )
    assert client.region_name == "us-west-1"

    # Legacy host shapes stay None (boto3 default chain applies)
    assert (
        SQSClient._region_from_queue_url(
            "https://queue.amazonaws.com/123456/q"
        )
        is None
    )


def test_disabled_idempotency_hook_returns_are_pinned(sqs_client):
    # With idempotency off the hooks are documented no-ops; pin the
    # exact protection-shaped values consumers would observe.
    assert sqs_client.check_duplicates("t-1") is False
    assert sqs_client.mark_processing_start("t-1") is True
    assert sqs_client.mark_processing_end("t-1") is True


def test_mark_processing_end_reports_write_failure(tmp_path, monkeypatch):
    client = SQSClient(
        queue_name=QUEUE,
        region_name=REGION,
        enable_idempotency=True,
        mps_storage_path=str(tmp_path),
    )

    def failing_end(*args, **kwargs):
        raise OSError("disk full")

    monkeypatch.setattr(
        client.mps_manager, "create_end_marker", failing_end
    )

    # Work is done but the dedup record could not be written: report
    # False (dedup memory lost) instead of raising after side effects
    assert client.mark_processing_end("t-9") is False
