"""
Tests for consumer_idempotency - the idempotent-consumption wiring
that main.py runs in production (main.py itself cannot be imported
here: it needs the client-environment-only log_util / schema /
doc_extract_app modules, which is exactly why the wiring logic lives
in the importable consumer_idempotency module).

Covers, against moto (in-process fake SQS) and a tmp_path marker
store:
- idempotency-key extraction (plain body, SNS envelope, malformed
  body, store-rejected trace_id, retry count)
- the serial-loop lifecycle: duplicate delivery suppressed and
  deleted; owned message left on the queue; failure writes a failed
  END (which must NOT suppress a retry) and clears the START lease
- fail-open behavior when the marker layer itself errors
- the parallel handler via ParallelSQSProcessor(message_arg="message")
"""

import json
import uuid

import boto3
import pytest
from moto import mock_aws

from consumer_idempotency import (
    PROCESS,
    SKIP_DUPLICATE,
    SKIP_OWNED,
    extract_idempotency_key,
    idempotency_gate,
    make_idempotent_handler,
    mark_processing_end_safe,
)
from sqs_service import ParallelSQSProcessor, SQSClient


REGION = "us-east-2"
QUEUE = "dev-HOSSYTH_rallm"
ERROR_QUEUE = "dev-HOSSYTH_docxtr_error"


def _consumer_body(trace_id):
    """Minimal body matching the consumer contract's key accesses."""
    return json.dumps({"metadata": {"traceId": trace_id}})


@pytest.fixture
def idem_client(tmp_path):
    with mock_aws():
        boto3.client("sqs", region_name=REGION).create_queue(
            QueueName=QUEUE
        )
        yield SQSClient(
            queue_name=QUEUE,
            region_name=REGION,
            enable_idempotency=True,
            mps_storage_path=str(tmp_path),
        )


# ----------------------------------------------------------------------
# extract_idempotency_key
# ----------------------------------------------------------------------

def test_extract_key_plain_body():
    trace = str(uuid.uuid4())
    message = {
        "Body": _consumer_body(trace),
        "MessageId": "mid-1",
        "Attributes": {"ApproximateReceiveCount": "1"},
    }

    assert extract_idempotency_key(message) == (trace, 0)


def test_extract_key_sns_wrapped():
    trace = str(uuid.uuid4())
    message = {
        "Body": json.dumps({"Message": _consumer_body(trace)}),
        "MessageId": "mid-2",
        "Attributes": {"ApproximateReceiveCount": "3"},
    }

    assert extract_idempotency_key(message) == (trace, 2)


def test_extract_key_malformed_body_falls_back_to_message_id():
    message = {"Body": "not json at all", "MessageId": "mid-3"}

    trace_id, retry_count = extract_idempotency_key(message)

    assert trace_id == "mid-3"
    assert retry_count == 0


def test_extract_key_store_rejected_trace_falls_back_to_message_id():
    # "__" is the marker-filename separator; the store rejects it.
    message = {
        "Body": _consumer_body("bad__trace/id"),
        "MessageId": "mid-4",
        "Attributes": {"ApproximateReceiveCount": "2"},
    }

    trace_id, retry_count = extract_idempotency_key(message)

    assert trace_id == "mid-4"
    assert retry_count == 1


# ----------------------------------------------------------------------
# Serial-loop lifecycle (the exact wiring main.py runs)
# ----------------------------------------------------------------------

def _serial_iteration(client, message, process_fn):
    """
    One iteration of main.py's serial loop, minus the client-env
    imports: gate -> process -> END -> delete / leave.
    Returns what happened: "processed", "skipped_dup", "skipped_owned",
    or "failed".
    """
    receipt_handle = message["ReceiptHandle"]
    trace_id, retry_count = extract_idempotency_key(message)

    gate = idempotency_gate(client, trace_id, retry_count)
    if gate == SKIP_DUPLICATE:
        client.delete_msg(receipt_handle)
        return "skipped_dup"
    if gate == SKIP_OWNED:
        return "skipped_owned"

    success = bool(process_fn(message))
    mark_processing_end_safe(client, trace_id, retry_count, success)

    if success:
        client.delete_msg(receipt_handle)
        return "processed"
    return "failed"


def test_duplicate_delivery_is_suppressed_and_deleted(idem_client):
    trace = str(uuid.uuid4())
    calls = []

    # Delivery #1: processed, END written, deleted.
    idem_client.send_message(_consumer_body(trace))
    msg = idem_client.receive_messages(max_messages=1)[0]
    outcome = _serial_iteration(
        idem_client, msg, lambda m: calls.append(m) or True
    )
    assert outcome == "processed"
    assert len(calls) == 1

    # Delivery #2 (same trace_id - a redelivery or producer resend):
    # recognized as Scenario A, deleted WITHOUT reprocessing.
    idem_client.send_message(_consumer_body(trace))
    msg2 = idem_client.receive_messages(max_messages=1)[0]
    outcome2 = _serial_iteration(
        idem_client, msg2, lambda m: calls.append(m) or True
    )
    assert outcome2 == "skipped_dup"
    assert len(calls) == 1  # the expensive work ran exactly once

    # Queue is empty: the duplicate was deleted too.
    assert idem_client.receive_messages(max_messages=10) == []


def test_owned_message_is_left_on_queue(idem_client):
    trace = str(uuid.uuid4())

    # Another worker holds the START lease for this trace_id.
    claimed, _ = idem_client.marker_store.create_start_marker(
        trace, QUEUE
    )
    assert claimed

    idem_client.send_message(_consumer_body(trace))
    msg = idem_client.receive_messages(
        max_messages=1, visibility_timeout=0
    )[0]

    outcome = _serial_iteration(
        idem_client, msg, lambda m: pytest.fail("must not process")
    )

    assert outcome == "skipped_owned"
    # The message must still be on the queue (Scenario B never
    # deletes - deleting would lose the work if the owner is dead).
    assert len(idem_client.receive_messages(max_messages=10)) == 1


def test_failed_processing_allows_retry(idem_client):
    trace = str(uuid.uuid4())

    idem_client.send_message(_consumer_body(trace))
    msg = idem_client.receive_messages(
        max_messages=1, visibility_timeout=0
    )[0]

    outcome = _serial_iteration(idem_client, msg, lambda m: False)

    assert outcome == "failed"
    # A failed END must NOT suppress a retry (Scenario A only skips
    # on success)...
    assert idem_client.check_duplicates(trace) is False
    # ...and the START lease is cleared, so the retry is immediate
    # (Scenario D), not blocked behind the 4h lease (Scenario B).
    assert idem_client.marker_store.get_start_marker(trace, QUEUE) is None
    assert idempotency_gate(idem_client, trace, 1) == PROCESS


def test_gate_fails_open_when_marker_layer_errors(idem_client, monkeypatch):
    def _boom(*args, **kwargs):
        raise OSError("marker volume unavailable")

    monkeypatch.setattr(idem_client, "check_duplicates", _boom)

    # Dedup breakage must never stop consumption.
    assert idempotency_gate(idem_client, str(uuid.uuid4()), 0) == PROCESS


# ----------------------------------------------------------------------
# Parallel handler (ParallelSQSProcessor, message_arg="message")
# ----------------------------------------------------------------------

@pytest.fixture
def parallel_setup(tmp_path):
    with mock_aws():
        sqs = boto3.client("sqs", region_name=REGION)
        sqs.create_queue(QueueName=QUEUE)
        sqs.create_queue(QueueName=ERROR_QUEUE)

        input_client = SQSClient(
            queue_name=QUEUE,
            region_name=REGION,
            enable_idempotency=True,
            mps_storage_path=str(tmp_path),
        )
        error_client = SQSClient(
            queue_name=ERROR_QUEUE, region_name=REGION
        )
        yield input_client, error_client


def test_parallel_handler_processes_once_and_deletes_duplicates(
    parallel_setup,
):
    input_client, error_client = parallel_setup
    trace = str(uuid.uuid4())
    calls = []

    handler = make_idempotent_handler(
        input_client,
        lambda m: calls.append(m) or True,
        lambda m: pytest.fail("no failures expected"),
    )
    processor = ParallelSQSProcessor(
        client=input_client,
        processing_function=handler,
        max_workers=4,
        delete_on_success=True,
        visibility_timeout=30,
        message_arg="message",
    )

    with processor:
        input_client.send_message(_consumer_body(trace))
        first = processor.process_with_threads(max_messages=4)
        assert len(first["successful"]) == 1

        # Same trace_id again: the handler returns True without
        # reprocessing, so the processor deletes the duplicate.
        input_client.send_message(_consumer_body(trace))
        second = processor.process_with_threads(max_messages=4)
        assert len(second["successful"]) == 1
        assert all(r["deleted"] for r in second["successful"])

    assert len(calls) == 1  # the pipeline ran exactly once
    assert input_client.receive_messages(max_messages=10) == []


def test_parallel_handler_failure_routes_to_error_queue(parallel_setup):
    input_client, error_client = parallel_setup
    trace = str(uuid.uuid4())
    routed = []

    def _route_error(message):
        # Mirrors main._route_to_error_queue: copy the body out, then
        # delete from the input queue.
        error_client.send_message(message.get("Body", ""))
        input_client.delete_msg(message["ReceiptHandle"])
        routed.append(message)

    handler = make_idempotent_handler(
        input_client, lambda m: False, _route_error
    )
    processor = ParallelSQSProcessor(
        client=input_client,
        processing_function=handler,
        max_workers=2,
        delete_on_success=True,
        visibility_timeout=30,
        message_arg="message",
    )

    with processor:
        input_client.send_message(_consumer_body(trace))
        result = processor.process_with_threads(max_messages=2)

    assert len(result["failed"]) == 1
    assert len(routed) == 1
    # The failed message landed on the error queue and left the input
    # queue; a failed END never suppresses a future retry.
    assert len(error_client.receive_messages(max_messages=10)) == 1
    assert input_client.receive_messages(max_messages=10) == []
    assert input_client.check_duplicates(trace) is False
