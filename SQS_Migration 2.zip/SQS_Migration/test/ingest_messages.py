"""
SQS ingestion test harness.

Sends N consumer-contract-valid test messages (default 100) to an SQS
queue in batches of 10, verifies queue depth, and writes a JSON report
containing every trace_id so results can be correlated with the k8s
consumer's logs.

Modes
-----
mock (default): runs entirely against an in-process moto fake SQS -
    NO AWS calls leave this machine. Fake credentials are forced into
    the environment before any boto3 client exists, so even a moto
    failure cannot reach a real account. After sending, the harness
    drains the queue and validates every payload against the exact key
    accesses the consumer performs (contract proof).

live: sends to the real queue. Intended ONLY for the client
    environment. Refuses to run unless BOTH the environment variable
    RUN_LIVE=1 and the --yes-live flag are provided.

Usage
-----
    python test/ingest_messages.py --mode mock --count 100
    RUN_LIVE=1 python test/ingest_messages.py --mode live --count 100 \
        --queue dev-HOSSYTH_rallm --region us-east-2 --yes-live \
        --s3-key <s3 key of a real test pdf>
"""

import argparse
import json
import os
import pathlib
import sys
import time
import uuid

sys.path.insert(
    0,
    str(pathlib.Path(__file__).resolve().parents[1]),
)

try:
    from test.message_factory import (
        build_message,
        extract_consumer_fields,
    )
except ImportError:
    from message_factory import build_message, extract_consumer_fields


BATCH_SIZE = 10  # AWS SQS batch limit


def parse_args():
    parser = argparse.ArgumentParser(
        description="Ingest N test messages into an SQS queue."
    )
    parser.add_argument(
        "--count",
        type=int,
        default=int(os.environ.get("SQS_TEST_MSG_TO_SPAWN", 100)),
        help="Number of messages to send (default: "
        "SQS_TEST_MSG_TO_SPAWN env or 100)",
    )
    parser.add_argument(
        "--queue",
        default=os.environ.get(
            "SQS_INPUT_QUEUE_NAME", "dev-HOSSYTH_rallm"
        ),
        help="Queue NAME (default: SQS_INPUT_QUEUE_NAME env)",
    )
    parser.add_argument(
        "--region",
        default=os.environ.get("SQS_AWS_REGION", "us-east-2"),
        help="AWS region (default: SQS_AWS_REGION env or us-east-2)",
    )
    parser.add_argument(
        "--mode",
        choices=["mock", "live"],
        default="mock",
        help="mock = in-process fake SQS, no AWS calls (default); "
        "live = real queue (client environment only)",
    )
    parser.add_argument(
        "--yes-live",
        action="store_true",
        help="Second confirmation required for --mode live "
        "(with RUN_LIVE=1)",
    )
    parser.add_argument(
        "--s3-key",
        default=None,
        help="S3 key of a real test document; required for the k8s "
        "pipeline to fully process the message (defaults to a "
        "synthetic path)",
    )
    parser.add_argument("--ra-mnemonic", default="abc")
    parser.add_argument("--tnnt-id", default="59")
    parser.add_argument("--clnt-id", default="59")
    parser.add_argument(
        "--report-dir",
        default=str(pathlib.Path(__file__).resolve().parent / "reports"),
        help="Directory for the JSON run report",
    )
    return parser.parse_args()


def force_fake_aws_credentials(region: str) -> None:
    """
    Overwrite AWS credentials with dummies so no call from this
    process can ever authenticate against a real AWS account.
    """
    os.environ["AWS_ACCESS_KEY_ID"] = "testing"
    os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"
    os.environ["AWS_SECURITY_TOKEN"] = "testing"
    os.environ["AWS_SESSION_TOKEN"] = "testing"
    os.environ["AWS_DEFAULT_REGION"] = region
    os.environ.pop("AWS_PROFILE", None)


def build_batch_entries(args, trace_ids):
    """
    Build send_message_batch entries for a list of trace_ids.
    """
    entries = []

    for i, trace_id in enumerate(trace_ids):
        body = build_message(
            trace_id=trace_id,
            s3_key=args.s3_key,
            ra_mnemonic=args.ra_mnemonic,
            tnnt_id=args.tnnt_id,
            clnt_id=args.clnt_id,
        )
        entries.append(
            {
                "Id": str(i),
                "MessageBody": body,
                "MessageAttributes": {"trace_id": trace_id},
            }
        )

    return entries


def send_all(client, args, report):
    """
    Send report['trace_ids'] to the queue in batches of BATCH_SIZE.
    """
    trace_ids = report["trace_ids"]
    start = time.time()

    for batch_start in range(0, len(trace_ids), BATCH_SIZE):
        batch_ids = trace_ids[batch_start:batch_start + BATCH_SIZE]
        entries = build_batch_entries(args, batch_ids)

        try:
            response = client.send_message_batch(entries)
        except Exception as e:
            report["errors"].append(
                f"Batch starting at {batch_start} failed: {e}"
            )
            report["failed"] += len(entries)
            continue

        sent = len(response.get("Successful", []))
        failed_entries = response.get("Failed", [])

        report["sent"] += sent
        report["failed"] += len(failed_entries)

        for failure in failed_entries:
            failed_index = batch_start + int(failure["Id"])
            report["failed_trace_ids"].append(trace_ids[failed_index])
            report["errors"].append(
                f"Entry {failure['Id']} failed: "
                f"{failure.get('Message', 'Unknown')} "
                f"(code={failure.get('Code')})"
            )

        done = batch_start + len(batch_ids)

        if done % 50 == 0 or done == len(trace_ids):
            elapsed = time.time() - start
            rate = report["sent"] / elapsed if elapsed > 0 else 0.0
            print(
                f"  sent {report['sent']}/{len(trace_ids)} "
                f"({rate:.1f} msg/sec)"
            )

    report["send_duration_sec"] = round(time.time() - start, 3)


def verify_queue_depth(client, expected: int, report):
    """
    Check ApproximateNumberOfMessages(+NotVisible) covers what we sent.
    """
    attrs = client.get_queue_attributes(
        [
            "ApproximateNumberOfMessages",
            "ApproximateNumberOfMessagesNotVisible",
        ]
    )

    visible = int(attrs.get("ApproximateNumberOfMessages", 0))
    in_flight = int(
        attrs.get("ApproximateNumberOfMessagesNotVisible", 0)
    )

    report["queue_depth_after_send"] = {
        "visible": visible,
        "in_flight": in_flight,
    }

    print(
        f"  queue depth: {visible} visible, {in_flight} in flight "
        f"(expected >= {expected}; counts are approximate on live SQS)"
    )


def drain_and_validate(client, expected: int, report):
    """
    Mock mode only: receive everything back and prove each payload
    satisfies the consumer contract, then delete it.
    """
    received = 0
    valid = 0
    empty_polls = 0
    seen_trace_ids = set()

    while received < expected and empty_polls < 5:
        messages = client.receive_messages(
            max_messages=10,
            wait_time_seconds=0,
        )

        if not messages:
            empty_polls += 1
            continue

        empty_polls = 0
        handles = []

        for msg in messages:
            received += 1
            handles.append(msg["ReceiptHandle"])

            try:
                body = json.loads(msg["Body"])
                fields = extract_consumer_fields(body)
                seen_trace_ids.add(fields["trace_id"])
                valid += 1
            except (json.JSONDecodeError, KeyError, TypeError) as e:
                report["errors"].append(
                    f"Contract violation in received message: {e!r}"
                )

        delete_response = client.delete_msg_batch(handles)

        if delete_response.get("Failed"):
            report["errors"].append(
                f"{len(delete_response['Failed'])} deletes failed"
            )

    missing = set(report["trace_ids"]) - seen_trace_ids

    report["mock_validation"] = {
        "received": received,
        "contract_valid": valid,
        "unique_trace_ids_received": len(seen_trace_ids),
        "missing_trace_ids": sorted(missing)[:10],
        "missing_count": len(missing),
    }

    print(
        f"  drained {received}, contract-valid {valid}, "
        f"missing {len(missing)}"
    )


def run(client, args, report):
    print(
        f"[{args.mode}] sending {args.count} messages to "
        f"'{args.queue}' ({args.region})"
    )

    send_all(client, args, report)
    verify_queue_depth(client, args.count, report)

    if args.mode == "mock":
        print("Draining and validating consumer contract (mock)...")
        drain_and_validate(client, args.count, report)


def write_report(report, report_dir: str) -> str:
    path = pathlib.Path(report_dir)
    path.mkdir(parents=True, exist_ok=True)

    filename = path / (
        f"ingest_report_{time.strftime('%Y%m%d_%H%M%S')}.json"
    )

    with open(filename, "w") as f:
        json.dump(report, f, indent=2)

    return str(filename)


def main():
    args = parse_args()

    report = {
        "mode": args.mode,
        "queue": args.queue,
        "region": args.region,
        "requested": args.count,
        "sent": 0,
        "failed": 0,
        "trace_ids": [str(uuid.uuid4()) for _ in range(args.count)],
        "failed_trace_ids": [],
        "errors": [],
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%S"),
    }

    if args.mode == "live":
        if os.environ.get("RUN_LIVE") != "1" or not args.yes_live:
            print(
                "REFUSING to run in live mode.\n"
                "Live mode sends to a REAL queue and must only be run "
                "from the client environment.\n"
                "Require BOTH: RUN_LIVE=1 environment variable AND "
                "the --yes-live flag."
            )
            sys.exit(2)

        from sqs_service import SQSClient

        client = SQSClient(
            queue_name=args.queue,
            region_name=args.region,
        )
        run(client, args, report)

    else:
        # Fake credentials BEFORE any boto3 session exists - no call
        # from this process can reach a real AWS account.
        force_fake_aws_credentials(args.region)

        try:
            from moto import mock_aws
        except ImportError:
            print(
                "moto is required for mock mode: "
                "pip install -r requirements-dev.txt"
            )
            sys.exit(2)

        import boto3

        from sqs_service import SQSClient

        with mock_aws():
            boto3.client("sqs", region_name=args.region).create_queue(
                QueueName=args.queue
            )

            client = SQSClient(
                queue_name=args.queue,
                region_name=args.region,
            )
            run(client, args, report)

    report["finished_at"] = time.strftime("%Y-%m-%dT%H:%M:%S")

    ok = report["sent"] == args.count and report["failed"] == 0

    if args.mode == "mock":
        validation = report.get("mock_validation", {})
        ok = ok and validation.get("contract_valid") == args.count

    report["result"] = "PASS" if ok else "FAIL"

    report_path = write_report(report, args.report_dir)

    print(
        f"\nResult: {report['result']} - "
        f"sent {report['sent']}/{args.count}, "
        f"failed {report['failed']}"
    )
    print(f"Report (incl. all trace_ids): {report_path}")

    if args.mode == "live":
        print(
            "Next: correlate these trace_ids with the k8s consumer "
            "logs / Datadog to confirm processing."
        )

    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
