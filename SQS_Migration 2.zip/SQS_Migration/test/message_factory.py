"""
Message factory for SQS ingestion testing.

Single source of truth for a test message that the doc-extract consumer
(main.process_sqs_message) can actually parse. Every key the consumer
reads from `metadata` MUST be present here - keep the two in sync.

Used by main.py (TEST mode), test/ingest_messages.py, and the test
suite so producer and consumer cannot drift apart.
"""

import json
import uuid
from datetime import datetime
from typing import Any, Dict, Optional


DEFAULT_FILE_NAME = (
    "CDA-CL_MRRHD_M_CTVI_ALL_DOCBINARY-"
    "de1bbf52-3616-46f2-9262-15f503672388-"
    "FILE-NAME_347W09527_IU PUI_SAM ABC_04211959_RES_001_43442_"
    "02102025_A330-156674.pdf"
)


def build_message(
    trace_id: Optional[str] = None,
    s3_key: Optional[str] = None,
    ra_mnemonic: str = "abc",
    tnnt_id: str = "59",
    clnt_id: str = "59",
    source_queue: str = "sqs-ingest-test",
    file_name: str = DEFAULT_FILE_NAME,
    priority: bool = False,
) -> Dict[str, Any]:
    """
    Build a complete message body (as a dict) matching the consumer
    contract of main.process_sqs_message.

    The returned dict is intended to be JSON-serialized and sent as the
    SQS message Body directly: the consumer does
    `data = json.loads(body["Message"]) if "Message" in body else body`,
    so a plain body dict takes the `else body` path.
    """
    if trace_id is None:
        trace_id = str(uuid.uuid4())

    base_loc = f"test/{trace_id}/"
    raw_file_location = f"{base_loc}input/{file_name}"

    # s3_key is what the consumer passes to the doc-extract pipeline as
    # metadata.file_path; for a real end-to-end run it must point at an
    # object that exists in the pipeline's S3 bucket.
    if s3_key is None:
        s3_key = raw_file_location

    metadata = {
        "sourceQueue": source_queue,
        "queuePath": [
            "cdi-ingestion-service",
            "dev-HOSSYTH_translation_history",
            "dev-HOSSYTH_docxtr_history",
        ],
        "lastService": "none",
        "process": "",
        "status": "WORKING",
        "retryCount": 0,
        "traceId": trace_id,
        "translationOutput": "",
        "sourceType": "test",
        "fileFormat": "BINARYDOC",
        # Keys read by main.process_sqs_message
        "file_path": s3_key,
        "RA_MNEMONIC": ra_mnemonic,
        "TNNT_ID": tnnt_id,
        "CLNT_ID": clnt_id,
        "rawFileLocation": raw_file_location,
        "docAsciiPath": "",
        "docBinaryPath": "",
        "docMetadataPath": "",
        "contextHash": "",
        "baseLocation": base_loc,
        "fileSize": "99999",
        "errorCode": "",
        "errorMsg": "",
        "priority": priority,
        "xrequestID": "nnn9999nnn",
        "errorMessage": False,
        # Kept for compatibility with upstream producers
        "EDL_TNNT_ID": tnnt_id,
        "EDL_CLNT_ID": clnt_id,
    }

    return {
        "metadata": metadata,
        "trace_id": trace_id,
        "test_run_id": datetime.now().strftime("%Y%m%d_%H%M%S"),
        "DOCBINARY_PATH": raw_file_location,
        "DOCASCII_PATH": "",
        "DOCENCOUNTER_PATHS": ["NA"],
    }


def build_message_json(trace_id: Optional[str] = None, **kwargs) -> str:
    """
    Build a message and return it as the JSON string to send as the
    SQS message Body.
    """
    return json.dumps(build_message(trace_id=trace_id, **kwargs))


def extract_consumer_fields(body: Dict[str, Any]) -> Dict[str, Any]:
    """
    Mirror the key accesses main.process_sqs_message performs on a
    parsed message body. Raises KeyError if the message violates the
    consumer contract - this is the local proof that a generated
    message will not crash the k8s consumer.
    """
    data = (
        json.loads(body["Message"]) if "Message" in body else body
    )

    metadata = data["metadata"]

    return {
        "trace_id": metadata["traceId"],
        "s3_key": metadata["file_path"],
        "ra_mnemonic": metadata["RA_MNEMONIC"],
        "base_location": metadata["baseLocation"],
        "doc_binary_path": metadata["docBinaryPath"],
        "source_queue": metadata["sourceQueue"],
        "queue_path": metadata["queuePath"],
        "last_service": metadata["lastService"],
        "status": metadata["status"],
        "translation_output": metadata["translationOutput"],
        "source_type": metadata["sourceType"],
        "file_format": metadata["fileFormat"],
        "raw_file_location": metadata["rawFileLocation"],
        "doc_ascii_path": metadata["docAsciiPath"],
        "doc_metadata_path": metadata["docMetadataPath"],
        "context_hash": metadata["contextHash"],
        "file_size": metadata["fileSize"],
        "priority": metadata["priority"],
        "xrequest_id": metadata["xrequestID"],
        "tnnt_id": metadata["TNNT_ID"],
        "clnt_id": metadata["CLNT_ID"],
        "retry_count": metadata["retryCount"],
    }
