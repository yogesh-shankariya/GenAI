"""
Unit Tests for SQS Idempotent Processor
=======================================

Tests the idempotency framework using mocks and temp directories.

Live-queue integration tests (TestSQSClientIntegration,
TestSQSClient10KMessages) are SKIPPED unless RUN_LIVE=1 is set - they
send/receive/delete on the real shared queue and must only run in the
client environment.
"""

import json
import os
import pathlib
import shutil
import sys
import tempfile
import threading
import time
import unittest
import uuid
from datetime import datetime
from time import sleep
from typing import Dict
from unittest.mock import MagicMock, patch

sys.path.insert(
    0,
    str(pathlib.Path(__file__).resolve().parents[1]),
)

# Defaults so constant.py imports without a full client .env
os.environ.setdefault("SQS_INPUT_QUEUE_NAME", "test-input-queue")
os.environ.setdefault("SQS_OUTPUT_QUEUE_NAME", "test-output-queue")
os.environ.setdefault("SQS_ERROR_QUEUE_NAME", "test-error-queue")
os.environ.setdefault("SQS_AWS_REGION", "us-east-2")
os.environ.setdefault("INPUT_QUEUE_TYPE", "SQS")

from botocore.exceptions import ClientError

import sqs_service
from sqs_service import (
    SQSClient,
    SQSMessage,
    ProcessingResult,
    MDCContext,
    MDCMarker,
    ProcessingError,
    ValidationError,
    ProcessingTimeoutError,
    PublishError,
)
from sqs_service._logging import get_logger
from constant import Constant

try:
    from test.message_factory import build_message
except ImportError:
    from message_factory import build_message


logger = get_logger()

POD = os.getenv("POD_NAME", "unknown")
NS = os.getenv("POD_NAMESPACE", "unknown")

SQS_AWS_REGION = Constant.SQS_AWS_REGION
SQS_MPS_PATH = Constant.SQS_MPS_PATH
SQS_TEST_MSG_TO_SPAWN = Constant.SQS_TEST_MSG_TO_SPAWN
SQS_INPUT_QUEUE_NAME = Constant.SQS_INPUT_QUEUE_NAME
SQS_OUTPUT_QUEUE_NAME = Constant.SQS_OUTPUT_QUEUE_NAME

RUN_LIVE = os.environ.get("RUN_LIVE") == "1"
LIVE_SKIP_REASON = (
    "Live SQS integration test - set RUN_LIVE=1 to run "
    "(client environment only, hits the real queue)"
)

# Simulated per-message processing lag for the large-scale test
# (the old hardcoded sleep(400) made the test take days)
PROCESSING_LAG_SECONDS = float(
    os.environ.get("SQS_TEST_PROCESSING_LAG", "0")
)


# Pod logging
def emit(event: str, **fields):
    payload = {
        "event": event,
        "pod": POD,
        "namespace": NS,
        "ts": time.time(),
        **fields,
    }
    logger.info(json.dumps(payload))


class TestMDCContext(unittest.TestCase):
    """
    Test for MDC (Mapped Diagnostic Context) logging.
    """

    def setUp(self):
        """
        Clear MDC context before each test.
        """
        MDCContext.clear()

    def test_set_and_get_context(self):
        """
        Test setting and getting MDC context.
        """
        MDCContext.set(
            trace_id="test-123",
            user_id="user-456",
        )

        context = MDCContext.get()

        self.assertEqual(context["trace_id"], "test-123")
        self.assertEqual(context["user_id"], "user-456")

    def test_update_context(self):
        """
        Test updating existing MDC context.
        """
        MDCContext.set(trace_id="test-123")
        MDCContext.set(user_id="user-456")

        context = MDCContext.get()

        self.assertEqual(context["trace_id"], "test-123")
        self.assertEqual(context["user_id"], "user-456")

    def test_clear_context(self):
        """
        Test clearing MDC context.
        """
        MDCContext.set(trace_id="test-123")
        MDCContext.clear()

        context = MDCContext.get()

        self.assertEqual(context, {})

    def test_context_scope(self):
        """
        Test scoped MDC context manager.
        """
        MDCContext.set(outer="value1")

        with MDCContext.scope(
            inner="value2",
            trace_id="test-123",
        ):
            context = MDCContext.get()

            self.assertEqual(context["outer"], "value1")
            self.assertEqual(context["inner"], "value2")
            self.assertEqual(context["trace_id"], "test-123")

        context = MDCContext.get()

        self.assertEqual(context["outer"], "value1")
        self.assertNotIn("inner", context)

    def test_thread_isolation(self):
        """
        Test that MDC thread is local.
        """
        MDCContext.set(thread="main")

        def thread_func():
            MDCContext.set(thread="worker")
            context = MDCContext.get()
            self.assertEqual(context["thread"], "worker")

        thread = threading.Thread(target=thread_func)
        thread.start()
        thread.join()

        # Main thread context should be unchanged
        context = MDCContext.get()
        self.assertEqual(context["thread"], "main")


class TestMDCMarker(unittest.TestCase):
    """
    Test for MDC lifecycle markers.
    """

    def setUp(self):
        """
        Clear MDC context so earlier tests cannot leak into markers.
        """
        MDCContext.clear()

    def test_marker_values(self):
        """
        Test marker enum values.
        """
        self.assertEqual(
            MDCMarker.MESSAGE_START.value,
            "MESSAGE_START",
        )
        self.assertEqual(
            MDCMarker.MESSAGE_SUCCESS.value,
            "MESSAGE_SUCCESS",
        )
        self.assertEqual(
            MDCMarker.MESSAGE_FAILED.value,
            "MESSAGE_FAILED",
        )
        self.assertEqual(
            MDCMarker.MESSAGE_END.value,
            "MESSAGE_END",
        )

    @patch("sqs_service.sqs_idempotent_processor.logger")
    def test_log_lifecycle_marker(self, mock_logger):
        """
        Test logging lifecycle markers.
        """
        sqs_service.log_lifecycle_marker(
            MDCMarker.MESSAGE_START,
            "trace-123",
            "test-queue",
            extra_field="value",
        )

        # Verify logger info was called
        self.assertTrue(mock_logger.info.called)

        # Extract log message
        log_call = mock_logger.info.call_args[0][0]

        self.assertIn("MESSAGE_START", log_call)
        self.assertIn("trace-123", log_call)
        self.assertIn("test-queue", log_call)

    @patch("sqs_service.sqs_idempotent_processor.logger")
    def test_log_with_mdc_context(self, mock_logger):
        """
        Test that lifecycle markers include MDC context.
        """
        MDCContext.set(request_id="req-456")

        sqs_service.log_lifecycle_marker(
            MDCMarker.MESSAGE_SUCCESS,
            "trace-789",
            "my-queue",
        )

        log_call = mock_logger.info.call_args[0][0]

        self.assertIn("req-456", log_call)

        MDCContext.clear()


class TestSQSClient(unittest.TestCase):
    """
    test SQS client functionality (boto3 fully mocked).
    """

    def setUp(self):
        """
        Setup test client with mocked boto3.
        """
        self.mock_sqs = MagicMock()

        with patch("boto3.Session") as mock_session:
            mock_session.return_value.client.return_value = self.mock_sqs

            self.client = SQSClient(
                queue_name=SQS_INPUT_QUEUE_NAME,
                region_name=SQS_AWS_REGION,
            )

        # Skip the get_queue_url lookup on the mock
        self.client.queue_url = (
            f"https://sqs.{SQS_AWS_REGION}.amazonaws.com/"
            f"000000000000/{SQS_INPUT_QUEUE_NAME}"
        )

    def test_send_message_with_string(self):
        """
        Test sending a message with string body
        """
        self.mock_sqs.send_message.return_value = {
            "MessageId": "msg-123",
            "MD5OfMessageBody": "abc123",
        }

        response = self.client.send_message("test message")

        self.mock_sqs.send_message.assert_called_once()
        self.assertEqual(response["MessageId"], "msg-123")

    def test_send_message_with_dict(self):
        """
        Test sending message
        """
        self.mock_sqs.send_message.return_value = {
            "MessageId": "msg-456"
        }

        message_body = {
            "key": "value",
            "data": 123,
        }

        response = self.client.send_message(message_body)

        #Verify JSON
        call_args = self.mock_sqs.send_message.call_args
        self.assertIn("MessageBody", call_args[1])

        body = call_args[1]["MessageBody"]

        self.assertEqual(json.loads(body), message_body)

    def test_send_message_size_validation(self):
        """
        Oversized messages must be rejected before reaching SQS.
        """
        with self.assertRaises(ValidationError):
            self.client.send_message("x" * (256 * 1024 + 1))

        self.mock_sqs.send_message.assert_not_called()

    def test_send_message_batch(self):
        self.mock_sqs.send_message_batch.return_value = {
            "Successful": [
                {"Id": "0"},
                {"Id": "1"},
            ],
            "Failed": [],
        }

        messages = [
            {
                "Id": "0",
                "MessageBody": "msg1",
            },
            {
                "Id": "1",
                "MessageBody": {
                    "data": "msg2",
                },
            },
        ]

        response = self.client.send_message_batch(messages)

        self.assertEqual(len(response["Successful"]), 2)
        self.mock_sqs.send_message_batch.assert_called_once()

    def test_send_message_batch_chunks_large_batches(self):
        """
        25 messages must be sent as 3 requests (10+10+5).
        """
        self.mock_sqs.send_message_batch.side_effect = [
            {
                "Successful": [{"Id": str(i)} for i in range(10)],
                "Failed": [],
            },
            {
                "Successful": [
                    {"Id": str(i)} for i in range(10, 20)
                ],
                "Failed": [],
            },
            {
                "Successful": [
                    {"Id": str(i)} for i in range(20, 25)
                ],
                "Failed": [],
            },
        ]

        messages = [
            {"MessageBody": f"msg-{i}"} for i in range(25)
        ]

        response = self.client.send_message_batch(messages)

        self.assertEqual(
            self.mock_sqs.send_message_batch.call_count, 3
        )
        self.assertEqual(len(response["Successful"]), 25)

        for call in self.mock_sqs.send_message_batch.call_args_list:
            self.assertLessEqual(len(call[1]["Entries"]), 10)


@unittest.skipUnless(RUN_LIVE, LIVE_SKIP_REASON)
class TestSQSClientIntegration(unittest.TestCase):
    """
    Integration tests for SQSClient (REAL queue - gated by RUN_LIVE=1).
    """

    @classmethod
    def setUpClass(cls):
        """
        Set up test environment.
        """
        cls.queue_name = SQS_INPUT_QUEUE_NAME
        cls.region = SQS_AWS_REGION
        cls.temp_dir = tempfile.mkdtemp()

    @classmethod
    def tearDownClass(cls):
        """
        Clean up test resources.
        """
        if os.path.exists(cls.temp_dir):
            shutil.rmtree(cls.temp_dir)

        client = SQSClient(
            queue_name=cls.queue_name,
            region_name=cls.region,
        )

        for _ in range(10):
            messages = client.receive_messages(
                max_messages=10,
                wait_time_seconds=1,
            )

            if not messages:
                break

            handles = [
                msg["ReceiptHandle"]
                for msg in messages
            ]

            if handles:
                client.delete_msg_batch(handles)

    def test_01_send_and_receive_message(self):
        """
        Test sending and receiving a message.
        """
        client = SQSClient(
            queue_name=SQS_INPUT_QUEUE_NAME,
            region_name=SQS_AWS_REGION,
        )

        # Send message
        test_data = {
            "test_id": str(uuid.uuid4()),
            "data": "integration test",
        }

        response = client.send_message(test_data)

        self.assertIn("MessageId", response)

        # Receive message
        messages = client.receive_messages(
            max_messages=1,
            wait_time_seconds=5,
        )

        self.assertGreater(len(messages), 0)

        # Clean up
        if messages:
            client.delete_msg(
                messages[0]["ReceiptHandle"]
            )

    def test_02_send_batch_messages(self):
        """
        Test sending batch of messages.
        """
        client = SQSClient(
            queue_name=SQS_INPUT_QUEUE_NAME,
            region_name=SQS_AWS_REGION,
        )

        messages = [
            {
                "Id": str(i),
                "MessageBody": {
                    "batch_id": i,
                    "data": f"test-{i}",
                },
            }
            for i in range(5)
        ]

        response = client.send_message_batch(messages)

        self.assertEqual(len(response["Successful"]), 5)
        self.assertEqual(
            len(response.get("Failed", [])),
            0,
        )

        # Clean up
        for _ in range(3):
            received = client.receive_messages(
                max_messages=10,
                wait_time_seconds=2,
            )

            if received:
                handles = [
                    msg["ReceiptHandle"]
                    for msg in received
                ]
                client.delete_msg_batch(handles)

    def test_03_idempotency_duplicate_detection(self):
        """
        Test idempotency with duplicate detection.
        """
        client = SQSClient(
            queue_name=SQS_INPUT_QUEUE_NAME,
            region_name=SQS_AWS_REGION,
            enable_idempotency=True,
            mps_storage_path=self.temp_dir,
        )

        trace_id = str(uuid.uuid4())

        # First message - should process as no duplicate
        is_dup1 = client.check_duplicates(trace_id)

        self.assertFalse(is_dup1)

        # Mark as processed
        client.mark_processing_start(trace_id)
        client.mark_processing_end(
            trace_id,
            success=True,
        )

        # Second check - should be duplicate
        is_dup2 = client.check_duplicates(trace_id)

        self.assertTrue(is_dup2)

    def test_04_message_attributes(self):
        """
        Test sending and receiving message attributes.
        """
        client = SQSClient(
            queue_name=SQS_INPUT_QUEUE_NAME,
            region_name=SQS_AWS_REGION,
        )

        attributes = {
            "trace_id": str(uuid.uuid4()),
            "priority": 1,
            "source": "integration_test",
        }

        response = client.send_message(
            {
                "data": "test with attributes",
            },
            message_attributes=attributes,
        )

        self.assertIn("MessageId", response)

        # Clean Up
        messages = client.receive_messages(
            max_messages=1,
            wait_time_seconds=2,
        )

        if messages:
            client.delete_msg(
                messages[0]["ReceiptHandle"]
            )


class TestReportGenerator:
    """
    Generates comprehensive test reports.
    """

    def __init__(self):
        self.test_results = {
            "start_time": None,
            "end_time": None,
            "messages_created": 0,
            "messages_sent": 0,
            "messages_received": 0,
            "messages_processed": 0,
            "messages_failed": 0,
            "duplicate_detections": 0,
            "errors": [],
            "performance_metrics": {},
        }

    def record_start(self):
        self.test_results["start_time"] = datetime.now()

    def record_end(self):
        self.test_results["end_time"] = datetime.now()

    def record_message_created(self):
        self.test_results["messages_created"] += 1

    def record_message_sent(self):
        self.test_results["messages_sent"] += 1

    def record_message_received(self):
        self.test_results["messages_received"] += 1

    def record_message_processed(self):
        self.test_results["messages_processed"] += 1

    def record_message_failed(self):
        self.test_results["messages_failed"] += 1

    def record_duplicate_detected(self):
        self.test_results["duplicate_detections"] += 1

    def record_error(self, error: str):
        self.test_results["errors"].append(
            {
                "timestamp": datetime.now().isoformat(),
                "error": error,
            }
        )

    def add_performance_metric(
        self,
        metric_name: str,
        value: float,
    ):
        self.test_results["performance_metrics"][
            metric_name
        ] = value

    def generate_report(
        self,
        output_file: str = None,
    ) -> str:
        """
        Generate comprehensive test report.
        """
        if (
            self.test_results["start_time"] is None
            or self.test_results["end_time"] is None
        ):
            return "No test run recorded."

        duration = (
            self.test_results["end_time"]
            - self.test_results["start_time"]
        ).total_seconds()

        report = f"""
{'=' * 80}
SQS CLIENT MESSAGE TEST REPORT
{'=' * 80}

TEST EXECUTION SUMMARY
{'=' * 80}

Start Time: {self.test_results['start_time'].isoformat()}
End Time: {self.test_results['end_time'].isoformat()}
Total Duration: {duration:.2f} seconds

Message Statistics
{'=' * 80}

Messages Created: {self.test_results['messages_created']:,}
Messages Sent to SQS: {self.test_results['messages_sent']:,}
Messages Received: {self.test_results['messages_received']:,}
Messages Processed: {self.test_results['messages_processed']:,}
Messages Failed: {self.test_results['messages_failed']:,}
Duplicate Detections: {self.test_results['duplicate_detections']:,}
Success Rate: {(self.test_results['messages_processed'] / max(self.test_results['messages_created'], 1) * 100):.2f}%
Send Throughput: {(self.test_results['messages_sent'] / max(duration, 1)):.2f} msg/sec
Process Throughput: {(self.test_results['messages_processed'] / max(duration, 1)):.2f} msg/sec

Performance Metrics
{'=' * 80}
"""

        for (
            metric,
            value,
        ) in self.test_results[
            "performance_metrics"
        ].items():
            report += f"{metric:<40} {value:.4f}\n"

        if self.test_results["errors"]:
            report += (
                f"\nErrors "
                f"({len(self.test_results['errors'])})\n"
            )
            report += f"{'=' * 80}\n"

            for i, err in enumerate(
                self.test_results["errors"][:10],
                1,
            ):
                report += (
                    f"{i}. [{err['timestamp']}] "
                    f"{err['error']}\n"
                )

            if len(self.test_results["errors"]) > 10:
                report += (
                    f"... and "
                    f"{len(self.test_results['errors']) - 10} "
                    f"more errors\n"
                )

        report += f"{'=' * 80}\n"

        if output_file:
            with open(output_file, "w") as f:
                f.write(report)

            print(f"Report saved to: {output_file}")

        return report


@unittest.skipUnless(RUN_LIVE, LIVE_SKIP_REASON)
class TestSQSClient10KMessages(unittest.TestCase):
    """
    Large-scale integration test for SQSClient
    (REAL queue - gated by RUN_LIVE=1).

    Message volume is configured with SQS_TEST_MSG_TO_SPAWN
    (default 100).

    This test:
    1. Generates N fake messages with realistic data
    2. Publishes messages to SQS queue in batches
    3. Receives and processes messages with idempotency checking
    4. Validates duplicate detection
    5. Cleans up all test messages
    6. Generates comprehensive test report
    """

    @classmethod
    def setUpClass(cls):
        """
        Set up test environment once for all tests.
        """
        cls.queue_name = SQS_INPUT_QUEUE_NAME
        cls.region = SQS_AWS_REGION
        # Never point at the shared system path during tests
        cls.mps_path = tempfile.mkdtemp(prefix="mps_test_")
        cls.trace_ids = []  # Track trace IDs for cleanup
        cls.report_generator = TestReportGenerator()
        cls.number_of_msg = SQS_TEST_MSG_TO_SPAWN

        print(f"\n{'=' * 80}")
        print(
            f"Starting SQS Client {cls.number_of_msg} Message Test"
        )
        print(f"Queue: {cls.queue_name}")
        print(f"MPS Storage: {cls.mps_path}")
        print(f"\n{'=' * 80}")

    @classmethod
    def tearDownClass(cls):
        """
        Clean up all created messages and generate report.
        """
        print(f"\n{'=' * 80}")
        print("Cleaning up test messages...")
        print(f"\n{'=' * 80}")

        cls._cleanup_messages()
        cls._cleanup_mps_files()

        # Generate and display report
        cls.report_generator.record_end()
        report = cls.report_generator.generate_report()
        print(report)

    @classmethod
    def _cleanup_messages(cls):
        """
        Delete all messages from queue. Drains until the queue
        attributes report empty (first empty receive is not enough -
        in-flight messages reappear after the visibility timeout).
        """
        client = SQSClient(
            queue_name=cls.queue_name,
            region_name=cls.region,
        )

        cleaned = 0

        print("Cleaning messages from queue...")

        for _ in range(200):  # Max 200 iterations to clean up
            messages = client.receive_messages(
                max_messages=10,
                wait_time_seconds=1,
            )

            if not messages:
                attrs = client.get_queue_attributes(
                    [
                        "ApproximateNumberOfMessages",
                        "ApproximateNumberOfMessagesNotVisible",
                    ]
                )
                visible = int(
                    attrs.get("ApproximateNumberOfMessages", 0)
                )
                in_flight = int(
                    attrs.get(
                        "ApproximateNumberOfMessagesNotVisible", 0
                    )
                )

                if visible == 0 and in_flight == 0:
                    break

                sleep(2)
                continue

            handles = [
                msg["ReceiptHandle"]
                for msg in messages
            ]

            if handles:
                try:
                    response = client.delete_msg_batch(handles)
                    cleaned += len(
                        response.get("Successful", [])
                    )

                except Exception as e:
                    print(f"Error deleting batch: {e}")

        print(f"Cleaned {cleaned} messages from queue")

    @classmethod
    def _cleanup_mps_files(cls):
        """
        Remove all MPS marker files (temp dir only).
        """
        if os.path.exists(cls.mps_path):
            try:
                shutil.rmtree(cls.mps_path)
                print(
                    f"Cleaned MPS files from "
                    f"{cls.mps_path}"
                )

            except Exception as e:
                print(f"Error cleaning MPS files: {e}")

    def _generate_fake_message(
        self,
        index: int,
    ) -> Dict:
        """
        Generate a fake message with realistic, consumer-contract-valid
        data (see test/message_factory.py).
        """
        trace_id = str(uuid.uuid4())

        self.__class__.trace_ids.append(trace_id)

        message_data = build_message(trace_id=trace_id)
        message_data["message_index"] = index
        message_data["priority_label"] = [
            "low",
            "normal",
            "high",
        ][index % 3]

        return message_data

    def test_01_generate_and_publish_messages(self):
        """
        Step 1: Generate and publish N messages to SQS.
        """
        total_messages = self.__class__.number_of_msg

        print(
            f"\nGenerating and publishing "
            f"{total_messages} messages to SQS..."
        )

        self.__class__.report_generator.record_start()

        client = SQSClient(
            queue_name=self.__class__.queue_name,
            region_name=self.__class__.region,
        )

        print("Connected to SQS")

        batch_size = 10
        start_time = time.time()

        for i in range(
            0,
            total_messages,
            batch_size,
        ):
            batch_messages = []

            for j in range(batch_size):
                if i + j >= total_messages:
                    break

                message_data = (
                    self._generate_fake_message(i + j)
                )

                self.__class__.report_generator.record_message_created()

                batch_messages.append(
                    {
                        "Id": str(j),
                        "MessageBody": message_data,
                        "MessageAttributes": {
                            "trace_id": message_data[
                                "trace_id"
                            ],
                            "priority": message_data[
                                "priority_label"
                            ],
                        },
                    }
                )

            try:
                response = client.send_message_batch(
                    batch_messages
                )

                successful = len(
                    response.get("Successful", [])
                )

                for _ in range(successful):
                    self.__class__.report_generator.record_message_sent()

                if response.get("Failed"):
                    for failure in response["Failed"]:
                        self.__class__.report_generator.record_error(
                            "Failed to send message: "
                            f"{failure.get('Message', 'Unknown')}"
                        )

            except Exception as e:
                self.__class__.report_generator.record_error(
                    f"Batch send error: {str(e)}"
                )

            # Progress update every 100 messages
            if (i + batch_size) % 100 == 0:
                elapsed = time.time() - start_time
                rate = (
                    (i + batch_size) / elapsed
                    if elapsed > 0
                    else 0
                )

                print(
                    f"Published {i + batch_size}/"
                    f"{total_messages} messages "
                    f"(Rate: {rate:.2f} msg/sec)..."
                )

        publish_duration = time.time() - start_time

        self.__class__.report_generator.add_performance_metric(
            "Message Generation & Publish Time (sec)",
            publish_duration,
        )
        self.__class__.report_generator.add_performance_metric(
            "Publish Throughput (msg/sec)",
            (
                self.__class__.report_generator.test_results[
                    "messages_sent"
                ]
                / max(publish_duration, 0.001)
            ),
        )

        print(
            "\nCompleted publishing "
            f"{self.__class__.report_generator.test_results['messages_sent']} "
            "messages"
        )
        print(
            f"Time taken: {publish_duration:.2f} seconds"
        )

        self.assertEqual(
            self.__class__.report_generator.test_results[
                "messages_sent"
            ],
            total_messages,
            "Not all messages were published successfully",
        )

    def test_02_receive_and_process_with_idempotency(self):
        """
        Step 2: Receive and process messages with idempotency checking.
        """
        print(
            "\nReceiving and processing messages "
            "with idempotency..."
        )

        client = SQSClient(
            queue_name=self.__class__.queue_name,
            region_name=self.__class__.region,
            enable_idempotency=True,
            mps_storage_path=self.__class__.mps_path,
        )

        max_iterations = 1500  # Max iterations to process
        empty_polls = 0
        processed_count = 0
        skipped_count = 0
        start_time = time.time()

        for iteration in range(max_iterations):
            messages = client.receive_messages_as_objects(
                max_messages=10,
                wait_time_seconds=1,
            )

            if not messages:
                # Check if we've processed enough messages
                if (
                    processed_count
                    >= self.__class__.report_generator.test_results[
                        "messages_sent"
                    ]
                ):
                    print("All messages processed!")
                    break

                empty_polls += 1

                if empty_polls >= 10:
                    print(
                        "Queue drained before all messages "
                        "were seen - stopping"
                    )
                    break

                continue

            empty_polls = 0

            for msg in messages:
                try:
                    self.__class__.report_generator.record_message_received()

                    # Check for duplicates
                    is_duplicate = client.check_duplicates(
                        msg.trace_id
                    )

                    if is_duplicate:
                        self.__class__.report_generator.record_duplicate_detected()
                        skipped_count += 1

                        # Still delete duplicate message
                        client.delete_msg(
                            msg.receipt_handle
                        )
                        continue

                    # Mark processing start (atomic)
                    can_process = client.mark_processing_start(
                        msg.trace_id,
                        msg.retry_count,
                    )

                    if not can_process:
                        skipped_count += 1
                        continue

                    # Simulated processing lag (configurable;
                    # default 0)
                    if PROCESSING_LAG_SECONDS > 0:
                        sleep(PROCESSING_LAG_SECONDS)

                    processing_success = True

                    # Mark processing end
                    client.mark_processing_end(
                        msg.trace_id,
                        msg.retry_count,
                        success=processing_success,
                    )

                    if processing_success:
                        self.__class__.report_generator.record_message_processed()
                        processed_count += 1

                        # Delete message from queue
                        client.delete_msg(
                            msg.receipt_handle
                        )
                    else:
                        self.__class__.report_generator.record_message_failed()

                except Exception as e:
                    self.__class__.report_generator.record_error(
                        f"Processed error: {str(e)}"
                    )
                    self.__class__.report_generator.record_message_failed()

            # Progress update every 100 iterations
            if iteration % 100 == 0 and iteration > 0:
                elapsed = time.time() - start_time
                rate = (
                    processed_count / elapsed
                    if elapsed > 0
                    else 0
                )

                print(
                    f"Processed {processed_count} messages, "
                    f"Skipped {skipped_count} "
                    f"(Rate: {rate:.2f} msg/sec, "
                    f"Iteration {iteration})..."
                )

        processing_duration = time.time() - start_time

        self.__class__.report_generator.add_performance_metric(
            "Message Processing Time (sec)",
            processing_duration,
        )
        self.__class__.report_generator.add_performance_metric(
            "Processing Throughput (msg/sec)",
            processed_count / max(processing_duration, 0.001),
        )

        print(
            f"\nCompleted processing "
            f"{processed_count} messages"
        )
        print(
            f"Skipped {skipped_count} "
            "duplicate/in-progress messages"
        )
        print(
            f"Time taken: "
            f"{processing_duration:.2f} seconds"
        )

    def test_03_validate_idempotency_with_sample(self):
        """
        Step 3: Validate idempotency by checking a random sample
        of trace IDs.
        """
        print(
            "\nValidating idempotency with "
            "sample trace IDs..."
        )

        client = SQSClient(
            queue_name=self.__class__.queue_name,
            region_name=self.__class__.region,
            enable_idempotency=True,
            mps_storage_path=self.__class__.mps_path,
        )

        #Pick up to 100 random trace_ids to validate
        import random

        sample_size = min(
            100,
            len(self.__class__.trace_ids),
        )

        sample_trace_ids = random.sample(
            self.__class__.trace_ids,
            sample_size,
        )

        duplicate_count = 0

        for trace_id in sample_trace_ids:
            is_duplicate = client.check_duplicates(
                trace_id
            )

            if is_duplicate:
                duplicate_count += 1

        print(
            f"Checked {sample_size} sample messages"
        )
        print(
            f"Found {duplicate_count} with END markers "
            "(already processed)"
        )

        duplicate_percentage = (
            duplicate_count / sample_size * 100
        ) if sample_size > 0 else 0

        print(
            f"Duplicate detection rate: "
            f"{duplicate_percentage:.2f}%"
        )

        # Assert that we detected some duplicates
        # (idempotency is working)
        self.assertGreater(
            duplicate_count,
            0,
            "Idempotency validation failed - "
            "no END markers found",
        )


if __name__ == "__main__":
    emit(
        "pod_start",
        service="sqs_test_consumer",
    )

    unittest.main()
