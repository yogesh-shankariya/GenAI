"""
Shared pytest configuration.

Forces fake AWS credentials for the whole test session so no test can
ever authenticate against a real AWS account - all SQS traffic must go
through moto. Also puts the repo root on sys.path so `import
sqs_service` works from any invocation directory.
"""

import os
import pathlib
import sys

sys.path.insert(
    0,
    str(pathlib.Path(__file__).resolve().parents[1]),
)

os.environ["AWS_ACCESS_KEY_ID"] = "testing"
os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"
os.environ["AWS_SECURITY_TOKEN"] = "testing"
os.environ["AWS_SESSION_TOKEN"] = "testing"
os.environ["AWS_DEFAULT_REGION"] = "us-east-2"
os.environ.pop("AWS_PROFILE", None)

# Defaults so importing constant.py never fails during collection
os.environ.setdefault("SQS_INPUT_QUEUE_NAME", "test-input-queue")
os.environ.setdefault("SQS_OUTPUT_QUEUE_NAME", "test-output-queue")
os.environ.setdefault("SQS_ERROR_QUEUE_NAME", "test-error-queue")
os.environ.setdefault("SQS_AWS_REGION", "us-east-2")
os.environ.setdefault("INPUT_QUEUE_TYPE", "SQS")
