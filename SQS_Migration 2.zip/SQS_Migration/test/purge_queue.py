"""
Purge an SQS queue and wait until it is actually empty.

AWS PurgeQueue is asynchronous: deletion can take up to 60 seconds and
messages sent DURING the purge window may also be deleted. This script
polls the queue attributes after purging and warns before returning,
so a test run started immediately afterwards is safe.

LIVE-QUEUE OPERATION - requires RUN_LIVE=1 (client environment only).

Usage:
    RUN_LIVE=1 python test/purge_queue.py [queue_name] [region]
"""

import os
import pathlib
import sys
import time

sys.path.insert(
    0,
    str(pathlib.Path(__file__).resolve().parents[1]),
)

from botocore.exceptions import ClientError

from sqs_service import SQSClient


PURGE_WINDOW_SECONDS = 60


def purge_queue_and_wait(
    queue_name: str,
    region: str = "us-east-2",
):
    client = SQSClient(
        queue_name=queue_name,
        region_name=region,
    )

    print(f"Purging queue {queue_name} ...")

    try:
        client.purge_queue()

    except ClientError as e:
        code = e.response.get("Error", {}).get("Code", "")

        if code == "AWS.SimpleQueueService.PurgeQueueInProgress":
            print(
                "A purge is already in progress "
                "(SQS allows one per 60s) - waiting it out"
            )
        else:
            print(f"Error purging queue: {e}")
            sys.exit(1)

    # Poll until the queue reports fully empty
    deadline = time.time() + PURGE_WINDOW_SECONDS + 30

    while time.time() < deadline:
        attrs = client.get_queue_attributes(
            [
                "ApproximateNumberOfMessages",
                "ApproximateNumberOfMessagesNotVisible",
                "ApproximateNumberOfMessagesDelayed",
            ]
        )

        remaining = sum(
            int(attrs.get(name, 0))
            for name in (
                "ApproximateNumberOfMessages",
                "ApproximateNumberOfMessagesNotVisible",
                "ApproximateNumberOfMessagesDelayed",
            )
        )

        if remaining == 0:
            break

        print(f"  {remaining} messages still reported - waiting...")
        time.sleep(5)

    print(
        "Queue purged. NOTE: messages sent within the last "
        f"{PURGE_WINDOW_SECONDS}s purge window may also have been "
        "deleted - wait before ingesting new test messages."
    )


def main():
    if os.environ.get("RUN_LIVE") != "1":
        print(
            "REFUSING to purge: this deletes ALL messages on a real "
            "queue. Set RUN_LIVE=1 to confirm (client environment only)."
        )
        sys.exit(2)

    queue_name = (
        sys.argv[1]
        if len(sys.argv) > 1
        else os.environ.get("SQS_INPUT_QUEUE_NAME", "dev-HOSSYTH_rallm")
    )
    region = (
        sys.argv[2]
        if len(sys.argv) > 2
        else os.environ.get("SQS_AWS_REGION", "us-east-2")
    )

    purge_queue_and_wait(queue_name, region)


if __name__ == "__main__":
    main()
