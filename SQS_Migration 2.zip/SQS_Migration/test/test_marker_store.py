"""
Contract tests for the MarkerStore port.

Every test here runs identically against EVERY backend (parametrized
fixture) - that is the point: the idempotency semantics live in the
port's contract, not in any one storage technology. A future
RedisMarkerStore/DynamoDBMarkerStore must pass this exact suite
(against fakeredis / moto DynamoDB) before it can ship.

Pure in-process tests - no AWS, no mocks needed except tmp_path.
"""

import threading
import uuid

import pytest

from sqs_service import (
    FileMarkerStore,
    InMemoryMarkerStore,
    MarkerStore,
    MPSManager,
    SQSClient,
    check_duplicate_status,
)


QUEUE = "dev-HOSSYTH_rallm"

BACKENDS = ["file", "memory"]


@pytest.fixture(params=BACKENDS)
def make_store(request, tmp_path):
    """
    Factory: make_store(timeout_seconds=...) -> a fresh MarkerStore
    of the parametrized backend.
    """
    def _make(timeout_seconds: float = 4 * 60 * 60) -> MarkerStore:
        if request.param == "file":
            return FileMarkerStore(
                storage_path=str(tmp_path),
                timeout_seconds=timeout_seconds,
            )
        return InMemoryMarkerStore(timeout_seconds=timeout_seconds)

    return _make


@pytest.fixture
def store(make_store):
    return make_store()


def test_claim_refused_while_live(store):
    trace_id = str(uuid.uuid4())

    claimed_first, _ = store.create_start_marker(trace_id, QUEUE)
    claimed_second, _ = store.create_start_marker(trace_id, QUEUE)

    assert claimed_first
    assert not claimed_second


def test_stale_claim_allows_takeover(make_store):
    # 0-second lease: every claim is immediately stale (crashed owner)
    store = make_store(timeout_seconds=0)
    trace_id = str(uuid.uuid4())

    claimed_first, _ = store.create_start_marker(trace_id, QUEUE)
    claimed_second, _ = store.create_start_marker(trace_id, QUEUE)

    assert claimed_first
    assert claimed_second


def test_success_end_suppresses_failed_end_does_not(store):
    trace_id = str(uuid.uuid4())

    store.create_start_marker(trace_id, QUEUE)
    store.create_end_marker(trace_id, QUEUE, success=False)
    assert not store.has_end_marker(trace_id, QUEUE)

    store.create_end_marker(trace_id, QUEUE, success=True)
    assert store.has_end_marker(trace_id, QUEUE)

    # Success is sticky: a later failed run must not un-suppress
    store.create_end_marker(trace_id, QUEUE, success=False)
    assert store.has_end_marker(trace_id, QUEUE)


def test_end_marker_clears_start(store):
    trace_id = str(uuid.uuid4())

    store.create_start_marker(trace_id, QUEUE)
    store.create_end_marker(trace_id, QUEUE, success=False)

    assert store.get_start_marker(trace_id, QUEUE) is None

    # ...so a failed message redelivers into a fresh claim, not a
    # lease wait
    claimed, _ = store.create_start_marker(trace_id, QUEUE)
    assert claimed


def test_four_scenarios_are_backend_agnostic(make_store):
    # check_duplicate_status is domain logic over the port - it must
    # behave identically on every backend
    store = make_store()
    trace_id = str(uuid.uuid4())

    # D: new message
    result = check_duplicate_status(store, trace_id, QUEUE)
    assert result.should_process and not result.is_takeover

    # B: live claim
    store.create_start_marker(trace_id, QUEUE)
    assert not check_duplicate_status(store, trace_id, QUEUE).should_process

    # A: successful END
    store.create_end_marker(trace_id, QUEUE, success=True)
    result = check_duplicate_status(store, trace_id, QUEUE)
    assert not result.should_process
    assert "MPS_END" in result.reason

    # C: stale claim -> takeover
    stale_store = make_store(timeout_seconds=0)
    takeover_trace = str(uuid.uuid4())
    stale_store.create_start_marker(takeover_trace, QUEUE)
    result = check_duplicate_status(stale_store, takeover_trace, QUEUE)
    assert result.should_process and result.is_takeover


def test_hostile_ids_rejected_by_every_backend(store):
    # _validate_id is a security boundary: every public read AND
    # write path must reject hostile ids, on every backend
    for hostile in ("bad__trace", "../../etc/pwned", "a/b", ".."):
        with pytest.raises(ValueError):
            store.create_start_marker(hostile, QUEUE)

        with pytest.raises(ValueError):
            store.create_end_marker(hostile, QUEUE)

        with pytest.raises(ValueError):
            store.has_end_marker(hostile, QUEUE)

        with pytest.raises(ValueError):
            store.get_start_marker(hostile, QUEUE)


def test_concurrent_claim_single_winner(store):
    trace_id = str(uuid.uuid4())
    barrier = threading.Barrier(2)
    results = []

    def contender():
        barrier.wait()
        claimed, _ = store.create_start_marker(trace_id, QUEUE)
        results.append(claimed)

    threads = [threading.Thread(target=contender) for _ in range(2)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    assert sorted(results) == [False, True]


def test_cleanup_removes_old_markers(store):
    import time

    trace_id = str(uuid.uuid4())
    store.create_end_marker(trace_id, QUEUE, success=True)
    time.sleep(0.02)

    removed = store.cleanup_old_markers(max_age_seconds=0)

    assert removed >= 1
    assert not store.has_end_marker(trace_id, QUEUE)


def test_sqs_client_accepts_injected_backend():
    # The client depends on the port, not a backend: injecting the
    # in-memory store gives a fully working idempotent lifecycle with
    # zero filesystem/AWS involvement (constructor and hooks make no
    # AWS calls).
    client = SQSClient(
        queue_name=QUEUE,
        region_name="us-east-2",
        marker_store=InMemoryMarkerStore(),
    )

    assert client.enable_idempotency
    assert client.marker_store is client.mps_manager

    trace_id = str(uuid.uuid4())

    assert not client.check_duplicates(trace_id)
    assert client.mark_processing_start(trace_id)
    assert not client.mark_processing_start(trace_id)  # concurrent dup
    assert client.mark_processing_end(trace_id, success=True)
    assert client.check_duplicates(trace_id)  # redelivery suppressed


def test_file_marker_store_is_mps_manager():
    # FileMarkerStore is the modern name for the historical class -
    # one implementation, two names, zero behavior drift
    assert FileMarkerStore is MPSManager
    assert issubclass(MPSManager, MarkerStore)
    assert issubclass(InMemoryMarkerStore, MarkerStore)


# ----------------------------------------------------------------------
# Config-driven backend selection (create_marker_store)
# ----------------------------------------------------------------------

from sqs_service import (  # noqa: E402
    create_marker_store,
    register_marker_store_backend,
)
from sqs_service.marker_store import _BACKEND_BUILDERS  # noqa: E402


def test_factory_defaults_to_file(tmp_path, monkeypatch):
    monkeypatch.delenv("MPS_BACKEND", raising=False)

    store = create_marker_store(storage_path=str(tmp_path))

    assert isinstance(store, FileMarkerStore)


def test_factory_env_selects_backend(tmp_path, monkeypatch):
    # The manager's requirement: switching storage is a CONFIG change
    monkeypatch.setenv("MPS_BACKEND", "memory")
    assert isinstance(create_marker_store(), InMemoryMarkerStore)

    # An explicit argument overrides the environment
    monkeypatch.setenv("MPS_BACKEND", "file")
    assert isinstance(
        create_marker_store(backend="memory"), InMemoryMarkerStore
    )


def test_factory_unknown_backend_fails_loudly(monkeypatch):
    monkeypatch.setenv("MPS_BACKEND", "redis")

    with pytest.raises(ValueError, match="redis"):
        create_marker_store()


def test_factory_file_backend_requires_a_path(monkeypatch):
    monkeypatch.delenv("MPS_BACKEND", raising=False)
    monkeypatch.delenv("SQS_MPS_PATH", raising=False)

    with pytest.raises(ValueError, match="storage path"):
        create_marker_store()


def test_factory_registration_is_open_closed():
    # A new adapter plugs in without modifying the factory
    name = "contract-test-backend"
    register_marker_store_backend(
        name, lambda **options: InMemoryMarkerStore()
    )

    try:
        store = create_marker_store(backend=name)
        assert isinstance(store, InMemoryMarkerStore)
    finally:
        _BACKEND_BUILDERS.pop(name, None)


def test_client_backend_swaps_via_config_only(tmp_path, monkeypatch):
    # End to end: the SQSClient construction line is IDENTICAL in both
    # cases - only the environment differs. This is the no-code-change
    # swap the backend abstraction exists for.
    monkeypatch.setenv("MPS_BACKEND", "memory")
    client = SQSClient(
        queue_name=QUEUE,
        region_name="us-east-2",
        enable_idempotency=True,
        mps_storage_path=str(tmp_path),
    )
    assert isinstance(client.mps_manager, InMemoryMarkerStore)

    monkeypatch.setenv("MPS_BACKEND", "file")
    client = SQSClient(
        queue_name=QUEUE,
        region_name="us-east-2",
        enable_idempotency=True,
        mps_storage_path=str(tmp_path),
    )
    assert isinstance(client.mps_manager, FileMarkerStore)


def test_factory_file_backend_uses_env_path(tmp_path, monkeypatch):
    # The documented SQS_MPS_PATH fallback, positively verified
    monkeypatch.setenv("SQS_MPS_PATH", str(tmp_path))

    store = create_marker_store(backend="file")

    assert isinstance(store, FileMarkerStore)
    assert str(store.storage_path) == str(tmp_path)


def test_factory_passes_timeout_through(tmp_path):
    assert (
        create_marker_store(
            backend="memory", timeout_seconds=1
        ).timeout_seconds
        == 1
    )
    assert (
        create_marker_store(
            backend="file",
            storage_path=str(tmp_path),
            timeout_seconds=2,
        ).timeout_seconds
        == 2
    )


def test_factory_rejects_unknown_options(tmp_path):
    # A misspelled option must fail loudly, never silently yield the
    # default lease
    with pytest.raises(ValueError, match="timeout_secs"):
        create_marker_store(
            backend="file",
            storage_path=str(tmp_path),
            timeout_secs=60,
        )


def test_factory_empty_env_means_default(tmp_path, monkeypatch):
    # Templated k8s config often renders MPS_BACKEND: "" - that must
    # mean "default", not "unknown backend ''"
    monkeypatch.setenv("MPS_BACKEND", "")

    store = create_marker_store(storage_path=str(tmp_path))

    assert isinstance(store, FileMarkerStore)


def test_registration_collision_raises():
    # Silently replacing a registered backend (especially "file")
    # would swap production storage behind ops' back
    with pytest.raises(ValueError, match="already registered"):
        register_marker_store_backend(
            "file", lambda **options: InMemoryMarkerStore()
        )


def test_success_end_survives_cleanup_of_failed_end(store):
    # END records age individually (one record per write, like one
    # file per write): cleaning up must not let a young failed END
    # drag a suppressing success record along with it, nor vice versa
    import time as _time

    trace_id = str(uuid.uuid4())
    store.create_end_marker(trace_id, QUEUE, success=True)
    _time.sleep(0.05)
    store.create_end_marker(trace_id, QUEUE, success=False)

    # Cutoff between the two writes: only the older SUCCESS record is
    # removed; the young failed record survives and does not suppress
    store.cleanup_old_markers(max_age_seconds=0.025)

    assert not store.has_end_marker(trace_id, QUEUE)
