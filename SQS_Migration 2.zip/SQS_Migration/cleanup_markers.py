#!/usr/bin/env python3
"""
Marker-store garbage collector - the scheduled entrypoint for
cleanup_old_markers, which nothing else in the codebase invokes
(see IDEMPOTENT_SQS_PROCESSING.md section 5.3, Gap 6).

Run it daily from a Kubernetes CronJob (example spec in README.md).
Deliberately does NOT import constant.py, so the CronJob pod only
needs SQS_MPS_PATH (and optionally MPS_BACKEND) in its environment -
not the consumer's queue configuration.

Usage:
    SQS_MPS_PATH=/data/main_resources/runtime_files_space \\
        python cleanup_markers.py [--max-age-days 7]

The retention window IS the dedup memory: a duplicate arriving after
the window would be reprocessed. Keep it longer than the longest
realistic redelivery gap.
"""

import argparse
import os
import sys

from sqs_service import create_marker_store


def main() -> int:
    parser = argparse.ArgumentParser(
        description="Remove idempotency markers older than the "
        "retention window.",
    )
    parser.add_argument(
        "--max-age-days",
        type=float,
        default=7.0,
        help="Retention window in days (default: 7)",
    )
    args = parser.parse_args()

    if args.max_age_days <= 0:
        parser.error("--max-age-days must be positive")

    # Backend from MPS_BACKEND env (default "file"); storage path from
    # SQS_MPS_PATH env, falling back to the same default the consumer
    # uses (keep the literal in sync with constant.py SQS_MPS_PATH) so
    # a deployment relying on that default gets a working cleaner,
    # not a crash-looping CronJob.
    store = create_marker_store(
        storage_path=(
            os.environ.get("SQS_MPS_PATH")
            or "/data/main_resources/runtime_files_space"
        ),
    )
    removed = store.cleanup_old_markers(
        max_age_seconds=args.max_age_days * 24 * 60 * 60,
    )
    print(f"cleanup_old_markers: removed {removed} marker file(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
