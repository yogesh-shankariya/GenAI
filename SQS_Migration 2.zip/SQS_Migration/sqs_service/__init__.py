# Bump on any behavioral change; logged/queryable so a deployed build
# is identifiable (there is no packaging metadata for this vendored
# library).
__version__ = "1.2.0"

from .marker_store import (
    MarkerStore,
    InMemoryMarkerStore,
    create_marker_store,
    register_marker_store_backend,
)
from .sqs_idempotent_processor import (
    SQSClient,
    SQSMessage,
    ProcessingResult,
    logger,
    MDCContext,
    MDCMarker,
    log_lifecycle_marker,
    ProcessingError,
    ValidationError,
    ProcessingTimeoutError,
    PublishError,
)
from .mps_manager import (
    MPSManager,
    FileMarkerStore,
    MPSInfo,
    DuplicateCheckResult,
    check_duplicate_status,
    MPSType,
)
from .sqs_parallel_processor import (
    ParallelSQSProcessor,
    process_messages_parallel,
)
