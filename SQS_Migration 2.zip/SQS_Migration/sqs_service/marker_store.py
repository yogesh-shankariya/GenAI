"""
MarkerStore - the storage port for idempotency markers
======================================================

This module is the seam that makes the idempotency ledger's storage
backend swappable (SOLID: the domain logic depends on this abstraction,
never on a concrete backend - Dependency Inversion; new backends are
added without modifying existing code - Open/Closed).

Architecture (Ports & Adapters / Strategy pattern - the same shape as
AWS Lambda Powertools' idempotency "persistence layer"):

    check_duplicate_status / SQSClient hooks   (domain logic)
                     |
                     v
                MarkerStore                    (this port)
                     |
        +------------+------------------+
        v            v                  v
    MPSManager   InMemoryMarkerStore   RedisMarkerStore /
    (files,      (dict, tests/dev)     DynamoDBMarkerStore
     today's                            (future - blueprint below)
     production)

A backend must provide FOUR guarantees, each enforced however the
technology allows:

1. **Atomic claim** (`create_start_marker`): at most one caller across
   all pods/threads gets `(True, ...)` for a live claim on the same
   (trace_id, queue_name). Files use an in-process lock registry +
   kernel fcntl; Redis uses SET NX; DynamoDB uses a conditional write.
2. **Lease expiry / takeover**: a START older than `timeout_seconds`
   is treated as a crashed owner - a new claim succeeds (and reports
   the old marker gone).
3. **Success-only suppression** (`has_end_marker`): only a SUCCESSFUL
   END suppresses reprocessing; a failed END must not (it would
   permanently poison the message).
4. **END clears START** (`create_end_marker`): finishing a message
   (either way) removes its START so redelivery of a *failed* message
   retries immediately instead of waiting out the lease.

Future-backend blueprint (do NOT implement without a test double -
fakeredis / moto DynamoDB - and a review):

    RedisMarkerStore
        START claim : SET mps:{queue}:{trace}:start <ts> NX PX <lease_ms>
                      (NX = atomic claim; PX = the lease - expiry IS
                      the takeover mechanism, no stale-scan needed)
        END write   : SET mps:{queue}:{trace}:end success|failed
                      PX <gc_ms>  then DEL ...:start  (MULTI/EXEC)
        END check   : GET ...:end == "success"
        cleanup     : free - Redis TTL does it

    DynamoDBMarkerStore
        START claim : PutItem(pk="{queue}#{trace}", sk="start")
                      ConditionExpression:
                        attribute_not_exists(pk) OR lease_until < :now
        END write   : TransactWriteItems: Put end item (+ TTL attr),
                      Delete start item
        END check   : GetItem end, status attribute == "success"
        cleanup     : free - DynamoDB TTL does it

Data model note: `MPSInfo.filepath` is an opaque backend reference -
a real file path for MPSManager, a synthetic "memory://..." ref for
InMemoryMarkerStore, and would be a key name for Redis/DynamoDB.
"""

import os
import threading
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from enum import Enum
from typing import Callable, Dict, List, Optional, Tuple

from ._logging import get_logger


logger = get_logger()

__all__ = [
    "MarkerStore",
    "InMemoryMarkerStore",
    "MPSInfo",
    "MPSType",
    "create_marker_store",
    "register_marker_store_backend",
]


class MPSType(Enum):
    START = "start"
    END = "end"


@dataclass(frozen=True)
class MPSInfo:
    """
    A marker record as seen through the port. Immutable: backends may
    hand out references to their internal records, so a mutable
    instance would let callers rewrite store state from outside.

    filepath is an opaque backend reference (file path, memory ref,
    or key name) - callers must not parse it.
    """

    trace_id: str
    queue_name: str
    mps_type: MPSType
    retry_count: int
    timestamp: float
    filepath: str


class MarkerStore(ABC):
    """
    Abstract storage backend for idempotency markers.

    Subclasses set `timeout_seconds` (the START lease used for
    crashed-owner takeover) and implement the five abstract methods
    honoring the four guarantees in the module docstring. Everything
    above this interface (`check_duplicate_status`, the `SQSClient`
    hooks) is backend-agnostic.
    """

    timeout_seconds: float

    @staticmethod
    def _validate_id(
        value: str,
        field: str,
        allow_separator: bool = False,
    ) -> None:
        """
        Reject ids that would break keys, filenames, or globs, or
        escape a storage directory. trace_id comes from message
        bodies - external input - so this is a security boundary
        shared by every backend.
        """
        if not value or not isinstance(value, str):
            raise ValueError(f"{field} must be a non-empty string")

        if (
            "/" in value
            or "\\" in value
            or "\x00" in value
            or value in (".", "..")
        ):
            raise ValueError(
                f"{field} must not contain path separators: {value!r}"
            )

        if not allow_separator and "__" in value:
            raise ValueError(
                f"{field} must not contain '__': {value!r}"
            )

    # ------------------------------------------------------------------
    # The port
    # ------------------------------------------------------------------

    @abstractmethod
    def create_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
    ) -> Tuple[bool, str]:
        """
        Atomically claim the message. Returns (claimed, reference).
        (False, ref-or-"") when another owner holds a live claim.
        """

    @abstractmethod
    def create_end_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
        success: bool = True,
    ) -> str:
        """
        Record completion (the durable dedup record) and remove the
        message's START markers. Returns a backend reference.
        """

    @abstractmethod
    def has_end_marker(self, trace_id: str, queue_name: str) -> bool:
        """
        True only if the message completed SUCCESSFULLY.
        """

    @abstractmethod
    def get_start_marker(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Optional[MPSInfo]:
        """
        The most recent START marker, or None.
        """

    @abstractmethod
    def cleanup_old_markers(
        self,
        max_age_seconds: float = 7 * 24 * 60 * 60,
    ) -> int:
        """
        Remove markers older than max_age_seconds; returns the count.
        Backends with native TTL (Redis/DynamoDB) may make this a
        no-op returning 0.
        """

    # ------------------------------------------------------------------
    # Shared behavior
    # ------------------------------------------------------------------

    def is_start_marker_stale(self, start_info: MPSInfo) -> bool:
        """
        A START older than the lease belongs to a presumed-dead owner.
        """
        age = time.time() - start_info.timestamp
        return age > self.timeout_seconds


class InMemoryMarkerStore(MarkerStore):
    """
    Process-local, thread-safe MarkerStore backed by dicts.

    Purpose: unit tests, local demos, and single-process consumers.
    NOT suitable for multi-pod production - state is neither shared
    nor durable (a restart forgets every marker). Its real job is to
    prove the port is substitutable: the contract test suite runs
    identically against this and the filesystem backend.
    """

    def __init__(self, timeout_seconds: float = 4 * 60 * 60):
        self.timeout_seconds = timeout_seconds
        self._lock = threading.Lock()
        self._starts: Dict[Tuple[str, str], MPSInfo] = {}
        # key -> one record per END write, exactly like the file
        # backend keeps one file per write: each record ages
        # individually under cleanup, so suppression semantics stay
        # identical across backends in every interleaving
        self._ends: Dict[
            Tuple[str, str], List[Tuple[MPSInfo, bool]]
        ] = {}

    def _ref(self, trace_id: str, queue_name: str, kind: str) -> str:
        return f"memory://{queue_name}/{trace_id}/{kind}"

    def create_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
    ) -> Tuple[bool, str]:
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)

        key = (trace_id, queue_name)

        with self._lock:
            existing = self._starts.get(key)

            if existing is not None:
                if not self.is_start_marker_stale(existing):
                    return False, existing.filepath
                # Stale claim: crashed owner - take over
                del self._starts[key]

            info = MPSInfo(
                trace_id=trace_id,
                queue_name=queue_name,
                mps_type=MPSType.START,
                retry_count=retry_count,
                timestamp=time.time(),
                filepath=self._ref(trace_id, queue_name, "start"),
            )
            self._starts[key] = info
            return True, info.filepath

    def create_end_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
        success: bool = True,
    ) -> str:
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)

        key = (trace_id, queue_name)

        with self._lock:
            info = MPSInfo(
                trace_id=trace_id,
                queue_name=queue_name,
                mps_type=MPSType.END,
                retry_count=retry_count,
                timestamp=time.time(),
                filepath=self._ref(trace_id, queue_name, "end"),
            )
            # Append, never replace: one record per END write, exactly
            # like the file backend keeps one END file per write. Any
            # surviving successful record suppresses - which also
            # makes success sticky against a later failed run, and
            # keeps cleanup aging each record individually so both
            # backends agree in every interleaving.
            self._ends.setdefault(key, []).append((info, success))

            # Finishing removes the claim so a failed message
            # redelivers into immediate reprocessing, not a lease wait
            self._starts.pop(key, None)

            return info.filepath

    def has_end_marker(self, trace_id: str, queue_name: str) -> bool:
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)

        with self._lock:
            records = self._ends.get((trace_id, queue_name), [])
            return any(success for _, success in records)

    def get_start_marker(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Optional[MPSInfo]:
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)

        with self._lock:
            # MPSInfo is frozen, so handing out the stored record
            # cannot let callers rewrite store state
            return self._starts.get((trace_id, queue_name))

    def cleanup_old_markers(
        self,
        max_age_seconds: float = 7 * 24 * 60 * 60,
    ) -> int:
        cutoff = time.time() - max_age_seconds
        removed = 0

        with self._lock:
            for key in list(self._starts):
                if self._starts[key].timestamp < cutoff:
                    del self._starts[key]
                    removed += 1

            for key in list(self._ends):
                kept = [
                    (info, success)
                    for info, success in self._ends[key]
                    if info.timestamp >= cutoff
                ]
                removed += len(self._ends[key]) - len(kept)

                if kept:
                    self._ends[key] = kept
                else:
                    del self._ends[key]

        return removed


# ----------------------------------------------------------------------
# Config-driven backend selection (the composition root)
# ----------------------------------------------------------------------
#
# The MPS_BACKEND environment variable (or an explicit `backend=` arg)
# decides which adapter runs - swapping file -> redis in the future is
# a CONFIG change, not a code change. New backends self-register via
# register_marker_store_backend() (Open/Closed: the factory is never
# edited to add one).

def _reject_unknown_options(backend_name: str, options: Dict) -> None:
    # A misspelled option (timeout_secs=...) silently yielding the
    # default lease would violate the fail-loudly principle below
    if options:
        raise ValueError(
            f"Unknown options for the {backend_name!r} marker-store "
            f"backend: {sorted(options)}"
        )


def _build_file_backend(**options) -> MarkerStore:
    # Imported lazily: mps_manager imports this module at load time,
    # so a top-level import here would be circular.
    from .mps_manager import MPSManager

    storage_path = options.pop("storage_path", None) or os.environ.get(
        "SQS_MPS_PATH"
    )
    timeout_seconds = options.pop("timeout_seconds", 4 * 60 * 60)
    _reject_unknown_options("file", options)

    if not storage_path:
        raise ValueError(
            "The 'file' marker-store backend needs a storage path: "
            "pass storage_path=... or set SQS_MPS_PATH"
        )

    return MPSManager(
        storage_path=storage_path,
        timeout_seconds=timeout_seconds,
    )


def _build_memory_backend(**options) -> MarkerStore:
    # storage_path is accepted-and-ignored BY DESIGN: it lets the
    # SQSClient(..., mps_storage_path=...) construction line stay
    # identical while MPS_BACKEND alone decides the storage
    options.pop("storage_path", None)
    timeout_seconds = options.pop("timeout_seconds", 4 * 60 * 60)
    _reject_unknown_options("memory", options)

    return InMemoryMarkerStore(timeout_seconds=timeout_seconds)


_BACKEND_BUILDERS: Dict[str, Callable[..., MarkerStore]] = {
    "file": _build_file_backend,
    "memory": _build_memory_backend,
}


def register_marker_store_backend(
    name: str,
    builder: Callable[..., MarkerStore],
    overwrite: bool = False,
) -> None:
    """
    Register a new backend under a config name, e.g.::

        register_marker_store_backend("redis", RedisMarkerStore.from_env)

    `builder(**options) -> MarkerStore` is called by
    create_marker_store when MPS_BACKEND (or backend=) equals `name`.
    Registering is how future adapters plug in WITHOUT modifying this
    module (Open/Closed).

    A name collision raises unless overwrite=True: silently replacing
    a registered backend (especially the built-in "file") would swap
    production storage behind ops' back.
    """
    key = name.strip().lower()

    if key in _BACKEND_BUILDERS and not overwrite:
        raise ValueError(
            f"Marker-store backend {key!r} is already registered; "
            "pass overwrite=True to replace it deliberately"
        )

    _BACKEND_BUILDERS[key] = builder


def create_marker_store(
    backend: Optional[str] = None,
    **options,
) -> MarkerStore:
    """
    Build the configured idempotency backend.

    Selection order: explicit `backend=` arg, else the MPS_BACKEND
    environment variable, else "file" (an empty value counts as
    unset - templated config often renders MPS_BACKEND: ""). Options
    are passed through to the backend builder (file: storage_path,
    timeout_seconds; memory: timeout_seconds - storage_path is
    accepted and ignored so caller code stays backend-agnostic);
    unknown option names raise.

    Unknown backend names raise immediately with the registered
    choices - a typo in config must fail loudly at startup, never
    silently fall back to a different storage than ops intended.
    """
    name = (
        backend
        if backend is not None
        else os.environ.get("MPS_BACKEND", "")
    )
    name = name.strip().lower() or "file"

    builder = _BACKEND_BUILDERS.get(name)

    if builder is None:
        raise ValueError(
            f"Unknown marker-store backend {name!r}. Registered "
            f"backends: {sorted(_BACKEND_BUILDERS)}. Future backends "
            "(e.g. 'redis') plug in via "
            "register_marker_store_backend() - implementation "
            "blueprint in sqs_service/marker_store.py's docstring."
        )

    store = builder(**options)
    logger.info(
        "Idempotency marker store: backend=%s (%s)",
        name,
        type(store).__name__,
    )
    return store
