"""
Parallel SQS Message Processing Module

Provides utilities for processing SQS messages in parallel using:
- ThreadPoolExecutor for I/O-bound tasks
- ProcessPoolExecutor for CPU-bound tasks
- AsyncIO for async operations
- A pipelined continuous mode that overlaps receiving with processing

Message lifecycle contract (at-least-once):
- processing_function receives the raw message Body string by default;
  construct with message_arg="message" to receive the full boto3
  message dict instead (needed to read MessageId, ReceiptHandle,
  MessageAttributes such as trace_id, or ApproximateReceiveCount -
  i.e. for composing parallelism with the idempotency hooks).
- Failure is signalled by RAISING, or by returning the exact value
  ``False`` (the convention used by main.process_sqs_message).
- With delete_on_success=True, messages are deleted after successful
  processing; otherwise they become visible again after
  visibility_timeout and WILL be redelivered.
- visibility_timeout must exceed the worst-case processing time of a
  single message; there is no ChangeMessageVisibility heartbeat here.
"""

import asyncio
import functools
import pickle
import threading
import time
from concurrent.futures import (
    FIRST_COMPLETED,
    Future,
    ProcessPoolExecutor,
    ThreadPoolExecutor,
    TimeoutError as FuturesTimeoutError,
    as_completed,
    wait as futures_wait,
)
from concurrent.futures.process import BrokenProcessPool
from typing import Any, Callable, Dict, List, Optional

from .sqs_idempotent_processor import SQSClient
from ._logging import get_logger


logger = get_logger()

# Per-message result dictionary.
# Success: {"success": True, "message_id", "receipt_handle", "result",
#           "deleted": bool, ["delete_error"]}
# Failure: {"success": False, "message_id", "receipt_handle", "error"}
ProcessResult = Dict[str, Any]


class ParallelSQSProcessor:
    """
    Process SQS messages in parallel.

    Args:
        client: SQSClient instance
        processing_function: Called with the message Body string.
            Signal failure by raising, or by returning ``False``.
        max_workers: Maximum number of parallel workers. Also caps how
            many messages are received per cycle, so messages never
            queue behind busy workers while their visibility timeout
            burns down.
        delete_on_success: Whether to delete messages after successful
            processing. Default False: processed messages are NOT
            deleted and redeliver after visibility_timeout.
        visibility_timeout: Message visibility timeout in seconds.
            Must exceed the worst-case single-message processing time.
        message_arg: What processing_function receives - "body" (the
            raw Body string, default) or "message" (the full boto3
            message dict, including MessageId / ReceiptHandle /
            MessageAttributes / Attributes).

    The processor lazily creates one shared ThreadPoolExecutor and (for
    the 'processes' mode) one shared ProcessPoolExecutor, reused across
    calls. Call close() when done, or use the processor as a context
    manager.
    """

    def __init__(
        self,
        client: SQSClient,
        processing_function: Callable[[Any], Any],
        max_workers: int = 10,
        delete_on_success: bool = False,
        visibility_timeout: int = 60,
        message_arg: str = "body",
    ):
        if max_workers < 1:
            raise ValueError("max_workers must be >= 1")

        if message_arg not in ("body", "message"):
            raise ValueError(
                "message_arg must be 'body' or 'message', "
                f"got {message_arg!r}"
            )

        self.client = client
        self.processing_function = processing_function
        self.max_workers = max_workers
        self.delete_on_success = delete_on_success
        self.visibility_timeout = visibility_timeout
        self.message_arg = message_arg

        self._executor_lock = threading.Lock()
        self._thread_executor: Optional[ThreadPoolExecutor] = None
        self._process_executor: Optional[ProcessPoolExecutor] = None
        self._receive_executor: Optional[ThreadPoolExecutor] = None

    def _handler_payload(self, message: Dict[str, Any]) -> Any:
        if self.message_arg == "message":
            return message

        return message.get("Body", "")

    # ------------------------------------------------------------------
    # Executor lifecycle
    # ------------------------------------------------------------------

    def _get_receive_executor(self) -> ThreadPoolExecutor:
        """
        Dedicated single-thread executor for the blocking long-poll
        receive in asyncio mode. Sharing the handler pool would let
        abandoned/slow handlers starve the receive itself.
        """
        with self._executor_lock:
            if self._receive_executor is None:
                self._receive_executor = ThreadPoolExecutor(
                    max_workers=1,
                    thread_name_prefix="sqs-receive",
                )
            return self._receive_executor

    def _get_thread_executor(self) -> ThreadPoolExecutor:
        with self._executor_lock:
            if self._thread_executor is None:
                self._thread_executor = ThreadPoolExecutor(
                    max_workers=self.max_workers,
                    thread_name_prefix="sqs-worker",
                )
            return self._thread_executor

    def _get_process_executor(self) -> ProcessPoolExecutor:
        with self._executor_lock:
            if self._process_executor is None:
                self._process_executor = ProcessPoolExecutor(
                    max_workers=self.max_workers,
                )
            return self._process_executor

    def close(self, wait: bool = True) -> None:
        """
        Shut down the shared executors. Safe to call more than once;
        the executors are recreated lazily if the processor is reused.
        """
        with self._executor_lock:
            if self._thread_executor is not None:
                self._thread_executor.shutdown(wait=wait)
                self._thread_executor = None

            if self._process_executor is not None:
                self._process_executor.shutdown(wait=wait)
                self._process_executor = None

            if self._receive_executor is not None:
                self._receive_executor.shutdown(wait=wait)
                self._receive_executor = None

    def __enter__(self) -> "ParallelSQSProcessor":
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    # ------------------------------------------------------------------
    # Receiving
    # ------------------------------------------------------------------

    def _receive_batch(
        self,
        max_messages: int,
        wait_time_seconds: int,
    ) -> List[Dict[str, Any]]:
        """
        Receive up to min(max_messages, max_workers) messages.

        SQS caps a single ReceiveMessage call at 10 messages, so this
        loops: the first call long-polls with wait_time_seconds, later
        calls use wait 0 and stop at the first empty response. The cap
        at max_workers ensures every received message gets a worker
        immediately instead of burning its visibility timeout in an
        executor queue.
        """
        target = max(1, min(max_messages, self.max_workers))
        messages: List[Dict[str, Any]] = []
        wait = wait_time_seconds

        while len(messages) < target:
            chunk = self.client.receive_messages(
                max_messages=min(
                    SQSClient.MAX_RECEIVE_MESSAGES,
                    target - len(messages),
                ),
                wait_time_seconds=wait,
                visibility_timeout=self.visibility_timeout,
            )

            if not chunk:
                break

            messages.extend(chunk)
            wait = 0

        return messages

    # ------------------------------------------------------------------
    # Result handling
    # ------------------------------------------------------------------

    @staticmethod
    def _failure_result(
        message: Dict[str, Any],
        error: str,
    ) -> ProcessResult:
        return {
            "success": False,
            "message_id": message.get("MessageId"),
            "receipt_handle": message.get("ReceiptHandle"),
            "error": error,
        }

    @staticmethod
    def _classify_result(
        result: ProcessResult,
        results: Dict[str, List[ProcessResult]],
    ) -> None:
        if result["success"]:
            results["successful"].append(result)
            logger.info(
                f"Processed message {result.get('message_id')}"
            )
        else:
            results["failed"].append(result)
            logger.error(
                f"Failed to process message "
                f"{result.get('message_id')}: {result.get('error')}"
            )

    def _delete_in_parent(
        self,
        result: ProcessResult,
        message: Dict[str, Any],
    ) -> ProcessResult:
        """
        Delete a successfully processed message using the parent's
        (correctly credentialed) client. Used by the multiprocessing
        path, whose workers never touch AWS themselves.

        A delete failure is reported as success=True / deleted=False,
        NOT as a processing failure: the work already happened and the
        message will simply redeliver.
        """
        if not result.get("success"):
            return result

        result.setdefault("deleted", False)
        receipt_handle = (
            result.get("receipt_handle")
            or message.get("ReceiptHandle")
        )

        if self.delete_on_success and receipt_handle:
            try:
                self.client.delete_msg(receipt_handle)
                result["deleted"] = True
            except Exception as e:
                logger.warning(
                    f"Processed message {result.get('message_id')} "
                    f"but delete failed - it will redeliver: {e}"
                )
                result["delete_error"] = str(e)

        return result

    def _collect_future_results(
        self,
        future_to_message: Dict[Future, Dict[str, Any]],
        batch_timeout: Optional[float] = None,
        on_completed: Optional[
            Callable[[ProcessResult, Dict[str, Any]], ProcessResult]
        ] = None,
    ) -> Dict[str, List[ProcessResult]]:
        """
        Collect futures as they complete into the results dict.

        With batch_timeout set, futures still pending when the overall
        timeout elapses are cancelled and recorded as failed (their
        messages redeliver after the visibility timeout). A thread
        already running cannot be interrupted - processing_function
        should enforce its own internal timeouts.
        """
        results: Dict[str, List[ProcessResult]] = {
            "successful": [],
            "failed": [],
        }
        pending = set(future_to_message)

        try:
            for future in as_completed(
                future_to_message,
                timeout=batch_timeout,
            ):
                pending.discard(future)
                message = future_to_message[future]

                try:
                    result = future.result()
                except Exception as e:
                    logger.exception(
                        f"Exception processing message "
                        f"{message.get('MessageId')}"
                    )
                    result = self._failure_result(message, str(e))

                if on_completed is not None:
                    result = on_completed(result, message)

                self._classify_result(result, results)

        except FuturesTimeoutError:
            for future in pending:
                future.cancel()
                message = future_to_message[future]
                self._classify_result(
                    self._failure_result(
                        message,
                        f"batch_timeout of {batch_timeout}s exceeded",
                    ),
                    results,
                )

        return results

    # ------------------------------------------------------------------
    # One-shot batch modes
    # ------------------------------------------------------------------

    def process_with_threads(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
        batch_timeout: Optional[float] = None,
    ) -> Dict[str, List[ProcessResult]]:
        """
        Process one batch using the shared ThreadPoolExecutor
        (for I/O-bound tasks).

        Args:
            max_messages: Maximum messages to receive (capped at
                max_workers; values above 10 are gathered over
                multiple receive calls)
            wait_time_seconds: Long polling wait time
            batch_timeout: Optional overall deadline in seconds for
                the whole batch; messages still pending when it
                elapses are recorded as failed and left to redeliver

        Returns:
            dict: {'successful': [...], 'failed': [...]} of per-message
            result dicts (see ProcessResult at module top)
        """
        messages = self._receive_batch(max_messages, wait_time_seconds)

        if not messages:
            logger.info("No messages received")
            return {"successful": [], "failed": []}

        logger.info(
            f"Processing {len(messages)} messages with "
            f"{self.max_workers} threads"
        )

        executor = self._get_thread_executor()
        future_to_message = {
            executor.submit(
                self._process_single_message,
                msg,
            ): msg
            for msg in messages
        }

        results = self._collect_future_results(
            future_to_message,
            batch_timeout=batch_timeout,
        )

        logger.info(
            f"Completed: {len(results['successful'])} successful, "
            f"{len(results['failed'])} failed"
        )

        return results

    def process_with_multiprocessing(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
        batch_timeout: Optional[float] = None,
    ) -> Dict[str, List[ProcessResult]]:
        """
        Process one batch using the shared ProcessPoolExecutor
        (best for CPU-bound tasks).

        processing_function must be a picklable module-level function
        (no lambdas, closures, or locally defined functions), and on
        spawn platforms (macOS/Windows) the calling script must be
        guarded with ``if __name__ == "__main__":``.

        Workers never touch AWS: deletes are performed in the parent
        with the parent's already-authenticated client, so explicit
        credentials/profiles are honored and no per-message boto3
        session is built.

        Args:
            max_messages: Maximum messages to receive (capped at
                max_workers)
            wait_time_seconds: Long polling wait time
            batch_timeout: Optional overall deadline in seconds

        Returns:
            dict: {'successful': [...], 'failed': [...]} of per-message
            result dicts

        Raises:
            TypeError: If processing_function is not picklable
        """
        try:
            pickle.dumps(self.processing_function)
        except Exception as e:
            raise TypeError(
                "processing_function must be a picklable module-level "
                "function for the 'processes' method (lambdas, "
                f"closures and bound methods are not): {e}"
            ) from e

        messages = self._receive_batch(max_messages, wait_time_seconds)

        if not messages:
            logger.info("No messages received")
            return {"successful": [], "failed": []}

        logger.info(
            f"Processing {len(messages)} messages with "
            f"{self.max_workers} processes"
        )

        def _submit_all(pool) -> Dict[Future, Dict[str, Any]]:
            return {
                pool.submit(
                    _process_message_multiprocess,
                    msg,
                    self.processing_function,
                    self.message_arg,
                ): msg
                for msg in messages
            }

        executor = self._get_process_executor()

        try:
            future_to_message = _submit_all(executor)
        except BrokenProcessPool:
            # Exception-driven detection (the public contract), not
            # just the private _broken attribute below: rebuild the
            # pool once and retry the submit.
            logger.error(
                "Process pool broken at submit; rebuilding and "
                "retrying once"
            )
            with self._executor_lock:
                if self._process_executor is not None:
                    self._process_executor.shutdown(wait=False)
                    self._process_executor = None

            executor = self._get_process_executor()
            future_to_message = _submit_all(executor)

        results = self._collect_future_results(
            future_to_message,
            batch_timeout=batch_timeout,
            on_completed=self._delete_in_parent,
        )

        # A crashed worker (e.g. OOM-killed) breaks the pool; rebuild
        # it lazily on the next call instead of failing forever.
        with self._executor_lock:
            broken = (
                self._process_executor is not None
                and getattr(self._process_executor, "_broken", False)
            )
            if broken:
                logger.error(
                    "Process pool is broken; it will be rebuilt on "
                    "the next call"
                )
                self._process_executor.shutdown(wait=False)
                self._process_executor = None

        logger.info(
            f"Completed: {len(results['successful'])} successful, "
            f"{len(results['failed'])} failed"
        )

        return results

    async def process_with_asyncio(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
        batch_timeout: Optional[float] = None,
    ) -> Dict[str, List[ProcessResult]]:
        """
        Process one batch using AsyncIO (for async I/O operations).

        processing_function may be a coroutine function or a plain
        function; plain functions (and deletes, and the blocking
        long-poll receive itself) are offloaded to the shared
        ThreadPoolExecutor so the event loop is never blocked.

        Args:
            max_messages: Maximum messages to receive (capped at
                max_workers)
            wait_time_seconds: Long polling wait time
            batch_timeout: Optional overall deadline in seconds;
                tasks still pending are cancelled and recorded failed

        Returns:
            dict: {'successful': [...], 'failed': [...]} of per-message
            result dicts
        """
        loop = asyncio.get_running_loop()

        # The long-poll receive is a blocking call - run it on its own
        # single-thread executor, NOT the shared handler pool, so a
        # pool full of slow handlers can never starve the receive
        messages = await loop.run_in_executor(
            self._get_receive_executor(),
            functools.partial(
                self._receive_batch,
                max_messages,
                wait_time_seconds,
            ),
        )

        if not messages:
            logger.info("No messages received")
            return {"successful": [], "failed": []}

        logger.info(
            f"Processing {len(messages)} messages with up to "
            f"{self.max_workers} concurrent tasks"
        )

        # Bound concurrency by max_workers
        semaphore = asyncio.Semaphore(self.max_workers)

        async def bounded_process(msg):
            async with semaphore:
                return await self._process_single_message_async(msg)

        task_to_message = {
            asyncio.ensure_future(bounded_process(msg)): msg
            for msg in messages
        }

        done, pending = await asyncio.wait(
            set(task_to_message),
            timeout=batch_timeout,
        )

        results: Dict[str, List[ProcessResult]] = {
            "successful": [],
            "failed": [],
        }

        for task in done:
            message = task_to_message[task]
            exc = task.exception()

            if exc is not None:
                logger.error(
                    f"Exception processing message "
                    f"{message.get('MessageId')}: {exc}",
                    exc_info=exc,
                )
                result = self._failure_result(message, str(exc))
            else:
                result = task.result()

            self._classify_result(result, results)

        for task in pending:
            task.cancel()
            message = task_to_message[task]
            self._classify_result(
                self._failure_result(
                    message,
                    f"batch_timeout of {batch_timeout}s exceeded",
                ),
                results,
            )

        logger.info(
            f"Completed: {len(results['successful'])} successful, "
            f"{len(results['failed'])} failed"
        )

        return results

    # ------------------------------------------------------------------
    # Continuous modes
    # ------------------------------------------------------------------

    def continuous_processing_with_threads(
        self,
        max_messages: int = 10,
        wait_time_seconds: int = 20,
        poll_interval: float = 0,
        stop_event: Optional[threading.Event] = None,
        error_backoff_seconds: float = 5.0,
    ):
        """
        Continuously poll and process messages with threads
        (batch-barrier: each batch completes before the next receive;
        see process_pipelined_with_threads for the overlapped version).

        Transient errors (e.g. SQS throttling, network blips) are
        logged and retried after error_backoff_seconds instead of
        killing the loop.

        Args:
            max_messages: Maximum messages per poll
            wait_time_seconds: Long polling wait time
            poll_interval: Additional sleep after an EMPTY poll
                (seconds); busy cycles never sleep
            stop_event: Optional threading.Event for graceful
                shutdown; the loop exits when it is set
            error_backoff_seconds: Sleep after a failed poll cycle
        """
        logger.info("Starting continuous processing with threads...")

        try:
            while stop_event is None or not stop_event.is_set():
                try:
                    results = self.process_with_threads(
                        max_messages,
                        wait_time_seconds,
                    )
                except Exception:
                    logger.exception(
                        f"Poll/process cycle failed; backing off "
                        f"{error_backoff_seconds}s"
                    )
                    time.sleep(error_backoff_seconds)
                    continue

                if results["failed"]:
                    logger.warning(
                        f"{len(results['failed'])} messages failed "
                        f"in this cycle"
                    )

                idle = not (
                    results["successful"] or results["failed"]
                )
                if poll_interval > 0 and idle:
                    time.sleep(poll_interval)

        except KeyboardInterrupt:
            logger.info("Stopping continuous processing")

    def process_pipelined_with_threads(
        self,
        wait_time_seconds: int = 20,
        stop_event: Optional[threading.Event] = None,
        on_result: Optional[Callable[[ProcessResult], None]] = None,
        error_backoff_seconds: float = 5.0,
        drain_timeout: Optional[float] = None,
    ) -> Dict[str, int]:
        """
        Continuously process messages, overlapping receiving with
        processing (no batch barrier).

        Whenever fewer than max_workers messages are in flight, more
        are received and submitted immediately - a slow message no
        longer gates the next receive, workers stay busy, and
        max_workers > 10 is actually usable (multiple receive calls
        fill the capacity). Long polls run only when nothing is in
        flight; busy cycles use a short 1s wait so completions are
        harvested promptly.

        Per-message results are streamed to on_result (if given)
        rather than accumulated, so memory stays bounded on
        long-running consumers; the return value carries counts only.

        Args:
            wait_time_seconds: Long polling wait time used when idle
            stop_event: threading.Event for graceful shutdown; when
                set, in-flight messages are drained (bounded by
                drain_timeout) before returning
            on_result: Optional callback invoked with each
                ProcessResult (e.g. to route failures to an error
                queue); exceptions from it are logged, not raised
            error_backoff_seconds: Sleep after a failed cycle
            drain_timeout: Max seconds to wait for in-flight messages
                on graceful stop (default: visibility_timeout)

        Returns:
            dict: {'successful_count': int, 'failed_count': int}
        """
        if not self.delete_on_success:
            logger.warning(
                "delete_on_success is False: pipelined processing "
                "will re-receive the same messages after "
                "visibility_timeout"
            )

        executor = self._get_thread_executor()
        in_flight: Dict[Future, Dict[str, Any]] = {}
        counts = {"successful_count": 0, "failed_count": 0}

        def harvest(done_futures):
            for future in done_futures:
                message = in_flight.pop(future)

                try:
                    result = future.result()
                except Exception as e:
                    logger.exception(
                        f"Exception processing message "
                        f"{message.get('MessageId')}"
                    )
                    result = self._failure_result(message, str(e))

                if result["success"]:
                    counts["successful_count"] += 1
                    logger.info(
                        f"Processed message "
                        f"{result.get('message_id')}"
                    )
                else:
                    counts["failed_count"] += 1
                    logger.error(
                        f"Failed to process message "
                        f"{result.get('message_id')}: "
                        f"{result.get('error')}"
                    )

                if on_result is not None:
                    try:
                        on_result(result)
                    except Exception:
                        logger.exception("on_result callback raised")

        logger.info(
            f"Starting pipelined processing with "
            f"{self.max_workers} workers"
        )

        try:
            while stop_event is None or not stop_event.is_set():
                try:
                    capacity = self.max_workers - len(in_flight)

                    if capacity > 0:
                        # Long-poll only when idle so completions of
                        # in-flight work are harvested promptly (cap
                        # the busy-path wait at 1s, never 0 - a zero
                        # wait would hot-loop the SQS API)
                        wait = 1 if in_flight else wait_time_seconds
                        messages = self.client.receive_messages(
                            max_messages=min(
                                SQSClient.MAX_RECEIVE_MESSAGES,
                                capacity,
                            ),
                            wait_time_seconds=wait,
                            visibility_timeout=self.visibility_timeout,
                        )

                        for msg in messages:
                            future = executor.submit(
                                self._process_single_message,
                                msg,
                            )
                            in_flight[future] = msg

                        if not messages and not in_flight and wait == 0:
                            # Idle with long-polling disabled: don't
                            # hot-loop the receive call
                            time.sleep(0.1)

                    if in_flight:
                        done, _ = futures_wait(
                            set(in_flight),
                            timeout=1.0,
                            return_when=FIRST_COMPLETED,
                        )
                        harvest(done)

                except Exception:
                    logger.exception(
                        f"Pipelined cycle failed; backing off "
                        f"{error_backoff_seconds}s"
                    )
                    time.sleep(error_backoff_seconds)

        except KeyboardInterrupt:
            logger.info(
                f"Interrupted with {len(in_flight)} messages in "
                f"flight; they will finish in the background or "
                f"redeliver"
            )
            return counts

        # Graceful stop: drain in-flight work (bounded)
        if in_flight:
            timeout = (
                drain_timeout
                if drain_timeout is not None
                else self.visibility_timeout
            )
            logger.info(
                f"Stop requested; draining {len(in_flight)} "
                f"in-flight messages (up to {timeout}s)"
            )

            done, not_done = futures_wait(
                set(in_flight),
                timeout=timeout,
            )
            harvest(done)

            for future in not_done:
                message = in_flight.pop(future)

                if future.cancel():
                    # Never started - safe to call it failed and
                    # promise redelivery
                    counts["failed_count"] += 1
                    logger.error(
                        f"Message {message.get('MessageId')} was "
                        f"cancelled before starting; it will "
                        f"redeliver"
                    )
                else:
                    # Still running: it may yet succeed (and delete);
                    # its outcome just won't be reported in counts
                    counts["failed_count"] += 1
                    logger.warning(
                        f"Message {message.get('MessageId')} still "
                        f"running at drain timeout; abandoning the "
                        f"result (counted as failed; the handler may "
                        f"still complete in the background)"
                    )

        logger.info(
            f"Pipelined processing stopped: "
            f"{counts['successful_count']} successful, "
            f"{counts['failed_count']} failed"
        )

        return counts

    # ------------------------------------------------------------------
    # Per-message workers
    # ------------------------------------------------------------------

    def _process_single_message(
        self,
        message: Dict[str, Any],
    ) -> ProcessResult:
        """
        Process a single message and optionally delete it.

        Processing failure and delete failure are reported
        independently: a delete failure after successful processing
        returns success=True with deleted=False and delete_error set
        (the work happened; the message will redeliver).
        """
        message_id = message.get("MessageId")
        receipt_handle = message.get("ReceiptHandle")

        try:
            result = self.processing_function(
                self._handler_payload(message)
            )
        except Exception as e:
            logger.exception(
                f"Error processing message {message_id}"
            )
            return self._failure_result(message, str(e))

        if result is False:
            logger.error(
                f"processing_function returned False for message "
                f"{message_id}"
            )
            return self._failure_result(
                message,
                "processing_function returned False",
            )

        out: ProcessResult = {
            "success": True,
            "message_id": message_id,
            "receipt_handle": receipt_handle,
            "result": result,
            "deleted": False,
        }

        if self.delete_on_success and receipt_handle:
            try:
                self.client.delete_msg(receipt_handle)
                out["deleted"] = True
            except Exception as e:
                logger.warning(
                    f"Processed message {message_id} but delete "
                    f"failed - it will redeliver: {e}"
                )
                out["delete_error"] = str(e)

        return out

    async def _process_single_message_async(
        self,
        message: Dict[str, Any],
    ) -> ProcessResult:
        """
        Asynchronously process a single message.

        Sync processing functions and deletes run on the shared
        ThreadPoolExecutor (sized max_workers), not the event loop's
        default executor, so configured concurrency is honored.
        """
        message_id = message.get("MessageId")
        receipt_handle = message.get("ReceiptHandle")
        loop = asyncio.get_running_loop()

        try:
            if asyncio.iscoroutinefunction(self.processing_function):
                result = await self.processing_function(
                    self._handler_payload(message)
                )
            else:
                result = await loop.run_in_executor(
                    self._get_thread_executor(),
                    self.processing_function,
                    self._handler_payload(message),
                )
        except Exception as e:
            logger.exception(
                f"Error processing message {message_id}"
            )
            return self._failure_result(message, str(e))

        if result is False:
            logger.error(
                f"processing_function returned False for message "
                f"{message_id}"
            )
            return self._failure_result(
                message,
                "processing_function returned False",
            )

        out: ProcessResult = {
            "success": True,
            "message_id": message_id,
            "receipt_handle": receipt_handle,
            "result": result,
            "deleted": False,
        }

        if self.delete_on_success and receipt_handle:
            try:
                await loop.run_in_executor(
                    self._get_thread_executor(),
                    self.client.delete_msg,
                    receipt_handle,
                )
                out["deleted"] = True
            except Exception as e:
                logger.warning(
                    f"Processed message {message_id} but delete "
                    f"failed - it will redeliver: {e}"
                )
                out["delete_error"] = str(e)

        return out


def _process_message_multiprocess(
    message: Dict[str, Any],
    processing_function: Callable[[Any], Any],
    message_arg: str = "body",
) -> ProcessResult:
    """
    Worker-process helper for multiprocessing.

    Deliberately performs NO AWS calls: the parent deletes with its
    own client (see _delete_in_parent), so worker processes need no
    credentials and no per-message boto3 session is built.
    """
    message_id = message.get("MessageId")
    receipt_handle = message.get("ReceiptHandle")

    payload = (
        message if message_arg == "message" else message.get("Body", "")
    )

    try:
        result = processing_function(payload)
    except Exception as e:
        return {
            "success": False,
            "message_id": message_id,
            "receipt_handle": receipt_handle,
            "error": str(e),
        }

    if result is False:
        return {
            "success": False,
            "message_id": message_id,
            "receipt_handle": receipt_handle,
            "error": "processing_function returned False",
        }

    return {
        "success": True,
        "message_id": message_id,
        "receipt_handle": receipt_handle,
        "result": result,
    }


# Helper for simple use cases
def process_messages_parallel(
    client: SQSClient,
    processing_function: Callable[[str], Any],
    max_messages: int = 10,
    max_workers: int = 10,
    method: str = "threads",
    delete_on_success: bool = False,
    visibility_timeout: int = 60,
    wait_time_seconds: int = 20,
) -> Dict[str, List[ProcessResult]]:
    """
    Quick helper to process one batch of messages in parallel.

    NOTE: by default messages are NOT deleted after processing and
    will redeliver after visibility_timeout - pass
    delete_on_success=True to delete successfully processed messages.

    Args:
        client: SQSClient instance
        processing_function: Called with the message Body string;
            raise (or return False) to signal failure
        max_messages: Maximum messages to receive
        max_workers: Number of parallel workers
        method: 'threads', 'processes', or 'asyncio'
        delete_on_success: Delete messages after successful processing
        visibility_timeout: Message visibility timeout in seconds
        wait_time_seconds: Long polling wait time

    Returns:
        dict: {'successful': [...], 'failed': [...]} of per-message
        result dicts (each includes receipt_handle, so callers using
        delete_on_success=False can delete/batch-delete themselves)
    """
    processor = ParallelSQSProcessor(
        client=client,
        processing_function=processing_function,
        max_workers=max_workers,
        delete_on_success=delete_on_success,
        visibility_timeout=visibility_timeout,
    )

    try:
        if method == "threads":
            return processor.process_with_threads(
                max_messages,
                wait_time_seconds,
            )

        elif method == "processes":
            return processor.process_with_multiprocessing(
                max_messages,
                wait_time_seconds,
            )

        elif method == "asyncio":
            return asyncio.run(
                processor.process_with_asyncio(
                    max_messages,
                    wait_time_seconds,
                )
            )

        else:
            raise ValueError(
                f"Unknown method: {method}. "
                "Use 'threads', 'processes' or 'asyncio'"
            )

    finally:
        processor.close()
