"""
Logging helper for the sqs_service package.

Prefers the client environment's log_util (which configures logging from
logger_config.yaml). Outside the client environment (local development,
mock testing) it falls back to a plain stdlib logger so the package stays
importable everywhere.
"""

import logging


def _stdlib_logger():
    logger = logging.getLogger("sqs_service")

    if not logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s %(levelname)s %(name)s %(message)s"
            )
        )
        logger.addHandler(handler)
        logger.setLevel(logging.INFO)

    return logger


def get_logger():
    # log_util absent is the EXPECTED case outside the client
    # environment - fall back silently. Any other failure means
    # log_util is present but misconfigured, and silently downgrading
    # would hide the loss of structured logging in prod - warn loudly.
    try:
        from log_util import logger as _log_util
    except ImportError:
        return _stdlib_logger()

    try:
        return _log_util.setup_logger(config_path="logger_config.yaml")
    except Exception as e:
        fallback = _stdlib_logger()
        fallback.warning(
            "log_util is present but setup_logger failed (%s); "
            "falling back to stdlib logging - the structured logging "
            "config is NOT active",
            e,
        )
        return fallback
