"""Streamlit entry point for the member→coach mapping UI."""

from __future__ import annotations

import streamlit as st

# NOTE: Streamlit runs this file as a script. Use absolute imports so they work
# when executed via: `streamlit run member_coach_mapping/app.py`.
import member_coach_mapping.db as db
from member_coach_mapping.ui_member import login_signup_ui, member_profile_page


def _ensure_session_state() -> None:
    if "logged_in" not in st.session_state:
        st.session_state.logged_in = False
    if "user" not in st.session_state:
        st.session_state.user = None


def main() -> None:
    st.set_page_config(page_title="Member→Coach Mapping (Local)", layout="wide")
    _ensure_session_state()
    db.ensure_tables()

    if not st.session_state.logged_in:
        login_signup_ui()
    else:
        member_profile_page()


if __name__ == "__main__":
    main()
