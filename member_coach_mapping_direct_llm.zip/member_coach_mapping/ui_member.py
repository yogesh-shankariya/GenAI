"""Streamlit UI for member profile + coach mapping."""

from __future__ import annotations

import json
from typing import Any, Dict, List, Optional, Tuple
import streamlit as st

from . import auth, db
from .llm_integration import LLMIntegrationError, get_llm_coach_ids
from .config import DB_PATH


PRIMARY_GOAL_OPTIONS = [
    ("fat_loss", "Fat loss / Weight loss"),
    ("muscle_gain", "Muscle gain / Hypertrophy"),
    ("strength", "Strength"),
    ("recomp", "Recomposition"),
    ("running_5k", "Running: 5K"),
    ("running_10k", "Running: 10K"),
    ("endurance", "Endurance (general)"),
    ("yoga", "Yoga"),
    ("mobility", "Mobility / Flexibility"),
    ("stress", "Stress reduction"),
    ("posture", "Posture / Desk mobility"),
    ("weight_gain", "Healthy weight gain"),
    ("nutrition_only", "Nutrition only"),
    ("habits", "General fitness habits"),
    ("other", "Other (free text)"),
]

CONSTRAINT_OPTIONS = [
    "None",
    "Low impact only",
    "No jumping",
    "Knee pain",
    "Back pain",
    "Shoulder pain",
    "Limited equipment",
    "Very busy schedule",
    "Travel / irregular routine",
    "Stress / anxiety",
    "Poor sleep",
    "Other (free text)",
]

EQUIPMENT_OPTIONS = [
    "Gym",
    "Home dumbbells",
    "Bodyweight only",
    "Treadmill",
    "Outdoors",
    "Other (free text)",
]

COACHING_STYLE_OPTIONS = [
    "Encouraging",
    "Strict",
    "Friendly",
    "Direct",
    "Calm",
    "Other (free text)",
]

AVOID_OPTIONS = [
    "Jumping",
    "Running",
    "Heavy squats",
    "High-impact cardio",
    "Other (free text)",
]


def safe_rerun() -> None:
    if hasattr(st, "rerun"):
        st.rerun()
    else:
        st.experimental_rerun()


def _opt_label_map(opts: List[Tuple[str, str]]) -> Dict[str, str]:
    return {k: v for k, v in opts}


def _normalize_free_text_list(selected: List[str], other_value: str, other_label: str) -> List[str]:
    out: List[str] = []
    for v in selected:
        if v == other_label:
            continue
        if v and v != "None":
            out.append(v)
    if other_value and other_value.strip():
        out.append(other_value.strip())
    return out


def login_signup_ui() -> None:
    st.title("Member Profile (Local)")
    st.caption(f"DB: {DB_PATH}")

    tabs = st.tabs(["Login", "Sign up"])

    with tabs[0]:
        with st.form("login_form"):
            username = st.text_input("Username")
            password = st.text_input("Password", type="password")
            submitted = st.form_submit_button("Login")
        if submitted:
            user = auth.authenticate(username, password)
            if not user:
                st.error("Invalid username or password")
                return
            st.session_state.logged_in = True
            st.session_state.user = user
            safe_rerun()

    with tabs[1]:
        with st.form("signup_form"):
            username = st.text_input("Choose username")
            password = st.text_input("Choose password", type="password")
            password2 = st.text_input("Confirm password", type="password")
            submitted = st.form_submit_button("Create account")
        if submitted:
            if password != password2:
                st.error("Passwords do not match")
                return
            try:
                user = auth.create_user(username, password, role="client")
            except Exception as e:
                st.error(str(e))
                return
            st.success("Account created. Please log in.")


def _build_intake_payload(form: Dict[str, Any], user_public_id: str) -> Dict[str, Any]:
    primary_goal_key = form["primary_goal_key"]
    primary_goal_other = form.get("primary_goal_other")

    equipment_key = form["equipment_key"]
    equipment_other = form.get("equipment_other")

    coaching_style = form["coaching_style"]
    coaching_style_other = form.get("coaching_style_other")
    if coaching_style == "Other (free text)":
        coaching_style = coaching_style_other.strip() if coaching_style_other else "Other"

    constraints = _normalize_free_text_list(
        form.get("constraints", []),
        form.get("constraints_other", ""),
        "Other (free text)",
    )

    avoid = _normalize_free_text_list(
        form.get("avoid", []),
        form.get("avoid_other", ""),
        "Other (free text)",
    )

    if primary_goal_key == "other":
        primary_goal = (primary_goal_other or "other").strip()
    else:
        primary_goal = primary_goal_key

    if equipment_key == "Other (free text)":
        equipment = (equipment_other or "other").strip()
    else:
        equipment = equipment_key

    return {
        "user_id": user_public_id,
        "height_cm": int(form["height_cm"]),
        "weight_kg": int(form["weight_kg"]),
        "primary_goal": primary_goal,
        "primary_goal_other": primary_goal_other,
        "goal_text": str(form["goal_text"]).strip(),
        "constraints": constraints,
        "session_minutes": int(form["session_minutes"]),
        "days_per_week": int(form["days_per_week"]),
        "equipment": equipment,
        "equipment_other": equipment_other,
        "experience_level": form["experience_level"],
        "preferences": {
            "coaching_style": coaching_style,
            "avoid": avoid,
        },
    }


def member_profile_page() -> None:
    user = st.session_state.user

    st.title("Member → Coach Mapping")
    st.write(f"Logged in as: **{user['username']}**")
    cols = st.columns([1, 1, 2])
    with cols[0]:
        if st.button("Logout"):
            st.session_state.logged_in = False
            st.session_state.user = None
            safe_rerun()

    # Load coaches for manual selection + validation
    coaches = db.list_enabled_coaches()
    coach_display = {
        c["coach_id"]: f"{c['name']}  ({', '.join(c.get('tags', [])[:6])})"
        for c in coaches
    }

    # Load existing profile
    existing = db.get_member_profile(user["user_id"])
    public_user_id = existing["public_user_id"] if existing else db.to_public_user_id(user["user_id"])

    st.caption(f"Your auto user_id: **{public_user_id}**")

    label_map = _opt_label_map(PRIMARY_GOAL_OPTIONS)
    goal_key_default = existing["primary_goal_key"] if existing else "fat_loss"
    exp_default = existing["experience_level"] if existing else "beginner"
    equip_default = existing["equipment_key"] if existing else "Gym"

    # Intake form
    st.subheader("Your profile")
    with st.form("member_profile_form"):
        height_cm = st.number_input("Height (cm)", min_value=50, max_value=250, value=int(existing["height_cm"]) if existing else 170, step=1)
        weight_kg = st.number_input("Weight (kg)", min_value=20, max_value=300, value=int(existing["weight_kg"]) if existing else 70, step=1)

        primary_goal_key = st.selectbox(
            "Primary Goal",
            options=[k for k, _ in PRIMARY_GOAL_OPTIONS],
            index=[k for k, _ in PRIMARY_GOAL_OPTIONS].index(goal_key_default) if goal_key_default in [k for k, _ in PRIMARY_GOAL_OPTIONS] else 0,
            format_func=lambda k: label_map.get(k, k),
        )
        primary_goal_other = ""
        if primary_goal_key == "other":
            primary_goal_other = st.text_input("Primary Goal (other)", value=existing.get("primary_goal_other", "") if existing else "")

        goal_text = st.text_area(
            "Goal (details)",
            value=existing["goal_text"] if existing else "",
            placeholder="Example: Lose 8kg in 12 weeks, 3 days/week. Knee pain, prefer low-impact.",
        )

        constraints_default = existing["constraints"] if existing else ["None"]
        constraints = st.multiselect("Constraints", options=CONSTRAINT_OPTIONS, default=constraints_default if constraints_default else ["None"])
        constraints_other = ""
        if "Other (free text)" in constraints:
            constraints_other = st.text_input("Constraints (other)")

        session_minutes = st.number_input("Session Minutes", min_value=10, max_value=180, value=int(existing["session_minutes"]) if existing else 45, step=5)
        days_per_week = st.number_input("Days per week", min_value=1, max_value=7, value=int(existing["days_per_week"]) if existing else 3, step=1)

        equipment_key = st.selectbox("Equipment", options=EQUIPMENT_OPTIONS, index=EQUIPMENT_OPTIONS.index(equip_default) if equip_default in EQUIPMENT_OPTIONS else 0)
        equipment_other = ""
        if equipment_key == "Other (free text)":
            equipment_other = st.text_input("Equipment (other)", value=existing.get("equipment_other", "") if existing else "")

        experience_level = st.selectbox("Experience Level", options=["beginner", "intermediate", "advanced"], index=["beginner","intermediate","advanced"].index(exp_default) if exp_default in ["beginner","intermediate","advanced"] else 0)

        st.markdown("### Preferences")
        pref = existing.get("preferences", {}) if existing else {}
        coaching_style = st.selectbox("Coaching style", options=COACHING_STYLE_OPTIONS, index=0)
        coaching_style_other = ""
        if coaching_style == "Other (free text)":
            coaching_style_other = st.text_input("Coaching style (other)")

        avoid_default = pref.get("avoid", []) if isinstance(pref, dict) else []
        avoid = st.multiselect("Avoid", options=AVOID_OPTIONS, default=avoid_default)
        avoid_other = ""
        if "Other (free text)" in avoid:
            avoid_other = st.text_input("Avoid (other)")

        save_profile = st.form_submit_button("Save profile")

    if save_profile:
        if not goal_text.strip():
            st.error("Goal (details) is required")
            return

        # Save profile WITHOUT coach selection first
        db.upsert_member_profile(
            user_id=user["user_id"],
            payload={
                "height_cm": int(height_cm),
                "weight_kg": int(weight_kg),
                "primary_goal_key": primary_goal_key,
                "primary_goal_other": primary_goal_other,
                "goal_text": goal_text.strip(),
                "constraints": _normalize_free_text_list(constraints, constraints_other, "Other (free text)"),
                "session_minutes": int(session_minutes),
                "days_per_week": int(days_per_week),
                "equipment_key": equipment_key,
                "equipment_other": equipment_other,
                "experience_level": experience_level,
                "preferences": {
                    "coaching_style": coaching_style_other.strip() if coaching_style == "Other (free text)" and coaching_style_other else coaching_style,
                    "avoid": _normalize_free_text_list(avoid, avoid_other, "Other (free text)"),
                },
                "primary_coach_id": existing.get("primary_coach_id") if existing else None,
                "secondary_coach_id": existing.get("secondary_coach_id") if existing else None,
            },
        )
        st.success("Profile saved")
        safe_rerun()

    # Recommendation section
    st.subheader("Coach selection")

    # reload profile after save
    existing = db.get_member_profile(user["user_id"]) or existing
    if not existing:
        st.info("Save your profile first.")
        return

    recommended_ids: List[str] = []
    recommended_names: List[str] = []

    if st.button("Get coach recommendation (LLM)"):
        intake_payload = _build_intake_payload(
            {
                "height_cm": existing["height_cm"],
                "weight_kg": existing["weight_kg"],
                "primary_goal_key": existing["primary_goal_key"],
                "primary_goal_other": existing.get("primary_goal_other", ""),
                "goal_text": existing["goal_text"],
                "constraints": existing.get("constraints", []),
                "session_minutes": existing["session_minutes"],
                "days_per_week": existing["days_per_week"],
                "equipment_key": existing["equipment_key"],
                "equipment_other": existing.get("equipment_other", ""),
                "experience_level": existing["experience_level"],
                "coaching_style": existing.get("preferences", {}).get("coaching_style", "Encouraging"),
                "coaching_style_other": "",
                "avoid": existing.get("preferences", {}).get("avoid", []),
                "avoid_other": "",
            },
            user_public_id=existing["public_user_id"],
        )

        # Minimal coach catalog for the prompt placeholder
        catalog = [
            {
                "coach_id": c["coach_id"],
                "coach_name": c["name"],
                "tags": c.get("tags", []),
                "min_session_minutes": int(c.get("min_session_minutes", 10)),
                "max_session_minutes": int(c.get("max_session_minutes", 180)),
            }
            for c in coaches
        ]

        try:
            ids_out = get_llm_coach_ids(user_profile=intake_payload, coaches_profile=catalog)
        except LLMIntegrationError as e:
            st.error(str(e))
            return
        except Exception as e:
            st.error(f"Unexpected error while calling LLM: {e}")
            return

        # Convert to the UI-friendly JSON you requested
        coach_ids = list(ids_out.get("Coach_ID", []))[:2]
        coach_names: List[str] = []
        for cid in coach_ids:
            nm = db.coach_name_by_id(cid)
            if nm:
                coach_names.append(nm)
        st.session_state.reco = {"Coach_name": coach_names, "Coach_ID": coach_ids}
        safe_rerun()

    reco = st.session_state.get("reco")
    if reco and isinstance(reco, dict):
        recommended_ids = list(reco.get("Coach_ID", [])[:2])
        recommended_names = list(reco.get("Coach_name", [])[:2])
        if recommended_ids:
            st.success("Recommendation received")
            st.write({"Coach_name": recommended_names, "Coach_ID": recommended_ids})

    # Manual override / final selection
    st.markdown("### Final selection (you can override)")

    default_primary = existing.get("primary_coach_id") or (recommended_ids[0] if recommended_ids else None)
    default_secondary = existing.get("secondary_coach_id") or (recommended_ids[1] if len(recommended_ids) > 1 else None)

    coach_id_list = [c["coach_id"] for c in coaches]
    if not coach_id_list:
        st.error("No coaches found in DB. Please add coaches via Admin UI first.")
        return

    def _idx(cid: Optional[str]) -> int:
        if cid in coach_id_list:
            return coach_id_list.index(cid)
        return 0

    primary_coach_id = st.selectbox(
        "Primary coach (required)",
        options=coach_id_list,
        index=_idx(default_primary),
        format_func=lambda cid: coach_display.get(cid, cid),
    )

    secondary_candidates = [None] + [cid for cid in coach_id_list if cid != primary_coach_id]
    secondary_coach_id = st.selectbox(
        "Secondary coach (optional)",
        options=secondary_candidates,
        index=secondary_candidates.index(default_secondary) if default_secondary in secondary_candidates else 0,
        format_func=lambda cid: "None" if cid is None else coach_display.get(cid, cid),
    )

    if st.button("Save coach mapping"):
        # enforce rule: max 2 (already) and primary required (always)
        db.upsert_member_profile(
            user_id=user["user_id"],
            payload={
                "height_cm": existing["height_cm"],
                "weight_kg": existing["weight_kg"],
                "primary_goal_key": existing["primary_goal_key"],
                "primary_goal_other": existing.get("primary_goal_other"),
                "goal_text": existing["goal_text"],
                "constraints": existing.get("constraints", []),
                "session_minutes": existing["session_minutes"],
                "days_per_week": existing["days_per_week"],
                "equipment_key": existing["equipment_key"],
                "equipment_other": existing.get("equipment_other"),
                "experience_level": existing["experience_level"],
                "preferences": existing.get("preferences", {}),
                "primary_coach_id": primary_coach_id,
                "secondary_coach_id": secondary_coach_id,
            },
        )
        st.success("Coach mapping saved")
        safe_rerun()

    # Show final stored mapping
    existing = db.get_member_profile(user["user_id"]) or existing
    if existing and existing.get("primary_coach_id"):
        p_name = db.coach_name_by_id(existing["primary_coach_id"]) or existing["primary_coach_id"]
        s_name = db.coach_name_by_id(existing.get("secondary_coach_id")) if existing.get("secondary_coach_id") else None
        st.info(
            {
                "primary": {"id": existing["primary_coach_id"], "name": p_name},
                "secondary": ({"id": existing["secondary_coach_id"], "name": s_name} if existing.get("secondary_coach_id") else None),
            }
        )
