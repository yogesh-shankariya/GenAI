"""SQLite operations for member profile + coach mapping.

Stores everything in SQLite, including:
 - users (credentials)
 - coaches (created by admin app)
 - member_profiles (the intake form + assigned coaches)

Instructions for coaches are NOT stored here.
"""

from __future__ import annotations

import json
import sqlite3
from datetime import datetime
from typing import Any, Dict, List, Optional

from .config import DB_PATH


def get_conn() -> sqlite3.Connection:
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def ensure_tables() -> None:
    """Create tables if missing.

    Note: The admin coach app might already have created `users` and `coaches`.
    We only create what is missing.
    """
    conn = get_conn()
    cur = conn.cursor()

    # Users table (shared with admin app)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS users (
            user_id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            salt_hex TEXT NOT NULL,
            hash_hex TEXT NOT NULL,
            iterations INTEGER NOT NULL,
            role TEXT NOT NULL DEFAULT 'client',
            created_at TEXT NOT NULL
        );
        """
    )

    # Coaches table (shared with admin app)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS coaches (
          coach_id TEXT PRIMARY KEY,
          name TEXT NOT NULL,
          enabled INTEGER NOT NULL DEFAULT 1,
          tags_json TEXT NOT NULL DEFAULT '[]',
          constraint_boost_json TEXT NOT NULL DEFAULT '{}',
          min_session_minutes INTEGER NOT NULL DEFAULT 10,
          max_session_minutes INTEGER NOT NULL DEFAULT 180,
          priority INTEGER NOT NULL DEFAULT 0,
          capacity_max_clients INTEGER,
          capacity_current_clients INTEGER NOT NULL DEFAULT 0,
          created_at TEXT NOT NULL,
          updated_at TEXT NOT NULL
        );
        """
    )

    # Member profile (one row per auth user)
    cur.execute(
        """
        CREATE TABLE IF NOT EXISTS member_profiles (
            profile_id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL,
            public_user_id TEXT UNIQUE NOT NULL,
            height_cm INTEGER NOT NULL,
            weight_kg INTEGER NOT NULL,
            primary_goal_key TEXT NOT NULL,
            primary_goal_other TEXT,
            goal_text TEXT NOT NULL,
            constraints_json TEXT NOT NULL DEFAULT '[]',
            session_minutes INTEGER NOT NULL,
            days_per_week INTEGER NOT NULL,
            equipment_key TEXT NOT NULL,
            equipment_other TEXT,
            experience_level TEXT NOT NULL,
            preferences_json TEXT NOT NULL DEFAULT '{}',
            primary_coach_id TEXT,
            secondary_coach_id TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(user_id) REFERENCES users(user_id)
        );
        """
    )

    conn.commit()
    conn.close()


def to_public_user_id(user_id: int) -> str:
    """Convert internal integer user_id to the public format requested."""
    return f"U-{1000 + int(user_id)}"


def upsert_member_profile(user_id: int, payload: Dict[str, Any]) -> None:
    """Insert or update the member profile row for this user."""
    now = datetime.utcnow().isoformat()
    public_user_id = to_public_user_id(user_id)

    conn = get_conn()
    cur = conn.cursor()

    cur.execute("SELECT profile_id FROM member_profiles WHERE user_id = ?", (user_id,))
    exists = cur.fetchone() is not None

    constraints_json = json.dumps(payload.get("constraints", []), ensure_ascii=False)
    preferences_json = json.dumps(payload.get("preferences", {}), ensure_ascii=False)

    values = (
        user_id,
        public_user_id,
        int(payload["height_cm"]),
        int(payload["weight_kg"]),
        str(payload["primary_goal_key"]),
        payload.get("primary_goal_other"),
        str(payload["goal_text"]),
        constraints_json,
        int(payload["session_minutes"]),
        int(payload["days_per_week"]),
        str(payload["equipment_key"]),
        payload.get("equipment_other"),
        str(payload["experience_level"]),
        preferences_json,
        payload.get("primary_coach_id"),
        payload.get("secondary_coach_id"),
    )

    if not exists:
        cur.execute(
            """
            INSERT INTO member_profiles (
                user_id, public_user_id, height_cm, weight_kg,
                primary_goal_key, primary_goal_other, goal_text,
                constraints_json, session_minutes, days_per_week,
                equipment_key, equipment_other, experience_level,
                preferences_json, primary_coach_id, secondary_coach_id,
                created_at, updated_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            values + (now, now),
        )
    else:
        cur.execute(
            """
            UPDATE member_profiles
            SET
                height_cm = ?,
                weight_kg = ?,
                primary_goal_key = ?,
                primary_goal_other = ?,
                goal_text = ?,
                constraints_json = ?,
                session_minutes = ?,
                days_per_week = ?,
                equipment_key = ?,
                equipment_other = ?,
                experience_level = ?,
                preferences_json = ?,
                primary_coach_id = ?,
                secondary_coach_id = ?,
                updated_at = ?
            WHERE user_id = ?
            """,
            (
                int(payload["height_cm"]),
                int(payload["weight_kg"]),
                str(payload["primary_goal_key"]),
                payload.get("primary_goal_other"),
                str(payload["goal_text"]),
                constraints_json,
                int(payload["session_minutes"]),
                int(payload["days_per_week"]),
                str(payload["equipment_key"]),
                payload.get("equipment_other"),
                str(payload["experience_level"]),
                preferences_json,
                payload.get("primary_coach_id"),
                payload.get("secondary_coach_id"),
                now,
                user_id,
            ),
        )

    conn.commit()
    conn.close()


def get_member_profile(user_id: int) -> Optional[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT
            user_id, public_user_id, height_cm, weight_kg,
            primary_goal_key, primary_goal_other, goal_text,
            constraints_json, session_minutes, days_per_week,
            equipment_key, equipment_other, experience_level,
            preferences_json, primary_coach_id, secondary_coach_id,
            created_at, updated_at
        FROM member_profiles
        WHERE user_id = ?
        """,
        (user_id,),
    )
    row = cur.fetchone()
    conn.close()
    if not row:
        return None
    return {
        "user_id": row[0],
        "public_user_id": row[1],
        "height_cm": row[2],
        "weight_kg": row[3],
        "primary_goal_key": row[4],
        "primary_goal_other": row[5],
        "goal_text": row[6],
        "constraints": json.loads(row[7]) if row[7] else [],
        "session_minutes": row[8],
        "days_per_week": row[9],
        "equipment_key": row[10],
        "equipment_other": row[11],
        "experience_level": row[12],
        "preferences": json.loads(row[13]) if row[13] else {},
        "primary_coach_id": row[14],
        "secondary_coach_id": row[15],
        "created_at": row[16],
        "updated_at": row[17],
    }


def list_enabled_coaches() -> List[Dict[str, Any]]:
    conn = get_conn()
    cur = conn.cursor()
    cur.execute(
        """
        SELECT coach_id, name, tags_json, min_session_minutes, max_session_minutes
        FROM coaches
        WHERE enabled = 1
        ORDER BY name COLLATE NOCASE
        """
    )
    rows = cur.fetchall()
    conn.close()
    coaches = []
    for r in rows:
        coaches.append(
            {
                "coach_id": r[0],
                "name": r[1],
                "tags": json.loads(r[2]) if r[2] else [],
                "min_session_minutes": r[3],
                "max_session_minutes": r[4],
            }
        )
    return coaches


def coach_name_by_id(coach_id: str) -> Optional[str]:
    if not coach_id:
        return None
    conn = get_conn()
    cur = conn.cursor()
    cur.execute("SELECT name FROM coaches WHERE coach_id = ?", (coach_id,))
    row = cur.fetchone()
    conn.close()
    return row[0] if row else None
