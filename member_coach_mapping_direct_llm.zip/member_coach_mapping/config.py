"""Shared configuration.

This app reuses the same SQLite database that stores coaches.
You can override the DB path using the environment variable APP_DB_PATH.
"""

from __future__ import annotations

import os
from pathlib import Path


DB_PATH = os.getenv("APP_DB_PATH", "local_coaches.db")

# Optional: where coach instruction markdowns live (not required for mapping UI)
COACH_INSTRUCTIONS_DIR = Path(os.getenv("COACH_INSTRUCTIONS_DIR", "coach_instructions"))

# ----------------------------
# LLM integration configuration
# ----------------------------
#
# These defaults match the file/module names shown in your screenshots.
# If your file names differ, change them here (no other code changes needed).

# Prompt markdown template (should include placeholders: {user_profile} and {coaches_profile})
PROMPT_TEMPLATE_PATH = os.getenv("PROMPT_TEMPLATE_PATH", "coach_mapping_prompt.md")

# Supporting modules (already present in your project)
HORIZON_CLIENT_MODULE = os.getenv("HORIZON_CLIENT_MODULE", "client")
HORIZON_CLIENT_SYMBOL = os.getenv("HORIZON_CLIENT_SYMBOL", "HorizonApiClient")

HORIZON_RETRY_MODULE = os.getenv("HORIZON_RETRY_MODULE", "horizon_client_retry")
HORIZON_RETRY_SYMBOL = os.getenv("HORIZON_RETRY_SYMBOL", "_call_llm_with_retry")

COACH_MAPPING_MODULE = os.getenv("COACH_MAPPING_MODULE", "coach_mapping")
COACH_MAPPING_MODEL_SYMBOL = os.getenv("COACH_MAPPING_MODEL_SYMBOL", "CoachIdsPayload")
