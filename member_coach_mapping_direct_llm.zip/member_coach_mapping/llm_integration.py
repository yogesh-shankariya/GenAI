"""LLM coach-mapping integration (direct call, no FastAPI).

You said you already have supporting modules for the Horizon LLM call, e.g.:

  - client.py  (exports `HorizonApiClient`)
  - horizon_client_retry.py (exports `_call_llm_with_retry`)
  - coach_mapping.py (exports `CoachIdsPayload` pydantic model)
  - coach_mapping_prompt.md (prompt template using `{user_profile}` and `{coaches_profile}`)

This module just glues Streamlit → your existing LLM logic:
1) Build the formatted prompt from the markdown template
2) Build a fully-inlined JSON schema from the pydantic model
3) Call your retry wrapper to get `{primary_coach_id, secondary_coach_id}`
4) Normalize into the UI-friendly format: {"Coach_ID": [..]} (max 2)

If your module/file names are different, update the constants in `member_coach_mapping/config.py`.
"""

from __future__ import annotations

import asyncio
import importlib
import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Any, Dict, List, Optional, Type

from .config import (
    COACH_MAPPING_MODEL_SYMBOL,
    COACH_MAPPING_MODULE,
    HORIZON_CLIENT_MODULE,
    HORIZON_CLIENT_SYMBOL,
    HORIZON_RETRY_MODULE,
    HORIZON_RETRY_SYMBOL,
    PROMPT_TEMPLATE_PATH,
)


class LLMIntegrationError(RuntimeError):
    """Raised when the LLM integration cannot be executed."""


def _import_symbol(module_name: str, symbol_name: str) -> Any:
    try:
        mod = importlib.import_module(module_name)
    except Exception as e:
        raise LLMIntegrationError(
            f"Failed to import module '{module_name}'. "
            f"Make sure it exists on PYTHONPATH. Original error: {e}"
        )

    try:
        return getattr(mod, symbol_name)
    except AttributeError:
        raise LLMIntegrationError(
            f"Module '{module_name}' does not export '{symbol_name}'. "
            f"Available: {dir(mod)}"
        )


def _read_prompt_template() -> str:
    path = Path(PROMPT_TEMPLATE_PATH)
    if not path.exists():
        # also try relative to CWD (common when running streamlit)
        alt = Path.cwd() / path.name
        if alt.exists():
            path = alt
        else:
            raise LLMIntegrationError(
                f"Prompt template not found: '{PROMPT_TEMPLATE_PATH}'. "
                f"Expected a file like 'coach_mapping_prompt.md'."
            )
    return path.read_text(encoding="utf-8")


def _pydantic_model_json_schema(model_cls: Any) -> Dict[str, Any]:
    """Support both pydantic v2 (`model_json_schema`) and v1 (`schema`)."""
    if hasattr(model_cls, "model_json_schema"):
        return model_cls.model_json_schema()
    if hasattr(model_cls, "schema"):
        return model_cls.schema()
    raise LLMIntegrationError(
        "Provided model does not look like a Pydantic model class. "
        "Expected `.model_json_schema()` (v2) or `.schema()` (v1)."
    )


def inline_refs(model_cls: Any) -> Dict[str, Any]:
    """Inline $ref entries in a pydantic-generated JSON schema.

    Your screenshot showed a `$defs`-based schema (pydantic v2). This function
    recursively replaces `$ref` nodes with the referenced definition.
    """
    schema = _pydantic_model_json_schema(model_cls)

    # pydantic v2 uses `$defs`, v1 uses `definitions`
    defs: Dict[str, Any] = schema.get("$defs", {}) or schema.get("definitions", {}) or {}

    def resolve(obj: Any) -> Any:
        if isinstance(obj, dict):
            if "$ref" in obj:
                ref_key = str(obj["$ref"]).split("/")[-1]
                if ref_key in defs:
                    return resolve(defs.get(ref_key, {}))
                # If we cannot resolve, return as-is
                return obj
            return {k: resolve(v) for k, v in obj.items() if k not in ("$defs", "definitions")}
        if isinstance(obj, list):
            return [resolve(i) for i in obj]
        return obj

    return resolve(schema)


def _run_async(coro: Any) -> Any:
    """Run an async coroutine from a synchronous Streamlit callback safely."""
    # Streamlit runs in sync context; `asyncio.run` usually works. If a loop
    # is already running, execute in a dedicated thread.
    try:
        return asyncio.run(coro)
    except RuntimeError as e:
        if "asyncio.run() cannot be called from a running event loop" not in str(e):
            raise

    with ThreadPoolExecutor(max_workers=1) as ex:
        fut = ex.submit(lambda: asyncio.run(coro))
        return fut.result()


def get_llm_coach_ids(user_profile: Dict[str, Any], coaches_profile: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Call your Horizon LLM flow and return the UI-friendly coach ID list.

    Parameters
    - user_profile: dict (your intake JSON)
    - coaches_profile: list[dict] (compact coach catalog)

    Returns
    - {"Coach_ID": ["C001", "C005"]}  (max 2, primary first)
    """

    HorizonApiClient = _import_symbol(HORIZON_CLIENT_MODULE, HORIZON_CLIENT_SYMBOL)
    call_llm_with_retry = _import_symbol(HORIZON_RETRY_MODULE, HORIZON_RETRY_SYMBOL)
    CoachIdsPayload = _import_symbol(COACH_MAPPING_MODULE, COACH_MAPPING_MODEL_SYMBOL)

    prompt_template = _read_prompt_template()
    final_prompt = prompt_template.format(
        user_profile=json.dumps(user_profile, ensure_ascii=False, indent=2),
        coaches_profile=json.dumps(coaches_profile, ensure_ascii=False, indent=2),
    )

    schema = inline_refs(CoachIdsPayload)

    # Instantiate your client
    hclient = HorizonApiClient()

    # Your `_call_llm_with_retry` is async (based on your screenshot)
    output = _run_async(call_llm_with_retry(hclient=hclient, schema=schema, prompt=final_prompt))

    if not isinstance(output, dict):
        raise LLMIntegrationError(f"LLM output must be a dict, got: {type(output)}")

    primary = str(output.get("primary_coach_id") or "").strip()
    secondary = str(output.get("secondary_coach_id") or "").strip()

    if not primary:
        raise LLMIntegrationError("LLM did not return 'primary_coach_id'.")

    ids: List[str] = [primary]
    if secondary and secondary != primary:
        ids.append(secondary)

    return {"Coach_ID": ids[:2]}
