#!/usr/bin/env python3
"""Deterministically compare explicitly mapped prompt and schema file pairs."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


VALID_CATEGORIES = {"prompt", "schema"}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def normalize_text(data: bytes) -> bytes:
    text = data.decode("utf-8-sig")
    return text.replace("\r\n", "\n").replace("\r", "\n").encode("utf-8")


def safe_file(root: Path, relative: str) -> Path:
    candidate = (root / relative).resolve()
    try:
        candidate.relative_to(root)
    except ValueError as exc:
        raise ValueError(f"path escapes repository root: {relative}") from exc
    return candidate


def compare_pair(master_root: Path, uat_root: Path, pair: dict[str, Any]) -> dict[str, Any]:
    result: dict[str, Any] = {
        "pipeline": str(pair.get("pipeline", "")),
        "category": str(pair.get("category", "")),
        "master_path": str(pair.get("master", "")),
        "uat_path": str(pair.get("uat", "")),
        "master_sha256": "",
        "uat_sha256": "",
        "master_size": "",
        "uat_size": "",
        "normalized_master_sha256": "",
        "normalized_uat_sha256": "",
        "status": "ERROR",
        "error": "",
    }

    try:
        if not result["pipeline"]:
            raise ValueError("missing pipeline")
        if result["category"] not in VALID_CATEGORIES:
            raise ValueError("category must be prompt or schema")
        if not result["master_path"] or not result["uat_path"]:
            raise ValueError("both master and UAT paths are required")

        master_file = safe_file(master_root, result["master_path"])
        uat_file = safe_file(uat_root, result["uat_path"])
        missing = [str(path) for path in (master_file, uat_file) if not path.is_file()]
        if missing:
            result["status"] = "MISSING"
            result["error"] = "; ".join(missing)
            return result

        master_bytes = master_file.read_bytes()
        uat_bytes = uat_file.read_bytes()
        result["master_size"] = len(master_bytes)
        result["uat_size"] = len(uat_bytes)
        result["master_sha256"] = sha256(master_bytes)
        result["uat_sha256"] = sha256(uat_bytes)

        if result["master_sha256"] == result["uat_sha256"]:
            result["status"] = "EXACT"
            return result

        try:
            normalized_master = normalize_text(master_bytes)
            normalized_uat = normalize_text(uat_bytes)
            result["normalized_master_sha256"] = sha256(normalized_master)
            result["normalized_uat_sha256"] = sha256(normalized_uat)
            if result["normalized_master_sha256"] == result["normalized_uat_sha256"]:
                result["status"] = "TEXT_EQUIVALENT"
            else:
                result["status"] = "DIFFERENT"
        except UnicodeDecodeError:
            result["status"] = "DIFFERENT"
        return result
    except (OSError, TypeError, ValueError) as exc:
        result["error"] = str(exc)
        return result


def load_pairs(manifest_path: Path) -> list[dict[str, Any]]:
    data = json.loads(manifest_path.read_text(encoding="utf-8"))
    pairs = data.get("exact_file_pairs")
    if not isinstance(pairs, list):
        raise ValueError("manifest must contain an exact_file_pairs array")
    if not all(isinstance(pair, dict) for pair in pairs):
        raise ValueError("every exact_file_pairs item must be an object")
    return pairs


def write_json(path: Path, results: list[dict[str, Any]]) -> None:
    counts: dict[str, int] = {}
    for item in results:
        counts[item["status"]] = counts.get(item["status"], 0) + 1
    payload = {"summary": counts, "pairs": results}
    path.write_text(json.dumps(payload, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_csv(path: Path, results: list[dict[str, Any]]) -> None:
    fieldnames = list(results[0].keys()) if results else [
        "pipeline",
        "category",
        "master_path",
        "uat_path",
        "master_sha256",
        "uat_sha256",
        "status",
        "error",
    ]
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(results)


def escaped(value: Any) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def write_markdown(path: Path, results: list[dict[str, Any]]) -> None:
    counts: dict[str, int] = {}
    for item in results:
        counts[item["status"]] = counts.get(item["status"], 0) + 1

    lines = [
        "# Prompt and Schema Hash Report",
        "",
        "Raw SHA-256 equality is authoritative. `TEXT_EQUIVALENT` is flagged and is not byte-identical.",
        "",
        "## Summary",
        "",
    ]
    if counts:
        lines.extend(f"- {status}: {count}" for status, count in sorted(counts.items()))
    else:
        lines.append("- No mapped pairs were supplied.")
    lines.extend(
        [
            "",
            "## File pairs",
            "",
            "| Pipeline | Category | Master file | UAT file | Master SHA-256 | UAT SHA-256 | Status | Error |",
            "|---|---|---|---|---|---|---|---|",
        ]
    )
    for item in results:
        lines.append(
            "| "
            + " | ".join(
                escaped(item[key])
                for key in (
                    "pipeline",
                    "category",
                    "master_path",
                    "uat_path",
                    "master_sha256",
                    "uat_sha256",
                    "status",
                    "error",
                )
            )
            + " |"
        )
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--master", required=True, type=Path)
    parser.add_argument("--uat", required=True, type=Path)
    parser.add_argument("--manifest", required=True, type=Path)
    parser.add_argument("--out-dir", required=True, type=Path)
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    master_root = args.master.resolve()
    uat_root = args.uat.resolve()
    if not master_root.is_dir() or not uat_root.is_dir():
        print("master and UAT paths must both be directories", file=sys.stderr)
        return 2
    if master_root == uat_root:
        print("master and UAT paths must be distinct", file=sys.stderr)
        return 2

    try:
        pairs = load_pairs(args.manifest.resolve())
    except (OSError, ValueError, json.JSONDecodeError) as exc:
        print(f"invalid manifest: {exc}", file=sys.stderr)
        return 2

    results = [compare_pair(master_root, uat_root, pair) for pair in pairs]
    args.out_dir.mkdir(parents=True, exist_ok=True)
    write_json(args.out_dir / "02-hash-report.json", results)
    write_csv(args.out_dir / "02-hash-report.csv", results)
    write_markdown(args.out_dir / "02-hash-report.md", results)

    failing = {"DIFFERENT", "MISSING", "ERROR", "TEXT_EQUIVALENT"}
    return 1 if any(item["status"] in failing for item in results) else 0


if __name__ == "__main__":
    raise SystemExit(main())
