import json
import os
import sqlite3
from pathlib import Path

BASE_DIR = Path(__file__).parent
SEED_DIR = BASE_DIR / "data" / "seed"
DB_PATH = BASE_DIR / "local_seed.db"


def read_json(filename: str):
    path = SEED_DIR / filename
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def to_json_str(obj) -> str:
    return json.dumps(obj, ensure_ascii=False)


def main():
    if not SEED_DIR.exists():
        raise FileNotFoundError(f"Seed folder not found: {SEED_DIR}")

    coaches = read_json("coaches.json")
    faqs = read_json("faqs.json")
    coach_documents = read_json("coach_documents.json")
    clients = read_json("clients.json")
    checkins = read_json("checkins.json")
    reminders = read_json("reminders.json")
    message_seeds = read_json("message_seeds.json")

    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()

    cur.execute("PRAGMA foreign_keys = ON;")

    cur.execute("""
    CREATE TABLE IF NOT EXISTS coaches (
      coach_id TEXT PRIMARY KEY,
      coach_name TEXT NOT NULL,
      specialty TEXT NOT NULL,
      persona_json TEXT NOT NULL,
      default_program_templates_json TEXT,
      exercise_substitutions_json TEXT,
      nutrition_guidelines_json TEXT,
      training_zones_json TEXT,
      pose_library_json TEXT,
      nutrition_toolkit_json TEXT
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS coach_faqs (
      faq_id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL,
      question TEXT NOT NULL,
      answer TEXT NOT NULL,
      tags TEXT,
      FOREIGN KEY (coach_id) REFERENCES coaches(coach_id) ON DELETE CASCADE
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS coach_documents (
      doc_id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL,
      title TEXT NOT NULL,
      doc_type TEXT NOT NULL,
      content TEXT NOT NULL,
      FOREIGN KEY (coach_id) REFERENCES coaches(coach_id) ON DELETE CASCADE
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS clients (
      client_id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL,
      client_name TEXT NOT NULL,
      age INTEGER,
      gender TEXT,
      timezone TEXT,
      height_cm INTEGER,
      start_weight_kg REAL,
      target_weight_kg REAL,
      goal TEXT,
      experience_level TEXT,
      constraints_json TEXT,
      diet_preferences_json TEXT,
      notes_for_coach TEXT,
      baseline_metrics_json TEXT,
      FOREIGN KEY (coach_id) REFERENCES coaches(coach_id) ON DELETE CASCADE
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS checkins (
      checkin_id TEXT PRIMARY KEY,
      client_id TEXT NOT NULL,
      date TEXT NOT NULL,
      payload_json TEXT NOT NULL,
      FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS reminders (
      reminder_id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL,
      client_id TEXT NOT NULL,
      cadence TEXT NOT NULL,
      days_of_week_json TEXT NOT NULL,
      time_local TEXT NOT NULL,
      timezone TEXT NOT NULL,
      template_key TEXT NOT NULL,
      message TEXT NOT NULL,
      enabled INTEGER NOT NULL,
      FOREIGN KEY (coach_id) REFERENCES coaches(coach_id) ON DELETE CASCADE,
      FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE CASCADE
    );
    """)

    cur.execute("""
    CREATE TABLE IF NOT EXISTS message_seeds (
      seed_id TEXT PRIMARY KEY,
      coach_id TEXT NOT NULL,
      client_id TEXT,
      title TEXT NOT NULL,
      tags_json TEXT NOT NULL,
      messages_json TEXT NOT NULL,
      FOREIGN KEY (coach_id) REFERENCES coaches(coach_id) ON DELETE CASCADE,
      FOREIGN KEY (client_id) REFERENCES clients(client_id) ON DELETE SET NULL
    );
    """)

    # Clean load (optional): uncomment if you want fresh reset every run
    # for t in ["message_seeds","reminders","checkins","clients","coach_documents","coach_faqs","coaches"]:
    #     cur.execute(f"DELETE FROM {t};")

    # Insert coaches
    for c in coaches:
        cur.execute("""
        INSERT OR REPLACE INTO coaches (
          coach_id, coach_name, specialty, persona_json,
          default_program_templates_json, exercise_substitutions_json, nutrition_guidelines_json,
          training_zones_json, pose_library_json, nutrition_toolkit_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            c["coach_id"],
            c["coach_name"],
            c["specialty"],
            to_json_str(c.get("persona", {})),
            to_json_str(c.get("default_program_templates", {})) if "default_program_templates" in c else None,
            to_json_str(c.get("exercise_substitutions", {})) if "exercise_substitutions" in c else None,
            to_json_str(c.get("nutrition_guidelines", {})) if "nutrition_guidelines" in c else None,
            to_json_str(c.get("training_zones", {})) if "training_zones" in c else None,
            to_json_str(c.get("pose_library", {})) if "pose_library" in c else None,
            to_json_str(c.get("nutrition_toolkit", {})) if "nutrition_toolkit" in c else None,
        ))

    # Insert FAQs
    for f in faqs:
        cur.execute("""
        INSERT OR REPLACE INTO coach_faqs (faq_id, coach_id, question, answer, tags)
        VALUES (?, ?, ?, ?, ?);
        """, (f["faq_id"], f["coach_id"], f["question"], f["answer"], f.get("tags")))

    # Insert coach documents
    for d in coach_documents:
        cur.execute("""
        INSERT OR REPLACE INTO coach_documents (doc_id, coach_id, title, doc_type, content)
        VALUES (?, ?, ?, ?, ?);
        """, (d["doc_id"], d["coach_id"], d["title"], d["doc_type"], d["content"]))

    # Insert clients
    for u in clients:
        cur.execute("""
        INSERT OR REPLACE INTO clients (
          client_id, coach_id, client_name, age, gender, timezone, height_cm,
          start_weight_kg, target_weight_kg, goal, experience_level,
          constraints_json, diet_preferences_json, notes_for_coach, baseline_metrics_json
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            u["client_id"], u["coach_id"], u["client_name"], u.get("age"), u.get("gender"),
            u.get("timezone"), u.get("height_cm"), u.get("start_weight_kg"), u.get("target_weight_kg"),
            u.get("goal"), u.get("experience_level"),
            to_json_str(u.get("constraints", [])),
            to_json_str(u.get("diet_preferences", [])),
            u.get("notes_for_coach"),
            to_json_str(u.get("baseline_metrics", {})),
        ))

    # Insert check-ins (store all fields other than ids/date as payload_json)
    for chk in checkins:
        payload = dict(chk)
        checkin_id = payload.pop("checkin_id")
        client_id = payload.pop("client_id")
        date_str = payload.pop("date")
        cur.execute("""
        INSERT OR REPLACE INTO checkins (checkin_id, client_id, date, payload_json)
        VALUES (?, ?, ?, ?);
        """, (checkin_id, client_id, date_str, to_json_str(payload)))

    # Insert reminders
    for r in reminders:
        cur.execute("""
        INSERT OR REPLACE INTO reminders (
          reminder_id, coach_id, client_id, cadence, days_of_week_json, time_local, timezone,
          template_key, message, enabled
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (
            r["reminder_id"], r["coach_id"], r["client_id"], r["cadence"],
            to_json_str(r["days_of_week"]), r["time_local"], r["timezone"],
            r["template_key"], r["message"], 1 if r.get("enabled", True) else 0
        ))

    # Insert message seeds
    for s in message_seeds:
        cur.execute("""
        INSERT OR REPLACE INTO message_seeds (
          seed_id, coach_id, client_id, title, tags_json, messages_json
        ) VALUES (?, ?, ?, ?, ?, ?);
        """, (
            s["seed_id"], s["coach_id"], s.get("client_id"),
            s["title"], to_json_str(s.get("tags", [])), to_json_str(s.get("messages", []))
        ))

    conn.commit()
    conn.close()

    print(f"Seeded SQLite DB: {DB_PATH}")


if __name__ == "__main__":
    main()
