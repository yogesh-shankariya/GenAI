"""Correctness and search-scope tests for the sharded EFS marker store."""

import fcntl
import inspect
import json
import multiprocessing
import select
import subprocess
import sys
import threading
import time
import uuid
from pathlib import Path

import pytest

import sqs_service.mps_manager as mps_module
from consumer_idempotency import make_idempotent_handler
from sqs_service import MPSManager, SQSClient, create_marker_store
from sqs_service.marker_paths import (
    marker_identity_digest,
    sharded_message_directory,
)


QUEUE = "input__queue"
TRACE = "trace-123"

_HOLD_LOCK_SCRIPT = (
    "import fcntl, os, sys, time\n"
    "fd = os.open(sys.argv[1], os.O_CREAT | os.O_RDWR, 0o644)\n"
    "fcntl.lockf(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)\n"
    "print('locked', flush=True)\n"
    "time.sleep(30)\n"
)


def _process_claim(storage_path, barrier, results):
    manager = MPSManager(storage_path, file_layout="v2")
    barrier.wait(timeout=15)
    claimed, _ = manager.create_start_marker("process-race", QUEUE)
    results.put(claimed)


def test_digest_known_vector_and_unambiguous_identity(tmp_path):
    digest = marker_identity_digest(TRACE, QUEUE)

    assert digest == (
        "a164f94dcb7d051542edbc850503d316"
        "4ac0bff4831c14f62683f565572025f8"
    )
    assert sharded_message_directory(tmp_path, TRACE, QUEUE) == (
        tmp_path / "v2" / "a1" / "64" / digest
    )
    assert marker_identity_digest("ab", "c") != marker_identity_digest(
        "a", "bc"
    )
    assert marker_identity_digest(TRACE, "queue-a") != (
        marker_identity_digest(TRACE, "queue-b")
    )


def test_v2_read_miss_does_not_create_directories(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")

    assert not manager.has_end_marker(TRACE, QUEUE)
    assert manager.get_start_marker(TRACE, QUEUE) is None
    assert not (tmp_path / "v2").exists()


def test_v2_keeps_basenames_inside_one_digest_directory(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    claimed, start_path_text = manager.create_start_marker(
        TRACE,
        QUEUE,
        retry_count=3,
    )
    start_path = Path(start_path_text)
    message_directory = sharded_message_directory(tmp_path, TRACE, QUEUE)

    assert claimed
    assert start_path.parent == message_directory
    assert start_path.name.startswith(f"{TRACE}__{QUEUE}__start__3__")
    assert manager._lock_filepath(TRACE, QUEUE).parent == message_directory
    assert manager._lock_filepath(TRACE, QUEUE).name == (
        f"{TRACE}__{QUEUE}__lock"
    )

    end_path = Path(
        manager.create_end_marker(TRACE, QUEUE, retry_count=3)
    )
    assert end_path.parent == message_directory
    assert end_path.name.startswith(f"{TRACE}__{QUEUE}__end__3__")
    assert not start_path.exists()
    assert manager._lock_filepath(TRACE, QUEUE).exists()
    assert [path for path in tmp_path.iterdir() if path.is_file()] == []


def test_start_contains_owner_token_and_matching_filename_time(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")

    claimed, start_path_text = manager.create_start_marker(
        TRACE,
        QUEUE,
        retry_count=7,
    )
    start_path = Path(start_path_text)
    payload = json.loads(start_path.read_text())
    filename_timestamp = float(start_path.name.split("__")[-1])

    assert claimed
    assert payload == {
        "schema_version": 2,
        "trace_id": TRACE,
        "queue_name": QUEUE,
        "retry_count": 7,
        "started_at": filename_timestamp,
        "owner_id": payload["owner_id"],
        "claim_token": payload["claim_token"],
    }
    assert payload["owner_id"]
    assert uuid.UUID(payload["claim_token"]).hex == payload["claim_token"]
    assert not list(start_path.parent.glob(".*.tmp"))


def test_every_hot_search_is_limited_to_target_digest_directory(
    tmp_path,
    monkeypatch,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    expected_directory = sharded_message_directory(tmp_path, TRACE, QUEUE)
    original_glob = mps_module.glob.glob
    patterns = []

    # A large unrelated tree must never be enumerated for this key.
    unrelated = tmp_path / "v2" / "ff" / "ff" / ("f" * 64)
    unrelated.mkdir(parents=True)
    for index in range(1000):
        (unrelated / f"unrelated-{index}").touch()

    def recording_glob(pattern):
        patterns.append(Path(pattern))
        return original_glob(pattern)

    monkeypatch.setattr(mps_module.glob, "glob", recording_glob)
    monkeypatch.setattr(
        mps_module.os,
        "walk",
        lambda *args, **kwargs: pytest.fail(
            "hot marker path recursively walked EFS"
        ),
    )

    assert not manager.has_end_marker(TRACE, QUEUE)
    claimed, _ = manager.create_start_marker(TRACE, QUEUE)
    manager.create_end_marker(TRACE, QUEUE, success=False)

    assert claimed
    assert patterns
    assert {pattern.parent for pattern in patterns} == {expected_directory}
    assert all("unrelated" not in str(pattern) for pattern in patterns)


def test_v2_has_no_legacy_root_fallback(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    basename = f"{TRACE}__{QUEUE}__end__0__1000.0"
    legacy = tmp_path / basename
    legacy.write_text("success")

    assert not manager.has_end_marker(TRACE, QUEUE)

    destination = sharded_message_directory(tmp_path, TRACE, QUEUE) / basename
    destination.parent.mkdir(parents=True)
    destination.write_text("success")
    assert manager.has_end_marker(TRACE, QUEUE)


def test_glob_metacharacters_unicode_and_queue_separator_are_isolated(
    tmp_path,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    trace = "trace-*?[é]"
    queue = "input__queue-*?[雪]"

    claimed, start_path = manager.create_start_marker(trace, queue)

    assert claimed
    assert Path(start_path).parent == sharded_message_directory(
        tmp_path,
        trace,
        queue,
    )
    assert manager.get_start_marker(trace, queue) is not None
    assert manager.get_start_marker("trace-literal", queue) is None


@pytest.mark.parametrize(
    ("trace", "queue"),
    [
        ("trace_", "queue"),
        ("trace", "_queue"),
        ("trace_", "_queue"),
    ],
)
def test_underscore_boundaries_round_trip_without_double_claim(
    tmp_path,
    trace,
    queue,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")

    claimed, start_path = manager.create_start_marker(trace, queue)

    assert claimed
    assert manager.get_start_marker(trace, queue).filepath == start_path
    assert not manager.create_start_marker(trace, queue)[0]


def test_fifty_threads_and_manager_instances_produce_one_winner(tmp_path):
    contenders = 50
    barrier = threading.Barrier(contenders)
    results = []
    result_lock = threading.Lock()

    def claim():
        manager = MPSManager(str(tmp_path), file_layout="v2")
        barrier.wait(timeout=15)
        result = manager.create_start_marker("thread-race", QUEUE)[0]
        with result_lock:
            results.append(result)

    threads = [threading.Thread(target=claim) for _ in range(contenders)]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=20)

    assert all(not thread.is_alive() for thread in threads)
    assert results.count(True) == 1
    manager = MPSManager(str(tmp_path), file_layout="v2")
    assert len(manager.find_mps_files("thread-race", QUEUE)) == 1


def test_different_keys_never_false_reject_each_other(tmp_path):
    contenders = 50
    barrier = threading.Barrier(contenders)
    results = []
    result_lock = threading.Lock()

    def claim(index):
        manager = MPSManager(str(tmp_path), file_layout="v2")
        barrier.wait(timeout=15)
        result = manager.create_start_marker(f"unique-{index}", QUEUE)[0]
        with result_lock:
            results.append(result)

    threads = [
        threading.Thread(target=claim, args=(index,))
        for index in range(contenders)
    ]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=20)

    assert all(not thread.is_alive() for thread in threads)
    assert results == [True] * contenders


def test_independent_processes_produce_one_winner(tmp_path):
    context = multiprocessing.get_context("spawn")
    contenders = 8
    barrier = context.Barrier(contenders)
    results = context.Queue()
    processes = [
        context.Process(
            target=_process_claim,
            args=(str(tmp_path), barrier, results),
        )
        for _ in range(contenders)
    ]
    for process in processes:
        process.start()
    for process in processes:
        process.join(timeout=25)

    assert all(process.exitcode == 0 for process in processes)
    outcomes = [results.get(timeout=5) for _ in range(contenders)]
    assert outcomes.count(True) == 1


def test_held_kernel_lock_is_nonblocking_contention(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    manager._ensure_message_directory(TRACE, QUEUE)
    lock_path = manager._lock_filepath(TRACE, QUEUE)
    holder = subprocess.Popen(
        [sys.executable, "-c", _HOLD_LOCK_SCRIPT, str(lock_path)],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        text=True,
    )

    try:
        ready, _, _ = select.select([holder.stdout], [], [], 5)
        assert ready
        assert holder.stdout.readline().strip() == "locked"
        started_at = time.perf_counter()
        claimed, _ = manager.create_start_marker(TRACE, QUEUE)
        assert not claimed
        assert time.perf_counter() - started_at < 5
    finally:
        if holder.poll() is None:
            holder.kill()
        holder.wait(timeout=5)

    assert manager.create_start_marker(TRACE, QUEUE)[0]


def test_non_contention_kernel_error_propagates_and_registry_is_released(
    tmp_path,
    monkeypatch,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")

    def fail_lock(*args, **kwargs):
        raise OSError(5, "EFS I/O error")

    monkeypatch.setattr(mps_module.fcntl, "lockf", fail_lock)
    with pytest.raises(OSError, match="EFS I/O error"):
        manager.create_start_marker(TRACE, QUEUE)
    assert mps_module._INTRAPROCESS_LOCKS == {}


def test_late_owner_cannot_remove_takeover_claim(tmp_path):
    old_worker = MPSManager(
        str(tmp_path), timeout_seconds=0, file_layout="v2"
    )
    new_worker = MPSManager(
        str(tmp_path), timeout_seconds=0, file_layout="v2"
    )

    assert old_worker.create_start_marker(TRACE, QUEUE)[0]
    assert new_worker.create_start_marker(TRACE, QUEUE)[0]
    new_start = new_worker.get_start_marker(TRACE, QUEUE)
    assert new_start is not None
    new_payload = Path(new_start.filepath).read_bytes()

    old_worker.create_end_marker(TRACE, QUEUE, success=False)

    assert Path(new_start.filepath).read_bytes() == new_payload
    observer = MPSManager(str(tmp_path), file_layout="v2")
    assert not observer.create_start_marker(TRACE, QUEUE)[0]

    new_worker.create_end_marker(TRACE, QUEUE, success=False)
    assert observer.create_start_marker(TRACE, QUEUE)[0]


def test_completion_without_thread_local_claim_leaves_owner_start(
    tmp_path,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    claimed = threading.Event()
    foreign_completion_done = threading.Event()
    outcome = {}

    def owner():
        outcome["claimed"], outcome["path"] = (
            manager.create_start_marker(TRACE, QUEUE)
        )
        claimed.set()
        foreign_completion_done.wait(timeout=10)
        manager.create_end_marker(TRACE, QUEUE, success=False)

    owner_thread = threading.Thread(target=owner)
    owner_thread.start()
    assert claimed.wait(timeout=10)

    manager.create_end_marker(TRACE, QUEUE, success=False)
    assert Path(outcome["path"]).exists()
    foreign_completion_done.set()
    owner_thread.join(timeout=10)

    assert outcome["claimed"]
    assert not owner_thread.is_alive()
    assert not Path(outcome["path"]).exists()


def test_failed_second_claim_keeps_original_ownership_handle(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    claimed, start_path = manager.create_start_marker(TRACE, QUEUE)

    assert claimed
    assert not manager.create_start_marker(TRACE, QUEUE)[0]
    manager.create_end_marker(TRACE, QUEUE, success=False)
    assert not Path(start_path).exists()


def test_transient_owned_start_read_failure_retains_handle_for_retry(
    tmp_path,
    monkeypatch,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    claimed, start_path_text = manager.create_start_marker(TRACE, QUEUE)
    start_path = Path(start_path_text)
    original_open = Path.open
    failed_once = False

    def fail_start_read_once(path, *args, **kwargs):
        nonlocal failed_once
        if path == start_path and not failed_once:
            failed_once = True
            raise OSError(5, "transient EFS read error")
        return original_open(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", fail_start_read_once)

    manager.create_end_marker(TRACE, QUEUE, success=False)
    assert claimed
    assert start_path.exists()
    assert (TRACE, QUEUE) in manager._claim_handles()

    manager.create_end_marker(TRACE, QUEUE, success=False)
    assert not start_path.exists()
    assert (TRACE, QUEUE) not in manager._claim_handles()


def test_non_object_start_json_never_crashes_completion(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    claimed, start_path_text = manager.create_start_marker(TRACE, QUEUE)
    start_path = Path(start_path_text)
    start_path.write_text("[]")

    end_path = manager.create_end_marker(TRACE, QUEUE, success=False)

    assert claimed
    assert Path(end_path).read_text() == "failed"
    assert start_path.exists()
    assert (TRACE, QUEUE) in manager._claim_handles()


def test_live_corrupt_start_blocks_and_stale_corrupt_start_is_replaced(
    tmp_path,
):
    live_manager = MPSManager(str(tmp_path), file_layout="v2")
    directory = live_manager._ensure_message_directory(TRACE, QUEUE)
    live_name = live_manager._build_filename(
        TRACE,
        QUEUE,
        mps_module.MPSType.START,
        0,
        timestamp=time.time(),
    )
    live_path = directory / live_name
    live_path.write_text("not-json")

    assert not live_manager.create_start_marker(TRACE, QUEUE)[0]
    assert live_path.exists()

    stale_manager = MPSManager(
        str(tmp_path), timeout_seconds=0, file_layout="v2"
    )
    assert stale_manager.create_start_marker(TRACE, QUEUE)[0]
    assert not live_path.exists()


@pytest.mark.parametrize("timestamp", ["nan", "inf", "-inf"])
def test_non_finite_marker_timestamp_is_ignored_not_a_permanent_lease(
    tmp_path,
    timestamp,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    directory = manager._ensure_message_directory(TRACE, QUEUE)
    malformed = directory / f"{TRACE}__{QUEUE}__start__0__{timestamp}"
    malformed.write_text("not-a-valid-marker")

    assert manager.get_start_marker(TRACE, QUEUE) is None
    assert manager.create_start_marker(TRACE, QUEUE)[0]


def test_atomic_start_failure_leaves_no_partial_and_releases_locks(
    tmp_path,
    monkeypatch,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    original_replace = mps_module.os.replace
    calls = 0

    def fail_once(source, destination):
        nonlocal calls
        calls += 1
        if calls == 1:
            raise OSError(5, "publish failed")
        return original_replace(source, destination)

    monkeypatch.setattr(mps_module.os, "replace", fail_once)
    with pytest.raises(OSError, match="publish failed"):
        manager.create_start_marker(TRACE, QUEUE)

    directory = sharded_message_directory(tmp_path, TRACE, QUEUE)
    assert manager.get_start_marker(TRACE, QUEUE) is None
    assert list(directory.glob("*.tmp")) == []
    assert list(directory.glob(".*.tmp")) == []
    assert mps_module._INTRAPROCESS_LOCKS == {}
    assert manager.create_start_marker(TRACE, QUEUE)[0]


def test_thread_lock_registry_does_not_grow_per_message(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    for index in range(200):
        assert manager.create_start_marker(f"registry-{index}", QUEUE)[0]
    assert mps_module._INTRAPROCESS_LOCKS == {}


def test_abandon_local_claim_bounds_handle_memory_without_deleting_start(
    tmp_path,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    for index in range(200):
        trace = f"abandoned-{index}"
        claimed, start_path = manager.create_start_marker(trace, QUEUE)
        assert claimed
        manager.abandon_local_claim(trace, QUEUE)
        assert Path(start_path).exists()

    assert manager._claim_handles() == {}


def test_parallel_handler_abandons_local_handle_when_processing_escapes(
    tmp_path,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    client = SQSClient(
        queue_name=QUEUE,
        region_name="us-east-2",
        marker_store=manager,
    )
    handler = make_idempotent_handler(
        client=client,
        process_fn=lambda _message: (_ for _ in ()).throw(
            RuntimeError("processing escaped")
        ),
        route_error_fn=lambda _message: None,
    )
    message = {
        "MessageId": "message-id",
        "Body": json.dumps({"metadata": {"traceId": TRACE}}),
        "Attributes": {"ApproximateReceiveCount": "1"},
    }

    with pytest.raises(RuntimeError, match="processing escaped"):
        handler(message)

    assert manager._claim_handles() == {}
    assert manager.get_start_marker(TRACE, QUEUE) is not None


def test_parallel_handler_abandons_handle_when_end_write_fails(
    tmp_path,
    monkeypatch,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    client = SQSClient(
        queue_name=QUEUE,
        region_name="us-east-2",
        marker_store=manager,
    )
    handler = make_idempotent_handler(
        client=client,
        process_fn=lambda _message: True,
        route_error_fn=lambda _message: None,
    )
    message = {
        "MessageId": "message-id",
        "Body": json.dumps({"metadata": {"traceId": TRACE}}),
        "Attributes": {"ApproximateReceiveCount": "1"},
    }

    def fail_end(*args, **kwargs):
        raise OSError(5, "END write failed")

    monkeypatch.setattr(manager, "create_end_marker", fail_end)

    assert handler(message) is True
    assert manager._claim_handles() == {}
    assert manager.get_start_marker(TRACE, QUEUE) is not None


def test_parallel_handler_abandons_retryable_cleanup_handle(
    tmp_path,
    monkeypatch,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    client = SQSClient(
        queue_name=QUEUE,
        region_name="us-east-2",
        marker_store=manager,
    )
    handler = make_idempotent_handler(
        client=client,
        process_fn=lambda _message: False,
        route_error_fn=lambda _message: None,
    )
    message = {
        "MessageId": "message-id",
        "Body": json.dumps({"metadata": {"traceId": TRACE}}),
        "Attributes": {"ApproximateReceiveCount": "1"},
    }

    monkeypatch.setattr(
        manager,
        "_remove_owned_start_locked",
        lambda *args, **kwargs: mps_module._START_RETRYABLE_ERROR,
    )

    assert handler(message) is False
    assert manager._claim_handles() == {}
    assert manager.get_start_marker(TRACE, QUEUE) is not None


def test_completion_serializes_with_claim_state_transition(
    tmp_path,
    monkeypatch,
):
    owner = MPSManager(str(tmp_path), timeout_seconds=0, file_layout="v2")
    contender = MPSManager(
        str(tmp_path), timeout_seconds=0, file_layout="v2"
    )
    assert owner.create_start_marker(TRACE, QUEUE)[0]
    original_write = owner._atomic_write_text
    completion_holds_lock = threading.Event()
    release_completion = threading.Event()
    outcome = {}

    def paused_end_write(filepath, content, **kwargs):
        if "__end__" in filepath.name:
            completion_holds_lock.set()
            assert release_completion.wait(timeout=10)
        return original_write(filepath, content, **kwargs)

    monkeypatch.setattr(owner, "_atomic_write_text", paused_end_write)

    completion_thread = threading.Thread(
        target=lambda: owner.create_end_marker(TRACE, QUEUE, success=True)
    )
    completion_thread.start()
    assert completion_holds_lock.wait(timeout=10)

    claim_thread = threading.Thread(
        target=lambda: outcome.setdefault(
            "claimed_while_finishing",
            contender.create_start_marker(TRACE, QUEUE)[0],
        )
    )
    claim_thread.start()
    claim_thread.join(timeout=10)
    assert not claim_thread.is_alive()
    assert outcome["claimed_while_finishing"] is False

    release_completion.set()
    completion_thread.join(timeout=10)
    assert not completion_thread.is_alive()
    assert contender.create_start_marker(TRACE, QUEUE)[0] is False
    assert contender.has_end_marker(TRACE, QUEUE)
    assert mps_module._INTRAPROCESS_LOCKS == {}


def test_cleanup_removes_end_but_never_unlinks_lock_file(tmp_path):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    manager.create_start_marker(TRACE, QUEUE)
    end_path = Path(manager.create_end_marker(TRACE, QUEUE))
    lock_path = manager._lock_filepath(TRACE, QUEUE)

    removed = manager.cleanup_old_markers(max_age_seconds=0)

    assert removed == 1
    assert not end_path.exists()
    assert lock_path.exists()


def test_v1_cleanup_never_descends_into_v2(tmp_path):
    v2_manager = MPSManager(str(tmp_path), file_layout="v2")
    v2_manager.create_start_marker(TRACE, QUEUE)
    v2_end = Path(v2_manager.create_end_marker(TRACE, QUEUE))
    assert v2_manager.has_end_marker(TRACE, QUEUE)

    v1_manager = MPSManager(str(tmp_path), file_layout="v1")
    assert v1_manager.cleanup_old_markers(max_age_seconds=0) == 0

    assert v2_end.exists()
    assert v2_manager.has_end_marker(TRACE, QUEUE)


def test_frozen_clock_cannot_overwrite_sticky_success(tmp_path, monkeypatch):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    monkeypatch.setattr(mps_module.time, "time", lambda: 1234.5)

    success_path = manager.create_end_marker(TRACE, QUEUE, success=True)
    failed_path = manager.create_end_marker(TRACE, QUEUE, success=False)

    assert success_path != failed_path
    assert Path(success_path).read_text() == "success"
    assert Path(failed_path).read_text() == "failed"
    assert manager.has_end_marker(TRACE, QUEUE)


def test_equivalent_storage_paths_share_process_lock(tmp_path, monkeypatch):
    alias = tmp_path / "alias"
    try:
        alias.symlink_to(tmp_path, target_is_directory=True)
    except OSError:
        pytest.skip("symlinks are unavailable")
    first = MPSManager(str(tmp_path), file_layout="v2")
    second = MPSManager(str(alias), file_layout="v2")
    barrier = threading.Barrier(2)
    results = []

    original_live_check = MPSManager._latest_live_start

    def synchronized_live_check(self, trace_id, queue_name):
        result = original_live_check(self, trace_id, queue_name)
        if result is None:
            try:
                barrier.wait(timeout=5)
            except threading.BrokenBarrierError:
                pass
        return result

    monkeypatch.setattr(
        MPSManager,
        "_latest_live_start",
        synchronized_live_check,
    )

    threads = [
        threading.Thread(
            target=lambda store: results.append(
                store.create_start_marker(TRACE, QUEUE)[0]
            ),
            args=(store,),
        )
        for store in (first, second)
    ]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join(timeout=10)

    assert all(not thread.is_alive() for thread in threads)
    assert sorted(results) == [False, True]


def test_locking_is_mandatory_in_public_apis_and_stale_option_fails(
    tmp_path,
):
    assert "apply_lock" not in inspect.signature(MPSManager).parameters
    assert "apply_lock" not in inspect.signature(SQSClient).parameters
    with pytest.raises(ValueError, match="apply_lock"):
        create_marker_store(
            backend="file",
            storage_path=str(tmp_path),
            apply_lock=False,
        )


def test_factory_selects_v2_from_environment(tmp_path, monkeypatch):
    monkeypatch.setenv("MPS_FILE_LAYOUT", "v2")

    manager = create_marker_store(
        backend="file",
        storage_path=str(tmp_path),
    )

    assert isinstance(manager, MPSManager)
    assert manager.file_layout == "v2"
    assert manager.create_start_marker(TRACE, QUEUE)[0]


def test_invalid_file_layout_fails_at_construction(tmp_path):
    with pytest.raises(ValueError, match="Unsupported MPS file layout"):
        MPSManager(str(tmp_path), file_layout="version-two")


def test_slow_claim_warning_keeps_stage_breakdown(
    tmp_path,
    monkeypatch,
    caplog,
):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    monkeypatch.setattr(mps_module, "_SLOW_MARKER_OPERATION_SECONDS", 0)
    caplog.set_level("WARNING", logger="DocMetaLogger.SQS")

    manager.create_start_marker(TRACE, QUEUE)

    matching = [
        record.getMessage()
        for record in caplog.records
        if record.getMessage().startswith("Slow MPS START claim:")
    ]
    assert len(matching) == 1
    assert "initial_start_scan=" in matching[0]
    assert "kernel_lock_acquire=" in matching[0]
    assert "locked_start_scan=" in matching[0]
    assert "locked_completion_scan=" in matching[0]
    assert "start_marker_write=" in matching[0]


def test_timing_logger_failure_does_not_change_claim(tmp_path, monkeypatch):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    monkeypatch.setattr(mps_module, "_SLOW_MARKER_OPERATION_SECONDS", 0)

    def fail_warning(*args, **kwargs):
        raise RuntimeError("logger unavailable")

    monkeypatch.setattr(mps_module.logger, "warning", fail_warning)
    assert manager.create_start_marker(TRACE, QUEUE)[0]
    manager.create_end_marker(TRACE, QUEUE, success=False)
    assert manager.create_start_marker(TRACE, QUEUE)[0]


def test_claim_and_completion_both_take_kernel_lock(tmp_path, monkeypatch):
    manager = MPSManager(str(tmp_path), file_layout="v2")
    original_lockf = mps_module.fcntl.lockf
    operations = []

    def recording_lockf(fd, operation):
        operations.append(operation)
        return original_lockf(fd, operation)

    monkeypatch.setattr(mps_module.fcntl, "lockf", recording_lockf)
    manager.create_start_marker(TRACE, QUEUE)
    manager.create_end_marker(TRACE, QUEUE)

    assert (fcntl.LOCK_EX | fcntl.LOCK_NB) in operations
    assert fcntl.LOCK_EX in operations
    assert operations.count(fcntl.LOCK_UN) == 2
