"""Safety and compatibility tests for the one-time MPS v1->v2 migrator."""

import json
import os
from pathlib import Path

import pytest

import scripts.migrate_mps_v1_to_v2 as migration_module
from scripts.migrate_mps_v1_to_v2 import (
    MigrationMode,
    main,
    migrate_v1_markers,
    parse_legacy_marker,
)
from sqs_service import MPSManager
from sqs_service.marker_paths import (
    marker_identity_digest,
    sharded_message_directory,
)


TRACE_ID = "trace-123"
QUEUE_NAME = "input__queue"
OBSERVED_AT = 20_000.0


def _marker_name(
    marker_type: str,
    *,
    trace_id: str = TRACE_ID,
    queue_name: str = QUEUE_NAME,
    retry_count: int = 0,
    timestamp: float = 1_000.0,
) -> str:
    return "__".join(
        (
            trace_id,
            queue_name,
            marker_type,
            str(retry_count),
            str(timestamp),
        )
    )


def _write_marker(
    root: Path,
    marker_type: str,
    content: bytes = b"",
    **name_parts,
) -> Path:
    marker = root / _marker_name(marker_type, **name_parts)
    marker.write_bytes(content)
    return marker


def _destination(root: Path, source: Path) -> Path:
    parsed = parse_legacy_marker(
        source,
        expected_queue_name=QUEUE_NAME,
    )
    assert parsed is not None
    return (
        sharded_message_directory(
            root,
            parsed.trace_id,
            parsed.queue_name,
        )
        / source.name
    )


def test_migrator_uses_the_exact_runtime_digest_and_path_contract(tmp_path):
    digest = marker_identity_digest(TRACE_ID, QUEUE_NAME)

    assert digest == (
        "a164f94dcb7d051542edbc850503d316"
        "4ac0bff4831c14f62683f565572025f8"
    )
    assert sharded_message_directory(tmp_path, TRACE_ID, QUEUE_NAME) == (
        tmp_path / "v2" / "a1" / "64" / digest
    )


def test_parser_preserves_queue_names_containing_separator(tmp_path):
    source = _write_marker(
        tmp_path,
        "end",
        b"success",
        retry_count=7,
        timestamp=1234.5,
    )

    marker = parse_legacy_marker(
        source,
        expected_queue_name=QUEUE_NAME,
    )

    assert marker is not None
    assert marker.trace_id == TRACE_ID
    assert marker.queue_name == QUEUE_NAME
    assert marker.marker_type == "end"
    assert marker.retry_count == 7
    assert marker.timestamp == 1234.5


def test_expected_queue_resolves_underscore_boundary_identity(tmp_path):
    source = _write_marker(
        tmp_path,
        "end",
        b"success",
        trace_id="trace_",
        queue_name="queue",
    )

    marker = parse_legacy_marker(source, expected_queue_name="queue")

    assert marker is not None
    assert marker.trace_id == "trace_"
    assert marker.queue_name == "queue"


def test_ambiguous_legacy_end_migrates_to_original_identity_with_queue(
    tmp_path,
):
    source = _write_marker(
        tmp_path,
        "end",
        b"success",
        trace_id="trace_",
        queue_name="queue",
    )

    report = migrate_v1_markers(
        tmp_path,
        mode="execute",
        queue_name="queue",
    )
    expected = sharded_message_directory(
        tmp_path,
        "trace_",
        "queue",
    ) / source.name
    wrong = sharded_message_directory(
        tmp_path,
        "trace",
        "_queue",
    ) / source.name

    assert report.status == "completed"
    assert expected.read_bytes() == b"success"
    assert not wrong.exists()


def test_queue_ending_underscore_migrates_and_is_visible_to_v2(tmp_path):
    queue_name = "queue_"
    source = _write_marker(
        tmp_path,
        "end",
        b"success",
        trace_id="trace",
        queue_name=queue_name,
    )

    report = migrate_v1_markers(
        tmp_path,
        mode="execute",
        queue_name=queue_name,
    )

    assert report.status == "completed"
    destination = sharded_message_directory(
        tmp_path,
        "trace",
        queue_name,
    ) / source.name
    assert destination.read_bytes() == b"success"
    assert MPSManager(
        str(tmp_path),
        file_layout="v2",
    ).has_end_marker("trace", queue_name)


def test_dry_run_is_default_and_creates_nothing(tmp_path, capsys):
    source = _write_marker(tmp_path, "end", b"success")
    lock = tmp_path / f"{TRACE_ID}__{QUEUE_NAME}__lock"
    lock.write_bytes(b"")

    exit_code = main(
        [
            "--storage-path",
            str(tmp_path),
            "--queue-name",
            QUEUE_NAME,
        ]
    )
    output = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert output["mode"] == "dry-run"
    assert output["status"] == "ready"
    assert output["would_copy"] == 1
    assert output["lock_files_skipped"] == 1
    assert not (tmp_path / "v2").exists()
    assert source.read_bytes() == b"success"
    assert lock.exists()


@pytest.mark.parametrize("blocker", ["live-start", "malformed", "conflict"])
def test_execute_preflight_blockers_prevent_every_copy(tmp_path, blocker):
    first = _write_marker(
        tmp_path,
        "end",
        b"success-one",
        trace_id="trace-one",
    )
    second = _write_marker(
        tmp_path,
        "end",
        b"success-two",
        trace_id="trace-two",
    )

    if blocker == "live-start":
        _write_marker(
            tmp_path,
            "start",
            trace_id="active-trace",
            timestamp=OBSERVED_AT - 10,
        )
    elif blocker == "malformed":
        (tmp_path / "not-a-marker").write_bytes(b"unexpected")
    else:
        conflicting_destination = _destination(tmp_path, first)
        conflicting_destination.parent.mkdir(parents=True)
        conflicting_destination.write_bytes(b"different-content")

    report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode=MigrationMode.EXECUTE,
        lease_timeout_seconds=100,
        observed_at=OBSERVED_AT,
    )

    assert report.status == "blocked"
    assert report.copied == 0
    assert not _destination(tmp_path, second).exists()
    if blocker == "live-start":
        assert report.live_start_markers == 1
    elif blocker == "malformed":
        assert report.malformed == 1
    else:
        assert report.conflicts == 1
        assert _destination(tmp_path, first).read_bytes() == b"different-content"


def test_execute_copies_end_atomically_preserving_bytes_name_and_mtime(tmp_path):
    source = _write_marker(
        tmp_path,
        "end",
        b"success\nwith-exact-bytes\x00",
        retry_count=2,
        timestamp=1234.567,
    )
    preserved_mtime_ns = 1_700_000_000_123_456_789
    os.utime(source, ns=(preserved_mtime_ns, preserved_mtime_ns))

    report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode=MigrationMode.EXECUTE,
        observed_at=OBSERVED_AT,
    )
    destination = _destination(tmp_path, source)

    assert report.status == "completed"
    assert report.copied == 1
    assert destination.name == source.name
    assert destination.read_bytes() == source.read_bytes()
    assert destination.stat().st_mtime_ns == source.stat().st_mtime_ns
    assert source.exists(), "migration must never remove the v1 source"
    assert not any(
        ".mps-v2-migrate." in child.name
        for child in destination.parent.iterdir()
    )


def test_rerun_is_idempotent_and_leaves_source_untouched(tmp_path):
    source = _write_marker(tmp_path, "end", b"success")

    first = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="execute",
    )
    second = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="execute",
    )

    assert first.copied == 1
    assert second.status == "completed"
    assert second.copied == 0
    assert second.already_present == 1
    assert source.exists()
    assert source.read_bytes() == b"success"


def test_concurrent_destination_is_never_overwritten(tmp_path, monkeypatch):
    source = _write_marker(tmp_path, "end", b"source-success")
    destination = _destination(tmp_path, source)

    def concurrent_winner(_temporary, destination_text, **_kwargs):
        Path(destination_text).write_bytes(b"competing-content")
        raise FileExistsError(destination_text)

    monkeypatch.setattr(migration_module.os, "link", concurrent_winner)

    report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="execute",
    )

    assert report.status == "failed"
    assert report.copied == 0
    assert report.conflicts == 1
    assert destination.read_bytes() == b"competing-content"
    assert source.read_bytes() == b"source-success"
    assert not any(
        ".mps-v2-migrate." in child.name
        for child in destination.parent.iterdir()
    )


def test_stale_start_is_reported_but_not_copied_or_deleted(tmp_path):
    end = _write_marker(tmp_path, "end", b"failed", timestamp=1_000)
    stale_start = _write_marker(
        tmp_path,
        "start",
        timestamp=1_001,
    )

    report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="execute",
        lease_timeout_seconds=100,
        observed_at=OBSERVED_AT,
    )

    assert report.status == "completed"
    assert report.stale_start_markers == 1
    assert report.copied == 1
    assert _destination(tmp_path, end).read_bytes() == b"failed"
    assert not _destination(tmp_path, stale_start).exists()
    assert stale_start.exists(), "even stale v1 STARTs are never deleted"


def test_verify_reports_missing_destination(tmp_path):
    source = _write_marker(tmp_path, "end", b"success")

    report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="verify",
    )

    assert report.status == "blocked"
    assert report.missing == 1
    assert report.verified == 0
    assert any(issue.category == "missing-destination" for issue in report.issues)
    assert source.exists()


def test_verify_reports_content_mismatch_without_overwrite(tmp_path):
    source = _write_marker(tmp_path, "end", b"success")
    destination = _destination(tmp_path, source)
    destination.parent.mkdir(parents=True)
    destination.write_bytes(b"failed")

    report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="verify",
    )

    assert report.status == "blocked"
    assert report.conflicts == 1
    assert destination.read_bytes() == b"failed"
    assert source.read_bytes() == b"success"


def test_verify_succeeds_after_execute(tmp_path):
    _write_marker(tmp_path, "end", b"success", trace_id="first")
    _write_marker(tmp_path, "end", b"", trace_id="legacy-empty")

    execute_report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="execute",
    )
    verify_report = migrate_v1_markers(
        tmp_path,
        queue_name=QUEUE_NAME,
        mode="verify",
    )

    assert execute_report.copied == 2
    assert verify_report.status == "verified"
    assert verify_report.verified == 2
    assert verify_report.succeeded


def test_invalid_source_and_timeout_fail_safely(tmp_path):
    missing = tmp_path / "missing"

    report = migrate_v1_markers(
        missing,
        queue_name=QUEUE_NAME,
        mode="execute",
    )

    assert report.status == "failed"
    assert report.errors == 1
    assert not missing.exists()

    with pytest.raises(ValueError, match="finite non-negative"):
        migrate_v1_markers(
            tmp_path,
            queue_name=QUEUE_NAME,
            lease_timeout_seconds=-1,
        )
