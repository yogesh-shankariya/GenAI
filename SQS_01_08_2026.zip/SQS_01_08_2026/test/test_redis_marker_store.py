"""
Redis-backend-specific tests (everything the parametrized contract
suite cannot express): TTL-based garbage collection, value-level sticky
success, owner-protected claim release, from_env validation, factory
selection, and secret hygiene. All against fakeredis - never a live
Redis (project rule).
"""

import logging
import uuid

import fakeredis
import pytest

import sqs_service.redis_marker_store as rms
from sqs_service import RedisMarkerStore, create_marker_store


QUEUE = "dev-HOSSYTH_rallm"

GC_TTL_MS_7D = 7 * 24 * 60 * 60 * 1000


@pytest.fixture
def client():
    return fakeredis.FakeRedis(decode_responses=True)


@pytest.fixture
def store(client):
    return RedisMarkerStore(client, timeout_seconds=4 * 60 * 60)


def _keys(store, trace_id):
    return (
        store._key(trace_id, QUEUE, "start"),
        store._key(trace_id, QUEUE, "end"),
    )


# ----------------------------------------------------------------------
# TTL / garbage collection (the redis replacement for cleanup sweeps)
# ----------------------------------------------------------------------

def test_markers_carry_gc_ttl(store, client):
    trace_id = str(uuid.uuid4())
    start_key, end_key = _keys(store, trace_id)

    store.create_start_marker(trace_id, QUEUE)
    assert 0 < client.pttl(start_key) <= GC_TTL_MS_7D

    store.create_end_marker(trace_id, QUEUE, success=True)
    assert 0 < client.pttl(end_key) <= GC_TTL_MS_7D
    # END released our claim
    assert client.exists(start_key) == 0


def test_cleanup_is_a_noop_returning_zero(store):
    trace_id = str(uuid.uuid4())
    store.create_end_marker(trace_id, QUEUE, success=True)

    assert store.cleanup_old_markers(max_age_seconds=0) == 0
    # ...and the marker is still there (TTL, not sweep, will remove it)
    assert store.has_end_marker(trace_id, QUEUE)


# ----------------------------------------------------------------------
# Value-level semantics
# ----------------------------------------------------------------------

def test_sticky_success_at_the_value_level(store, client):
    trace_id = str(uuid.uuid4())
    _, end_key = _keys(store, trace_id)

    store.create_end_marker(trace_id, QUEUE, success=False)
    assert client.get(end_key) == "failed"

    store.create_end_marker(trace_id, QUEUE, success=True)
    assert client.get(end_key) == "success"

    # A later failed run must not overwrite the success value
    store.create_end_marker(trace_id, QUEUE, success=False)
    assert client.get(end_key) == "success"


def test_owner_protected_release(store, client):
    # A worker finishing must release ONLY its own claim - a claim
    # taken over by another worker (foreign owner field) survives.
    trace_id = str(uuid.uuid4())
    start_key, _ = _keys(store, trace_id)

    store.create_start_marker(trace_id, QUEUE)
    # Simulate a takeover: another pod's owner id now holds the claim
    client.hset(start_key, "owner", "other-host:999:12345")

    store.create_end_marker(trace_id, QUEUE, success=False)

    # The foreign claim was NOT deleted (file backend would have
    # deleted it - deliberate, documented divergence; M2-safe)
    assert client.exists(start_key) == 1
    assert client.hget(start_key, "owner") == "other-host:999:12345"


def test_bytes_client_tolerated():
    # decode_responses=False clients still work (values normalized)
    raw = fakeredis.FakeRedis(decode_responses=False)
    store = RedisMarkerStore(raw)
    trace_id = str(uuid.uuid4())

    claimed, _ = store.create_start_marker(trace_id, QUEUE)
    assert claimed
    info = store.get_start_marker(trace_id, QUEUE)
    assert info is not None and info.timestamp > 0

    store.create_end_marker(trace_id, QUEUE, success=True)
    assert store.has_end_marker(trace_id, QUEUE)
    claimed_again, _ = store.create_start_marker(trace_id, QUEUE)
    assert not claimed_again


def test_get_start_marker_fields(store):
    trace_id = str(uuid.uuid4())
    store.create_start_marker(trace_id, QUEUE, retry_count=3)

    info = store.get_start_marker(trace_id, QUEUE)

    assert info.trace_id == trace_id
    assert info.queue_name == QUEUE
    assert info.retry_count == 3
    assert info.timestamp > 0
    assert not store.is_start_marker_stale(info)


# ----------------------------------------------------------------------
# Adversarial-review regressions (findings verified 2026-08-03)
# ----------------------------------------------------------------------

def test_claim_script_replay_is_recognized_as_our_claim(store):
    # redis-py's automatic retry can re-run the claim script after a
    # lost response. The replay carries IDENTICAL args (same token) and
    # must return 'claimed' - not 'owned', which would park the message
    # for the full 4h lease with the worker refusing itself.
    trace_id = str(uuid.uuid4())
    start_key, end_key = _keys(store, trace_id)
    args = ["owner-a", "1000.5", "14400.0", 0, GC_TTL_MS_7D, "token-1"]

    first = store._s(
        store._claim_script(keys=[end_key, start_key], args=args)
    )
    replay = store._s(
        store._claim_script(keys=[end_key, start_key], args=args)
    )

    assert first == "claimed"
    assert replay == "claimed"


def test_genuine_second_claim_still_refused(store):
    # The replay exemption must NOT weaken the lock: a real second
    # create_start_marker call carries a fresh token and is refused
    trace_id = str(uuid.uuid4())

    claimed, _ = store.create_start_marker(trace_id, QUEUE)
    claimed_again, _ = store.create_start_marker(trace_id, QUEUE)

    assert claimed
    assert not claimed_again


def test_corrupt_ts_reads_as_stale_and_self_heals(store, client):
    # A non-numeric ts (external tampering / foreign writer) must not
    # crash the claim script or get_start_marker - it reads as
    # maximally stale, is claimable, and the takeover REPLACES the
    # broken hash
    trace_id = str(uuid.uuid4())
    start_key, _ = _keys(store, trace_id)
    client.hset(
        start_key, mapping={"owner": "x", "ts": "garbage", "retry": "0"}
    )

    info = store.get_start_marker(trace_id, QUEUE)
    assert info.timestamp == 0.0  # parsed safely, not a crash
    assert store.is_start_marker_stale(info)

    claimed, _ = store.create_start_marker(trace_id, QUEUE)
    assert claimed  # not a Lua arithmetic error
    assert store.get_start_marker(trace_id, QUEUE).timestamp > 0


def test_takeover_replaces_stale_hash_instead_of_merging(store, client):
    # DEL-before-HSET: a takeover must not inherit residue fields from
    # the previous (possibly corrupted / older-schema) claim
    trace_id = str(uuid.uuid4())
    start_key, _ = _keys(store, trace_id)
    client.hset(
        start_key,
        mapping={"owner": "dead", "ts": "1.0", "retry": "9", "zombie": "z"},
    )

    claimed, _ = store.create_start_marker(trace_id, QUEUE)

    assert claimed
    assert client.hget(start_key, "zombie") is None


def test_underscore_shift_keys_do_not_collide(store):
    # trace 'a_' + queue 'x' vs trace 'a' + queue '_x' concatenate to
    # the same string; the len(trace) key suffix must keep them
    # distinct (otherwise one message's success END silently suppresses
    # the OTHER message - data loss disguised as deduplication)
    assert store._key("a_", "x", "end") != store._key("a", "_x", "end")

    store.create_end_marker("a_", "x", success=True)

    assert not store.has_end_marker("a", "_x")
    claimed, _ = store.create_start_marker("a", "_x")
    assert claimed


def test_braces_rejected_in_ids(store):
    # '{'/'}' would corrupt the cluster hash tag (a leading '}' makes
    # it empty, splitting one message's keys across slots)
    with pytest.raises(ValueError, match="hash tag"):
        store.create_start_marker("}abc", QUEUE)
    with pytest.raises(ValueError, match="hash tag"):
        store.has_end_marker("abc", "que{ue")


def test_gc_ttl_must_exceed_lease(client):
    # A GC TTL at or below the lease would expire a LIVE claim
    # mid-processing and reopen the message to a second worker
    with pytest.raises(ValueError, match="gc_ttl_seconds"):
        RedisMarkerStore(
            client,
            timeout_seconds=14 * 24 * 60 * 60,
            gc_ttl_seconds=7 * 24 * 60 * 60,
        )
    with pytest.raises(ValueError, match="gc_ttl_seconds"):
        RedisMarkerStore(client, timeout_seconds=0, gc_ttl_seconds=0)


# ----------------------------------------------------------------------
# from_env validation (no network attempts - construction fails first,
# or the Redis class is monkeypatched to fakeredis)
# ----------------------------------------------------------------------

def _patch_redis_class(monkeypatch, ping_error=None):
    """
    Replace redis.Redis with a fakeredis factory that RECORDS the
    construction kwargs and ping() calls, so tests verify the actual
    connection plumbing (host/port/password/ssl/timeouts) and the
    boot-time fail-fast - not just that from_env returns something.
    """
    calls = {"kwargs": None, "ping": 0}

    class _RecordingFake(fakeredis.FakeRedis):
        def ping(self):
            calls["ping"] += 1
            if ping_error is not None:
                raise ping_error
            return super().ping()

    def _ctor(**kwargs):
        calls["kwargs"] = kwargs
        return _RecordingFake(decode_responses=True)

    monkeypatch.setattr(rms.redis_lib, "Redis", _ctor)
    return calls


def test_from_env_requires_host(monkeypatch):
    monkeypatch.delenv("REDIS_HOST_NAME", raising=False)

    with pytest.raises(ValueError, match="REDIS_HOST_NAME"):
        RedisMarkerStore.from_env()


def test_from_env_rejects_bad_port(monkeypatch):
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")
    monkeypatch.setenv("REDIS_PORT_NUMBER", "not-a-number")

    with pytest.raises(ValueError, match="REDIS_PORT_NUMBER"):
        RedisMarkerStore.from_env()


def test_from_env_rejects_token_without_tls(monkeypatch):
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")
    monkeypatch.setenv("REDIS_AUTH_TOKEN", "supersecret")
    monkeypatch.setenv("REDIS_SSL", "false")

    with pytest.raises(ValueError, match="REDIS_SSL"):
        RedisMarkerStore.from_env()


def test_from_env_builds_and_pings(monkeypatch):
    calls = _patch_redis_class(monkeypatch)
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")
    monkeypatch.setenv("REDIS_PORT_NUMBER", "6380")
    monkeypatch.setenv("REDIS_AUTH_TOKEN", "sekrit")
    monkeypatch.setenv("REDIS_SSL", "true")

    store = RedisMarkerStore.from_env(timeout_seconds=42)

    assert isinstance(store, RedisMarkerStore)
    assert store.timeout_seconds == 42

    # The env values actually reached the redis client construction
    kw = calls["kwargs"]
    assert kw["host"] == "redis.example.internal"
    assert kw["port"] == 6380
    assert kw["password"] == "sekrit"
    assert kw["ssl"] is True
    assert kw["decode_responses"] is True
    # The outage-blast-radius controls are load-bearing (see adapter)
    assert kw["socket_timeout"] == 2
    assert kw["socket_connect_timeout"] == 2
    # Boot-time fail-fast actually pinged
    assert calls["ping"] == 1


def test_from_env_ping_failure_aborts_boot(monkeypatch):
    # A misconfigured/unreachable endpoint must kill a redis-opted-in
    # pod at boot - never let it run without duplicate protection
    calls = _patch_redis_class(
        monkeypatch,
        ping_error=rms.redis_lib.exceptions.ConnectionError("unreachable"),
    )
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")

    with pytest.raises(rms.redis_lib.exceptions.ConnectionError):
        RedisMarkerStore.from_env()
    assert calls["ping"] == 1


@pytest.mark.parametrize("spelling", ["1", "yes", "0", "TRUE please"])
def test_from_env_rejects_nonboolean_ssl(monkeypatch, spelling):
    # 'REDIS_SSL: "1"' must NOT silently mean plaintext - only the
    # literals 'true'/'false' (or unset/empty) are accepted
    _patch_redis_class(monkeypatch)
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")
    monkeypatch.setenv("REDIS_SSL", spelling)

    with pytest.raises(ValueError, match="REDIS_SSL"):
        RedisMarkerStore.from_env()


def test_from_env_empty_ssl_means_default_tls(monkeypatch):
    # A templated-empty ConfigMap value ('REDIS_SSL: ""') is unset ->
    # the secure default (TLS on)
    calls = _patch_redis_class(monkeypatch)
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")
    monkeypatch.setenv("REDIS_SSL", "")

    RedisMarkerStore.from_env()

    assert calls["kwargs"]["ssl"] is True


def test_from_env_never_logs_the_token(monkeypatch, caplog):
    _patch_redis_class(monkeypatch)
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")
    monkeypatch.setenv("REDIS_AUTH_TOKEN", "supersecret-token-value")
    monkeypatch.setenv("REDIS_SSL", "true")

    with caplog.at_level(logging.DEBUG):
        RedisMarkerStore.from_env()

    assert "supersecret-token-value" not in caplog.text
    assert "auth=yes" in caplog.text


# ----------------------------------------------------------------------
# Factory integration (MPS_BACKEND=redis is a pure config change)
# ----------------------------------------------------------------------

def test_factory_selects_redis(monkeypatch, tmp_path):
    _patch_redis_class(monkeypatch)
    monkeypatch.setenv("MPS_BACKEND", "redis")
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")

    # The SQSClient construction line passes storage_path either way -
    # the redis builder accepts-and-ignores it (memory-backend pattern)
    store = create_marker_store(storage_path=str(tmp_path))

    assert isinstance(store, RedisMarkerStore)


def test_factory_passes_timeout_to_redis(monkeypatch):
    _patch_redis_class(monkeypatch)
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")

    store = create_marker_store(backend="redis", timeout_seconds=77)
    assert store.timeout_seconds == 77

    # Omitted -> the adapter's own 4h default
    store = create_marker_store(backend="redis")
    assert store.timeout_seconds == 4 * 60 * 60


def test_factory_rejects_unknown_redis_options(monkeypatch):
    _patch_redis_class(monkeypatch)
    monkeypatch.setenv("REDIS_HOST_NAME", "redis.example.internal")

    with pytest.raises(ValueError, match="lease_secs"):
        create_marker_store(backend="redis", lease_secs=60)
