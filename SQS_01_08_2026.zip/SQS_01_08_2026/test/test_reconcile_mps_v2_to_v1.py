"""Rollback-safety tests for sharded-v2 to flat-v1 reconciliation."""

import json
import os
from pathlib import Path

import pytest

import scripts.reconcile_mps_v2_to_v1 as reconciliation_module
from scripts.reconcile_mps_v2_to_v1 import (
    ReconciliationMode,
    main,
    parse_v2_marker,
    reconcile_v2_markers,
)
from sqs_service import MPSManager
from sqs_service.marker_paths import sharded_message_directory


TRACE_ID = "trace-rollback-123"
QUEUE_NAME = "input__queue"
OBSERVED_AT = 20_000.0


def _marker_name(
    marker_type: str,
    *,
    trace_id: str = TRACE_ID,
    queue_name: str = QUEUE_NAME,
    retry_count: int = 0,
    timestamp: float = 1_000.0,
) -> str:
    return "__".join(
        (
            trace_id,
            queue_name,
            marker_type,
            str(retry_count),
            str(timestamp),
        )
    )


def _write_v2_marker(
    root: Path,
    marker_type: str,
    content: bytes = b"",
    **name_parts,
) -> Path:
    trace_id = name_parts.get("trace_id", TRACE_ID)
    queue_name = name_parts.get("queue_name", QUEUE_NAME)
    directory = sharded_message_directory(root, trace_id, queue_name)
    directory.mkdir(parents=True, exist_ok=True)
    marker = directory / _marker_name(marker_type, **name_parts)
    if marker_type == "start" and content == b"":
        retry_count = name_parts.get("retry_count", 0)
        timestamp = name_parts.get("timestamp", 1_000.0)
        content = json.dumps(
            {
                "schema_version": 2,
                "trace_id": trace_id,
                "queue_name": queue_name,
                "retry_count": retry_count,
                "started_at": timestamp,
                "owner_id": "test-owner",
                "claim_token": "test-claim-token",
            },
            sort_keys=True,
            separators=(",", ":"),
        ).encode()
    marker.write_bytes(content)
    return marker


def _write_v2_lock(
    root: Path,
    *,
    trace_id: str = TRACE_ID,
    queue_name: str = QUEUE_NAME,
) -> Path:
    directory = sharded_message_directory(root, trace_id, queue_name)
    directory.mkdir(parents=True, exist_ok=True)
    lock = directory / f"{trace_id}__{queue_name}__lock"
    lock.write_bytes(b"")
    return lock


def _flat_destination(root: Path, source: Path) -> Path:
    return root / source.name


def test_parser_preserves_queue_separator_and_marker_fields(tmp_path):
    source = _write_v2_marker(
        tmp_path,
        "end",
        b"success",
        retry_count=4,
        timestamp=1234.5,
    )

    marker = parse_v2_marker(source)

    assert marker is not None
    assert marker.trace_id == TRACE_ID
    assert marker.queue_name == QUEUE_NAME
    assert marker.marker_type == "end"
    assert marker.retry_count == 4
    assert marker.timestamp == 1234.5


@pytest.mark.parametrize(
    ("trace_id", "queue_name"),
    [("..", QUEUE_NAME), (TRACE_ID, "."), (TRACE_ID, "bad\\queue")],
)
def test_parser_rejects_runtime_incompatible_identities(
    tmp_path,
    trace_id,
    queue_name,
):
    source = _write_v2_marker(
        tmp_path,
        "end",
        b"success",
        trace_id=trace_id,
        queue_name=queue_name,
    )

    assert parse_v2_marker(source) is None


def test_dry_run_is_default_creates_nothing_and_ignores_valid_lock(
    tmp_path,
    capsys,
):
    source = _write_v2_marker(tmp_path, "end", b"success")
    lock = _write_v2_lock(tmp_path)

    exit_code = main(["--storage-path", str(tmp_path)])
    output = json.loads(capsys.readouterr().out)

    assert exit_code == 0
    assert output["mode"] == "dry-run"
    assert output["status"] == "ready"
    assert output["would_copy"] == 1
    assert output["lock_files_skipped"] == 1
    assert not _flat_destination(tmp_path, source).exists()
    assert source.read_bytes() == b"success"
    assert lock.exists()


@pytest.mark.parametrize(
    "blocker",
    [
        "live-start",
        "malformed-hierarchy",
        "malformed-marker",
        "misplaced-marker",
        "conflict",
    ],
)
def test_execute_preflight_blockers_prevent_every_flat_copy(
    tmp_path,
    blocker,
):
    first = _write_v2_marker(
        tmp_path,
        "end",
        b"success-one",
        trace_id="trace-one",
    )
    second = _write_v2_marker(
        tmp_path,
        "end",
        b"success-two",
        trace_id="trace-two",
    )

    if blocker == "live-start":
        _write_v2_marker(
            tmp_path,
            "start",
            trace_id="active-trace",
            timestamp=OBSERVED_AT - 10,
        )
    elif blocker == "malformed-hierarchy":
        (tmp_path / "v2" / "ZZ").mkdir()
    elif blocker == "malformed-marker":
        (first.parent / "not-a-marker").write_bytes(b"unexpected")
    elif blocker == "misplaced-marker":
        wrong_digest = "f" * 64
        wrong_directory = tmp_path / "v2" / "ff" / "ff" / wrong_digest
        wrong_directory.mkdir(parents=True)
        (wrong_directory / first.name).write_bytes(b"success-one")
    else:
        _flat_destination(tmp_path, first).write_bytes(b"different")

    report = reconcile_v2_markers(
        tmp_path,
        mode=ReconciliationMode.EXECUTE,
        lease_timeout_seconds=100,
        observed_at=OBSERVED_AT,
    )

    assert report.status == "blocked"
    assert report.copied == 0
    assert not _flat_destination(tmp_path, second).exists()
    if blocker == "live-start":
        assert report.live_start_markers == 1
    elif blocker == "conflict":
        assert report.conflicts == 1
        assert _flat_destination(tmp_path, first).read_bytes() == b"different"
    else:
        assert report.malformed >= 1


def test_execute_preserves_name_bytes_mtime_and_v2_source(tmp_path):
    source = _write_v2_marker(
        tmp_path,
        "end",
        b"success\nexact-content\x00",
        retry_count=2,
        timestamp=1234.567,
    )
    preserved_mtime_ns = 1_700_000_000_987_654_321
    os.utime(source, ns=(preserved_mtime_ns, preserved_mtime_ns))

    report = reconcile_v2_markers(tmp_path, mode="execute")
    destination = _flat_destination(tmp_path, source)

    assert report.status == "completed"
    assert report.copied == 1
    assert destination.name == source.name
    assert destination.read_bytes() == source.read_bytes()
    assert destination.stat().st_mtime_ns == source.stat().st_mtime_ns
    assert source.exists(), "rollback reconciliation must retain v2 source"
    assert not any(
        ".mps-v1-reconcile." in child.name for child in tmp_path.iterdir()
    )


def test_rerun_is_idempotent_and_source_remains_untouched(tmp_path):
    source = _write_v2_marker(tmp_path, "end", b"success")

    first = reconcile_v2_markers(tmp_path, mode="execute")
    second = reconcile_v2_markers(tmp_path, mode="execute")

    assert first.copied == 1
    assert second.status == "completed"
    assert second.copied == 0
    assert second.already_present == 1
    assert source.exists()
    assert source.read_bytes() == b"success"


def test_stale_start_is_reported_but_not_copied_or_deleted(tmp_path):
    end = _write_v2_marker(tmp_path, "end", b"failed", timestamp=1_000)
    stale_start = _write_v2_marker(
        tmp_path,
        "start",
        timestamp=1_001,
    )

    report = reconcile_v2_markers(
        tmp_path,
        mode="execute",
        lease_timeout_seconds=100,
        observed_at=OBSERVED_AT,
    )

    assert report.status == "completed"
    assert report.stale_start_markers == 1
    assert report.copied == 1
    assert _flat_destination(tmp_path, end).read_bytes() == b"failed"
    assert not _flat_destination(tmp_path, stale_start).exists()
    assert stale_start.exists()


def test_ambiguous_start_filename_uses_json_identity_and_blocks_when_live(
    tmp_path,
):
    source = _write_v2_marker(
        tmp_path,
        "start",
        trace_id="ambiguous_",
        queue_name="queue",
        timestamp=OBSERVED_AT - 10,
    )

    report = reconcile_v2_markers(
        tmp_path,
        mode="execute",
        lease_timeout_seconds=100,
        observed_at=OBSERVED_AT,
    )

    assert report.status == "blocked"
    assert report.live_start_markers == 1
    assert report.malformed == 0
    assert source.exists()


@pytest.mark.parametrize("content", [b"[]", b'"owner"', b"42"])
def test_non_object_start_json_is_reported_not_crashed(tmp_path, content):
    source = _write_v2_marker(
        tmp_path,
        "start",
        content=content,
        timestamp=OBSERVED_AT - 10,
    )

    report = reconcile_v2_markers(
        tmp_path,
        mode="execute",
        lease_timeout_seconds=100,
        observed_at=OBSERVED_AT,
    )

    assert report.status == "blocked"
    assert report.malformed == 1
    assert source.exists()


def test_v1_basename_collision_blocks_all_copies_before_execution(tmp_path):
    first = _write_v2_marker(
        tmp_path,
        "end",
        b"same-content",
        trace_id="collision_",
        queue_name="queue",
    )
    second = _write_v2_marker(
        tmp_path,
        "end",
        b"same-content",
        trace_id="collision",
        queue_name="_queue",
    )
    unrelated = _write_v2_marker(
        tmp_path,
        "end",
        b"unrelated",
        trace_id="safe-trace",
        queue_name="safe-queue",
    )

    assert first.name == second.name
    assert first.parent != second.parent

    report = reconcile_v2_markers(tmp_path, mode="execute")

    assert report.status == "blocked"
    assert report.copied == 0
    assert report.name_collisions == 1
    assert any(
        issue.category == "v1-name-collision" for issue in report.issues
    )
    assert not _flat_destination(tmp_path, first).exists()
    assert not _flat_destination(tmp_path, unrelated).exists()


def test_misplaced_lock_is_blocker_not_silently_ignored(tmp_path):
    source = _write_v2_marker(tmp_path, "end", b"success")
    wrong_digest = "e" * 64
    wrong_directory = tmp_path / "v2" / "ee" / "ee" / wrong_digest
    wrong_directory.mkdir(parents=True)
    (wrong_directory / f"{TRACE_ID}__{QUEUE_NAME}__lock").write_bytes(b"")

    report = reconcile_v2_markers(tmp_path, mode="execute")

    assert report.status == "blocked"
    assert report.malformed == 1
    assert report.lock_files_skipped == 0
    assert not _flat_destination(tmp_path, source).exists()
    assert any(issue.category == "misplaced-lock" for issue in report.issues)


def test_symlink_shard_is_rejected_and_never_traversed(tmp_path):
    outside = tmp_path / "outside"
    outside.mkdir()
    external_marker = outside / _marker_name("end")
    external_marker.write_bytes(b"outside-content")
    (tmp_path / "v2").mkdir()
    (tmp_path / "v2" / "aa").symlink_to(outside, target_is_directory=True)

    report = reconcile_v2_markers(tmp_path, mode="execute")

    assert report.status == "blocked"
    assert report.malformed == 1
    assert report.end_markers == 0
    assert not _flat_destination(tmp_path, external_marker).exists()
    assert external_marker.read_bytes() == b"outside-content"


def test_concurrent_flat_destination_is_never_overwritten(
    tmp_path,
    monkeypatch,
):
    source = _write_v2_marker(tmp_path, "end", b"v2-success")
    destination = _flat_destination(tmp_path, source)

    def concurrent_winner(_temporary, destination_text, **_kwargs):
        Path(destination_text).write_bytes(b"competing-flat-content")
        raise FileExistsError(destination_text)

    monkeypatch.setattr(
        reconciliation_module.os,
        "link",
        concurrent_winner,
    )

    report = reconcile_v2_markers(tmp_path, mode="execute")

    assert report.status == "failed"
    assert report.copied == 0
    assert report.conflicts == 1
    assert destination.read_bytes() == b"competing-flat-content"
    assert source.read_bytes() == b"v2-success"
    assert not any(
        ".mps-v1-reconcile." in child.name for child in tmp_path.iterdir()
    )


def test_verify_reports_missing_flat_destination(tmp_path):
    source = _write_v2_marker(tmp_path, "end", b"success")

    report = reconcile_v2_markers(tmp_path, mode="verify")

    assert report.status == "blocked"
    assert report.missing == 1
    assert report.verified == 0
    assert any(issue.category == "missing-destination" for issue in report.issues)
    assert source.exists()


def test_verify_reports_mismatch_without_overwrite(tmp_path):
    source = _write_v2_marker(tmp_path, "end", b"success")
    destination = _flat_destination(tmp_path, source)
    destination.write_bytes(b"failed")

    report = reconcile_v2_markers(tmp_path, mode="verify")

    assert report.status == "blocked"
    assert report.conflicts == 1
    assert destination.read_bytes() == b"failed"
    assert source.read_bytes() == b"success"


def test_verify_succeeds_after_execute(tmp_path):
    _write_v2_marker(tmp_path, "end", b"success", trace_id="first")
    _write_v2_marker(tmp_path, "end", b"", trace_id="legacy-empty")

    execute_report = reconcile_v2_markers(tmp_path, mode="execute")
    verify_report = reconcile_v2_markers(tmp_path, mode="verify")

    assert execute_report.copied == 2
    assert verify_report.status == "verified"
    assert verify_report.verified == 2
    assert verify_report.succeeded


def test_reconciled_success_and_failure_have_v1_runtime_semantics(tmp_path):
    successful_trace = "runtime-success"
    failed_trace = "runtime-failure"
    v2 = MPSManager(str(tmp_path), file_layout="v2")
    v2.create_end_marker(
        successful_trace,
        QUEUE_NAME,
        success=True,
    )
    v2.create_end_marker(
        failed_trace,
        QUEUE_NAME,
        success=False,
    )

    execute_report = reconcile_v2_markers(tmp_path, mode="execute")
    verify_report = reconcile_v2_markers(tmp_path, mode="verify")

    assert execute_report.status == "completed"
    assert execute_report.copied == 2
    assert verify_report.status == "verified"
    assert verify_report.verified == 2

    v1 = MPSManager(str(tmp_path), file_layout="v1")
    assert v1.has_end_marker(successful_trace, QUEUE_NAME)
    successful_claimed, _ = v1.create_start_marker(
        successful_trace,
        QUEUE_NAME,
    )
    assert not successful_claimed

    assert not v1.has_end_marker(failed_trace, QUEUE_NAME)
    failed_claimed, _ = v1.create_start_marker(failed_trace, QUEUE_NAME)
    assert failed_claimed


def test_runtime_underscore_boundary_end_and_lock_reconcile_to_v1(tmp_path):
    trace_id = "trace_"
    queue_name = "queue"
    v2 = MPSManager(str(tmp_path), file_layout="v2")
    v2.create_end_marker(trace_id, queue_name, success=True)

    execute_report = reconcile_v2_markers(tmp_path, mode="execute")
    verify_report = reconcile_v2_markers(tmp_path, mode="verify")

    assert execute_report.status == "completed"
    assert execute_report.copied == 1
    assert execute_report.lock_files_skipped == 1
    assert verify_report.status == "verified"
    v1 = MPSManager(str(tmp_path), file_layout="v1")
    assert v1.has_end_marker(trace_id, queue_name)
    assert not v1.create_start_marker(trace_id, queue_name)[0]


def test_runtime_queue_ending_underscore_reconciles_to_v1(tmp_path):
    trace_id = "trace"
    queue_name = "queue_"
    v2 = MPSManager(str(tmp_path), file_layout="v2")
    v2.create_end_marker(trace_id, queue_name, success=True)

    execute_report = reconcile_v2_markers(tmp_path, mode="execute")
    verify_report = reconcile_v2_markers(tmp_path, mode="verify")

    assert execute_report.status == "completed"
    assert execute_report.copied == 1
    assert execute_report.lock_files_skipped == 1
    assert verify_report.status == "verified"
    v1 = MPSManager(str(tmp_path), file_layout="v1")
    assert v1.has_end_marker(trace_id, queue_name)


def test_missing_v2_source_and_invalid_timeouts_fail_safely(tmp_path):
    report = reconcile_v2_markers(tmp_path, mode="execute")

    assert report.status == "blocked"
    assert report.errors == 1
    assert not (tmp_path / "v2").exists()

    with pytest.raises(ValueError, match="finite non-negative"):
        reconcile_v2_markers(tmp_path, lease_timeout_seconds=-1)

    (tmp_path / "v2").mkdir()
    with pytest.raises(ValueError, match="observed_at must be finite"):
        reconcile_v2_markers(tmp_path, observed_at=float("nan"))
