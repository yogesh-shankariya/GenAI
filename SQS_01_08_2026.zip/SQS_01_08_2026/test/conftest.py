"""
Shared pytest configuration.

Forces fake AWS credentials for the whole test session so no test can
ever authenticate against a real AWS account, and no test may ever talk
to a real Redis (all redis-backend tests inject fakeredis). Also puts
the repo root on sys.path so `import sqs_service` works from any
invocation directory.
"""

import os
import pathlib
import sys

sys.path.insert(
    0,
    str(pathlib.Path(__file__).resolve().parents[1]),
)

os.environ["AWS_ACCESS_KEY_ID"] = "testing"
os.environ["AWS_SECRET_ACCESS_KEY"] = "testing"
os.environ["AWS_SECURITY_TOKEN"] = "testing"
os.environ["AWS_SESSION_TOKEN"] = "testing"
os.environ["AWS_DEFAULT_REGION"] = "us-east-2"
os.environ.pop("AWS_PROFILE", None)

# No test may accidentally pick up a real Redis endpoint from the shell
for _var in ("REDIS_HOST_NAME", "REDIS_PORT_NUMBER", "REDIS_AUTH_TOKEN", "REDIS_SSL"):
    os.environ.pop(_var, None)
