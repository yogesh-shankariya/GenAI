"""
Python library for reading and posting to AWS SQS queues with built-in idempotency
======================

Implements the full message processing lifecycle with idempotency guarantees

Flow:
1. Poll Message
2. Duplicate check
3. Pre-processing (create MPS_START, MDC Logging)
4. Process Message
5. Post-processing (validate, publish, MPS_END, delete)

Ordering invariant for step 5: MPS_END must be written AFTER the side
effects (publish) succeed and BEFORE the SQS delete. A crash before
MPS_END redelivers and visibly reprocesses; a crash after MPS_END but
before delete redelivers and is suppressed by the duplicate check.
Writing MPS_END only after a successful delete would reopen the
crash-between-publish-and-delete duplicate window that this library
exists to close.
"""

import json
from time import time, sleep
import threading
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Optional, Dict, List
from contextlib import contextmanager
import uuid

import boto3
from botocore.exceptions import BotoCoreError, ClientError

from .marker_store import MarkerStore, create_marker_store

import logging
logger = logging.getLogger("DocMetaLogger.SQS")

# Public API
__all__ = [
    # Main client
    "SQSClient",
    # Message Models
    "SQSMessage",
    "ProcessingResult",
    "logger",
    # MDC logging
    "MDCContext",
    "MDCMarker",
    "log_lifecycle_marker",
    # Exceptions
    "ProcessingError",
    "ValidationError",
    "ProcessingTimeoutError",
    "PublishError",
]


# ===============================================================================================
# MDC (Mapped Diagnostic Contex) Logging
# ===============================================================================================


class MDCMarker(Enum):
    """
    Lifecycle markers for observability
    """

    MESSAGE_START = "MESSAGE_START"
    MESSAGE_SUCCESS = "MESSAGE_SUCCESS"
    MESSAGE_FAILED = "MESSAGE_FAILED"
    MESSAGE_END = "MESSAGE_END"


class MDCContext:
    """
    Thread-local MDC context for structured logging.
    """

    _local = threading.local()

    @classmethod
    def set(cls, **kwargs) -> None:
        if not hasattr(cls._local, "context"):
            cls._local.context = {}

        cls._local.context.update(kwargs)

    @classmethod
    def get(cls) -> Dict[str, Any]:
        if not hasattr(cls._local, "context"):
            cls._local.context = {}

        return cls._local.context.copy()

    @classmethod
    def clear(cls) -> None:
        cls._local.context = {}

    @classmethod
    @contextmanager
    def scope(cls, **kwargs):
        """
        Context manager for scoped MDC values.
        """
        old_context = cls.get()
        cls.set(**kwargs)

        try:
            yield
        finally:
            cls._local.context = old_context


def log_lifecycle_marker(
    marker: MDCMarker,
    trace_id: str,
    queue_name: str,
    **extra,
) -> None:
    """
    Log a lifecycle marker with MDC context.
    """
    context = MDCContext.get()

    # Explicit arguments take precedence over ambient MDC context
    log_data = {
        "timestamp": time(),
        **context,
        "marker": marker.value,
        "trace_id": trace_id,
        "queue_name": queue_name,
        **extra,
    }

    logger.info(f"[{marker.value}] {json.dumps(log_data)}")


# =================================================================================================
# Message Models
# =================================================================================================


@dataclass
class SQSMessage:
    """
    Represents an SQS message with metadata.
    """

    message_id: str
    receipt_handle: str
    body: str
    trace_id: str
    queue_name: str
    attributes: Dict[str, Any] = field(default_factory=dict)
    retry_count: int = 0

    @classmethod
    def from_sqs_response(
        cls,
        msg: Dict,
        queue_name: str,
    ) -> "SQSMessage":
        """
        Parse SQS message from boto3 response.
        """
        body = msg.get("Body", "")

        # Extract trace_id from body
        try:
            body_json = json.loads(body)
            trace_id = body_json.get("trace_id") or body_json.get("traceId")

            if not trace_id and isinstance(
                body_json.get("metadata"), dict
            ):
                trace_id = body_json["metadata"].get("traceId")

        except (json.JSONDecodeError, TypeError):
            trace_id = None

        # Fallback to the trace_id message attribute set by
        # send_message_with_idempotency
        if not trace_id:
            trace_id = (
                msg.get("MessageAttributes", {})
                .get("trace_id", {})
                .get("StringValue")
            )

        # Fallback to message ID if no trace_id
        if not trace_id:
            trace_id = msg.get("MessageId", str(uuid.uuid4()))

        # Get retry count from system attributes
        attributes = msg.get("Attributes", {})
        retry_count = (
            int(attributes.get("ApproximateReceiveCount", "1")) - 1
        )

        return cls(
            message_id=msg["MessageId"],
            receipt_handle=msg["ReceiptHandle"],
            body=body,
            trace_id=trace_id,
            queue_name=queue_name,
            attributes=attributes,
            retry_count=retry_count,
        )


@dataclass
class ProcessingResult:
    """
    Result of message processing
    """

    success: bool
    output_message: Optional[str] = None
    error: Optional[str] = None
    should_retry: bool = True


# =================================================================================================
# Custom Exceptions
# =================================================================================================


class ProcessingError(Exception):
    """
    Base exception for processing errors.
    """

    def __init__(self, message: str, should_retry: bool = True):
        super().__init__(message)
        self.should_retry = should_retry


class ValidationError(ProcessingError):
    """
    Raised when message validation fails.
    """

    def __init__(self, message: str):
        super().__init__(message, should_retry=False)


class ProcessingTimeoutError(ProcessingError):
    """
    Raised when processing exceeds time.

    (Named ProcessingTimeoutError to avoid shadowing the builtin
    TimeoutError.)
    """

    pass


class PublishError(ProcessingError):
    """
    Raised when publishing to next queue fails.
    """

    pass


# =================================================================================================
# SQS client with Idempotency support
# =================================================================================================


class SQSClient:
    """
    A client for interacting with SQS queues with idempotency support.

    Args:
        queue_url (str, optional) : The url of the queue
        queue_name (str, optional) : Name of the queue
            (either queue name or url must be provided)
        region_name (str, optional): AWS region; falls back to the
            default boto3 resolution chain (env/config) when omitted
        aws_access_key_id (str, optional): AWS access key ID
        aws_secret_access_key (str, optional): AWS secret access key
        profile_name (str, optional): AWS profile name for credential file
        enable_idempotency (bool, optional): Enable idempotency features.
            Defaults to False
        mps_storage_path (str, optional): Path for MPS marker files.
            Required when enable_idempotency is True and no
            marker_store is given
        mps_timeout_seconds (float, optional): START-marker lease used
            for crashed-owner takeover. Defaults to the store's own
            default (4 hours) when omitted
        marker_store (MarkerStore, optional): An explicit idempotency
            storage backend (filesystem, in-memory, or a future
            Redis/DynamoDB adapter — see sqs_service.marker_store).
            Passing one implies enable_idempotency=True; this client
            depends only on the MarkerStore port, so backends swap
            without touching this class
        max_retries (int, optional): Max retries for publish/delete operations.
            Defaults to 2
    """

    MAX_MESSAGE_SIZE = 256 * 1024  # 256 KB (SQS default per-message limit)
    MAX_BATCH_ENTRIES = 10  # SQS limit per batch request
    MAX_BATCH_PAYLOAD_SIZE = 1024 * 1024  # SQS limit per batch request (1 MiB)
    MAX_RECEIVE_MESSAGES = 10  # SQS limit per receive request
    MAX_WAIT_TIME_SECONDS = 20  # SQS long-polling limit
    MAX_VISIBILITY_TIMEOUT = 12 * 60 * 60  # SQS limit (12 hours)

    # ClientError codes that fail identically on retry - retrying them
    # only adds latency before the inevitable failure
    NON_RETRYABLE_ERROR_CODES = frozenset({
        "AWS.SimpleQueueService.NonExistentQueue",
        "QueueDoesNotExist",
        "AccessDenied",
        "AccessDeniedException",
        "InvalidMessageContents",
        "InvalidParameterValue",
        "ReceiptHandleIsInvalid",
    })

    # ------------------------------------------------------------------
    # Constructor
    # ------------------------------------------------------------------

    def __init__(
        self,
        queue_url: Optional[str] = None,
        queue_name: Optional[str] = None,
        region_name: Optional[str] = None,
        aws_access_key_id: Optional[str] = None,
        aws_secret_access_key: Optional[str] = None,
        profile_name: Optional[str] = None,
        enable_idempotency: bool = False,
        mps_storage_path: Optional[str] = None,
        mps_timeout_seconds: Optional[float] = None,
        marker_store: Optional[MarkerStore] = None,
        max_retries: int = 2,
    ):
        if not (queue_url or queue_name):
            raise ValueError(
                "Either queue_name or queue_url should be provided"
            )

        self.queue_url = queue_url
        self.queue_name = (
            queue_name
            if queue_name
            else self._extract_queue_name(queue_url)
        )
        # Derive the region from the queue URL when not given: a
        # session that falls back to a different default region than
        # the queue's would fail every call.
        if not region_name and queue_url:
            region_name = self._region_from_queue_url(queue_url)
            if region_name:
                logger.info(
                    "Derived region %s from queue_url", region_name
                )

        self.region_name = region_name
        self.enable_idempotency = enable_idempotency
        self.max_retries = max_retries

        # Initialize boto3 SQS Client
        session_kwargs: Dict[str, Any] = {}

        if region_name:
            session_kwargs["region_name"] = region_name
        if profile_name:
            session_kwargs["profile_name"] = profile_name
        if aws_access_key_id and aws_secret_access_key:
            session_kwargs["aws_access_key_id"] = aws_access_key_id
            session_kwargs["aws_secret_access_key"] = (
                aws_secret_access_key
            )

        session = boto3.Session(**session_kwargs)
        self.client = session.client("sqs")

        # Initialize the idempotency backend. This client depends only
        # on the MarkerStore port - the concrete storage (files today,
        # Redis/DynamoDB tomorrow) is injected, never hardcoded.
        self.mps_manager: Optional[MarkerStore] = None

        if marker_store is not None:
            # An explicit backend implies idempotency is on (even if
            # enable_idempotency was passed as False) - log which
            # storage is live so ops can see the override
            self.enable_idempotency = True
            self.mps_manager = marker_store
            logger.info(
                "Idempotency enabled via injected marker store %s "
                "for queue %s",
                type(marker_store).__name__,
                self.queue_name,
            )
        elif enable_idempotency:
            if not mps_storage_path:
                raise ValueError(
                    "mps_storage_path is required when "
                    "enable_idempotency is True and no marker_store "
                    "is provided"
                )

            # The concrete backend comes from config (MPS_BACKEND env,
            # default "file") via the factory - swapping storage in
            # the future is a config change, not a code change here.
            # The START lease (mps_timeout_seconds) is passed through when
            # given; previously the configured value was logged but the
            # store always used its hardcoded 4h default.
            store_options: Dict[str, Any] = {
                "storage_path": mps_storage_path
            }
            if mps_timeout_seconds is not None:
                store_options["timeout_seconds"] = mps_timeout_seconds
            self.mps_manager = create_marker_store(**store_options)
        else:
            # Make the absence of duplicate protection visible: with
            # idempotency disabled, check_duplicates/mark_processing_*
            # silently return protection-shaped no-op values.
            logger.info(
                "Idempotency disabled for queue %s - "
                "check_duplicates/mark_processing_start/"
                "mark_processing_end are no-ops",
                self.queue_name,
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _ensure_queue_url(self):
        """
        Lookup and cache the queue URL when only the name is supplied.
        """
        if not self.queue_url:
            self.queue_url = self.get_queue_url(
                self.client,
                self.queue_name,
            )

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_queue_url(self, sqs_client, queue_name: str) -> str:
        try:
            response = sqs_client.get_queue_url(QueueName=queue_name)
            logger.info("SQS URL: %s", response["QueueUrl"])
            return response["QueueUrl"]
        except ClientError as e:
            logger.error(
                "Failed to get queue URL for %s: %s",
                queue_name,
                e,
            )
            raise

    @staticmethod
    def _extract_queue_name(queue_url: str) -> str:
        """
        Extract queue name from URL.
        """
        return queue_url.rstrip("/").split("/")[-1]

    @staticmethod
    def _region_from_queue_url(queue_url: str) -> Optional[str]:
        """
        Best-effort region extraction from an SQS queue URL host
        (sqs.<region>.amazonaws.com). Returns None for legacy or
        unrecognized hosts.
        """
        host = queue_url.split("//", 1)[-1].split("/", 1)[0]
        parts = host.split(".")

        if len(parts) >= 3 and parts[0] == "sqs":
            return parts[1]

        return None

    def send_message(
        self,
        message_body: Any,
        message_attributes: Optional[Dict[str, Any]] = None,
        delay_seconds: int = 0,
    ) -> Dict[str, Any]:
        """
        Send a message to the SQS queue.

        Raises:
            ValidationError: If the message exceeds the SQS size limit
            ClientError: If SQS rejects the request
        """
        self._ensure_queue_url()

        # Serialize body if required
        if not isinstance(message_body, str):
            message_body = json.dumps(message_body)

        formatted_attributes = (
            self._format_message_attributes(message_attributes)
            if message_attributes
            else None
        )

        # SQS counts body PLUS attributes toward the size limit
        self._validate_message_size(message_body, formatted_attributes)

        params = {
            "QueueUrl": self.queue_url,
            "MessageBody": message_body,
            "DelaySeconds": delay_seconds,
        }

        if formatted_attributes:
            params["MessageAttributes"] = formatted_attributes

        try:
            return self.client.send_message(**params)
        except ClientError as e:
            logger.error("Error sending message to SQS: %s", e)
            raise

    def send_message_batch(
        self,
        messages: List[Dict[str, Any]],
        retry_failed: bool = True,
    ) -> Dict[str, Any]:
        """
        Send multiple messages to the SQS queue.

        Messages are sent in chunks of MAX_BATCH_ENTRIES (the AWS limit
        is 10 entries per request). Entries reported as Failed by SQS
        are retried once; anything still failing is returned in the
        aggregated 'Failed' list.

        Args:
            messages: List of message dictionaries with
                'Id' (optional), 'MessageBody', and optionally
                'MessageAttributes' / 'DelaySeconds'

        Returns:
            dict: {'Successful': [...], 'Failed': [...]} aggregated
                across all chunks

        Raises:
            ValidationError: If any message exceeds the SQS size limit
            ClientError: If SQS rejects a whole request
        """
        self._ensure_queue_url()

        entries = []

        for index, msg in enumerate(messages):
            body = (
                msg["MessageBody"]
                if isinstance(msg["MessageBody"], str)
                else json.dumps(msg["MessageBody"])
            )

            entry = {
                "Id": str(msg.get("Id", index)),
                "MessageBody": body,
            }

            if "MessageAttributes" in msg:
                entry["MessageAttributes"] = (
                    self._format_message_attributes(
                        msg["MessageAttributes"]
                    )
                )

            if "DelaySeconds" in msg:
                entry["DelaySeconds"] = msg["DelaySeconds"]

            self._validate_message_size(
                body, entry.get("MessageAttributes")
            )
            entries.append(entry)

        # An explicit 'Id' colliding with another entry's Id (including
        # an index default like "1") makes SQS reject the request and
        # the aggregated results ambiguous - fail fast instead.
        ids = [e["Id"] for e in entries]

        if len(set(ids)) != len(ids):
            duplicates = sorted({i for i in ids if ids.count(i) > 1})
            raise ValidationError(
                f"Duplicate batch entry Ids: {duplicates} "
                "(explicit Ids colliding with index defaults?)"
            )

        # Chunk by the 10-entry limit AND the per-request payload
        # limit (body + attribute bytes across all entries)
        chunks: List[List[Dict[str, Any]]] = []
        current: List[Dict[str, Any]] = []
        current_size = 0

        for entry in entries:
            entry_size = self._entry_payload_size(entry)

            if current and (
                len(current) >= self.MAX_BATCH_ENTRIES
                or current_size + entry_size
                > self.MAX_BATCH_PAYLOAD_SIZE
            ):
                chunks.append(current)
                current = []
                current_size = 0

            current.append(entry)
            current_size += entry_size

        if current:
            chunks.append(current)

        successful: List[Dict[str, Any]] = []
        failed: List[Dict[str, Any]] = []

        for chunk in chunks:
            try:
                response = self.client.send_message_batch(
                    QueueUrl=self.queue_url,
                    Entries=chunk,
                )
            except ClientError as e:
                logger.error("Error sending batch to SQS: %s", e)
                raise

            successful.extend(response.get("Successful", []))
            chunk_failed = response.get("Failed", [])

            # SenderFault entries (malformed message, our bug) fail
            # identically on retry - only server-side failures are
            # worth re-sending (once).
            sender_faults = [
                f for f in chunk_failed if f.get("SenderFault")
            ]
            retryable = [
                f for f in chunk_failed if not f.get("SenderFault")
            ]

            if retryable and retry_failed:
                failed_ids = {f["Id"] for f in retryable}
                retry_entries = [
                    e for e in chunk if e["Id"] in failed_ids
                ]

                logger.info(
                    "Retrying %d failed batch entries",
                    len(retry_entries),
                )

                try:
                    retry_response = self.client.send_message_batch(
                        QueueUrl=self.queue_url,
                        Entries=retry_entries,
                    )
                    successful.extend(
                        retry_response.get("Successful", [])
                    )
                    retryable = retry_response.get("Failed", [])
                except ClientError as e:
                    logger.error("Error retrying batch to SQS: %s", e)
                    raise

            failed.extend(sender_faults + retryable)

        if failed:
            logger.error(
                "send_message_batch: %d entries failed after retry",
                len(failed),
            )

        return {"Successful": successful, "Failed": failed}

    def receive_messages(
        self,
        max_messages: int = 1,
        wait_time_seconds: int = 0,
        visibility_timeout: Optional[int] = None,
        message_attribute_names: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        """
        Receive message from SQS queue.

        max_messages is clamped to the SQS limit of 10 and
        wait_time_seconds to the long-polling limit of 20.
        """
        self._ensure_queue_url()
        request_start_time = time()

        max_messages = max(
            1, min(max_messages, self.MAX_RECEIVE_MESSAGES)
        )
        wait_time_seconds = max(
            0, min(wait_time_seconds, self.MAX_WAIT_TIME_SECONDS)
        )

        if visibility_timeout is not None:
            visibility_timeout = max(
                0, min(visibility_timeout, self.MAX_VISIBILITY_TIMEOUT)
            )

        try:
            response = self.client.receive_message(
                QueueUrl=self.queue_url,
                MaxNumberOfMessages=max_messages,
                WaitTimeSeconds=wait_time_seconds,
                VisibilityTimeout=(
                    300
                    if visibility_timeout is None
                    else visibility_timeout
                ),
                MessageAttributeNames=message_attribute_names or ["All"],
                # System attributes (ApproximateReceiveCount is used
                # for SQSMessage.retry_count)
                AttributeNames=["All"],
            )

            logger.debug(
                "SQS receive_message completed in %.3f sec",
                time() - request_start_time,
            )

            return response.get("Messages", [])

        except ClientError as e:
            logger.error("Error receiving messages from SQS: %s", e)
            raise

    def delete_msg(self, receipt_handle: str) -> None:
        """
        Delete message from a queue
        """
        self._ensure_queue_url()

        logger.debug(
            "Deleting message from queue %s with receipt_handle %s",
            self.queue_name or self.queue_url,
            receipt_handle,
        )

        self.client.delete_message(
            QueueUrl=self.queue_url,
            ReceiptHandle=receipt_handle,
        )

    def delete_msg_batch(
        self,
        receipt_handles: List[str],
    ) -> Dict[str, Any]:
        """
        Deletes multiple messages from SQS queue.

        Receipt handles are deleted in chunks of MAX_BATCH_ENTRIES
        (the AWS limit is 10 entries per request). Per-entry failures
        are aggregated and logged.

        Args:
            receipt_handles : List of receipt handles of messages to delete

        Returns:
            dict : {'Successful': [...], 'Failed': [...]} aggregated
                across all chunks

        Raises:
            ClientError: If SQS rejects a whole request
        """
        self._ensure_queue_url()

        successful: List[Dict[str, Any]] = []
        failed: List[Dict[str, Any]] = []

        for start in range(
            0, len(receipt_handles), self.MAX_BATCH_ENTRIES
        ):
            chunk = receipt_handles[start:start + self.MAX_BATCH_ENTRIES]

            # Global index as the Id so Failed/Successful entries in
            # the aggregated result map back to the caller's list
            # unambiguously across chunks
            entries = [
                {
                    "Id": str(start + i),
                    "ReceiptHandle": handle,
                }
                for i, handle in enumerate(chunk)
            ]

            try:
                response = self.client.delete_message_batch(
                    QueueUrl=self.queue_url,
                    Entries=entries,
                )
            except ClientError as e:
                logger.error(
                    "Error deleting message batch from SQS: %s", e
                )
                raise

            successful.extend(response.get("Successful", []))
            failed.extend(response.get("Failed", []))

        if failed:
            logger.error(
                "delete_msg_batch: %d entries failed - these messages "
                "will redeliver after the visibility timeout",
                len(failed),
            )

        return {"Successful": successful, "Failed": failed}

    def purge_queue(self) -> Dict[str, Any]:
        """
        Delete all messages from the queue
        """
        self._ensure_queue_url()

        try:
            response = self.client.purge_queue(QueueUrl=self.queue_url)
            return response
        except ClientError as e:
            logger.error("Error purging queue: %s", e)
            raise

    def get_queue_attributes(
        self,
        attribute_names: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """
        Get attributes of the queue.
        """
        self._ensure_queue_url()

        try:
            response = self.client.get_queue_attributes(
                QueueUrl=self.queue_url,
                AttributeNames=attribute_names or ["All"],
            )
            return response.get("Attributes", {})
        except ClientError as e:
            logger.error("Error getting queue attributes: %s", e)
            raise

    # ------------------------------------------------------------------
    # Static helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _format_message_attributes(
        attributes: Dict[str, Any],
    ) -> Dict[str, Dict[str, Any]]:
        """
        Format message attributes for the SQS API.

        Strings and numbers stay DataType='String' (matching the
        original behavior); bytes are sent as Binary attributes
        (String + BinaryValue is rejected by SQS).
        """
        formatted: Dict[str, Dict[str, Any]] = {}

        for key, value in attributes.items():
            if isinstance(value, str):
                formatted[key] = {
                    "DataType": "String",
                    "StringValue": value,
                }
            elif isinstance(value, (int, float)):
                formatted[key] = {
                    "DataType": "String",
                    "StringValue": str(value),
                }
            elif isinstance(value, bytes):
                formatted[key] = {
                    "DataType": "Binary",
                    "BinaryValue": value,
                }
            else:
                formatted[key] = {
                    "DataType": "String",
                    "StringValue": json.dumps(value),
                }

        return formatted

    # =========================================================================================
    # Idempotency Methods
    # =========================================================================================

    @staticmethod
    def _attributes_size(
        formatted_attributes: Optional[Dict[str, Dict[str, Any]]],
    ) -> int:
        """
        Byte size of formatted message attributes as SQS counts them:
        attribute name + DataType + value, all UTF-8.
        """
        if not formatted_attributes:
            return 0

        size = 0

        for name, attr in formatted_attributes.items():
            size += len(name.encode("utf-8"))
            size += len(attr.get("DataType", "").encode("utf-8"))

            if "StringValue" in attr:
                size += len(attr["StringValue"].encode("utf-8"))

            if "BinaryValue" in attr:
                value = attr["BinaryValue"]
                size += (
                    len(value)
                    if isinstance(value, (bytes, bytearray))
                    else len(str(value).encode("utf-8"))
                )

        return size

    def _entry_payload_size(self, entry: Dict[str, Any]) -> int:
        return len(
            entry["MessageBody"].encode("utf-8")
        ) + self._attributes_size(entry.get("MessageAttributes"))

    def _validate_message_size(
        self,
        message: str,
        formatted_attributes: Optional[
            Dict[str, Dict[str, Any]]
        ] = None,
    ) -> None:
        """
        Validate message size does not exceed the SQS limit.

        SQS counts the body PLUS message attributes (name + type +
        value bytes) toward the limit, so validating the body alone
        would pass messages the API then rejects.
        """
        size = len(message.encode("utf-8")) + self._attributes_size(
            formatted_attributes
        )

        if size > self.MAX_MESSAGE_SIZE:
            raise ValidationError(
                f"Message size {size} (body + attributes) exceeds "
                f"limit {self.MAX_MESSAGE_SIZE}"
            )

    def _publish_with_retry(
        self,
        message: str,
        trace_id: str,
        target_queue_url: Optional[str] = None,
    ) -> bool:
        """
        Publish message to the target queue with retries.

        Falls back to this client's own queue when no target is given.
        """
        retry_delays = [1, 3]  # seconds
        last_error = None

        self._ensure_queue_url()
        queue_url = target_queue_url or self.queue_url

        for attempt in range(self.max_retries + 1):
            try:
                self.client.send_message(
                    QueueUrl=queue_url,
                    MessageBody=message,
                    # Attribute key must match what
                    # SQSMessage.from_sqs_response reads ("trace_id");
                    # the old "TraceId" key broke the consumer-side
                    # trace_id attribute fallback.
                    MessageAttributes={
                        "trace_id": {
                            "DataType": "String",
                            "StringValue": trace_id,
                        }
                    },
                )

                logger.info(
                    f"Published message for {trace_id} "
                    f"to {queue_url}"
                )
                return True

            # BotoCoreError covers connection-level transients
            # (EndpointConnectionError, ReadTimeoutError, ...) which are
            # NOT ClientError subclasses - without this they skipped the
            # retry loop entirely and escaped unwrapped
            except (ClientError, BotoCoreError) as e:
                last_error = e
                code = (
                    e.response.get("Error", {}).get("Code", "")
                    if isinstance(e, ClientError)
                    else ""
                )

                if code in self.NON_RETRYABLE_ERROR_CODES:
                    logger.error(
                        "Publish failed with non-retryable error "
                        f"{code}: {e}"
                    )
                    break

                logger.warning(
                    f"Publish attempt {attempt + 1} failed {e}"
                )

                if attempt < self.max_retries:
                    sleep(
                        retry_delays[
                            min(attempt, len(retry_delays) - 1)
                        ]
                    )

        raise PublishError(
            f"Failed to publish after "
            f"{self.max_retries + 1} attempts: {last_error}"
        )

    def _delete_with_retry(
        self,
        receipt_handle,
    ) -> Dict[str, Any]:
        """
        Delete message from the queue with retries.

        Terminal failure behavior depends on idempotency: when it is
        ENABLED, the failure is swallowed (SQS will redeliver, but the
        MPS_END duplicate check suppresses reprocessing); when it is
        DISABLED there is no such safety net, so the last error is
        re-raised - swallowing it would silently guarantee duplicate
        processing on redelivery.
        """
        retry_delays = [1, 3]
        last_error: Optional[ClientError] = None

        self._ensure_queue_url()

        for attempt in range(self.max_retries + 1):
            try:
                response = self.client.delete_message(
                    QueueUrl=self.queue_url,
                    ReceiptHandle=receipt_handle,
                )

                logger.info("Deleted message from queue")
                return response

            except ClientError as e:
                last_error = e
                code = e.response.get("Error", {}).get("Code", "")

                if code in self.NON_RETRYABLE_ERROR_CODES:
                    logger.error(
                        "Delete failed with non-retryable error "
                        f"{code}: {e}"
                    )
                    break

                logger.warning(
                    f"Delete attempt {attempt + 1} failed: {e}"
                )

                if attempt < self.max_retries:
                    sleep(
                        retry_delays[
                            min(attempt, len(retry_delays) - 1)
                        ]
                    )

        if not self.enable_idempotency and last_error is not None:
            logger.error(
                "Failed to delete message and idempotency is "
                "disabled - redelivery WOULD be reprocessed"
            )
            raise last_error

        logger.error(
            "Failed to delete message - "
            "MPS_END will prevent reprocessing"
        )
        return {}

    def send_message_with_retry(
        self,
        message_body: Any,
        trace_id: Optional[str] = None,
    ) -> bool:
        """
        Send a message with bounded retries (max_retries attempts beyond
        the first, 1s/3s backoff; non-retryable AWS errors abort early).

        Serializes non-string bodies to JSON and attaches trace_id as a
        message attribute (generated when omitted), matching what
        SQSMessage.from_sqs_response reads on the consumer side.

        Returns True on success. Raises PublishError after exhausting
        retries and ValidationError for oversized messages, so callers
        can distinguish "sent" from "gave up".
        """
        if not isinstance(message_body, str):
            message_body = json.dumps(message_body)

        if not trace_id:
            trace_id = str(uuid.uuid4())
        # Coerce non-string trace ids (e.g. a JSON-numeric traceId from a
        # producer): botocore rejects a raw int in StringValue with
        # ParamValidationError, which is NOT a ClientError - it would skip
        # the retry loop and the PublishError contract entirely
        trace_id = str(trace_id)

        # Fail fast on oversized payloads - retrying a message SQS will
        # always reject only adds latency (size counts body + attributes,
        # including the trace_id attribute added by _publish_with_retry)
        self._validate_message_size(
            message_body,
            self._format_message_attributes({"trace_id": trace_id}),
        )

        return self._publish_with_retry(message_body, trace_id)

    def send_message_with_idempotency(
        self,
        message_body: Any,
        trace_id: Optional[str] = None,
        message_attributes: Optional[Dict[str, Any]] = None,
        delay_seconds: int = 0,
    ) -> Dict[str, Any]:
        """
        Send a message to SQS queue with Idempotency

        Args:
            message_body: The message body
                (will be JSON serialized if not a string)
            trace_id: Optional trace_id for idempotency tracking
            message_attributes: Optional message attributes
            delay_seconds: Delay before the message becomes available
                (0-900 seconds)

        Returns:
            dict: Response from SQS

        Raises:
            ValidationError: If message validation fails
        """
        # Convert message_body to string if needed
        if not isinstance(message_body, str):
            message_body = json.dumps(message_body)

        #Generate trace_id if not provided
        if not trace_id:
            trace_id = str(uuid.uuid4())

        # Add trace_id to a COPY of the attributes - mutating the
        # caller's dict would leak our trace_id into their reused
        # attribute dicts
        message_attributes = (
            dict(message_attributes) if message_attributes else {}
        )
        message_attributes["trace_id"] = trace_id

        # Log lifecycle marker for idempotency
        if self.enable_idempotency:
            log_lifecycle_marker(
                MDCMarker.MESSAGE_START,
                trace_id,
                self.queue_name,
            )

        return self.send_message(
            message_body,
            message_attributes,
            delay_seconds,
        )

    def receive_messages_as_objects(
        self,
        max_messages: int = 1,
        wait_time_seconds: int = 0,
        visibility_timeout: Optional[int] = None,
    ) -> List[SQSMessage]:
        """
        Receive messages for SQS Queue as SQSMessage objects
        """
        raw_messages = self.receive_messages(
            max_messages=max_messages,
            wait_time_seconds=wait_time_seconds,
            visibility_timeout=visibility_timeout,
            message_attribute_names=["All"],
        )

        return [
            SQSMessage.from_sqs_response(msg, self.queue_name)
            for msg in raw_messages
        ]

    @property
    def marker_store(self) -> Optional[MarkerStore]:
        """
        The idempotency storage backend (modern name for the
        historical `mps_manager` attribute; both are the same object).
        """
        return self.mps_manager

    def check_duplicates(self, trace_id: str) -> bool:
        """
        Scenario A only: True if a successful MPS_END marker exists
        (message already completed).

        This does NOT protect against concurrent duplicates - two pods
        can both see False here. You MUST also call
        mark_processing_start (which atomically claims the message)
        before processing. Returns False unconditionally when
        idempotency is disabled - i.e. no protection at all.
        """
        if not self.enable_idempotency or not self.mps_manager:
            return False

        return self.mps_manager.has_end_marker(
            trace_id,
            self.queue_name,
        )

    def mark_processing_start(
        self,
        trace_id: str,
        retry_count: int = 0,
    ) -> bool:
        """
        Atomically claim the message (create MPS_START).

        Returns False when the message could not be claimed - another
        pod/thread owns it or is mid-claim. On False: skip processing
        but do NOT delete the message; it must stay on the queue so
        redelivery/takeover can handle it if the current owner dies.
        Returns True unconditionally when idempotency is disabled.
        """
        if not self.enable_idempotency or not self.mps_manager:
            return True

        success, _ = self.mps_manager.create_start_marker(
            trace_id,
            self.queue_name,
            retry_count,
        )

        return success

    def mark_processing_end(
        self,
        trace_id: str,
        retry_count: int = 0,
        success: bool = True,
    ) -> bool:
        """
        Mark the end of message processing (write MPS_END).

        Returns False if the marker could not be written: dedup memory
        for this message is lost and a redelivery may reprocess it.
        The processing work itself already happened, so callers should
        still ack/delete the message - raising here would wrongly turn
        a completed message into a failure after its side effects
        (publish) were committed.
        """
        if not self.enable_idempotency or not self.mps_manager:
            return True

        try:
            self.mps_manager.create_end_marker(
                trace_id,
                self.queue_name,
                retry_count,
                success=success,
            )
        except OSError as e:
            logger.error(
                "Failed to write MPS_END for %s - dedup memory lost, "
                "redelivery may reprocess: %s",
                trace_id,
                e,
            )
            return False

        # Log lifecycle markers
        marker = (
            MDCMarker.MESSAGE_SUCCESS
            if success
            else MDCMarker.MESSAGE_FAILED
        )

        log_lifecycle_marker(
            marker,
            trace_id,
            self.queue_name,
        )
        log_lifecycle_marker(
            MDCMarker.MESSAGE_END,
            trace_id,
            self.queue_name,
            success=success,
        )

        return True
