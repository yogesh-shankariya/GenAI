"""
RedisMarkerStore - Redis adapter for the idempotency MarkerStore port
=====================================================================

Implements the four port guarantees (see marker_store.py) on Redis:

1. **Atomic claim**: one Lua script runs the END-check, the lease check,
   and the START write as a single atomic unit (Redis executes scripts
   serially), so at most one caller across all pods/threads gets a claim
   - and a message that COMPLETED between the caller's gate check and
   the claim is refused (the M1 race is closed natively).
2. **Lease expiry / takeover**: staleness is decided by the stored
   claim TIMESTAMP against ``timeout_seconds`` - the same strict
   semantics as ``is_start_marker_stale`` - NOT by key TTL (a TTL lease
   would break Scenario-C takeover reporting and make the lease
   untestable). Keys carry a 7-day TTL purely for garbage collection.
3. **Success-only suppression**: the END key holds ``success`` or
   ``failed``; only ``success`` suppresses, and success is sticky (a
   later failed run can never overwrite it - enforced in the script).
4. **END clears START**: the END script releases the claim - but ONLY
   if the claim is our own (owner field match). This deliberately
   diverges from the file backend's delete-all-STARTs: it is strictly
   safer (a late finisher can no longer cancel another worker's live
   claim - the M2 hazard).

Key scheme::

    mps__{<trace_id>__<queue_name>}__<len(trace_id)>__start
        -> HASH  {owner, ts, retry, token}
    mps__{<trace_id>__<queue_name>}__<len(trace_id)>__end
        -> STRING "success"|"failed"

The trailing ``len(trace_id)`` makes the scheme provably collision-free:
two different (trace_id, queue_name) pairs could otherwise share a key
via an underscore shift (trace ``a_`` + queue ``x`` vs trace ``a`` +
queue ``_x`` both concatenate to ``a___x``); with the length pinned,
equal keys force equal trace_ids and therefore equal queue_names.

The ``{...}`` braces are a Redis Cluster hash tag so both keys of one
message always land on the same slot - free today, and future-proofs a
cluster migration. To keep the tag well-formed, ``{`` and ``}`` are
rejected in ids by this adapter (a leading ``}`` would empty the tag).
NOTE: this adapter targets a cluster-mode-DISABLED endpoint
(ElastiCache primary endpoint); cluster-mode-enabled would need
redis.RedisCluster.

Failure policy: ``from_env`` pings at construction so a misconfigured
opted-in pod fails at boot, loudly. At runtime, Redis errors propagate
to the callers' documented handling (the consumer gate fails OPEN -
duplicate protection must never become an outage source). The 2-second
socket timeouts bound the blast radius of a black-holed endpoint.

Clock note: lease timestamps come from the CLAIMER pod's clock (same
design as the file backend). Pods must be NTP-synced - a fast-clocked
pod's crashed claim stays "owned" for the skew on top of the lease,
and a slow-clocked pod's live claim can be taken over early.

Config (client-provided; used only when MPS_BACKEND=redis):
    REDIS_HOST_NAME     required
    REDIS_PORT_NUMBER   default 6379
    REDIS_AUTH_TOKEN    optional secret - NEVER logged
    REDIS_SSL           default "true" (ElastiCache AUTH requires TLS)
"""

import logging
import os
import socket
import threading
import time
import uuid
from typing import Optional, Tuple

import redis as redis_lib
from redis.backoff import ExponentialBackoff
from redis.retry import Retry

from .marker_store import MarkerStore, MPSInfo, MPSType

logger = logging.getLogger("DocMetaLogger.SQS")

__all__ = ["RedisMarkerStore"]


# KEYS[1]=end_key KEYS[2]=start_key
# ARGV[1]=owner ARGV[2]=now(float) ARGV[3]=timeout_seconds
# ARGV[4]=retry_count ARGV[5]=gc_ttl_ms ARGV[6]=claim_token
#
# ARGV[6] is unique per create_start_marker CALL (not per owner):
# redis-py's automatic retry can re-run this script after a lost
# response, and without the token the replay would see its own
# just-committed claim and answer 'owned' - parking the message for
# the full lease. The token lets a replay recognize the claim it
# already committed ('claimed'), while a GENUINE second call from the
# same thread carries a fresh token and is still refused ('owned').
#
# tonumber(ts) is guarded: a corrupt (non-numeric) ts must read as
# stale-and-claimable, not crash the script - and the DEL before HSET
# replaces the broken/stale hash instead of merging into it.
_CLAIM_SCRIPT = """
local e = redis.call('GET', KEYS[1])
if e and e ~= 'failed' then
  return 'completed'
end
local tsn = tonumber(redis.call('HGET', KEYS[2], 'ts'))
if tsn and (tonumber(ARGV[2]) - tsn) <= tonumber(ARGV[3]) then
  if redis.call('HGET', KEYS[2], 'token') == ARGV[6] then
    return 'claimed'
  end
  return 'owned'
end
redis.call('DEL', KEYS[2])
redis.call('HSET', KEYS[2], 'owner', ARGV[1], 'ts', ARGV[2], 'retry', ARGV[4], 'token', ARGV[6])
redis.call('PEXPIRE', KEYS[2], ARGV[5])
return 'claimed'
"""

# KEYS[1]=end_key KEYS[2]=start_key
# ARGV[1]='success'|'failed' ARGV[2]=gc_ttl_ms ARGV[3]=owner
# Success is sticky: a plain SET for success may overwrite anything; a
# failed status is only written when no success exists. The claim is
# released only when it is OUR claim (owner match). Lua GET on a
# missing key returns false, hence `not cur`.
_END_SCRIPT = """
if ARGV[1] == 'success' then
  redis.call('SET', KEYS[1], 'success', 'PX', ARGV[2])
else
  local cur = redis.call('GET', KEYS[1])
  if (not cur) or cur == 'failed' then
    redis.call('SET', KEYS[1], 'failed', 'PX', ARGV[2])
  end
end
local owner = redis.call('HGET', KEYS[2], 'owner')
if owner and owner == ARGV[3] then
  redis.call('DEL', KEYS[2])
end
return 1
"""


class RedisMarkerStore(MarkerStore):
    """
    Redis-backed idempotency marker store.

    Args:
        client: a redis.Redis-compatible client (fakeredis.FakeRedis in
            tests). ``decode_responses=True`` is recommended; raw-bytes
            clients are tolerated (values are normalized on read).
        timeout_seconds: the START lease for crashed-owner takeover.
        gc_ttl_seconds: TTL applied to every marker key purely for
            garbage collection (replaces the file backend's cleanup
            CronJob). MUST exceed timeout_seconds (enforced): a TTL
            shorter than the lease would expire a live claim
            mid-processing and reopen it to a second worker.

    NOTE: socket timeouts on the client are load-bearing for the
    "duplicate protection must never become an outage source" policy -
    without them a black-holed endpoint hangs the consumer gate
    indefinitely (a hang cannot be caught by the fail-open handlers).
    ``from_env`` sets 2s timeouts; injected clients should too.
    """

    KEY_PREFIX = "mps"

    def __init__(
        self,
        client,
        timeout_seconds: float = 4 * 60 * 60,
        gc_ttl_seconds: float = 7 * 24 * 60 * 60,
    ):
        if gc_ttl_seconds <= timeout_seconds:
            raise ValueError(
                f"gc_ttl_seconds ({gc_ttl_seconds}) must exceed "
                f"timeout_seconds ({timeout_seconds}): a GC TTL shorter "
                "than the lease would expire a LIVE claim mid-processing "
                "and reopen the message to a second worker."
            )
        if int(gc_ttl_seconds * 1000) <= 0:
            raise ValueError(
                f"gc_ttl_seconds ({gc_ttl_seconds}) is too small - the "
                "millisecond TTL rounds to 0, which would delete markers "
                "as they are written."
            )
        self.client = client
        self.timeout_seconds = timeout_seconds
        self.gc_ttl_seconds = gc_ttl_seconds
        # register_script -> EVALSHA with automatic NOSCRIPT fallback
        # (matters after an ElastiCache failover clears the script cache)
        self._claim_script = client.register_script(_CLAIM_SCRIPT)
        self._end_script = client.register_script(_END_SCRIPT)
        self._warn_if_no_socket_timeout(client)

    @staticmethod
    def _warn_if_no_socket_timeout(client) -> None:
        # Best-effort: warn when an injected client has no socket
        # timeout (see class docstring). Introspection failures are
        # ignored - this must never block construction.
        try:
            kwargs = client.connection_pool.connection_kwargs
            has_timeout = kwargs.get("socket_timeout") is not None
        except Exception:
            return
        if not has_timeout:
            logger.warning(
                "Redis marker-store client has no socket_timeout - a "
                "black-holed endpoint would hang the consumer gate "
                "indefinitely. Set socket_timeout (from_env uses 2s)."
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _s(value):
        """Normalize a possibly-bytes Redis reply to str (None-safe)."""
        if isinstance(value, (bytes, bytearray)):
            return value.decode("utf-8")
        return value

    def _validate_key_part(
        self,
        value: str,
        field: str,
        allow_separator: bool = False,
    ) -> None:
        # The shared security boundary, plus redis-specific rules: '{'
        # and '}' would corrupt the cluster hash tag (a leading '}'
        # empties it, splitting one message's keys across slots).
        self._validate_id(value, field, allow_separator=allow_separator)
        if "{" in value or "}" in value:
            raise ValueError(
                f"{field} must not contain '{{' or '}}' "
                f"(redis cluster hash tag): {value!r}"
            )

    def _key(self, trace_id: str, queue_name: str, kind: str) -> str:
        # The trailing len(trace_id) pins where the trace ends, making
        # the key provably collision-free (see module docstring: the
        # '__' delimiter alone is ambiguous under an underscore shift
        # like trace 'a_'/queue 'x' vs trace 'a'/queue '_x').
        return (
            f"{self.KEY_PREFIX}__{{{trace_id}__{queue_name}}}"
            f"__{len(trace_id)}__{kind}"
        )

    @staticmethod
    def _owner() -> str:
        """
        Claim ownership identity, unique per host/process/thread. The
        same thread that claims a message is the one that marks its end
        (both serial loop and parallel handler), so the END script's
        owner check releases exactly our own claim.
        """
        return f"{socket.gethostname()}:{os.getpid()}:{threading.get_ident()}"

    def _gc_ttl_ms(self) -> int:
        return int(self.gc_ttl_seconds * 1000)

    # ------------------------------------------------------------------
    # The port
    # ------------------------------------------------------------------

    def create_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
    ) -> Tuple[bool, str]:
        self._validate_key_part(trace_id, "trace_id")
        self._validate_key_part(queue_name, "queue_name", allow_separator=True)

        start_key = self._key(trace_id, queue_name, "start")
        end_key = self._key(trace_id, queue_name, "end")

        outcome = self._s(
            self._claim_script(
                keys=[end_key, start_key],
                args=[
                    self._owner(),
                    repr(time.time()),  # full float precision
                    repr(float(self.timeout_seconds)),
                    int(retry_count),
                    self._gc_ttl_ms(),
                    # Per-call token: lets redis-py's automatic retry
                    # replay be recognized as OUR claim (see script)
                    uuid.uuid4().hex,
                ],
            )
        )

        if outcome == "claimed":
            logger.info("Created MPS_START (redis): %s", start_key)
            return True, start_key

        if outcome == "completed":
            logger.info(
                "MPS_END exists for %s - claim refused "
                "(message completed during the gate)",
                trace_id,
            )
            return False, end_key

        logger.info("MPS_START already exists for %s", trace_id)
        return False, start_key

    def create_end_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
        success: bool = True,
    ) -> str:
        self._validate_key_part(trace_id, "trace_id")
        self._validate_key_part(queue_name, "queue_name", allow_separator=True)

        start_key = self._key(trace_id, queue_name, "start")
        end_key = self._key(trace_id, queue_name, "end")

        self._end_script(
            keys=[end_key, start_key],
            args=[
                "success" if success else "failed",
                self._gc_ttl_ms(),
                self._owner(),
            ],
        )

        logger.info(
            "Created MPS_END (redis): %s (success=%s)", end_key, success
        )
        return end_key

    def has_end_marker(self, trace_id: str, queue_name: str) -> bool:
        self._validate_key_part(trace_id, "trace_id")
        self._validate_key_part(queue_name, "queue_name", allow_separator=True)

        value = self._s(
            self.client.get(self._key(trace_id, queue_name, "end"))
        )
        return value is not None and value != "failed"

    def get_start_marker(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Optional[MPSInfo]:
        self._validate_key_part(trace_id, "trace_id")
        self._validate_key_part(queue_name, "queue_name", allow_separator=True)

        start_key = self._key(trace_id, queue_name, "start")
        raw = self.client.hgetall(start_key)

        if not raw:
            return None

        fields = {self._s(k): self._s(v) for k, v in raw.items()}

        # A malformed hash - ts/retry missing OR non-numeric - parses
        # as timestamp 0 -> maximally stale -> claimable, which is the
        # safe reading of a broken claim (and matches the claim script,
        # whose guarded tonumber treats a corrupt ts as stale too)
        return MPSInfo(
            trace_id=trace_id,
            queue_name=queue_name,
            mps_type=MPSType.START,
            retry_count=self._parse_int(fields.get("retry")),
            timestamp=self._parse_float(fields.get("ts")),
            filepath=start_key,
        )

    @staticmethod
    def _parse_int(value) -> int:
        try:
            return int(value)
        except (TypeError, ValueError):
            return 0

    @staticmethod
    def _parse_float(value) -> float:
        try:
            return float(value)
        except (TypeError, ValueError):
            return 0.0

    def cleanup_old_markers(
        self,
        max_age_seconds: float = 7 * 24 * 60 * 60,
    ) -> int:
        # Native TTL does the garbage collection - nothing to sweep.
        logger.debug(
            "cleanup_old_markers is a no-op for the redis backend "
            "(keys carry a %ss TTL)",
            self.gc_ttl_seconds,
        )
        return 0

    # ------------------------------------------------------------------
    # Production construction
    # ------------------------------------------------------------------

    @classmethod
    def from_env(
        cls,
        timeout_seconds: Optional[float] = None,
        gc_ttl_seconds: Optional[float] = None,
    ) -> "RedisMarkerStore":
        """
        Build from the client-provided environment (REDIS_HOST_NAME,
        REDIS_PORT_NUMBER, REDIS_AUTH_TOKEN, REDIS_SSL). Fails loudly at
        construction - a misconfigured redis-opted-in pod must die at
        boot, not silently run without duplicate protection.
        """
        host = (os.environ.get("REDIS_HOST_NAME") or "").strip()
        if not host:
            raise ValueError(
                "The 'redis' marker-store backend needs REDIS_HOST_NAME. "
                "Set it in the deployment ConfigMap "
                "(client-provided Redis/ElastiCache endpoint)."
            )

        raw_port = (os.environ.get("REDIS_PORT_NUMBER") or "").strip() or "6379"
        try:
            port = int(raw_port)
        except ValueError as exc:
            raise ValueError(
                f"Invalid REDIS_PORT_NUMBER: {raw_port!r} - expected an "
                "integer. Check deployment ConfigMap."
            ) from exc

        auth_token = os.environ.get("REDIS_AUTH_TOKEN") or None

        # Strict boolean: every other config error here fails loudly,
        # and a silently-misread REDIS_SSL would downgrade transport
        # security ('1'/'yes' must NOT quietly mean plaintext).
        raw_ssl = (os.environ.get("REDIS_SSL") or "").strip().lower()
        if raw_ssl in ("", "true"):
            use_ssl = True
        elif raw_ssl == "false":
            use_ssl = False
        else:
            raise ValueError(
                f"Invalid REDIS_SSL: {raw_ssl!r} - use exactly 'true' or "
                "'false' (default is true). Check deployment ConfigMap."
            )

        if auth_token and not use_ssl:
            raise ValueError(
                "REDIS_AUTH_TOKEN is set but REDIS_SSL is false - "
                "ElastiCache AUTH requires in-transit encryption (TLS). "
                "Set REDIS_SSL=true (or remove the auth token for a "
                "non-TLS dev Redis)."
            )

        client = redis_lib.Redis(
            host=host,
            port=port,
            password=auth_token,
            ssl=use_ssl,
            decode_responses=True,
            # Bound the blast radius of a black-holed endpoint: without
            # socket timeouts every marker call can hang for minutes
            socket_connect_timeout=2,
            socket_timeout=2,
            health_check_interval=30,
            # Auto-retry is safe ONLY because both Lua scripts are
            # replay-idempotent: the claim script's per-call token
            # recognizes its own committed claim on a lost-response
            # replay, and the END script is idempotent by construction.
            retry=Retry(ExponentialBackoff(cap=0.5), 1),
            retry_on_error=[
                redis_lib.exceptions.ConnectionError,
                redis_lib.exceptions.TimeoutError,
            ],
        )

        store = cls(
            client,
            timeout_seconds=(
                timeout_seconds if timeout_seconds is not None
                else 4 * 60 * 60
            ),
            gc_ttl_seconds=(
                gc_ttl_seconds if gc_ttl_seconds is not None
                else 7 * 24 * 60 * 60
            ),
        )

        # Fail fast at pod boot if unreachable/misauthenticated
        client.ping()

        # Never log the auth token
        logger.info(
            "Redis marker store connected: host=%s port=%s ssl=%s "
            "auth=%s lease=%ss gc_ttl=%ss",
            host,
            port,
            use_ssl,
            "yes" if auth_token else "no",
            store.timeout_seconds,
            store.gc_ttl_seconds,
        )
        return store
