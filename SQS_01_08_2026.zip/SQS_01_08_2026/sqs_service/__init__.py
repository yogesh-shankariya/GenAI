"""
SQS Service Package with Storage Abstraction
============================================
Version: 1.2.0 (Reference Script Integration)

Provides SQS client functionality with pluggable storage backends for idempotency.

Basic Usage (Backward Compatible):
    from sqs_service import SQSClient
    client = SQSClient(queue_name="my-queue")

Idempotent Usage (File Backend):
    from sqs_service import SQSClient
    client = SQSClient(
        queue_name="my-queue",
        enable_idempotency=True,
        mps_storage_path="/data/mps"
    )

Pluggable Backend Usage (NEW - Storage Abstraction):
    import os
    os.environ['MPS_BACKEND'] = 'file'  # or 'memory', 'redis', 'dynamodb'

    from sqs_service import create_marker_store
    store = create_marker_store(storage_path="/data/mps")

Config-based (Backward Compatible):
    from sqs_service import get_sqs_client
    client = get_sqs_client(queue_name="my-queue")
"""

__version__ = "1.2.0"

# Try to import basic client (optional for backward compatibility)
try:
    from .sqs_service import SQSClient as BasicSQSClient
    HAS_BASIC_CLIENT = True
except ImportError:
    BasicSQSClient = None
    HAS_BASIC_CLIENT = False

# Try to import config (optional)
try:
    from .sqs_config import SQSConfig
    HAS_CONFIG = True
except ImportError:
    HAS_CONFIG = False

# Core imports - MarkerStore abstraction (NEW from reference script)
from .marker_store import (
    MarkerStore,
    InMemoryMarkerStore,
    create_marker_store,
    register_marker_store_backend,
    MPSType,
    MPSInfo,
)

# Import idempotent processor
from .sqs_idempotent_processor import (
    SQSClient,
    SQSMessage,
    ProcessingResult,
    MDCContext,
    MDCMarker,
    log_lifecycle_marker,
    ProcessingError,
    ValidationError,
    ProcessingTimeoutError,
    PublishError,
)

# Import MPS manager (file backend)
from .mps_manager import (
    MPSManager,
    FileMarkerStore,
    DuplicateCheckResult,
    check_duplicate_status,
)

# Import parallel processor
from .sqs_parallel_processor import (
    ParallelSQSProcessor,
    process_messages_parallel,
)


# Backward compatibility factory
def get_sqs_client(queue_name=None, queue_url=None, region_name="us-east-1", **kwargs):
    """
    Factory function to get SQS client based on configuration.

    Backward compatible with old main script usage.

    Args:
        queue_name: Queue name
        queue_url: Queue URL
        region_name: AWS region
        **kwargs: Additional arguments (enable_idempotency, mps_storage_path, etc.)

    Returns:
        SQSClient: Idempotent client (now with storage abstraction)
    """
    if HAS_CONFIG and SQSConfig.ENABLE_IDEMPOTENCY:
        # Use config-driven idempotency
        return SQSClient(
            queue_name=queue_name,
            queue_url=queue_url,
            region_name=region_name,
            enable_idempotency=True,
            mps_storage_path=SQSConfig.MPS_STORAGE_PATH,
            max_retries=SQSConfig.MAX_RETRIES,
            **kwargs
        )
    elif HAS_BASIC_CLIENT:
        # Use basic client if available
        return BasicSQSClient(
            queue_name=queue_name,
            queue_url=queue_url,
            region_name=region_name,
            **kwargs
        )
    else:
        # Default to idempotent client without idempotency
        return SQSClient(
            queue_name=queue_name,
            queue_url=queue_url,
            region_name=region_name,
            enable_idempotency=False,
            **kwargs
        )


# Public API
__all__ = [
    # Version
    '__version__',

    # Clients
    'SQSClient',  # Main client (idempotent)
    'get_sqs_client',  # Backward compatible factory

    # Storage Abstraction (NEW - YOUR REQUIREMENT)
    'MarkerStore',  # Abstract base class
    'InMemoryMarkerStore',  # In-memory backend
    'FileMarkerStore',  # File backend (alias for MPSManager)
    'MPSManager',  # File backend implementation
    'create_marker_store',  # Factory function
    'register_marker_store_backend',  # Backend registration

    # Parallel Processing
    'ParallelSQSProcessor',
    'process_messages_parallel',

    # Data Types
    'SQSMessage',
    'ProcessingResult',
    'MPSInfo',
    'MPSType',
    'DuplicateCheckResult',

    # Idempotency Functions
    'check_duplicate_status',

    # Logging (MDC)
    'MDCContext',
    'MDCMarker',
    'log_lifecycle_marker',

    # Exceptions
    'ProcessingError',
    'ValidationError',
    'ProcessingTimeoutError',
    'PublishError',
]

# Add optional exports if available
if HAS_BASIC_CLIENT:
    __all__.append('BasicSQSClient')
if HAS_CONFIG:
    __all__.append('SQSConfig')
