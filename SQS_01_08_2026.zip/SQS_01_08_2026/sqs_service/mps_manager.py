"""
MPS (Message Processing State) Manager
=====================================

Handles creation and querying of marker files for idempotency control.

MPS files are the source of truth for message lifecycle:
- MPS_START : Processing has begun
- MPS_END : Processing completed (success or Failure)
"""

import os
import fcntl
import glob
import threading
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple, List
from pathlib import Path

import logging
logger = logging.getLogger("DocMetaLogger.SQS")


from .marker_store import MarkerStore, MPSInfo, MPSType

# Public API (MPSInfo/MPSType are canonically defined in marker_store
# and re-exported here for backward compatibility)
__all__ = [
    "MPSManager",
    "FileMarkerStore",
    "MPSInfo",
    "DuplicateCheckResult",
    "check_duplicate_status",
    "MPSType",
]


# POSIX record locks (fcntl.lockf) do NOT conflict between fds of the
# same process, so they only give cross-POD exclusion. This registry
# provides the cross-THREAD half: one threading.Lock per lock-file
# path, shared by every MPSManager in the process.
_INTRAPROCESS_LOCKS: Dict[str, threading.Lock] = {}
_INTRAPROCESS_GUARD = threading.Lock()


def _intraprocess_lock_for(path: str) -> threading.Lock:
    with _INTRAPROCESS_GUARD:
        return _INTRAPROCESS_LOCKS.setdefault(path, threading.Lock())


class MPSManager(MarkerStore):
    """
    Manages MPS files for idempotency

    File Pattern :
    {traceId}__{queueName}__{start|end}__{retryCount}__{timestamp}

    trace_id must not contain the separator ("__"); queue names may
    (the parser rejoins the middle segments).

    These marker files enforce:
    - Duplicate suppression (skip if MPS_END exists)
    - Ownership tracking (skip if another pod owns via MPS_START)
    - Crash recovery (reprocess if MPS_START is stale)
    - Lifecycle completion (MPS_END marks done)
    """

    SEPARATOR = "__"
    LOCK_SUFFIX = "lock"

    def __init__(
        self,
        storage_path: str,
        timeout_seconds: float = 4 * 60 * 60,  # 4 hours
    ):
        # storage_path is deliberately required: the old default
        # ("/main_resources/...") disagreed with Constant.SQS_MPS_PATH
        # ("/data/main_resources/...") and silently mkdir'd a root-level
        # directory. Callers must pass the configured path explicitly.
        self.storage_path = Path(storage_path)
        self.timeout_seconds = timeout_seconds
        self._ensure_storage_exists()

    # id validation (_validate_id) is inherited from MarkerStore -
    # every backend shares the same external-input security boundary

    def _ensure_storage_exists(self) -> None:
        """
        Create storage_directory if it doesn't exists.
        """
        self.storage_path.mkdir(parents=True, exist_ok=True)

    def _build_filename(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: MPSType,
        retry_count: int,
        timestamp: Optional[float] = None,
    ) -> str:
        """
        Build MPS filename from components.
        """
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)

        ts = timestamp if timestamp is not None else time.time()

        return self.SEPARATOR.join(
            [
                trace_id,
                queue_name,
                mps_type.value,
                str(retry_count),
                str(ts),
            ]
        )

    def _parse_filename(self, filepath: str) -> Optional[MPSInfo]:
        """
        Parse MPS filename into components.

        trace_id is the first segment and type/retry/timestamp the last
        three; the middle segments are rejoined so queue names containing
        the separator still parse.
        """
        try:
            filename = os.path.basename(filepath)
            parts = filename.split(self.SEPARATOR)

            if len(parts) < 5:
                logger.info(f"Invalid MPS filename format: {filename}")
                return None

            trace_id = parts[0]
            queue_name = self.SEPARATOR.join(parts[1:-3])
            type_str, retry_str, ts_str = parts[-3:]

            return MPSInfo(
                trace_id=trace_id,
                queue_name=queue_name,
                mps_type=MPSType(type_str),
                retry_count=int(retry_str),
                timestamp=float(ts_str),
                filepath=filepath,
            )

        except (ValueError, KeyError) as e:
            logger.info(f"Failed to parse MPS filename {filepath}: {e}")
            return None

    def _get_pattern(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: Optional[MPSType] = None,
    ) -> str:
        """
        Build glob pattern for finding MPS files.

        trace_id and queue_name are glob-escaped so metacharacters
        (* ? [) in externally-supplied ids cannot match foreign
        markers or be matched by them.
        """
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)

        type_pattern = mps_type.value if mps_type else "*"

        return str(
            self.storage_path
            / self.SEPARATOR.join(
                [
                    glob.escape(trace_id),
                    glob.escape(queue_name),
                    type_pattern,
                    "*",
                ]
            )
        )

    def find_mps_files(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: Optional[MPSType] = None,
    ) -> List[MPSInfo]:
        """
        Find all MPS files matching the criteria.
        """
        pattern = self._get_pattern(trace_id, queue_name, mps_type)
        files = glob.glob(pattern)
        parsed = []

        for f in files:
            info = self._parse_filename(f)

            if info:
                parsed.append(info)

        # Sort by timestamp descending (most recent first)
        parsed.sort(key=lambda x: x.timestamp, reverse=True)

        return parsed

    def has_end_marker(self, trace_id: str, queue_name: str) -> bool:
        """
        Check if the message already completed SUCCESSFULLY.

        A failed END marker (file content "failed") does NOT suppress
        reprocessing — otherwise one failure would permanently poison
        the message, since Scenario A skips on this check. Failed END
        markers are kept purely as an audit record. Unreadable or
        legacy-empty content is treated as success (suppress) — in a
        regulated pipeline, skipping a duplicate is safer than
        double-processing one.
        """
        for info in self.find_mps_files(
            trace_id, queue_name, MPSType.END
        ):
            try:
                with open(info.filepath) as f:
                    if f.read().strip() != "failed":
                        return True
            except FileNotFoundError:
                # Marker vanished between glob and open (e.g. a cleanup
                # sweep removed an old FAILED marker) - a missing file
                # proves nothing and must NOT suppress; check the rest
                # (review M3: suppressing here silently deleted
                # unprocessed messages)
                continue
            except OSError:
                # Marker exists but can't be read - err on suppression
                return True

        return False

    def get_start_marker(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Optional[MPSInfo]:
        """
        Get the most recent MPS_START file if it exists.
        """
        files = self.find_mps_files(trace_id, queue_name, MPSType.START)
        return files[0] if files else None

    # is_start_marker_stale is inherited from MarkerStore (the lease
    # semantics are identical for every backend)

    def _lock_filepath(self, trace_id: str, queue_name: str) -> Path:
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)

        return self.storage_path / self.SEPARATOR.join(
            [trace_id, queue_name, self.LOCK_SUFFIX]
        )

    def create_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
    ) -> Tuple[bool, str]:
        """
        Atomically create MPS_START marker

        Uses a kernel-held fcntl lock on a per-message lock file so
        only one pod can create the START marker:

        1. Check if a live (non-stale) START marker already exists for
           this trace_id + queue_name; stale markers from crashed pods
           are removed so takeover can proceed
        2. Take fcntl.lockf(LOCK_EX | LOCK_NB) on the lock file; a
           held lock means another pod is mid-create - back off
        3. Re-check for a live START under the lock, then create it

        The lock is released by the kernel automatically when the fd
        closes - including on crash - so there is no lock TTL and no
        stale-lock stealing: a lock can never be removed out from
        under a live holder, and a crashed holder never wedges the
        message. The lock FILE is left in place (unlinking a lock file
        is inherently racy); cleanup_old_markers sweeps disused ones.
        Requires a POSIX filesystem; on NFS/EFS shared volumes this
        uses NFSv4 byte-range locks, which the server releases when
        the client's lease expires after a crash.
        """
        # First, check for existing START markers. Stale ones belong to
        # a crashed pod and must not block takeover.
        if self._live_start_marker_exists(trace_id, queue_name):
            marker = self.get_start_marker(trace_id, queue_name)
            return False, marker.filepath if marker else ""

        lock_filepath = self._lock_filepath(trace_id, queue_name)

        # Cross-thread exclusion first (fcntl locks never conflict
        # within one process), then cross-pod exclusion via fcntl.
        thread_lock = _intraprocess_lock_for(str(lock_filepath))

        if not thread_lock.acquire(blocking=False):
            logger.info(
                "Lock held - another thread is creating "
                f"MPS_START for {trace_id}"
            )
            return False, ""

        try:
            fd = os.open(
                str(lock_filepath),
                os.O_CREAT | os.O_WRONLY,
                0o644,
            )
        except OSError as e:
            thread_lock.release()
            logger.info(f"Failed to open lock file for {trace_id}: {e}")
            raise

        try:
            try:
                fcntl.lockf(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                logger.info(
                    "Lock held - another pod is creating "
                    f"MPS_START for {trace_id}"
                )
                return False, ""

            # Mark the lock file as recently used so
            # cleanup_old_markers won't consider it disused.
            try:
                os.utime(lock_filepath)
            except OSError:
                pass

            # Now that the lock is owned, ensure no live START marker
            # was created in the meantime
            if self._live_start_marker_exists(trace_id, queue_name):
                logger.info(
                    f"MPS_START was created by another pod for {trace_id}"
                )
                marker = self.get_start_marker(trace_id, queue_name)
                return False, marker.filepath if marker else ""

            # Completion re-check under the lock (review M1): the caller's
            # END-check ran BEFORE this claim, so a message that completed
            # in that gap (owner wrote END and removed its START) would
            # otherwise be re-claimed and fully reprocessed here.
            if self.has_end_marker(trace_id, queue_name):
                logger.info(
                    f"MPS_END exists for {trace_id} - claim refused "
                    "(message completed during the gate)"
                )
                return False, ""

            # Create the actual START marker with timestamp
            filename = self._build_filename(
                trace_id,
                queue_name,
                MPSType.START,
                retry_count,
            )
            filepath = self.storage_path / filename

            with open(filepath, "w") as f:
                f.write("")

            logger.info(f"Created MPS_START: {filename}")
            return True, str(filepath)

        finally:
            # Unlock and close; the kernel would also release the lock
            # if this pod died here. The lock file itself stays.
            try:
                fcntl.lockf(fd, fcntl.LOCK_UN)
            except OSError:
                pass
            os.close(fd)
            thread_lock.release()

    def _live_start_marker_exists(
        self,
        trace_id: str,
        queue_name: str,
    ) -> bool:
        """
        True if a non-stale START marker exists. Stale markers
        (crashed pod) are removed as a side effect so the caller
        can take over.
        """
        existing = self.find_mps_files(
            trace_id,
            queue_name,
            MPSType.START,
        )

        live = False

        for info in existing:
            if self.is_start_marker_stale(info):
                try:
                    os.remove(info.filepath)
                    logger.info(
                        f"Removed stale MPS_START for takeover: "
                        f"{info.filepath}"
                    )
                except OSError:
                    pass
            else:
                live = True

        if live:
            logger.info(f"MPS_START already exists for {trace_id}")

        return live

    def create_end_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
        success: bool = True,
    ) -> str:
        """
        Create MPS_END marker to signal processing completion.

        Args:
            trace_id: Message trace ID
            queue_name: Queue name
            retry_count: Current retry attempt
            success: Whether processing

        Returns:
            Path to created marker file
        """
        # Include success/failure indicator in a way that's querytable
        filename = self._build_filename(
            trace_id,
            queue_name,
            MPSType.END,
            retry_count,
        )
        filepath = self.storage_path / filename

        try:
            # Write status to file content. fsync before close: the
            # END marker is the durable dedup record - "MPS_END will
            # prevent reprocessing" is only true if it survives a
            # crash/power loss right after processing.
            with open(filepath, "w") as f:
                f.write("success" if success else "failed")
                f.flush()
                os.fsync(f.fileno())

            logger.info(
                f"Created MPS_END: {filename} (success={success})"
            )

        except OSError as e:
            logger.info(f"Failed to create MPS_END {filename}: {e}")
            raise

        # Processing is over either way, so remove this message's START
        # markers. Without this, a FAILED message's live START would
        # push every redelivery into Scenario B ("another pod is
        # processing") for the whole 4h lease instead of retrying.
        for info in self.find_mps_files(
            trace_id, queue_name, MPSType.START
        ):
            try:
                os.remove(info.filepath)
            except OSError:
                pass

        return str(filepath)

    def cleanup_start_markers(
        self,
        trace_id: str,
        queue_name: str,
    ) -> int:
        """
        Remove stale MPS_START markers for a message.

        Called when taking over from a crashed pod.
        """
        files = self.find_mps_files(
            trace_id,
            queue_name,
            MPSType.START,
        )
        removed = 0

        for info in files:
            if self.is_start_marker_stale(info):
                try:
                    os.remove(info.filepath)
                    logger.info(
                        f"Removed stale MPS_START: {info.filepath}"
                    )
                    removed += 1

                except OSError as e:
                    logger.info(
                        f"Failed to remove stale marker "
                        f"{info.filepath}: {e}"
                    )

        return removed

    def cleanup_old_markers(
        self,
        max_age_seconds: float = 7 * 24 * 60 * 60,
    ) -> int:
        """
        Cleanup markers older than max_age_seconds (default 7 days)

        Also sweeps lock files not used since the cutoff, but only
        when their fcntl lock can be acquired (i.e. nobody holds it).

        Run periodically to prevent storage bloat.
        """
        cutoff = time.time() - max_age_seconds
        removed = 0

        for filepath in glob.glob(str(self.storage_path / "*")):
            if filepath.endswith(self.SEPARATOR + self.LOCK_SUFFIX):
                removed += self._cleanup_lock_file(filepath, cutoff)
                continue

            info = self._parse_filename(filepath)

            if info and info.timestamp < cutoff:
                try:
                    os.remove(filepath)
                    removed += 1

                except OSError as e:
                    logger.info(
                        f"Failed to cleanup old marker {filepath}: {e}"
                    )

        logger.info(f"Cleaned up {removed} old MPS markers")
        return removed

    def _cleanup_lock_file(self, filepath: str, cutoff: float) -> int:
        """
        Remove a disused lock file: mtime older than the cutoff AND its
        fcntl lock is free (create_start_marker touches mtime on every
        acquisition, so a recently-used lock is never eligible).
        """
        try:
            if os.path.getmtime(filepath) >= cutoff:
                return 0
        except OSError:
            return 0

        thread_lock = _intraprocess_lock_for(filepath)

        if not thread_lock.acquire(blocking=False):
            return 0  # held by a thread in this process - leave it

        try:
            try:
                fd = os.open(filepath, os.O_WRONLY)
            except OSError:
                return 0

            try:
                try:
                    fcntl.lockf(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except OSError:
                    return 0  # held by another pod - leave it

                try:
                    os.remove(filepath)
                    return 1
                except OSError:
                    return 0

            finally:
                try:
                    fcntl.lockf(fd, fcntl.LOCK_UN)
                except OSError:
                    pass
                os.close(fd)

        finally:
            thread_lock.release()


@dataclass
class DuplicateCheckResult:
    """
    Result of duplicate check operation
    """

    should_process: bool
    reason: str
    existing_marker: Optional[MPSInfo] = None
    is_takeover: bool = False  # True id pod crashed and taking over


def check_duplicate_status(
    mps_manager: MarkerStore,
    trace_id: str,
    queue_name: str,
) -> DuplicateCheckResult:
    """
    Perform duplicate check per stage 2 of the flow.

    Scenarios:
    A. Successful MPS_END exists -> skip (already completed; a FAILED
       END marker does not suppress - see has_end_marker)
    B. MPS_START exists within timeout -> skip (another pod owns it)
    C. MPS_START exists but stale -> Reprocess (takeover from crashed pod)
    D. No markers -> Process (new message)
    """
    # Scenario A: Check for successful completion marker
    if mps_manager.has_end_marker(trace_id, queue_name):
        return DuplicateCheckResult(
            should_process=False,
            reason="MPS_END exists - message already completed",
        )

    # Check for start marker
    start_marker = mps_manager.get_start_marker(trace_id, queue_name)

    if start_marker:
        # Scenario B: Another pod is actively processing
        if not mps_manager.is_start_marker_stale(start_marker):
            return DuplicateCheckResult(
                should_process=False,
                reason=(
                    "MPS_START exists within timeout - "
                    "another pod is processing"
                ),
                existing_marker=start_marker,
            )

        # Scenario C: Stale marker - previous pod likely crashed
        return DuplicateCheckResult(
            should_process=True,
            reason=(
                "MPS_START is stale - taking over from crashed pod"
            ),
            existing_marker=start_marker,
            is_takeover=True,
        )

    # Scenario D: No markers - new message
    return DuplicateCheckResult(
        should_process=True,
        reason="No MPS markers - new message",
    )


# The modern, backend-neutral name for the filesystem adapter.
# MPSManager is the historical name; both refer to the same class.
FileMarkerStore = MPSManager
