"""EFS-backed message-processing-state markers.

The v2 file layout keeps the historical marker basenames but places every
message in a deterministic SHA-256 directory.  Runtime searches therefore
enumerate only one message's few files instead of the entire EFS directory.
"""

from __future__ import annotations

import errno
import fcntl
import glob
import json
import logging
import math
import os
import socket
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from .marker_paths import sharded_message_directory
from .marker_store import MPSInfo, MPSType, MarkerStore


logger = logging.getLogger("DocMetaLogger.SQS")

_SLOW_MARKER_OPERATION_SECONDS = 1.0
_PROCESS_INSTANCE_ID = uuid.uuid4().hex


def _record_elapsed(
    timings: Dict[str, float],
    operation: str,
    started_at: float,
) -> None:
    timings[operation] = time.perf_counter() - started_at


def _warn_if_slow_claim(
    trace_id: str,
    total_elapsed: float,
    timings: Dict[str, float],
) -> None:
    if total_elapsed < _SLOW_MARKER_OPERATION_SECONDS:
        return

    stage_summary = " ".join(
        f"{name}={elapsed:.3f}s" for name, elapsed in timings.items()
    )
    try:
        logger.warning(
            "Slow MPS START claim: trace_id=%s mode=locked "
            "total_seconds=%.3f stages=[%s]",
            trace_id,
            total_elapsed,
            stage_summary,
        )
    except Exception:
        # Diagnostics must never alter marker semantics.
        pass


@dataclass
class _ProcessLockEntry:
    lock: threading.Lock
    references: int = 0


# POSIX record locks do not conflict between file descriptors in one process.
# This process-wide registry provides the cross-thread half.  Entries are
# reference-counted so a long-running pod does not retain one Python lock per
# message forever.
_INTRAPROCESS_LOCKS: Dict[str, _ProcessLockEntry] = {}
_INTRAPROCESS_GUARD = threading.Lock()


def _retain_intraprocess_lock(path: str) -> _ProcessLockEntry:
    with _INTRAPROCESS_GUARD:
        entry = _INTRAPROCESS_LOCKS.get(path)
        if entry is None:
            entry = _ProcessLockEntry(threading.Lock())
            _INTRAPROCESS_LOCKS[path] = entry
        entry.references += 1
        return entry


def _release_intraprocess_lock(
    path: str,
    entry: _ProcessLockEntry,
) -> None:
    with _INTRAPROCESS_GUARD:
        current = _INTRAPROCESS_LOCKS.get(path)
        if current is not entry:
            raise RuntimeError("MPS in-process lock registry corruption")
        entry.references -= 1
        if entry.references == 0:
            del _INTRAPROCESS_LOCKS[path]


@dataclass
class _HeldMessageLock:
    path: str
    entry: _ProcessLockEntry
    fd: int


@dataclass(frozen=True)
class _ClaimHandle:
    filepath: str
    owner_id: str
    claim_token: str


_START_CLEANED = "cleaned"
_START_FOREIGN = "foreign"
_START_RETRYABLE_ERROR = "retryable_error"


class MPSManager(MarkerStore):
    """Filesystem implementation of the idempotency marker contract.

    Marker basename (unchanged)::

        {traceId}__{queueName}__{start|end}__{retryCount}__{timestamp}

    ``file_layout="v1"`` reads the legacy flat root.  ``file_layout="v2"``
    reads only ``v2/aa/bb/<digest>/`` for the requested message.  There is no
    runtime fallback between layouts; cutover uses the offline migrator.
    """

    SEPARATOR = "__"
    LOCK_SUFFIX = "lock"
    SUPPORTED_FILE_LAYOUTS = frozenset({"v1", "v2"})

    def __init__(
        self,
        storage_path: str,
        timeout_seconds: float = 4 * 60 * 60,
        file_layout: str = "v1",
    ):
        # Canonicalize once so equivalent spellings/symlinks of the same EFS
        # mount share the same process-local mutex registry key.
        self.storage_path = Path(storage_path).expanduser().resolve()
        self.timeout_seconds = timeout_seconds
        normalized_layout = str(file_layout).strip().lower()
        if normalized_layout not in self.SUPPORTED_FILE_LAYOUTS:
            raise ValueError(
                f"Unsupported MPS file layout {file_layout!r}; expected "
                f"one of {sorted(self.SUPPORTED_FILE_LAYOUTS)}"
            )
        self.file_layout = normalized_layout
        self.layout_path = (
            self.storage_path / "v2"
            if self.file_layout == "v2"
            else self.storage_path
        )
        self._claim_context = threading.local()
        self._ensure_storage_exists()

    def _ensure_storage_exists(self) -> None:
        # Only the configured root is created at startup.  v2 message/shard
        # directories are lazy, so read misses do not mutate EFS.
        self.storage_path.mkdir(parents=True, exist_ok=True)

    def _message_directory(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Path:
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)
        if self.file_layout == "v2":
            return sharded_message_directory(
                self.storage_path,
                trace_id,
                queue_name,
            )
        return self.storage_path

    def _ensure_message_directory(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Path:
        directory = self._message_directory(trace_id, queue_name)
        directory.mkdir(parents=True, exist_ok=True)
        return directory

    def _build_filename(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: MPSType,
        retry_count: int,
        timestamp: Optional[float] = None,
    ) -> str:
        self._validate_id(trace_id, "trace_id")
        self._validate_id(queue_name, "queue_name", allow_separator=True)
        marker_timestamp = time.time() if timestamp is None else timestamp
        return self.SEPARATOR.join(
            (
                trace_id,
                queue_name,
                mps_type.value,
                str(retry_count),
                str(marker_timestamp),
            )
        )

    def _parse_filename(
        self,
        filepath: str,
        *,
        expected_trace_id: Optional[str] = None,
        expected_queue_name: Optional[str] = None,
    ) -> Optional[MPSInfo]:
        try:
            filename = os.path.basename(filepath)
            if expected_trace_id is not None or expected_queue_name is not None:
                if expected_trace_id is None or expected_queue_name is None:
                    raise ValueError("both expected marker identities are required")
                prefix = self.SEPARATOR.join(
                    (expected_trace_id, expected_queue_name, "")
                )
                if not filename.startswith(prefix):
                    return None
                suffix_parts = filename[len(prefix):].split(self.SEPARATOR)
                if len(suffix_parts) != 3:
                    return None
                trace_id = expected_trace_id
                queue_name = expected_queue_name
                type_text, retry_text, timestamp_text = suffix_parts
            else:
                parts = filename.split(self.SEPARATOR)
                if len(parts) < 5:
                    return None
                trace_id = parts[0]
                queue_name = self.SEPARATOR.join(parts[1:-3])
                type_text, retry_text, timestamp_text = parts[-3:]

            marker_timestamp = float(timestamp_text)
            if not math.isfinite(marker_timestamp):
                return None
            return MPSInfo(
                trace_id=trace_id,
                queue_name=queue_name,
                mps_type=MPSType(type_text),
                retry_count=int(retry_text),
                timestamp=marker_timestamp,
                filepath=filepath,
            )
        except (ValueError, KeyError):
            return None

    def _get_pattern(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: Optional[MPSType] = None,
    ) -> str:
        directory = self._message_directory(trace_id, queue_name)
        type_pattern = mps_type.value if mps_type else "*"
        basename_pattern = self.SEPARATOR.join(
            (
                glob.escape(trace_id),
                glob.escape(queue_name),
                type_pattern,
                "*",
            )
        )
        return str(directory / basename_pattern)

    def find_mps_files(
        self,
        trace_id: str,
        queue_name: str,
        mps_type: Optional[MPSType] = None,
    ) -> List[MPSInfo]:
        """Find markers by scanning only this message's directory in v2."""

        parsed: List[MPSInfo] = []
        for filepath in glob.glob(
            self._get_pattern(trace_id, queue_name, mps_type)
        ):
            info = self._parse_filename(
                filepath,
                expected_trace_id=trace_id,
                expected_queue_name=queue_name,
            )
            # Treat the digest directory as an index, not as authority.  An
            # unexpected/corrupt file must never affect another identity.
            if (
                info is not None
                and info.trace_id == trace_id
                and info.queue_name == queue_name
                and (mps_type is None or info.mps_type == mps_type)
            ):
                parsed.append(info)

        parsed.sort(key=lambda item: item.timestamp, reverse=True)
        return parsed

    def has_end_marker(self, trace_id: str, queue_name: str) -> bool:
        """Return True when any readable END is successful/legacy-empty."""

        for info in self.find_mps_files(trace_id, queue_name, MPSType.END):
            try:
                with open(info.filepath, encoding="utf-8") as marker_file:
                    if marker_file.read().strip() != "failed":
                        return True
            except FileNotFoundError:
                continue
            except OSError:
                # Existing but unreadable completion is suppressed.  In an
                # idempotent pipeline, avoiding duplicate side effects is the
                # safer direction.
                return True
        return False

    def get_start_marker(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Optional[MPSInfo]:
        files = self.find_mps_files(trace_id, queue_name, MPSType.START)
        return files[0] if files else None

    def _lock_filepath(self, trace_id: str, queue_name: str) -> Path:
        directory = self._message_directory(trace_id, queue_name)
        basename = self.SEPARATOR.join(
            (trace_id, queue_name, self.LOCK_SUFFIX)
        )
        return directory / basename

    def _acquire_message_lock(
        self,
        trace_id: str,
        queue_name: str,
        *,
        blocking: bool,
        timings: Optional[Dict[str, float]] = None,
    ) -> Optional[_HeldMessageLock]:
        """Acquire the per-message thread lock followed by the EFS lock."""

        timings = timings if timings is not None else {}
        directory_started_at = time.perf_counter()
        try:
            self._ensure_message_directory(trace_id, queue_name)
        finally:
            _record_elapsed(
                timings,
                "message_directory_create",
                directory_started_at,
            )

        lock_path = str(self._lock_filepath(trace_id, queue_name))
        entry = _retain_intraprocess_lock(lock_path)
        thread_started_at = time.perf_counter()
        try:
            acquired = entry.lock.acquire(blocking=blocking)
        finally:
            _record_elapsed(
                timings,
                "thread_lock_acquire",
                thread_started_at,
            )

        if not acquired:
            _release_intraprocess_lock(lock_path, entry)
            return None

        open_started_at = time.perf_counter()
        try:
            try:
                fd = os.open(
                    lock_path,
                    os.O_CREAT | os.O_RDWR,
                    0o644,
                )
            finally:
                _record_elapsed(
                    timings,
                    "lock_file_open",
                    open_started_at,
                )
        except BaseException:
            entry.lock.release()
            _release_intraprocess_lock(lock_path, entry)
            raise

        kernel_started_at = time.perf_counter()
        try:
            operation = fcntl.LOCK_EX
            if not blocking:
                operation |= fcntl.LOCK_NB
            try:
                fcntl.lockf(fd, operation)
            finally:
                _record_elapsed(
                    timings,
                    "kernel_lock_acquire",
                    kernel_started_at,
                )
        except OSError as exc:
            os.close(fd)
            entry.lock.release()
            _release_intraprocess_lock(lock_path, entry)
            if not blocking and exc.errno in (errno.EACCES, errno.EAGAIN):
                return None
            raise
        except BaseException:
            os.close(fd)
            entry.lock.release()
            _release_intraprocess_lock(lock_path, entry)
            raise

        try:
            os.utime(lock_path)
        except OSError:
            # mtime is diagnostic only.  Lock files are never unlinked while
            # consumers can run because replacing their inode splits locks.
            pass

        return _HeldMessageLock(lock_path, entry, fd)

    def _release_message_lock(
        self,
        held: _HeldMessageLock,
        timings: Optional[Dict[str, float]] = None,
    ) -> None:
        timings = timings if timings is not None else {}
        unlock_started_at = time.perf_counter()
        try:
            try:
                fcntl.lockf(held.fd, fcntl.LOCK_UN)
            except OSError:
                pass
        finally:
            _record_elapsed(
                timings,
                "kernel_lock_release",
                unlock_started_at,
            )
            close_started_at = time.perf_counter()
            try:
                os.close(held.fd)
            finally:
                _record_elapsed(
                    timings,
                    "lock_file_close",
                    close_started_at,
                )
                held.entry.lock.release()
                _release_intraprocess_lock(held.path, held.entry)

    def _latest_live_start(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Optional[MPSInfo]:
        for info in self.find_mps_files(
            trace_id,
            queue_name,
            MPSType.START,
        ):
            if not self.is_start_marker_stale(info):
                return info
        return None

    def _clean_stale_starts_locked(
        self,
        trace_id: str,
        queue_name: str,
    ) -> Tuple[int, Optional[MPSInfo]]:
        """Remove stale leases and return one live lease under the lock."""

        removed = 0
        live: Optional[MPSInfo] = None
        for info in self.find_mps_files(
            trace_id,
            queue_name,
            MPSType.START,
        ):
            if not self.is_start_marker_stale(info):
                if live is None:
                    live = info
                continue
            try:
                os.remove(info.filepath)
                removed += 1
                logger.info(
                    "Removed stale MPS_START for takeover: %s",
                    info.filepath,
                )
            except FileNotFoundError:
                continue
        return removed, live

    def _claim_handles(self) -> Dict[Tuple[str, str], _ClaimHandle]:
        handles = getattr(self._claim_context, "handles", None)
        if handles is None:
            handles = {}
            self._claim_context.handles = handles
        return handles

    def abandon_local_claim(
        self,
        trace_id: str,
        queue_name: str,
    ) -> None:
        """Drop only this thread's local handle; keep the EFS START lease."""

        self._claim_handles().pop((trace_id, queue_name), None)

    @staticmethod
    def _owner_id() -> str:
        return ":".join(
            (
                socket.gethostname(),
                str(os.getpid()),
                _PROCESS_INSTANCE_ID,
                str(threading.get_ident()),
            )
        )

    @staticmethod
    def _fsync_directory(directory: Path) -> None:
        try:
            directory_fd = os.open(str(directory), os.O_RDONLY)
        except OSError:
            return
        try:
            try:
                os.fsync(directory_fd)
            except OSError:
                # Some platforms/filesystems do not support directory fsync.
                pass
        finally:
            os.close(directory_fd)

    def _atomic_write_text(
        self,
        filepath: Path,
        content: str,
        *,
        replace_existing: bool = True,
    ) -> None:
        filepath.parent.mkdir(parents=True, exist_ok=True)
        temporary = filepath.parent / (
            f".{filepath.name}.mps-write.{os.getpid()}."
            f"{threading.get_ident()}.{uuid.uuid4().hex}.tmp"
        )
        fd: Optional[int] = None
        try:
            fd = os.open(
                str(temporary),
                os.O_CREAT | os.O_EXCL | os.O_WRONLY,
                0o644,
            )
            with os.fdopen(fd, "w", encoding="utf-8") as marker_file:
                fd = None
                marker_file.write(content)
                marker_file.flush()
                os.fsync(marker_file.fileno())
            if replace_existing:
                os.replace(temporary, filepath)
            else:
                # Atomic no-overwrite publication.  A hard link either wins
                # or reports that another completion already used this exact
                # timestamped basename; it never replaces a sticky SUCCESS.
                os.link(temporary, filepath, follow_symlinks=False)
                temporary.unlink()
            self._fsync_directory(filepath.parent)
        finally:
            if fd is not None:
                os.close(fd)
            try:
                temporary.unlink()
            except FileNotFoundError:
                pass

    def create_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
    ) -> Tuple[bool, str]:
        """Atomically claim one message across threads, processes and pods."""

        claim_started_at = time.perf_counter()
        timings: Dict[str, float] = {}
        try:
            result = self._create_start_marker(
                trace_id,
                queue_name,
                retry_count,
                timings,
            )
        finally:
            _warn_if_slow_claim(
                trace_id,
                time.perf_counter() - claim_started_at,
                timings,
            )

        if result[0]:
            logger.info("Created MPS_START: %s", os.path.basename(result[1]))
        return result

    def _create_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int,
        timings: Dict[str, float],
    ) -> Tuple[bool, str]:
        # The fast check is read-only.  Stale lease removal is a state
        # transition and therefore happens only after both locks are held.
        initial_started_at = time.perf_counter()
        try:
            existing = self._latest_live_start(trace_id, queue_name)
        finally:
            _record_elapsed(timings, "initial_start_scan", initial_started_at)
        if existing is not None:
            return False, existing.filepath

        held = self._acquire_message_lock(
            trace_id,
            queue_name,
            blocking=False,
            timings=timings,
        )
        if held is None:
            logger.info("MPS claim lock is held for %s", trace_id)
            return False, ""

        try:
            locked_start_started_at = time.perf_counter()
            try:
                _, existing = self._clean_stale_starts_locked(
                    trace_id,
                    queue_name,
                )
            finally:
                _record_elapsed(
                    timings,
                    "locked_start_scan",
                    locked_start_started_at,
                )
            if existing is not None:
                return False, existing.filepath

            locked_end_started_at = time.perf_counter()
            try:
                completed = self.has_end_marker(trace_id, queue_name)
            finally:
                _record_elapsed(
                    timings,
                    "locked_completion_scan",
                    locked_end_started_at,
                )
            if completed:
                logger.info(
                    "MPS_END exists for %s - claim refused",
                    trace_id,
                )
                return False, ""

            return self._write_start_marker(
                trace_id,
                queue_name,
                retry_count,
                timings,
            )
        finally:
            self._release_message_lock(held, timings)

    def _write_start_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int,
        timings: Dict[str, float],
    ) -> Tuple[bool, str]:
        started_at = time.time()
        filename = self._build_filename(
            trace_id,
            queue_name,
            MPSType.START,
            retry_count,
            timestamp=started_at,
        )
        filepath = self._message_directory(trace_id, queue_name) / filename
        owner_id = self._owner_id()
        claim_token = uuid.uuid4().hex
        payload = json.dumps(
            {
                "schema_version": 2,
                "trace_id": trace_id,
                "queue_name": queue_name,
                "retry_count": retry_count,
                "started_at": started_at,
                "owner_id": owner_id,
                "claim_token": claim_token,
            },
            sort_keys=True,
            separators=(",", ":"),
        )

        write_started_at = time.perf_counter()
        try:
            self._atomic_write_text(filepath, payload)
        finally:
            _record_elapsed(
                timings,
                "start_marker_write",
                write_started_at,
            )

        self._claim_handles()[(trace_id, queue_name)] = _ClaimHandle(
            filepath=str(filepath),
            owner_id=owner_id,
            claim_token=claim_token,
        )
        return True, str(filepath)

    def _remove_owned_start_locked(
        self,
        trace_id: str,
        queue_name: str,
        handle: _ClaimHandle,
    ) -> str:
        filepath = Path(handle.filepath)
        expected_directory = self._message_directory(trace_id, queue_name)
        if filepath.parent != expected_directory:
            logger.error(
                "Refusing START cleanup outside message directory: %s",
                filepath,
            )
            return _START_FOREIGN

        try:
            with filepath.open(encoding="utf-8") as marker_file:
                payload = json.load(marker_file)
        except FileNotFoundError:
            return _START_CLEANED
        except (OSError, ValueError, TypeError):
            logger.warning(
                "Refusing to remove unreadable START ownership record: %s",
                filepath,
            )
            return _START_RETRYABLE_ERROR

        if not isinstance(payload, dict):
            logger.warning(
                "Refusing to remove non-object START ownership record: %s",
                filepath,
            )
            return _START_RETRYABLE_ERROR

        if (
            payload.get("schema_version") != 2
            or payload.get("trace_id") != trace_id
            or payload.get("queue_name") != queue_name
            or payload.get("owner_id") != handle.owner_id
            or payload.get("claim_token") != handle.claim_token
        ):
            logger.warning(
                "START ownership changed; leaving newer claim in place: %s",
                filepath,
            )
            return _START_FOREIGN

        try:
            filepath.unlink()
        except FileNotFoundError:
            pass
        return _START_CLEANED

    def create_end_marker(
        self,
        trace_id: str,
        queue_name: str,
        retry_count: int = 0,
        success: bool = True,
    ) -> str:
        """Durably complete processing and clear only the caller's claim."""

        held = self._acquire_message_lock(
            trace_id,
            queue_name,
            blocking=True,
        )
        if held is None:  # blocking acquisition cannot return contention
            raise RuntimeError("failed to acquire blocking MPS completion lock")

        key = (trace_id, queue_name)
        handles = self._claim_handles()
        handle = handles.get(key)
        try:
            completed_at = time.time()
            directory = self._message_directory(trace_id, queue_name)
            # Although time.time() collisions are rare, overwriting an older
            # successful END with a failed END breaks sticky suppression.
            # Retry with the next representable float until a unique audit
            # basename is published.
            while True:
                filename = self._build_filename(
                    trace_id,
                    queue_name,
                    MPSType.END,
                    retry_count,
                    timestamp=completed_at,
                )
                filepath = directory / filename
                try:
                    self._atomic_write_text(
                        filepath,
                        "success" if success else "failed",
                        replace_existing=False,
                    )
                    break
                except FileExistsError:
                    completed_at = math.nextafter(completed_at, math.inf)
            logger.info(
                "Created MPS_END: %s (success=%s)",
                filename,
                success,
            )

            if handle is None:
                # Direct completion is supported, but must never clear a
                # claim made by a different worker.
                logger.warning(
                    "MPS_END has no local START ownership handle for %s; "
                    "leaving any START marker unchanged",
                    trace_id,
                )
            else:
                cleanup_outcome = self._remove_owned_start_locked(
                    trace_id,
                    queue_name,
                    handle,
                )
                if cleanup_outcome != _START_RETRYABLE_ERROR:
                    handles.pop(key, None)
                else:
                    # The END is already durable, but retain the token so an
                    # explicit retry can clear this worker's failed START.
                    logger.error(
                        "MPS_END was written but owned START cleanup needs "
                        "retry for %s",
                        trace_id,
                    )
            return str(filepath)
        finally:
            self._release_message_lock(held)

    def cleanup_start_markers(
        self,
        trace_id: str,
        queue_name: str,
    ) -> int:
        held = self._acquire_message_lock(
            trace_id,
            queue_name,
            blocking=True,
        )
        if held is None:
            return 0
        try:
            removed, _ = self._clean_stale_starts_locked(
                trace_id,
                queue_name,
            )
            return removed
        finally:
            self._release_message_lock(held)

    def cleanup_old_markers(
        self,
        max_age_seconds: float = 7 * 24 * 60 * 60,
    ) -> int:
        """Remove aged marker records, never deterministic lock files.

        v2 traversal is maintenance-only and recursive.  No runtime lookup
        invokes it.  Lock files stay in place because unlinking one can split
        two pods across old/new inodes and defeat mutual exclusion.
        """

        cutoff = time.time() - max_age_seconds
        removed = 0
        root = self.layout_path
        if not root.exists():
            return 0

        stale_start_keys = set()
        if self.file_layout == "v1":
            # Never descend into root/v2: a legacy cleanup process must not
            # delete migrated/sharded records during cutover or rollback.
            with os.scandir(root) as entries:
                paths = [
                    Path(entry.path)
                    for entry in entries
                    if entry.is_file(follow_symlinks=False)
                ]
        else:
            paths = [
                Path(directory) / filename
                for directory, _, filenames in os.walk(root)
                for filename in filenames
            ]

        for path in paths:
            filename = path.name
            filepath = str(path)
            if filename.endswith(self.SEPARATOR + self.LOCK_SUFFIX):
                continue
            info = self._parse_filename(filepath)
            if info is None or info.timestamp >= cutoff:
                continue
            if info.mps_type == MPSType.START:
                stale_start_keys.add((info.trace_id, info.queue_name))
                continue
            try:
                os.remove(filepath)
                removed += 1
            except FileNotFoundError:
                continue
            except OSError as exc:
                logger.info(
                    "Failed to cleanup old marker %s: %s",
                    filepath,
                    exc,
                )

        for trace_id, queue_name in stale_start_keys:
            removed += self.cleanup_start_markers(trace_id, queue_name)

        logger.info("Cleaned up %s old MPS markers", removed)
        return removed


@dataclass
class DuplicateCheckResult:
    should_process: bool
    reason: str
    existing_marker: Optional[MPSInfo] = None
    is_takeover: bool = False


def check_duplicate_status(
    mps_manager: MarkerStore,
    trace_id: str,
    queue_name: str,
) -> DuplicateCheckResult:
    """Evaluate the four idempotency-gate scenarios."""

    if mps_manager.has_end_marker(trace_id, queue_name):
        return DuplicateCheckResult(
            should_process=False,
            reason="MPS_END exists - message already completed",
        )

    start_marker = mps_manager.get_start_marker(trace_id, queue_name)
    if start_marker:
        if not mps_manager.is_start_marker_stale(start_marker):
            return DuplicateCheckResult(
                should_process=False,
                reason=(
                    "MPS_START exists within timeout - another pod is "
                    "processing"
                ),
                existing_marker=start_marker,
            )
        return DuplicateCheckResult(
            should_process=True,
            reason="MPS_START is stale - taking over from crashed pod",
            existing_marker=start_marker,
            is_takeover=True,
        )

    return DuplicateCheckResult(
        should_process=True,
        reason="No MPS markers - new message",
    )


FileMarkerStore = MPSManager

__all__ = [
    "MPSManager",
    "FileMarkerStore",
    "MPSInfo",
    "DuplicateCheckResult",
    "check_duplicate_status",
    "MPSType",
]
