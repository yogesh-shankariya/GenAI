"""Deterministic EFS paths for the sharded MPS file layout.

The digest contract in this module is shared by the runtime marker store and
the offline v1-to-v2 migration command.  Changing it would make migrated
markers invisible to consumers, so keep the framing and field order stable.
"""

from __future__ import annotations

import hashlib
from pathlib import Path


_IDENTITY_PREFIX = b"MPS2\0"


def _length_prefixed(value: str) -> bytes:
    encoded = value.encode("utf-8")
    if len(encoded) > 0xFFFFFFFF:
        raise ValueError("marker identity field is too large")
    return len(encoded).to_bytes(4, "big") + encoded


def marker_identity_digest(trace_id: str, queue_name: str) -> str:
    """Return the stable SHA-256 identity for one queue/message pair.

    Length-prefixing makes boundaries unambiguous even when queue names
    contain ``__`` or either identity contains glob metacharacters.
    """

    if not isinstance(trace_id, str) or not isinstance(queue_name, str):
        raise TypeError("trace_id and queue_name must be strings")

    framed = (
        _IDENTITY_PREFIX
        + _length_prefixed(queue_name)
        + _length_prefixed(trace_id)
    )
    return hashlib.sha256(framed).hexdigest()


def sharded_message_directory(
    storage_path: str | Path,
    trace_id: str,
    queue_name: str,
) -> Path:
    """Return ``<root>/v2/aa/bb/<digest>`` without creating it."""

    digest = marker_identity_digest(trace_id, queue_name)
    return Path(storage_path) / "v2" / digest[:2] / digest[2:4] / digest


__all__ = ["marker_identity_digest", "sharded_message_directory"]
