#!/usr/bin/env python3
"""Safely copy legacy flat MPS END markers into the sharded v2 layout.

This command is intentionally conservative:

* dry-run is the default;
* source files are never renamed, modified, or deleted;
* only END markers are copied (START markers are leases, not history);
* a non-stale START, malformed source entry, or content conflict blocks an
  execute run before any marker is copied;
* destination publication is atomic and never overwrites an existing file;
* rerunning the command is safe because byte-identical destinations are
  reported as already present.

The command is designed for a coordinated cutover after SQS polling has been
stopped and all workers have drained.  Run dry-run in advance to inventory
problems, then use execute and verify during the drained cutover.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import shutil
import stat
import sys
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Iterable, Optional, Sequence


# ``python scripts/migrate_mps_v1_to_v2.py`` puts ``scripts/`` rather than
# the repository root on sys.path.  Add the root so the migration always uses
# the exact same path contract as the production marker store.
REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from sqs_service.marker_paths import (  # noqa: E402
    sharded_message_directory,
)


SEPARATOR = "__"
V2_DIRECTORY = "v2"
DEFAULT_LEASE_TIMEOUT_SECONDS = 4 * 60 * 60
COPY_BUFFER_BYTES = 1024 * 1024


class MigrationMode(str, Enum):
    """Supported command modes."""

    DRY_RUN = "dry-run"
    EXECUTE = "execute"
    VERIFY = "verify"


@dataclass(frozen=True)
class LegacyMarker:
    """A marker parsed from the legacy flat-directory filename."""

    source_path: Path
    basename: str
    trace_id: str
    queue_name: str
    marker_type: str
    retry_count: int
    timestamp: float


@dataclass(frozen=True)
class MigrationIssue:
    """A cutover-affecting problem found during scan/copy/verification."""

    category: str
    path: str
    detail: str


@dataclass
class MigrationReport:
    """Machine-readable result and complete migration counters."""

    mode: str
    source_root: str
    destination_root: str
    scanned_entries: int = 0
    end_markers: int = 0
    live_start_markers: int = 0
    stale_start_markers: int = 0
    lock_files_skipped: int = 0
    v2_directory_skipped: int = 0
    would_copy: int = 0
    copied: int = 0
    already_present: int = 0
    verified: int = 0
    missing: int = 0
    conflicts: int = 0
    malformed: int = 0
    errors: int = 0
    issues: list[MigrationIssue] = field(default_factory=list)
    status: str = "initializing"

    @property
    def blocker_count(self) -> int:
        return (
            self.live_start_markers
            + self.conflicts
            + self.malformed
            + self.missing
            + self.errors
        )

    @property
    def succeeded(self) -> bool:
        return self.blocker_count == 0

    def add_issue(self, category: str, path: Path, detail: str) -> None:
        self.issues.append(
            MigrationIssue(
                category=category,
                path=str(path),
                detail=detail,
            )
        )

    def as_dict(self) -> dict:
        result = asdict(self)
        result["blocker_count"] = self.blocker_count
        result["succeeded"] = self.succeeded
        return result


def parse_legacy_marker(
    path: Path,
    *,
    expected_queue_name: str,
) -> Optional[LegacyMarker]:
    """Parse one v1 START/END basename using the production grammar.

    The exact queue name is supplied by deployment configuration and matched
    from the right. This is required because a legacy basename alone cannot
    distinguish ``trace_``/``queue`` from ``trace``/``_queue``.
    """

    basename = path.name
    marker_parts = basename.rsplit(SEPARATOR, 3)
    if len(marker_parts) != 4:
        return None

    identity_text, marker_type, retry_text, timestamp_text = marker_parts
    queue_delimiter = SEPARATOR + expected_queue_name
    if not identity_text.endswith(queue_delimiter):
        return None
    trace_id = identity_text[: -len(queue_delimiter)]
    queue_name = expected_queue_name

    if not trace_id or not queue_name or marker_type not in {"start", "end"}:
        return None

    try:
        retry_count = int(retry_text)
        timestamp = float(timestamp_text)
    except ValueError:
        return None

    if not math.isfinite(timestamp):
        return None

    return LegacyMarker(
        source_path=path,
        basename=basename,
        trace_id=trace_id,
        queue_name=queue_name,
        marker_type=marker_type,
        retry_count=retry_count,
        timestamp=timestamp,
    )


def _looks_like_lock_file(path: Path) -> bool:
    suffix = SEPARATOR + "lock"
    return path.name.endswith(suffix) and bool(path.name[: -len(suffix)])


def _is_regular_file(path: Path) -> bool:
    try:
        return stat.S_ISREG(path.lstat().st_mode)
    except OSError:
        return False


def _files_equal(first: Path, second: Path) -> bool:
    """Compare regular files exactly without trusting size alone."""

    if not _is_regular_file(first) or not _is_regular_file(second):
        return False

    if first.stat().st_size != second.stat().st_size:
        return False

    with first.open("rb") as first_file, second.open("rb") as second_file:
        while True:
            first_chunk = first_file.read(COPY_BUFFER_BYTES)
            second_chunk = second_file.read(COPY_BUFFER_BYTES)
            if first_chunk != second_chunk:
                return False
            if not first_chunk:
                return True


def _destination_for(storage_root: Path, marker: LegacyMarker) -> Path:
    return (
        sharded_message_directory(
            storage_root,
            marker.trace_id,
            marker.queue_name,
        )
        / marker.basename
    )


def _scan_legacy_root(
    storage_root: Path,
    report: MigrationReport,
    lease_timeout_seconds: float,
    observed_at: float,
    expected_queue_name: str,
) -> list[LegacyMarker]:
    end_markers: list[LegacyMarker] = []

    try:
        entries: Iterable[os.DirEntry[str]] = os.scandir(storage_root)
    except OSError as exc:
        report.errors += 1
        report.add_issue("scan-error", storage_root, str(exc))
        return end_markers

    with entries:
        for entry in entries:
            report.scanned_entries += 1
            source_path = Path(entry.path)

            if entry.name == V2_DIRECTORY and entry.is_dir(
                follow_symlinks=False
            ):
                report.v2_directory_skipped += 1
                continue

            if not entry.is_file(follow_symlinks=False):
                report.malformed += 1
                report.add_issue(
                    "malformed-entry",
                    source_path,
                    "expected a regular v1 marker file",
                )
                continue

            if _looks_like_lock_file(source_path):
                report.lock_files_skipped += 1
                continue

            marker = parse_legacy_marker(
                source_path,
                expected_queue_name=expected_queue_name,
            )
            if marker is None:
                report.malformed += 1
                report.add_issue(
                    "malformed-marker",
                    source_path,
                    "filename does not match the v1 START/END grammar",
                )
                continue

            if marker.marker_type == "start":
                age_seconds = observed_at - marker.timestamp
                if age_seconds <= lease_timeout_seconds:
                    report.live_start_markers += 1
                    report.add_issue(
                        "live-start",
                        source_path,
                        "START lease is still live; stop and drain all "
                        "workers before cutover",
                    )
                else:
                    report.stale_start_markers += 1
                continue

            report.end_markers += 1
            end_markers.append(marker)

    return end_markers


def _inspect_destinations(
    storage_root: Path,
    markers: Sequence[LegacyMarker],
    report: MigrationReport,
    mode: MigrationMode,
) -> list[tuple[LegacyMarker, Path]]:
    pending: list[tuple[LegacyMarker, Path]] = []

    for marker in markers:
        destination = _destination_for(storage_root, marker)

        try:
            destination_exists = (
                destination.exists() or destination.is_symlink()
            )
        except OSError as exc:
            report.errors += 1
            report.add_issue("destination-error", destination, str(exc))
            continue

        if not destination_exists:
            if mode == MigrationMode.VERIFY:
                report.missing += 1
                report.add_issue(
                    "missing-destination",
                    destination,
                    f"v2 copy is missing for {marker.source_path}",
                )
            else:
                report.would_copy += 1
                pending.append((marker, destination))
            continue

        try:
            identical = _files_equal(marker.source_path, destination)
        except OSError as exc:
            report.errors += 1
            report.add_issue("comparison-error", destination, str(exc))
            continue

        if identical:
            if mode == MigrationMode.VERIFY:
                report.verified += 1
            else:
                report.already_present += 1
            continue

        report.conflicts += 1
        report.add_issue(
            "content-conflict",
            destination,
            f"destination differs from source {marker.source_path}; "
            "existing destination was not overwritten",
        )

    return pending


def _fsync_directory(directory: Path) -> None:
    """Best-effort durability for a newly linked directory entry."""

    try:
        directory_fd = os.open(str(directory), os.O_RDONLY)
    except OSError:
        return

    try:
        try:
            os.fsync(directory_fd)
        except OSError:
            # Some filesystems/platforms reject fsync on directory fds. The
            # marker inode itself was already fsynced before publication.
            pass
    finally:
        os.close(directory_fd)


def _copy_marker_without_overwrite(source: Path, destination: Path) -> str:
    """Atomically publish one copy and return ``copied`` or ``existing``.

    ``os.link`` publishes a fully copied temporary inode without replacing an
    existing destination.  If another migrator wins the race, the caller can
    compare the destination and handle it idempotently.
    """

    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.parent / (
        f".{destination.name}.mps-v2-migrate."
        f"{os.getpid()}.{uuid.uuid4().hex}.tmp"
    )

    try:
        shutil.copy2(source, temporary, follow_symlinks=False)
        with temporary.open("rb") as copied_file:
            os.fsync(copied_file.fileno())

        try:
            os.link(
                str(temporary),
                str(destination),
                follow_symlinks=False,
            )
        except FileExistsError:
            return "existing"

        _fsync_directory(destination.parent)
        return "copied"
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def migrate_v1_markers(
    storage_path: Path | str,
    *,
    queue_name: str,
    mode: MigrationMode | str = MigrationMode.DRY_RUN,
    lease_timeout_seconds: float = DEFAULT_LEASE_TIMEOUT_SECONDS,
    observed_at: Optional[float] = None,
) -> MigrationReport:
    """Scan, copy, or verify v1 END markers under ``storage_path``.

    Execute uses an all-clear preflight: it performs no copies if the initial
    scan finds malformed entries, content conflicts, read errors, or any live
    START lease.  Per-file publication is atomic; if an I/O failure happens
    after some copies, a rerun safely recognizes those copies and resumes.
    """

    selected_mode = MigrationMode(mode)
    if not math.isfinite(lease_timeout_seconds) or lease_timeout_seconds < 0:
        raise ValueError(
            "lease_timeout_seconds must be a finite non-negative number"
        )
    if (
        not queue_name
        or "/" in queue_name
        or "\\" in queue_name
        or "\x00" in queue_name
        or queue_name in {".", ".."}
    ):
        raise ValueError("queue_name must be a valid non-empty queue name")

    storage_root = Path(storage_path).expanduser().resolve()
    report = MigrationReport(
        mode=selected_mode.value,
        source_root=str(storage_root),
        destination_root=str(storage_root / V2_DIRECTORY),
    )

    if not storage_root.is_dir():
        report.errors += 1
        report.add_issue(
            "invalid-source",
            storage_root,
            "storage path does not exist or is not a directory",
        )
        report.status = "failed"
        return report

    now = time.time() if observed_at is None else observed_at
    if not math.isfinite(now):
        raise ValueError("observed_at must be finite")
    markers = _scan_legacy_root(
        storage_root,
        report,
        lease_timeout_seconds,
        now,
        queue_name,
    )
    pending = _inspect_destinations(
        storage_root,
        markers,
        report,
        selected_mode,
    )

    if selected_mode == MigrationMode.DRY_RUN:
        report.status = "ready" if report.succeeded else "blocked"
        return report

    if selected_mode == MigrationMode.VERIFY:
        report.status = "verified" if report.succeeded else "blocked"
        return report

    # A coordinated cutover should never copy around an active lease or an
    # unexplained source/destination problem.  Crucially, this check happens
    # before the first destination directory is created.
    if not report.succeeded:
        report.status = "blocked"
        return report

    for marker, destination in pending:
        try:
            outcome = _copy_marker_without_overwrite(
                marker.source_path,
                destination,
            )
            if outcome == "copied":
                report.copied += 1
                continue

            # Another process published after preflight.  It is idempotent
            # only when its bytes are exactly the same.
            if _files_equal(marker.source_path, destination):
                report.already_present += 1
            else:
                report.conflicts += 1
                report.add_issue(
                    "content-conflict",
                    destination,
                    f"destination appeared during migration and differs "
                    f"from source {marker.source_path}",
                )
        except OSError as exc:
            report.errors += 1
            report.add_issue("copy-error", destination, str(exc))

    report.status = "completed" if report.succeeded else "failed"
    return report


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Copy legacy flat MPS END markers into deterministic sharded "
            "v2 directories. Dry-run is the default and source files are "
            "never deleted."
        ),
        epilog=(
            "Examples:\n"
            "  migrate_mps_v1_to_v2.py --storage-path /efs/mps "
            "--queue-name input__queue\n"
            "  migrate_mps_v1_to_v2.py --storage-path /efs/mps "
            "--queue-name input__queue --execute\n"
            "  migrate_mps_v1_to_v2.py --storage-path /efs/mps "
            "--queue-name input__queue --verify"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--storage-path",
        required=True,
        help="legacy MPS root; the v2 tree is created below this directory",
    )
    parser.add_argument(
        "--queue-name",
        required=True,
        help=(
            "exact queue name represented by this marker root; required "
            "to parse legacy basenames without underscore-boundary ambiguity"
        ),
    )

    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--execute",
        action="store_true",
        help="copy END markers after a clean preflight",
    )
    mode.add_argument(
        "--verify",
        action="store_true",
        help="verify every v1 END has an identical v2 copy",
    )
    parser.add_argument(
        "--lease-timeout-seconds",
        type=float,
        default=DEFAULT_LEASE_TIMEOUT_SECONDS,
        help=(
            "START lease used to distinguish live cutover blockers from "
            f"stale records (default: {DEFAULT_LEASE_TIMEOUT_SECONDS})"
        ),
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    selected_mode = (
        MigrationMode.EXECUTE
        if args.execute
        else MigrationMode.VERIFY
        if args.verify
        else MigrationMode.DRY_RUN
    )

    try:
        report = migrate_v1_markers(
            args.storage_path,
            mode=selected_mode,
            lease_timeout_seconds=args.lease_timeout_seconds,
            queue_name=args.queue_name,
        )
    except ValueError as exc:
        parser.error(str(exc))

    print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
    return 0 if report.succeeded else 2


if __name__ == "__main__":
    sys.exit(main())
