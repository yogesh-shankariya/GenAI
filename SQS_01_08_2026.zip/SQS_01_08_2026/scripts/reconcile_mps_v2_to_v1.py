#!/usr/bin/env python3
"""Safely reconcile sharded v2 MPS END markers into the legacy flat root.

This command exists only for a coordinated rollback from v2 consumers to the
legacy v1 file layout.  Stop SQS polling, drain in-flight workers, and scale
all consumers to zero before execute.  The command is deliberately strict:

* dry-run is the default; writes require explicit ``--execute``;
* v2 sources are never renamed, modified, hard-linked, or deleted;
* only END markers are copied; permanent lock files are validated and ignored;
* every directory and marker must match the exact deterministic v2 hierarchy;
* a live START, malformed entry, or conflicting flat basename blocks execute
  before any destination is copied;
* publication is atomic, never overwrites an existing path, and preserves the
  source basename, bytes, mode, and timestamps supported by the filesystem;
* reruns are idempotent and ``--verify`` checks the completed reconciliation.
"""

from __future__ import annotations

import argparse
import json
import math
import os
import re
import shutil
import stat
import sys
import time
import uuid
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Iterator, Optional, Sequence


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]
if str(REPOSITORY_ROOT) not in sys.path:
    sys.path.insert(0, str(REPOSITORY_ROOT))

from sqs_service.marker_paths import (  # noqa: E402
    sharded_message_directory,
)


SEPARATOR = "__"
V2_DIRECTORY = "v2"
DEFAULT_LEASE_TIMEOUT_SECONDS = 4 * 60 * 60
COPY_BUFFER_BYTES = 1024 * 1024
_HEX_PAIR = re.compile(r"[0-9a-f]{2}\Z")
_HEX_DIGEST = re.compile(r"[0-9a-f]{64}\Z")


class ReconciliationMode(str, Enum):
    """Supported rollback-reconciliation modes."""

    DRY_RUN = "dry-run"
    EXECUTE = "execute"
    VERIFY = "verify"


@dataclass(frozen=True)
class V2Marker:
    """A validated marker discovered in one deterministic v2 directory."""

    source_path: Path
    basename: str
    trace_id: str
    queue_name: str
    marker_type: str
    retry_count: int
    timestamp: float


@dataclass(frozen=True)
class ReconciliationIssue:
    """A rollback-affecting problem found during scan/copy/verification."""

    category: str
    path: str
    detail: str


@dataclass
class ReconciliationReport:
    """Machine-readable reconciliation counters and diagnostics."""

    mode: str
    source_root: str
    destination_root: str
    scanned_entries: int = 0
    first_level_shards: int = 0
    second_level_shards: int = 0
    message_directories: int = 0
    end_markers: int = 0
    live_start_markers: int = 0
    stale_start_markers: int = 0
    lock_files_skipped: int = 0
    would_copy: int = 0
    copied: int = 0
    already_present: int = 0
    verified: int = 0
    missing: int = 0
    conflicts: int = 0
    name_collisions: int = 0
    malformed: int = 0
    errors: int = 0
    issues: list[ReconciliationIssue] = field(default_factory=list)
    status: str = "initializing"

    @property
    def blocker_count(self) -> int:
        return (
            self.live_start_markers
            + self.conflicts
            + self.name_collisions
            + self.malformed
            + self.missing
            + self.errors
        )

    @property
    def succeeded(self) -> bool:
        return self.blocker_count == 0

    def add_issue(self, category: str, path: Path, detail: str) -> None:
        self.issues.append(
            ReconciliationIssue(
                category=category,
                path=str(path),
                detail=detail,
            )
        )

    def as_dict(self) -> dict:
        result = asdict(self)
        result["blocker_count"] = self.blocker_count
        result["succeeded"] = self.succeeded
        return result


def _valid_identity(value: str, *, allow_separator: bool) -> bool:
    """Mirror the runtime file backend's identity safety boundary."""

    if not value or value in {".", ".."}:
        return False
    if "/" in value or "\\" in value or "\x00" in value:
        return False
    return allow_separator or SEPARATOR not in value


def _identity_for_digest_directory(
    storage_root: Path,
    message_directory: Path,
    identity_text: str,
) -> Optional[tuple[str, str]]:
    """Resolve the unique trace/queue boundary validated by the digest.

    Legacy-style basenames are ambiguous when underscores touch ``__``. The
    v2 parent digest is authoritative, so try every separator boundary and
    accept exactly one runtime-valid pair whose computed directory matches.
    """

    candidates: list[tuple[str, str]] = []
    start = 0
    while True:
        boundary = identity_text.find(SEPARATOR, start)
        if boundary < 0:
            break
        trace_id = identity_text[:boundary]
        queue_name = identity_text[boundary + len(SEPARATOR):]
        if (
            _valid_identity(trace_id, allow_separator=False)
            and _valid_identity(queue_name, allow_separator=True)
            and sharded_message_directory(
                storage_root,
                trace_id,
                queue_name,
            )
            == message_directory
        ):
            candidates.append((trace_id, queue_name))
        start = boundary + 1

    return candidates[0] if len(candidates) == 1 else None


def parse_v2_marker(
    path: Path,
    *,
    storage_root: Optional[Path] = None,
    message_directory: Optional[Path] = None,
) -> Optional[V2Marker]:
    """Parse a START/END basename, using its digest directory when given."""

    basename = path.name
    marker_parts = basename.rsplit(SEPARATOR, 3)
    if len(marker_parts) != 4:
        return None

    identity_text, marker_type, retry_text, timestamp_text = marker_parts

    if storage_root is None and message_directory is None:
        # Standalone parser calls can infer the root from the strict
        # root/v2/aa/bb/digest/file hierarchy.
        try:
            inferred_v2_root = path.parents[3]
            if inferred_v2_root.name != V2_DIRECTORY:
                return None
            storage_root = path.parents[4]
            message_directory = path.parent
        except IndexError:
            return None
    if storage_root is None or message_directory is None:
        return None

    identity = _identity_for_digest_directory(
        storage_root,
        message_directory,
        identity_text,
    )
    if identity is None:
        return None
    trace_id, queue_name = identity

    if (
        not _valid_identity(trace_id, allow_separator=False)
        or not _valid_identity(queue_name, allow_separator=True)
        or marker_type not in {"start", "end"}
    ):
        return None

    try:
        retry_count = int(retry_text)
        timestamp = float(timestamp_text)
    except ValueError:
        return None

    if not math.isfinite(timestamp):
        return None

    return V2Marker(
        source_path=path,
        basename=basename,
        trace_id=trace_id,
        queue_name=queue_name,
        marker_type=marker_type,
        retry_count=retry_count,
        timestamp=timestamp,
    )


def _parse_lock_identity(
    path: Path,
    storage_root: Path,
    message_directory: Path,
) -> Optional[tuple[str, str]]:
    lock_suffix = SEPARATOR + "lock"
    if not path.name.endswith(lock_suffix):
        return None

    identity_text = path.name[: -len(lock_suffix)]
    return _identity_for_digest_directory(
        storage_root,
        message_directory,
        identity_text,
    )


def _parse_start_with_ownership(path: Path) -> Optional[V2Marker]:
    """Parse v2 START identity from its authoritative ownership payload.

    The legacy filename grammar is ambiguous at an underscore adjacent to
    the ``__`` delimiter.  V2 START JSON carries the original fields, so use
    it both to classify leases correctly and to validate the filename fields.
    """

    marker_parts = path.name.rsplit(SEPARATOR, 3)
    if len(marker_parts) != 4 or marker_parts[1] != "start":
        return None
    try:
        retry_count = int(marker_parts[2])
        timestamp = float(marker_parts[3])
        with path.open(encoding="utf-8") as start_file:
            payload = json.load(start_file)
    except (OSError, ValueError, TypeError):
        return None

    if not isinstance(payload, dict):
        return None

    trace_id = payload.get("trace_id")
    queue_name = payload.get("queue_name")
    started_at = payload.get("started_at")
    payload_retry = payload.get("retry_count")
    if (
        payload.get("schema_version") != 2
        or not isinstance(trace_id, str)
        or not isinstance(queue_name, str)
        or not _valid_identity(trace_id, allow_separator=False)
        or not _valid_identity(queue_name, allow_separator=True)
        or payload_retry != retry_count
        or not isinstance(started_at, (int, float))
        or not math.isfinite(started_at)
        or float(started_at) != timestamp
    ):
        return None

    expected_prefix = SEPARATOR.join(
        (
            trace_id,
            queue_name,
            "start",
            str(retry_count),
            "",
        )
    )
    if not path.name.startswith(expected_prefix):
        return None

    return V2Marker(
        source_path=path,
        basename=path.name,
        trace_id=trace_id,
        queue_name=queue_name,
        marker_type="start",
        retry_count=retry_count,
        timestamp=timestamp,
    )


def _is_real_directory(path: Path) -> bool:
    try:
        return stat.S_ISDIR(path.lstat().st_mode)
    except OSError:
        return False


def _is_regular_file(path: Path) -> bool:
    try:
        return stat.S_ISREG(path.lstat().st_mode)
    except OSError:
        return False


def _iter_entries(
    directory: Path,
    report: ReconciliationReport,
) -> Iterator[os.DirEntry[str]]:
    """Yield direct children without following links; report scan failures."""

    try:
        with os.scandir(directory) as entries:
            yield from entries
    except OSError as exc:
        report.errors += 1
        report.add_issue("scan-error", directory, str(exc))


def _record_malformed(
    report: ReconciliationReport,
    path: Path,
    detail: str,
    *,
    category: str = "malformed-hierarchy",
) -> None:
    report.malformed += 1
    report.add_issue(category, path, detail)


def _validate_identity_directory(
    storage_root: Path,
    message_directory: Path,
    trace_id: str,
    queue_name: str,
) -> bool:
    return (
        sharded_message_directory(storage_root, trace_id, queue_name)
        == message_directory
    )


def _scan_message_directory(
    storage_root: Path,
    message_directory: Path,
    report: ReconciliationReport,
    lease_timeout_seconds: float,
    observed_at: float,
    seen_end_basenames: dict[str, Path],
    collision_basenames: set[str],
) -> list[V2Marker]:
    end_markers: list[V2Marker] = []

    for entry in _iter_entries(message_directory, report):
        report.scanned_entries += 1
        source_path = Path(entry.path)

        try:
            regular_file = entry.is_file(follow_symlinks=False)
        except OSError as exc:
            report.errors += 1
            report.add_issue("entry-error", source_path, str(exc))
            continue

        if not regular_file:
            _record_malformed(
                report,
                source_path,
                "message directory may contain only regular marker files",
            )
            continue

        marker_parts = source_path.name.rsplit(SEPARATOR, 3)
        is_end_basename = (
            len(marker_parts) == 4 and marker_parts[1] == "end"
        )
        if is_end_basename:
            previous = seen_end_basenames.setdefault(
                source_path.name,
                source_path,
            )
            if (
                previous.parent != source_path.parent
                and source_path.name not in collision_basenames
            ):
                collision_basenames.add(source_path.name)
                report.name_collisions += 1
                report.add_issue(
                    "v1-name-collision",
                    source_path,
                    "multiple v2 message identities map to the same legacy "
                    f"basename; first source is {previous}",
                )

        is_lock_basename = source_path.name.endswith(SEPARATOR + "lock")
        if is_lock_basename:
            lock_identity = _parse_lock_identity(
                source_path,
                storage_root,
                message_directory,
            )
            if lock_identity is None:
                _record_malformed(
                    report,
                    source_path,
                    "lock filename identity does not match its digest directory",
                    category="misplaced-lock",
                )
                continue

            report.lock_files_skipped += 1
            continue

        marker = (
            _parse_start_with_ownership(source_path)
            if len(marker_parts) == 4 and marker_parts[1] == "start"
            else parse_v2_marker(
                source_path,
                storage_root=storage_root,
                message_directory=message_directory,
            )
        )
        if marker is None:
            _record_malformed(
                report,
                source_path,
                "filename does not match the v2 START/END marker grammar",
                category="malformed-marker",
            )
            continue

        if not _validate_identity_directory(
            storage_root,
            message_directory,
            marker.trace_id,
            marker.queue_name,
        ):
            _record_malformed(
                report,
                source_path,
                "marker identity does not match its digest directory",
                category="misplaced-marker",
            )
            continue

        if marker.marker_type == "start":
            age_seconds = observed_at - marker.timestamp
            if age_seconds <= lease_timeout_seconds:
                report.live_start_markers += 1
                report.add_issue(
                    "live-start",
                    source_path,
                    "START lease is still live; stop and drain all v2 "
                    "workers before rollback",
                )
            else:
                report.stale_start_markers += 1
            continue

        report.end_markers += 1
        end_markers.append(marker)

    return end_markers


def _scan_v2_tree(
    storage_root: Path,
    report: ReconciliationReport,
    lease_timeout_seconds: float,
    observed_at: float,
) -> list[V2Marker]:
    """Traverse exactly ``v2/<2hex>/<2hex>/<64hex>/files``."""

    v2_root = storage_root / V2_DIRECTORY
    if not _is_real_directory(v2_root):
        report.errors += 1
        report.add_issue(
            "invalid-source",
            v2_root,
            "v2 source does not exist or is not a real directory",
        )
        return []

    end_markers: list[V2Marker] = []
    seen_end_basenames: dict[str, Path] = {}
    collision_basenames: set[str] = set()
    for first_entry in _iter_entries(v2_root, report):
        report.scanned_entries += 1
        first_path = Path(first_entry.path)
        try:
            first_is_dir = first_entry.is_dir(follow_symlinks=False)
        except OSError as exc:
            report.errors += 1
            report.add_issue("entry-error", first_path, str(exc))
            continue

        if not first_is_dir or _HEX_PAIR.fullmatch(first_entry.name) is None:
            _record_malformed(
                report,
                first_path,
                "expected a lowercase two-hex first-level shard directory",
            )
            continue

        report.first_level_shards += 1
        for second_entry in _iter_entries(first_path, report):
            report.scanned_entries += 1
            second_path = Path(second_entry.path)
            try:
                second_is_dir = second_entry.is_dir(follow_symlinks=False)
            except OSError as exc:
                report.errors += 1
                report.add_issue("entry-error", second_path, str(exc))
                continue

            if (
                not second_is_dir
                or _HEX_PAIR.fullmatch(second_entry.name) is None
            ):
                _record_malformed(
                    report,
                    second_path,
                    "expected a lowercase two-hex second-level shard directory",
                )
                continue

            report.second_level_shards += 1
            expected_prefix = first_entry.name + second_entry.name

            for digest_entry in _iter_entries(second_path, report):
                report.scanned_entries += 1
                digest_path = Path(digest_entry.path)
                try:
                    digest_is_dir = digest_entry.is_dir(
                        follow_symlinks=False
                    )
                except OSError as exc:
                    report.errors += 1
                    report.add_issue("entry-error", digest_path, str(exc))
                    continue

                if (
                    not digest_is_dir
                    or _HEX_DIGEST.fullmatch(digest_entry.name) is None
                    or not digest_entry.name.startswith(expected_prefix)
                ):
                    _record_malformed(
                        report,
                        digest_path,
                        "expected a 64-hex digest directory matching both shards",
                    )
                    continue

                report.message_directories += 1
                end_markers.extend(
                    _scan_message_directory(
                        storage_root,
                        digest_path,
                        report,
                        lease_timeout_seconds,
                        observed_at,
                        seen_end_basenames,
                        collision_basenames,
                    )
                )

    return end_markers


def _files_equal(first: Path, second: Path) -> bool:
    if not _is_regular_file(first) or not _is_regular_file(second):
        return False
    if first.stat().st_size != second.stat().st_size:
        return False

    with first.open("rb") as first_file, second.open("rb") as second_file:
        while True:
            first_chunk = first_file.read(COPY_BUFFER_BYTES)
            second_chunk = second_file.read(COPY_BUFFER_BYTES)
            if first_chunk != second_chunk:
                return False
            if not first_chunk:
                return True


def _inspect_destinations(
    storage_root: Path,
    markers: Sequence[V2Marker],
    report: ReconciliationReport,
    mode: ReconciliationMode,
) -> list[tuple[V2Marker, Path]]:
    pending: list[tuple[V2Marker, Path]] = []

    for marker in markers:
        destination = storage_root / marker.basename
        try:
            destination_exists = (
                destination.exists() or destination.is_symlink()
            )
        except OSError as exc:
            report.errors += 1
            report.add_issue("destination-error", destination, str(exc))
            continue

        if not destination_exists:
            if mode == ReconciliationMode.VERIFY:
                report.missing += 1
                report.add_issue(
                    "missing-destination",
                    destination,
                    f"legacy copy is missing for {marker.source_path}",
                )
            else:
                report.would_copy += 1
                pending.append((marker, destination))
            continue

        try:
            identical = _files_equal(marker.source_path, destination)
        except OSError as exc:
            report.errors += 1
            report.add_issue("comparison-error", destination, str(exc))
            continue

        if identical:
            if mode == ReconciliationMode.VERIFY:
                report.verified += 1
            else:
                report.already_present += 1
            continue

        report.conflicts += 1
        report.add_issue(
            "content-conflict",
            destination,
            f"flat destination differs from source {marker.source_path}; "
            "existing destination was not overwritten",
        )

    return pending


def _fsync_directory(directory: Path) -> None:
    try:
        directory_fd = os.open(str(directory), os.O_RDONLY)
    except OSError:
        return

    try:
        try:
            os.fsync(directory_fd)
        except OSError:
            pass
    finally:
        os.close(directory_fd)


def _copy_marker_without_overwrite(source: Path, destination: Path) -> str:
    """Atomically publish one independent copy without replacing a path."""

    temporary = destination.parent / (
        f".{destination.name}.mps-v1-reconcile."
        f"{os.getpid()}.{uuid.uuid4().hex}.tmp"
    )
    try:
        shutil.copy2(source, temporary, follow_symlinks=False)
        with temporary.open("rb") as copied_file:
            os.fsync(copied_file.fileno())

        try:
            os.link(
                str(temporary),
                str(destination),
                follow_symlinks=False,
            )
        except FileExistsError:
            return "existing"

        _fsync_directory(destination.parent)
        return "copied"
    finally:
        try:
            temporary.unlink()
        except FileNotFoundError:
            pass


def reconcile_v2_markers(
    storage_path: Path | str,
    *,
    mode: ReconciliationMode | str = ReconciliationMode.DRY_RUN,
    lease_timeout_seconds: float = DEFAULT_LEASE_TIMEOUT_SECONDS,
    observed_at: Optional[float] = None,
) -> ReconciliationReport:
    """Scan, copy, or verify v2 END markers in the legacy flat root."""

    selected_mode = ReconciliationMode(mode)
    if not math.isfinite(lease_timeout_seconds) or lease_timeout_seconds < 0:
        raise ValueError(
            "lease_timeout_seconds must be a finite non-negative number"
        )

    storage_root = Path(storage_path).expanduser().resolve()
    report = ReconciliationReport(
        mode=selected_mode.value,
        source_root=str(storage_root / V2_DIRECTORY),
        destination_root=str(storage_root),
    )
    if not storage_root.is_dir():
        report.errors += 1
        report.add_issue(
            "invalid-destination",
            storage_root,
            "storage path does not exist or is not a directory",
        )
        report.status = "failed"
        return report

    now = time.time() if observed_at is None else observed_at
    if not math.isfinite(now):
        raise ValueError("observed_at must be finite")

    markers = _scan_v2_tree(
        storage_root,
        report,
        lease_timeout_seconds,
        now,
    )
    pending = _inspect_destinations(
        storage_root,
        markers,
        report,
        selected_mode,
    )

    if selected_mode == ReconciliationMode.DRY_RUN:
        report.status = "ready" if report.succeeded else "blocked"
        return report

    if selected_mode == ReconciliationMode.VERIFY:
        report.status = "verified" if report.succeeded else "blocked"
        return report

    # Complete validation occurs before the first flat destination is made.
    if not report.succeeded:
        report.status = "blocked"
        return report

    for marker, destination in pending:
        try:
            outcome = _copy_marker_without_overwrite(
                marker.source_path,
                destination,
            )
            if outcome == "copied":
                report.copied += 1
                continue

            if _files_equal(marker.source_path, destination):
                report.already_present += 1
            else:
                report.conflicts += 1
                report.add_issue(
                    "content-conflict",
                    destination,
                    "destination appeared during reconciliation and differs "
                    f"from source {marker.source_path}",
                )
        except OSError as exc:
            report.errors += 1
            report.add_issue("copy-error", destination, str(exc))

    report.status = "completed" if report.succeeded else "failed"
    return report


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Reconcile sharded v2 MPS END markers into the legacy flat root. "
            "Dry-run is the default and v2 sources are never deleted."
        ),
        epilog=(
            "Examples:\n"
            "  reconcile_mps_v2_to_v1.py --storage-path /efs/mps\n"
            "  reconcile_mps_v2_to_v1.py --storage-path /efs/mps --execute\n"
            "  reconcile_mps_v2_to_v1.py --storage-path /efs/mps --verify"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--storage-path",
        required=True,
        help="MPS root containing v2/ and the legacy flat destination",
    )
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--execute",
        action="store_true",
        help="copy END markers into the flat root after a clean preflight",
    )
    mode.add_argument(
        "--verify",
        action="store_true",
        help="verify every v2 END has an identical flat-root copy",
    )
    parser.add_argument(
        "--lease-timeout-seconds",
        type=float,
        default=DEFAULT_LEASE_TIMEOUT_SECONDS,
        help=(
            "START lease used to distinguish live rollback blockers from "
            f"stale records (default: {DEFAULT_LEASE_TIMEOUT_SECONDS})"
        ),
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    parser = _build_parser()
    args = parser.parse_args(argv)
    selected_mode = (
        ReconciliationMode.EXECUTE
        if args.execute
        else ReconciliationMode.VERIFY
        if args.verify
        else ReconciliationMode.DRY_RUN
    )

    try:
        report = reconcile_v2_markers(
            args.storage_path,
            mode=selected_mode,
            lease_timeout_seconds=args.lease_timeout_seconds,
        )
    except ValueError as exc:
        parser.error(str(exc))

    print(json.dumps(report.as_dict(), indent=2, sort_keys=True))
    return 0 if report.succeeded else 2


if __name__ == "__main__":
    sys.exit(main())
