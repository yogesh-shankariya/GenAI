from __future__ import annotations

import atexit
import os
import threading
from concurrent.futures import Future, ThreadPoolExecutor
from typing import Callable
from constant import Constant

# --------------------------------------------------------------------------- #
# Global executor                                                             #
# --------------------------------------------------------------------------- #
POOL_NAME = "metadata-svc"
# total worker threads for the universal pool (default 32, override via env)
DEFAULT_WORKERS = int(Constant.DEFAULT_WORKERS)
EXECUTOR: ThreadPoolExecutor | None = None

# semaphore that caps how many outer (encounter-level) tasks can run concurrently
OUTER_CONCURRENCY = int(Constant.OUTER_CONCURRENCY)
outer_gate      = threading.Semaphore(OUTER_CONCURRENCY)


def get_executor(max_workers: int = DEFAULT_WORKERS) -> ThreadPoolExecutor:
    """
    Return a singleton ThreadPoolExecutor shared by the application.
    The first call creates the executor; later calls return the same instance.
    """
    global EXECUTOR
    if EXECUTOR is None:
        EXECUTOR = ThreadPoolExecutor(
            max_workers=max_workers,
            thread_name_prefix=POOL_NAME,
        )
        atexit.register(EXECUTOR.shutdown, wait=True)
    return EXECUTOR
