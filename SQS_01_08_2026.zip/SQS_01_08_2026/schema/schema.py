from enum import Enum
from typing import Any, Optional, Dict, Union, TypedDict, List
from dataclasses import dataclass
from pydantic import BaseModel, Field


class KafkaMarkerEnum(Enum):
    START = "KAFKA_MESSAGE_CONSUME_START"
    FAIL = "KAFKA_MESSAGE_FAILURE"
    END = "KAFKA_MESSAGE_CONSUME_END"
    SUCCESS = "KAFKA_MESSAGE_SUCCESS"
    PRODUCE = "KAFKA_MESSAGE_PRODUCE"


KafkaContextMapLog = TypedDict(
    "KafkaContextMapLog",
    {
        'FILE_FORMAT': str,
        'RA_MNEMONIC': str,
        'SYNTHESIS_SERVICE_OPERATION': str,
        'X-Trace-ID': str,
        'X-REQUEST-ID': str,
        'dd.service':str
    }
)

KafkaContextMap = TypedDict(
    "KafkaContextMap",
    {
        "metadata": Dict,
        "DOCBINARY_PATH": str,
        "DOCASCII_PATH": str,
        "DOCENCOUNTER_PATHS": List,
    }
)


class KafkaLogFormat(TypedDict):
    contextMap: KafkaContextMapLog
    marker: str


class ResponseFromMetadata(TypedDict):
    DOCBINARY_PATH: str
    DOCASCII_PATH: str
    DOCMETADATA_PATH: str
