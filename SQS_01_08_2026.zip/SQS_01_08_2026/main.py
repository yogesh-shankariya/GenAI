# ---------------------------------------------------------------------------
#  Standard bootstrap (logger, ThreadPool patch, src-alias)
# ---------------------------------------------------------------------------
from log_util.bootstrap import logger             # <-- centralised bootstrap

# ---------------------------------------------------------------------------
#  Project-specific imports
# ---------------------------------------------------------------------------
from log_util.logger import kafka_msg_logger, clear_context_map
from log_util import logger as log_utils

from schema import KafkaMarkerEnum, KafkaContextMapLog
from constant import Constant, ErrorCodes
from ddtrace.trace import tracer

# Import SQS client with storage abstraction support
# Now uses pluggable MarkerStore backend for idempotency
from sqs_service import SQSClient, __version__ as sqs_version

# Import idempotency helpers
from consumer_idempotency import (
    SKIP_DUPLICATE,
    SKIP_OWNED,
    extract_idempotency_key,
    idempotency_gate,
    make_idempotent_handler,
    mark_processing_end_safe,
)

from app.execute_main import execute as doc_meta_execute
import json
from time import sleep
from copy import deepcopy
from typing import Dict, Any
import sys
from app.src.utils.file_handler import download_s3

# Log SQS service version
logger.info(f"SQS Service Version: {sqs_version} (with MarkerStore abstraction)")

# Initialize SQS clients
# Output and error clients don't need idempotency (only input does)
output_client = SQSClient(
    queue_name=Constant.SQS_OUTPUT_QUEUE_NAME,
    region_name=Constant.SQS_AWS_REGION,
    max_retries=Constant.SQS_MAX_RETRIES,
)

error_client = SQSClient(
    queue_name=Constant.SQS_ERROR_QUEUE_NAME,
    region_name=Constant.SQS_AWS_REGION,
    max_retries=Constant.SQS_MAX_RETRIES,
)


def _build_malformed_error_message(message_body, err_msg: str) -> Dict[str, Any]:
    """
    Error-queue envelope for messages that cannot be parsed or enriched.
    SQS rejects empty bodies, so a blank input is wrapped rather than
    forwarded raw; the SQS MessageId stands in for the missing traceId.
    """
    raw_body = ""
    sqs_message_id = ""
    if isinstance(message_body, dict):
        raw_body = str(message_body.get("Body", ""))
        sqs_message_id = str(message_body.get("MessageId", ""))
    return {
        "originalBody": raw_body,
        "sqsMessageId": sqs_message_id,
        "metadata": {
            "errorCode": ErrorCodes.MISSING_REQUIRED_FIELDS.value,
            "errorMsg": err_msg,
            "errorMessage": True,
            "status": "ERROR",
            "sourceQueue": Constant.SQS_INPUT_QUEUE_NAME,
            "lastService": Constant.LAST_SERVICE,
            "queuePath": [Constant.SQS_INPUT_QUEUE_NAME],
        },
    }


def _send_malformed_to_error_queue(message_body, err_msg: str) -> None:
    """
    Send the malformed-message envelope with retries. On ultimate failure
    log CRITICAL and re-raise: the message then stays unacked on the input
    queue and is retried after the MPS lease expires (deliberate backoff).
    """
    envelope = _build_malformed_error_message(message_body, err_msg)
    trace_id = envelope["sqsMessageId"] or None
    try:
        error_client.send_message_with_retry(envelope, trace_id=trace_id)
    except Exception:
        logger.critical(
            "Failed to send malformed message %s to the error queue after "
            "retries - message stays on the input queue and will retry "
            "after the MPS lease",
            trace_id,
            exc_info=True,
        )
        raise


def run_pipeline_in_process(file_path: list,
                            trace_id: str,
                            s3_bucket: str,
                            s3_region: str,
                            source_binary_path: str,
                            baseLocation: str,
                            ra_mnemonic: str,
                            logger_) -> Dict[str, Any]:
    """
    Set env vars (bucket/region) and call execute_main.execute().
    """

    if not file_path:
        logger_.error("Encounter path is empty")
        return {
            "trace_id": trace_id,
            "status_code": ErrorCodes.MISSING_REQUIRED_FIELDS.value ,
            "err_msg": "encounter path is empty",
            "data": [],
        }

    if not trace_id or str(trace_id).strip() == "":
        logger_.error("trace_id is empty")
        return {
            "trace_id": trace_id,
            "status_code": ErrorCodes.MISSING_REQUIRED_FIELDS.value ,
            "err_msg": "trace_id is empty",
            "data": [],
        }

    if not baseLocation or str(baseLocation).strip() == "":
        logger_.error("baseLocation is empty")
        return {
            "trace_id": trace_id,
            "status_code": ErrorCodes.MISSING_REQUIRED_FIELDS.value ,
            "err_msg": "baseLocation is empty",
            "data": [],
        }

    json_text = json.dumps(
        {
            "file_path" : file_path,
            "trace_id" : trace_id,
            "s3_bucket" : s3_bucket,
            "s3_region" : s3_region,
            "source_binary_path" : source_binary_path,
            "baseLocation" : baseLocation,
            "ra_mnemonic" : ra_mnemonic
        })
    response = doc_meta_execute(
        logger=logger_,
        sqs_text=json_text
    )
    return response

@tracer.wrap(service=Constant.APP_NAME, resource="llm_execute_bg")
def process_sqs_message(message_body) -> bool:
    """
    This wrapper extracts parameters from the SQS message
    and calls the doc_Meta_execute function.

    Returns:
        bool: True if the message was fully processed and its output
              posted downstream; False on any failure. On failure the
              enriched error message (or malformed-message envelope) has
              ALREADY been sent to the error queue in here - the caller
              only deletes/acks the input copy (single-sender, review H3).
    """
    context_map = {}
    input_message = None
    trace_id = None
    success = False

    # Malformed messages must never kill the process (sys.exit raises
    # SystemExit, which escapes every `except Exception` up the stack and
    # crash-loops the pod on redelivery - review C1). They are routed to
    # the error queue and reported as a normal failure instead.
    if (
        not isinstance(message_body, dict)
        or "Body" not in message_body
        or str(message_body.get("Body", "")).strip() == ""
    ):
        err_msg = "Input message is blank"
        logger.error(err_msg)
        _send_malformed_to_error_queue(message_body, err_msg)
        return False

    try:
        # Parse the SQS message. TypeError: json.loads(None) - a
        # non-string Body passes the blank check via str() but is not a
        # JSONDecodeError, and must not escape the malformed handling.
        body = json.loads(message_body["Body"])
    except (json.JSONDecodeError, TypeError) as exc:
        err_msg = f"Input message is corrupted - cannot parse JSON. {exc}"
        logger.error(err_msg)
        _send_malformed_to_error_queue(message_body, err_msg)
        return False

    try:

        input_message = json.loads(body["Message"]) if "Message" in body else body

        if not (input_message["metadata"]["traceId"] and str(input_message["metadata"]["traceId"]).strip()):
            logger.error("Trace id is not present")
            # Handled by the except block below: enriched error message to
            # the error queue, then a normal False return (review C1)
            raise ValueError("traceId is blank in metadata")

        trace_id = input_message["metadata"]["traceId"]

        #DATADOG CONFIGURATION
        with tracer.trace(service=Constant.APP_NAME, name="process_sqs_message") as span:
            span.set_tag("trace-id", trace_id)

        meta = input_message.get("metadata", {})

        fileFormat  = (meta.get("fileFormat")  or "").strip()
        xrequestID  = (meta.get("xrequestID")  or "").strip()
        RA_MNEMONIC = (meta.get("sourceType")  or "").strip()


        context_map: KafkaContextMapLog = {
            "FILE_FORMAT": fileFormat,
            "RA_MNEMONIC": RA_MNEMONIC,
            "SYNTHESIS_SERVICE_OPERATION": Constant.SYNTHESIS_SERVICE_OPERATION,
            "X-Trace-ID": trace_id,
            "X-REQUEST-ID": xrequestID,
            "dd.service": ""
        }

        log_utils.set_context_map(context_map)

        kafka_msg_logger(
            msg="Doc Metadata pipeline started",
            marker=KafkaMarkerEnum.START,
            context_map=context_map
        )

        logger.info(f"Message Body : {body}")

        logger.debug(f"Processing trace_id: {trace_id}")

        DOCBINARY_PATH = input_message["DOCBINARY_PATH"]
        DOCENCOUNTER_PATH_JSON = input_message["DOCENCOUNTER_PATH"]
        baseLocation = input_message["metadata"]["baseLocation"]
        s3_bucket = Constant.AWS_S3_BUCKET
        s3_region = Constant.AWS_S3_REGION

        try:
            logger.debug(f"Downloading encounter-path JSON: {DOCENCOUNTER_PATH_JSON}")
            json_txt = download_s3(
                logger=logger,
                bucket_name=s3_bucket,
                aws_region=s3_region,
                s3_file_key=DOCENCOUNTER_PATH_JSON
            )
            logger.debug(f"Encounter-path JSON content: {json_txt}")
            DOCENCOUNTER_PATHS = json.loads(json_txt)
            logger.debug(f"Parsed encounter-paths list + {DOCENCOUNTER_PATHS} "
                         f"(type={type(DOCENCOUNTER_PATHS)})")
            if not isinstance(DOCENCOUNTER_PATHS, list):
                raise ValueError("Encounter-path JSON must contain a list")
        except Exception as exc:
            logger.error(f"Failed to obtain encounter paths: {exc}", exc_info=True)
            raise

        result = run_pipeline_in_process(
            file_path = DOCENCOUNTER_PATHS,
            trace_id = trace_id,
            s3_bucket = s3_bucket,
            s3_region = s3_region,
            source_binary_path = DOCBINARY_PATH,
            baseLocation = baseLocation,
            ra_mnemonic = RA_MNEMONIC,
            logger_ = logger
        )

        result_data = result.get("data")
        status = result.get("status_code")
        err_msg = result.get("err_msg")

        if status != 200:
            output_message = deepcopy(input_message)
            output_message.pop("DOCENCOUNTER_PATHS", None)
            output_message["DOCASCII_PATH"]    = ""
            output_message["DOCMETADATA_PATH"] = ""

            meta = output_message.get("metadata", {})
            meta["errorCode"]    = int(status)
            meta["errorMessage"] = True
            meta["errorMsg"]     = err_msg or ""

            if "queuePath" in meta:
                if Constant.SQS_INPUT_QUEUE_NAME not in meta["queuePath"]:
                    meta["queuePath"].append(Constant.SQS_INPUT_QUEUE_NAME)
            else:
                meta["queuePath"] = [Constant.SQS_INPUT_QUEUE_NAME]

            meta["sourceQueue"] = Constant.SQS_INPUT_QUEUE_NAME
            meta["lastService"] = Constant.LAST_SERVICE
            meta["status"] = "ERROR"
            output_message["metadata"] = meta
            logger.error("Error encountered: %s", err_msg)
            #Produce Error Message
            kafka_msg_logger(
                msg=f"Error {err_msg} encountered",
                marker=KafkaMarkerEnum.FAIL,
                context_map=context_map
            )

            logger.error(f"Final output - {output_message}")

            error_client.send_message_with_retry(output_message, trace_id=trace_id)

        else:

            output_message = deepcopy(input_message)

            output_message.pop("DOCENCOUNTER_PATHS", None)

            output_message["DOCMETADATA_PATH"] = result_data[0]

            meta = output_message.get("metadata", {})

            if "queuePath" in meta:
                if Constant.SQS_INPUT_QUEUE_NAME not in meta["queuePath"]:
                    meta["queuePath"].append(Constant.SQS_INPUT_QUEUE_NAME)
            else:
                meta["queuePath"] = [Constant.SQS_INPUT_QUEUE_NAME]

            meta["sourceQueue"] = Constant.SQS_INPUT_QUEUE_NAME
            meta["lastService"] = Constant.LAST_SERVICE

            output_message["metadata"] = meta

            logger.info(f"Final output - {output_message}")
            kafka_msg_logger(

                msg=f"Doc Metadata pipeline completed",
                marker=KafkaMarkerEnum.END,
                context_map=context_map
            )

            # Post to SQS output queue (bounded retries - a transient blip
            # here must not throw away a completed LLM run; review H1)
            output_client.send_message_with_retry(output_message, trace_id=trace_id)

            kafka_msg_logger(
                msg=f"Final output from Doc Meta posting to Kafka.: {output_message}",
                marker=KafkaMarkerEnum.PRODUCE,
                context_map=context_map
            )

            kafka_msg_logger(
                msg=f"Doc Metadata pipeline completed.",
                marker=KafkaMarkerEnum.SUCCESS,
                context_map=context_map
            )

            # Success - message processed and posted to output
            success = True
    except Exception as exc:
        logger.error("Unexpected error in processing pipeline: %s", exc)
        # context_map is {} (never None) when parsing failed early, so this
        # logging call can no longer crash the error handler (review H2)
        kafka_msg_logger(
            msg=f"Error {exc} encountered",
            marker=KafkaMarkerEnum.FAIL,
            context_map=context_map
        )
        if isinstance(input_message, dict):
            output_message = deepcopy(input_message)
            output_message.pop("DOCENCOUNTER_PATHS", None)
            output_message["DOCASCII_PATH"]    = ""
            output_message["DOCMETADATA_PATH"] = ""

            # This is the malformed path: "metadata" may EXIST as a
            # non-dict (null/string/list) - .get's default only covers a
            # missing key, and meta["errorCode"] on a non-dict would crash
            # this handler again (review H2, third trigger shape)
            meta = output_message.get("metadata")
            if not isinstance(meta, dict):
                meta = {}
            meta["errorCode"]    = ErrorCodes.INTERNAL_SERVER_ERROR.value
            meta["errorMsg"]     = str(exc)
            meta["errorMessage"] = True
            if "queuePath" in meta:
                if Constant.SQS_INPUT_QUEUE_NAME not in meta["queuePath"]:
                    meta["queuePath"].append(Constant.SQS_INPUT_QUEUE_NAME)
            else:
                meta["queuePath"] = [Constant.SQS_INPUT_QUEUE_NAME]
            meta["sourceQueue"] = Constant.SQS_INPUT_QUEUE_NAME
            meta["lastService"] = Constant.LAST_SERVICE
            meta["status"] = "ERROR"
            output_message["metadata"] = meta
        else:
            # Failure before the body was parsed (e.g. inner "Message" is
            # invalid JSON) - fall back to the malformed-message envelope
            # so the error queue still receives a record (review H2)
            output_message = _build_malformed_error_message(message_body, str(exc))
        logger.error(f"Final output - {output_message}")
        # ---- send to error queue (bounded retries; on ultimate failure the
        # message deliberately stays locked by its MPS_START and retries
        # after the lease - keep-current-behavior decision for review H1) --
        try:
            error_client.send_message_with_retry(
                output_message,
                trace_id=trace_id or (
                    message_body.get("MessageId")
                    if isinstance(message_body, dict) else None
                ),
            )
        except Exception:
            logger.critical(
                "Failed to send error message to the error queue after "
                "retries - message stays locked by its MPS_START and will "
                "retry after the lease",
                exc_info=True,
            )
            raise
    finally:
        clear_context_map()

    return success


def _route_to_error_queue(input_client, message) -> bool:
    """
    Acknowledge a failed message by deleting it from the input queue so
    it cannot redeliver forever.

    The enriched error message was already sent to the error queue inside
    process_sqs_message (single sender - re-sending the raw body here
    produced two differently-shaped error messages per failure; review H3).

    Returns True if the message was deleted; False leaves it on the input
    queue for redelivery after the visibility timeout.
    """
    receipt_handle = message["ReceiptHandle"]

    try:
        input_client.delete_msg(receipt_handle)
        logger.info("Failed message acknowledged - deleted from input queue")
        return True

    except Exception as exc:
        logger.exception(
            "Could not delete failed message from input queue (%s) - "
            "leaving it for redelivery",
            exc,
        )
        return False


def get_service_configuration() -> Dict[str, Any]:
    """
    Collect all non-sensitive configuration values for startup logging.
    Excludes secrets like CLIENT_SECRET, OPENAI_API_KEY, etc.
    """
    return {
        # Service Identity
        "SERVICE_NAME": Constant.SERVICE_NAME,
        "APP_NAME": Constant.APP_NAME,
        "LOG_LEVEL": Constant.LOG_LEVEL,
        "DEBUG_MODE": Constant.DEBUG_MODE,

        # SQS Configuration
        "SQS_INPUT_QUEUE_NAME": Constant.SQS_INPUT_QUEUE_NAME,
        "SQS_OUTPUT_QUEUE_NAME": Constant.SQS_OUTPUT_QUEUE_NAME,
        "SQS_ERROR_QUEUE_NAME": Constant.SQS_ERROR_QUEUE_NAME,
        "SQS_AWS_REGION": Constant.SQS_AWS_REGION,
        "AWS_SQS_REGION": Constant.AWS_SQS_REGION,

        # SQS Idempotency Configuration
        "SQS_MPS_PATH": Constant.SQS_MPS_PATH,
        "MPS_BACKEND": Constant.MPS_BACKEND,
        # Redis marker store (only used when MPS_BACKEND=redis);
        # the auth token itself is never logged
        "REDIS_HOST_NAME": Constant.REDIS_HOST_NAME,
        "REDIS_PORT_NUMBER": Constant.REDIS_PORT_NUMBER,
        "REDIS_SSL": Constant.REDIS_SSL,
        "REDIS_AUTH_TOKEN": "***" if Constant.REDIS_AUTH_TOKEN else None,
        "SQS_PROCESSING_MODE": Constant.SQS_PROCESSING_MODE,
        "SQS_MAX_WORKERS": Constant.SQS_MAX_WORKERS,
        "SQS_VISIBILITY_TIMEOUT": Constant.SQS_VISIBILITY_TIMEOUT,
        "SQS_MAX_RETRIES": Constant.SQS_MAX_RETRIES,
        "SQS_MPS_TIMEOUT_SECONDS": Constant.SQS_MPS_TIMEOUT_SECONDS,

        # SQS Feature Flags (backward compat)
        "SQS_ENABLE_IDEMPOTENCY": Constant.SQS_ENABLE_IDEMPOTENCY,
        "SQS_ENABLE_PARALLEL_PROCESSING": Constant.SQS_ENABLE_PARALLEL_PROCESSING,
        "SQS_ENABLE_BATCH_OPERATIONS": Constant.SQS_ENABLE_BATCH_OPERATIONS,

        # AWS Configuration
        "AWS_S3_REGION": Constant.AWS_S3_REGION,
        "AWS_S3_BUCKET": Constant.AWS_S3_BUCKET,

        # Thread Pool Configuration
        "DEFAULT_WORKERS": Constant.DEFAULT_WORKERS,
        "MAX_SPAWN_PROCESSES": Constant.MAX_SPAWN_PROCESSES,
        "MAX_SPAWN_THREADS": Constant.MAX_SPAWN_THREADS,
        "OUTER_CONCURRENCY": Constant.OUTER_CONCURRENCY,
        "INNER_CONCURRENCY": Constant.INNER_CONCURRENCY,

        # LLM Configuration
        "LLM_QOS": Constant.LLM_QOS,
        "LLM_REASONING": Constant.LLM_REASONING,
        "LLM_PREVIEW": Constant.LLM_PREVIEW,
        "PHI_CHECK_QOS": Constant.PHI_CHECK_QOS,
        "PHI_CHECK_REASONING": Constant.PHI_CHECK_REASONING,
        "PHI_CHECK_PREVIEW": Constant.PHI_CHECK_PREVIEW,

        # S3 Batch Configuration
        "S3_BATCH_MAX_WORKERS": Constant.S3_BATCH_MAX_WORKERS,
        "S3_BATCH_CHUNK_SIZE": Constant.S3_BATCH_CHUNK_SIZE,
        "S3_DECRYPT": Constant.S3_DECRYPT,

        # Feature Flags
        "DEFAULT_FLAG_STATE": Constant.DEFAULT_FLAG_STATE,
        "URGENT_APPEAL_ENABLED": Constant.URGENT_APPEAL_ENABLED,

        # DOS Validation
        "DOS_VALIDATION_ENABLED": Constant.DOS_VALIDATION_ENABLED,
        "DOS_VALIDATION_START_DATE": str(Constant.DOS_VALIDATION_START_DATE),
        "DOS_VALIDATION_WHITELIST_MNEMONICS": Constant.DOS_VALIDATION_WHITELIST_MNEMONICS,

        # Kafka Configuration
        "KAFKA_URL": Constant.KAFKA_URL,
        "KAFKA_TOPIC_EXTR": Constant.KAFKA_TOPIC_EXTR,
        "KAFKA_TOPIC_ERR": Constant.KAFKA_TOPIC_ERR,
        "KAFKA_TOPIC_OUTPUT": Constant.KAFKA_TOPIC_OUTPUT,
        "KAFKA_TOPIC_OUTPUT_ERR": Constant.KAFKA_TOPIC_OUTPUT_ERR,
        "KAFKA_API_TIME_OUT": Constant.KAFKA_API_TIME_OUT,

        # Synthesis Service
        "SYNTHESIS_SERVICE_OPERATION": Constant.SYNTHESIS_SERVICE_OPERATION,
        "LAST_SERVICE": Constant.LAST_SERVICE,
    }


def main():
    """
    Main Entry Point with Idempotency
    """
    logger.info("Starting Doc Metadata Service...")

    # Log complete service configuration
    config = get_service_configuration()
    logger.info("Service Configuration Loaded", extra={"configuration": config})
    logger.info(f"SQS Input Queue: {Constant.SQS_INPUT_QUEUE_NAME}")
    logger.info(f"SQS Region: {Constant.SQS_AWS_REGION}")

    # Input client with idempotency ENABLED
    input_client = SQSClient(
        queue_name=Constant.SQS_INPUT_QUEUE_NAME,
        region_name=Constant.SQS_AWS_REGION,
        enable_idempotency=True,  # ALWAYS ON in new pattern
        mps_storage_path=Constant.SQS_MPS_PATH,
        # Wire the configured lease/retries in - both were logged at startup
        # but never actually applied (reviews H6 and H1/SQS_MAX_RETRIES)
        mps_timeout_seconds=Constant.SQS_MPS_TIMEOUT_SECONDS,
        max_retries=Constant.SQS_MAX_RETRIES,
    )

    # Log idempotency configuration
    logger.info(
        f"Idempotency: ENABLED, MPS Path: {Constant.SQS_MPS_PATH}, "
        f"Backend: {Constant.MPS_BACKEND}"
    )

    # Validate processing mode
    mode = Constant.SQS_PROCESSING_MODE
    if mode not in ("serial", "parallel"):
        logger.error(
            f"Unsupported SQS_PROCESSING_MODE: {mode!r} "
            "(expected serial or parallel)"
        )
        sys.exit(1)

    # Process based on mode
    if mode == "parallel":
        logger.info(
            f"Parallel consumption mode with idempotency "
            f"({Constant.SQS_MAX_WORKERS} workers)"
        )

        # Import ParallelSQSProcessor
        from sqs_service import ParallelSQSProcessor

        # Create idempotent handler that wraps process_sqs_message
        # route_error_fn must be a ONE-argument callable - passing the bare
        # two-argument function raised TypeError on every failed message
        # (review C2; the lambda restores the original working wiring)
        idempotent_handler = make_idempotent_handler(
            client=input_client,
            process_fn=process_sqs_message,
            route_error_fn=lambda msg: _route_to_error_queue(input_client, msg),
        )

        # Create parallel processor
        processor = ParallelSQSProcessor(
            client=input_client,
            processing_function=idempotent_handler,
            max_workers=Constant.SQS_MAX_WORKERS,
            delete_on_success=True,
            visibility_timeout=Constant.SQS_VISIBILITY_TIMEOUT,
            message_arg="message",
        )

        logger.info("Starting pipelined parallel processing...")

        # Start continuous pipelined processing
        try:
            processor.process_pipelined_with_threads(
                wait_time_seconds=20,
            )
        except KeyboardInterrupt:
            logger.info("Parallel processing stopped by user")
        finally:
            processor.close()

    elif mode == "serial":
        # Serial mode with idempotency
        logger.info("Serial consumption mode with idempotency")

        while True:
            try:
                # Long polling; up to 10 messages per request
                messages = input_client.receive_messages(
                    max_messages=10,
                    wait_time_seconds=20,
                    visibility_timeout=Constant.SQS_VISIBILITY_TIMEOUT,
                )

                if not messages:
                    logger.debug("No messages received from SQS")
                    continue

                for message in messages:
                    receipt_handle = message["ReceiptHandle"]

                    # STEP 1: Extract idempotency key
                    trace_id, retry_count = extract_idempotency_key(message)
                    logger.debug(
                        f"[IDEMPOTENCY] Extracted key: trace_id={trace_id}, retry_count={retry_count}"
                    )

                    # STEP 2: Idempotency gate (duplicate check + atomic claim)
                    gate = idempotency_gate(input_client, trace_id, retry_count)
                    logger.debug(
                        f"[IDEMPOTENCY] Gate check result: {gate} for trace_id={trace_id}"
                    )

                    if gate == SKIP_DUPLICATE:
                        # Scenario A - already completed on an earlier delivery;
                        # the duplicate is safe to delete
                        logger.info(
                            f"Duplicate {trace_id} already completed - deleting"
                        )
                        input_client.delete_msg(receipt_handle)
                        logger.debug(
                            f"[IDEMPOTENCY] Message deleted (duplicate): trace_id={trace_id}"
                        )
                        continue

                    if gate == SKIP_OWNED:
                        # Scenario B - another worker holds the START lease;
                        # leave the message on the queue so it can redeliver
                        # (or be taken over if that worker died)
                        logger.info(
                            f"Message {trace_id} owned by another worker - "
                            "left on queue"
                        )
                        logger.debug(
                            f"[IDEMPOTENCY] Message left on queue (owned): trace_id={trace_id}, "
                            f"will be available after visibility timeout"
                        )
                        continue

                    # STEP 3: Process message
                    logger.debug(
                        f"[IDEMPOTENCY] Starting message processing: trace_id={trace_id}, "
                        f"retry_count={retry_count}"
                    )
                    success = process_sqs_message(message)

                    # STEP 4: Mark processing end BEFORE delete
                    # (MPS_END after the publish, which happens inside
                    # process_sqs_message, before the delete; a failed END
                    # also clears START so retries are fast)
                    mark_processing_end_safe(
                        input_client, trace_id, retry_count, success
                    )
                    logger.debug(
                        f"[IDEMPOTENCY] Processing end marked: trace_id={trace_id}, "
                        f"success={success}"
                    )

                    # STEP 5: Delete or route to error
                    if success:
                        # Delete message after successful consumption
                        input_client.delete_msg(receipt_handle)
                        logger.debug(
                            f"[IDEMPOTENCY] Message deleted (success): trace_id={trace_id}"
                        )
                    else:
                        # Route to error queue and delete from input
                        routed = _route_to_error_queue(input_client, message)
                        logger.debug(
                            f"[IDEMPOTENCY] Error queue routing: trace_id={trace_id}, "
                            f"routed={routed}"
                        )

            except KeyboardInterrupt:
                logger.info("Consumer stopped by user")
                break

            except Exception:
                # Transient AWS/network errors must not kill the pod
                logger.exception("SQS consumer loop error")
                sleep(5)


if __name__ == "__main__":
    main()
