# EFS MPS Sharding — Production Implementation and Rollout

## Executive decision

Keep EFS as the marker store, but stop searching one flat directory.

The implemented v2 layout places each `(trace_id, queue_name)` identity in a
deterministic SHA-256 directory:

```text
<SQS_MPS_PATH>/
└── v2/
    └── a1/
        └── 64/
            └── a164f94dcb7d051542edbc850503d3164ac0bff4831c14f62683f565572025f8/
                ├── trace-123__input__queue__lock
                ├── trace-123__input__queue__start__0__1786590053.123
                └── trace-123__input__queue__end__0__1786590078.456
```

The existing START, END, and lock basenames are preserved. Only their parent
directory changes.

This changes a marker lookup from scanning every retained marker on EFS to
scanning only the few files for one message. The idempotency algorithm remains
the same: successful END suppresses a duplicate, a live START blocks another
worker, and a stale START permits takeover.

## Evidence from the production log sample

The supplied timestamps isolate the delay to directory searches:

| Event | Timestamp | Elapsed |
|---|---:|---:|
| Message polled; END search begins | 11:00:53 | — |
| No END found | 11:00:58 | about 5 seconds |
| Initial START check and lock acquisition | 11:00:58 | under 1 second at log resolution |
| Locked START recheck finishes | 11:01:03 | about 5 seconds |
| START created | 11:01:03 | under 1 second at log resolution |

The lock was acquired within the same logged second. The two visible five-second
gaps are searches, not waiting for the lock.

In the legacy layout, each wildcard lookup has to enumerate the shared flat
directory. The cost grows with the total number of retained files, even when
the requested trace has no markers. A new message also performs repeated
checks to close concurrency races, so the cost is paid multiple times.

AWS documents the relevant EFS characteristics:

- EFS has latency overhead per file operation.
- File open, close, and metadata operations are synchronous round trips.
- AWS recommends nested directories and warns about listing very large,
  concurrently modified directories.

Source: [Amazon EFS performance tips](https://docs.aws.amazon.com/efs/latest/ug/performance-tips.html).

## What `v2`, `a1`, `64`, and the full digest mean

`v2` is a layout version boundary. It prevents old flat-layout consumers from
silently mixing state with sharded consumers and gives operations a clear
cutover and rollback boundary.

The 64-character value is a SHA-256 digest of an unambiguous, length-prefixed
encoding of `(queue_name, trace_id)`. For the example:

```text
trace_id   = trace-123
queue_name = input__queue
digest     = a164f94dcb7d051542edbc850503d3164ac0bff4831c14f62683f565572025f8
```

`a1` is the first byte of the digest in hexadecimal, and `64` is the second
byte. They distribute message directories instead of placing every child
directly below `v2`.

The full digest is the deterministic directory for exactly one queue/message
identity. All checks can calculate this directory without searching parent
directories. Length-prefixing prevents ambiguous concatenations, and including
the queue name keeps the same trace ID on two queues isolated.

The digest contract lives in one shared module and is imported by both the
runtime and migration tools. This prevents migration/runtime path drift.

## Runtime flow after the change

### New message claim

1. Calculate the deterministic message directory.
2. Search that directory for a live START. A read miss creates no directory.
3. Lazily create the directory when a claim is attempted.
4. Serialize the state transition for that message across local threads and
   EFS-mounted pods.
5. Under the same message lock, remove stale START records, recheck START, and
   recheck successful END.
6. Publish the START through a same-directory temporary file, `fsync`, and
   atomic replacement.

No step lists `SQS_MPS_PATH`, `v2`, `a1`, or `64`. Marker globs are restricted
to the full-digest directory.

### Completion

1. Serialize completion with claim/takeover for the same message.
2. Publish the END marker through a same-directory temporary file, `fsync`,
   and an atomic no-overwrite link. A timestamp collision advances to the next
   representable timestamp, so a failed END can never overwrite sticky success.
3. Remove only the exact START claim owned by the completing worker.

Completion no longer searches the shared marker population to delete START.

## Multiple pods and multiple threads

The implementation retains two layers of per-message serialization:

- a process-wide, path-specific thread mutex, because POSIX record locks do not
  exclude threads within one process;
- an `fcntl` record lock on the deterministic lock file for exclusion between
  processes and pods sharing EFS.

Thread-lock registry entries are reference-counted and removed after use. This
prevents a long-running pod from retaining one Python lock object for every
message it has ever seen. Different message keys use different mutexes, so an
unrelated message is never rejected because another key is busy.

EFS supports NFSv4 file locking, including byte-range locking. Its locks are
advisory, so every state-changing code path must participate in this protocol,
which the file marker adapter now does. Source: [Amazon EFS features — file locking](https://docs.aws.amazon.com/en_en/efs/latest/ug/features.html#features-file-locking).

The deterministic lock file is not deleted while consumers may be running.
Unlinking it can split pods between the old inode and a newly created inode,
allowing both to believe they hold the lock.

This deliberately retains one small lock inode and one message directory per
identity. If that inode growth eventually requires reclamation, it must be an
offline maintenance operation performed only after every consumer using the
EFS path has stopped; online retention cleanup never removes lock files.

## START ownership and stale takeover safety

The basename remains unchanged, but a newly written START contains JSON:

```json
{
  "schema_version": 2,
  "trace_id": "trace-123",
  "queue_name": "input__queue",
  "retry_count": 0,
  "started_at": 1786590053.123,
  "owner_id": "pod:pid:process-instance:thread",
  "claim_token": "a-random-uuid-per-claim"
}
```

The claim token solves this race:

1. Worker A owns START-A.
2. A exceeds the lease or becomes unreachable.
3. Worker B takes over, removes stale START-A, and creates START-B.
4. A returns late and completes.

The old behavior removed every matching START, so late A could remove B's live
claim. The new behavior compares the exact path, owner, and random claim token.
A can write its END record, but it cannot remove B's START.

The current serial and parallel consumers claim and complete on the same worker
thread. The claim handle is therefore kept in thread-local state without
changing the public `MarkerStore` or `SQSClient` method signatures.

## Configuration and safe activation

The runtime setting is:

```text
MPS_FILE_LAYOUT=v1 | v2
```

The default is `v1`. This is deliberate: merely deploying new code must not
make all historical successful END markers invisible. `v2` must be enabled
only after migration and as one coordinated all-pod cutover.

There is no v1 fallback read in v2. A fallback would scan the flat directory on
every new-key miss and reintroduce the original latency.

## Migration utility

The repository contains:

```text
scripts/migrate_mps_v1_to_v2.py
```

Properties:

- dry-run is the default;
- writes require explicit `--execute`;
- `--verify` compares every source END with its destination;
- only END records are copied;
- v1 sources are never modified or deleted;
- basenames, bytes, and modification times are preserved;
- publication is atomic and never overwrites a different destination;
- reruns are idempotent;
- `--queue-name` is mandatory because legacy basenames do not encode an
  unambiguous trace/queue boundary when underscores touch the separator;
- live START, malformed input, content conflict, or I/O error blocks execution
  before the first copy.

Example commands:

```bash
python scripts/migrate_mps_v1_to_v2.py \
  --storage-path /efs/mps \
  --queue-name input__queue

python scripts/migrate_mps_v1_to_v2.py \
  --storage-path /efs/mps \
  --queue-name input__queue \
  --execute

python scripts/migrate_mps_v1_to_v2.py \
  --storage-path /efs/mps \
  --queue-name input__queue \
  --verify
```

Each command emits structured JSON and returns a nonzero exit code when the
operation is blocked.

## Production cutover runbook

Do not run v1 and v2 consumers together. They use disjoint marker paths and
would not see each other's claims or completions.

1. Confirm the configured EFS path and take a recoverable snapshot/backup.
2. Deploy the code with `MPS_FILE_LAYOUT=v1`; confirm normal processing.
3. Stop SQS polling and drain in-flight work.
4. Scale every consumer pod to zero.
5. Confirm the queue visibility state and use the same START lease timeout as
   production when running the migration dry-run.
6. Investigate every reported live START, malformed file, or conflict. Do not
   bypass blockers.
7. Run migration with `--execute`.
8. Run `--verify` and archive the JSON reports with the change record.
9. Set `MPS_FILE_LAYOUT=v2` for every replica.
10. Start one controlled consumer, verify marker paths and gate latency, then
    scale the remaining v2 replicas.
11. Keep the v1 tree unchanged throughout the observation window.
12. Observe for 24–48 hours before closing the change.

A normal rolling deployment that overlaps v1 and v2 pods is prohibited.

## Rollback safety

Stopping v2 and starting the old layout immediately is unsafe after v2 has
completed new messages: those new END records exist only under v2.

Rollback must therefore follow this order:

1. stop polling, drain, and scale all v2 consumers to zero;
2. reconcile every v2 END created after cutover back into the v1 flat root;
3. verify source/destination content and confirm there are no live v2 STARTs;
4. only then start v1 consumers.

Never run old-layout consumers as a binary rollback without that reconciliation.

The rollback command is equally conservative and dry-run by default:

```bash
python scripts/reconcile_mps_v2_to_v1.py \
  --storage-path /efs/mps

python scripts/reconcile_mps_v2_to_v1.py \
  --storage-path /efs/mps \
  --execute

python scripts/reconcile_mps_v2_to_v1.py \
  --storage-path /efs/mps \
  --verify
```

It validates the exact v2 hierarchy and digest identities, blocks on live
STARTs, malformed files, conflicts, or ambiguous flat-basename collisions,
and never deletes v2 sources.

## Expected efficiency

### Structural improvement

| Property | Legacy flat layout | Sharded v2 layout |
|---|---|---|
| Search population | All retained marker files | One identity's marker history |
| Lookup growth | `O(total files)` | `O(files for this message)`, normally constant |
| Unrelated growth effect | Directly increases lookup time | Does not increase the searched directory |
| Completion cleanup | Wildcard START search | Exact owned START path |

This complexity change is the principal performance proof. Absolute EFS
latency still depends on mount options, EFS mode, cache state, concurrency, and
network conditions.

### Local scaling check

A non-EFS local benchmark against the implemented lookup path produced:

| Unrelated flat files | Legacy miss p50 | v2 miss p50 | Ratio |
|---:|---:|---:|---:|
| 50,000 | 22.720 ms | 0.018 ms | about 1,286× |

This is not an EFS service-level promise. It proves that the old operation grows
with unrelated directory entries while the v2 operation does not. EFS magnifies
metadata round-trip cost, which is consistent with the supplied five-second
production scans.

### Production acceptance targets

Against the observed roughly 10-second marker gate, the release target is:

- marker gate p95 at or below 500 ms;
- marker gate p99 at or below 1 second;
- no gate above 1 second in the absence of an EFS or host error;
- zero duplicate claim winners in same-key concurrency testing;
- less than 20% p95 degradation when unrelated retained state grows from the
  current population to the two-year forecast.

Reaching 500 ms from 10 seconds is at least a 95% gate-latency reduction and a
20× improvement. If the measured 25-second end-to-end duration contains exactly
10 seconds of marker-gate time, a 500 ms gate projects about 15.5 seconds total,
or roughly 38% end-to-end reduction. Business processing, S3, model calls, and
SQS publish/delete time are unchanged.

These figures are acceptance targets until they are measured on the production
EFS class, mount options, data volume, pod count, and thread count.

## Required staging validation

Run on the same NFSv4.1/EFS configuration used by production:

1. Load current marker cardinality plus at least 2× forecast growth.
2. Use at least two pods and the production number of threads per pod.
3. Test cold-cache and warm-cache runs.
4. Mix new messages, live duplicates, completed duplicates, failed retries,
   and stale takeovers.
5. Start at least 50 simultaneous claim attempts for one key; exactly one may
   win.
6. Run simultaneous distinct-key claims; every key must progress independently.
7. Capture p50, p95, and p99 for END check, START check, lock open/acquire,
   locked rechecks, START publication, and END publication.
8. Kill a worker before START publication, after START publication, during
   business processing, and around END publication; verify the documented
   takeover behavior.

Local process tests prove application locking and path scope. Only the staging
test proves the deployed EFS mount, kernel, CSI driver, permissions, and network
behavior.

## Monitoring after cutover

Retain alerts for:

- `Slow idempotency gate operation`;
- `Slow MPS START claim`, including its per-stage timing breakdown;
- EFS I/O, stale-file-handle, permission, and lock errors;
- unexpected marker-gate fail-open events;
- successful END write failures;
- duplicate downstream output indicators.

Dashboard at minimum:

- gate p50/p95/p99 and max;
- each START claim stage p50/p95/p99;
- claim wins versus owned refusals versus stale takeovers;
- EFS client connections, metadata operations, and throughput;
- marker record and message-directory growth.

## Files changed

| File | Responsibility |
|---|---|
| `sqs_service/marker_paths.py` | Stable digest framing and v2 path calculation |
| `sqs_service/mps_manager.py` | Sharded lookup, lazy directories, atomic writes, concurrency, ownership-safe completion, recursive record cleanup |
| `sqs_service/marker_store.py` | File-layout selection in the backend factory |
| `sqs_service/sqs_idempotent_processor.py` | Claim-handle lifecycle delegation through the existing SQS client |
| `consumer_idempotency.py` | Safe local claim-handle release after processing and completion attempts |
| `constant/constant.py` | Validated `MPS_FILE_LAYOUT` service configuration |
| `main.py` | Startup configuration visibility |
| `scripts/migrate_mps_v1_to_v2.py` | Dry-run, execute, and verify migration workflow |
| `scripts/reconcile_mps_v2_to_v1.py` | Safe rollback reconciliation from v2 ENDs to v1 |
| `test/test_mps_file_sharding.py` | Thread, process, search-scope, ownership, failure, and cleanup tests |
| `test/test_migrate_mps_v1_to_v2.py` | Migration safety and idempotency tests |
| `test/test_reconcile_mps_v2_to_v1.py` | Rollback traversal, collision, and reconciliation tests |

## Verification completed in this repository

At the time of implementation:

- full test suite: **157 passed**;
- sharding/concurrency suite: **41 passed**;
- forward migration suite: **17 passed**;
- rollback reconciliation suite: **28 passed**;
- targeted lint across the changed sharding runtime, migration, and test
  files: **passed**;
- Python compilation and both migration CLI help smoke checks: **passed**.

The tests include 50 same-key threads, 50 different-key threads, eight
independent processes, a held kernel lock, atomic-publication failure, stale
takeover, late-owner completion, corrupt START content, search-scope
enforcement, and migration conflict handling.

## Explicit limitations unchanged by sharding

Sharding fixes marker lookup scale; it does not claim exactly-once business
side effects.

- Processing publishes output before END is recorded. A crash in that interval
  can cause a later replay even with correct markers.
- A worker that exceeds the START lease can overlap a takeover worker. The
  ownership token prevents the late worker from deleting the newer START, but
  it cannot undo duplicate external side effects already performed.
- The START lease must exceed the real maximum processing duration. A heartbeat
  or downstream fencing token would be a separate enhancement.
- The current gate catches storage errors and continues processing. Alerting on
  those fail-open events remains mandatory.

These limitations existed before the directory change and should be stated
plainly in the business risk record.
