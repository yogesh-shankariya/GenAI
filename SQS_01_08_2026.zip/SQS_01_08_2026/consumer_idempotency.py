"""
Idempotent-consumption helpers shared by main.py and the test suite.

main.py cannot be imported outside the client environment (it needs
log_util / schema / doc_extract_app), so the idempotency wiring logic
lives here, where it is unit-testable with moto and a temporary marker
store. This module imports only the standard library and sqs_service.

The lifecycle implemented here is the one prescribed by
PROD_READINESS_REVIEW.md section 6, step 1:

    check_duplicates -> mark_processing_start -> process
    (publish happens inside) -> mark_processing_end -> delete

and the skip semantics proven by
test_sqs_idempotency.TestSQSClient10KMessages.test_02:

    duplicate (Scenario A)  -> DELETE the message and move on
    owned     (Scenario B)  -> leave the message ON the queue
    takeover / new (C / D)  -> process normally

Every idempotency call here fails OPEN: if the marker layer errors
unexpectedly, the message is processed normally. Duplicate protection
must never become an outage source.
"""

import json
from typing import Any, Callable, Dict, Tuple


import logging
logger = logging.getLogger("DocMetaLogger.SQS")

# Gate outcomes
PROCESS = "process"                  # Scenario C/D - claim succeeded
SKIP_DUPLICATE = "skip_duplicate"    # Scenario A - done before; safe to delete
SKIP_OWNED = "skip_owned"            # Scenario B - another worker owns it

# Characters the marker store rejects in a trace_id (see
# MarkerStore._validate_id); "__" is the marker-filename separator.
_FORBIDDEN_KEY_SUBSTRINGS = ("__", "/", "\\", "\x00")


def extract_idempotency_key(message: Dict[str, Any]) -> Tuple[str, int]:
    """
    Resolve (trace_id, retry_count) from a raw boto3 message dict
    BEFORE processing, using the same body parsing as
    main.process_sqs_message: JSON body, optional SNS envelope
    ("Message" key), then metadata.traceId.

    Falls back to the SQS MessageId - which stays identical across
    redeliveries of the same message, so dedup still works - when the
    body is malformed or the trace_id would be rejected by the marker
    store.
    """
    trace_id = ""

    try:
        body = json.loads(message["Body"])
        data = json.loads(body["Message"]) if "Message" in body else body
        trace_id = str(data["metadata"]["traceId"])
    except (KeyError, TypeError, ValueError):
        pass

    unusable = (
        not trace_id
        or trace_id in (".", "..")
        or any(bad in trace_id for bad in _FORBIDDEN_KEY_SUBSTRINGS)
    )

    if unusable:
        fallback = message.get("MessageId", "")
        if trace_id:
            logger.warning(
                "trace_id %r is not usable as an idempotency key - "
                "falling back to MessageId %s",
                trace_id,
                fallback,
            )
        trace_id = fallback

    try:
        retry_count = (
            int(message.get("Attributes", {}).get("ApproximateReceiveCount", "1"))
            - 1
        )
    except (TypeError, ValueError):
        retry_count = 0

    return trace_id, max(retry_count, 0)


def idempotency_gate(client, trace_id: str, retry_count: int) -> str:
    """
    Run the pre-processing duplicate check against ``client`` (an
    SQSClient with idempotency enabled; with it disabled the hooks are
    no-ops and this always returns PROCESS).

    Returns SKIP_DUPLICATE (Scenario A - a successful MPS_END exists:
    the message may be deleted), SKIP_OWNED (Scenario B - a live
    MPS_START belongs to another worker: the message must stay on the
    queue), or PROCESS (Scenario C takeover / Scenario D new - the
    START claim succeeded; stale STARTs are replaced inside
    create_start_marker).
    """
    try:
        if client.check_duplicates(trace_id):
            return SKIP_DUPLICATE

        if not client.mark_processing_start(trace_id, retry_count):
            # The claim can also fail because the message COMPLETED between
            # the END-check above and this call (review M1) - re-check so
            # the duplicate is deleted now instead of left to redeliver.
            # Own try/except: the claim already answered definitively, so a
            # failing re-check must degrade to SKIP_OWNED (safe: redeliver),
            # never fall through to the outer fail-open PROCESS.
            try:
                if client.check_duplicates(trace_id):
                    return SKIP_DUPLICATE
            except Exception:
                logger.exception(
                    "Post-claim duplicate re-check failed for %s - "
                    "treating as owned",
                    trace_id,
                )
            return SKIP_OWNED

    except Exception:
        logger.exception(
            "Idempotency gate failed for %s - processing without "
            "duplicate protection",
            trace_id,
        )

    return PROCESS


def mark_processing_end_safe(
    client,
    trace_id: str,
    retry_count: int,
    success: bool,
) -> None:
    """
    Write the MPS_END marker, never raising: on failure the dedup
    memory for this message is lost (a redelivery would reprocess),
    but the message itself must still be acknowledged by the caller.
    """
    try:
        client.mark_processing_end(trace_id, retry_count, success=success)
    except Exception:
        logger.exception("Could not write MPS_END for %s", trace_id)


def make_idempotent_handler(
    client,
    process_fn: Callable[[Dict[str, Any]], bool],
    route_error_fn: Callable[[Dict[str, Any]], Any],
) -> Callable[[Dict[str, Any]], bool]:
    """
    Build the processing_function for
    ParallelSQSProcessor(message_arg="message", delete_on_success=True)
    that runs the same idempotent lifecycle as the serial loop.

    Return contract of the handler: True -> the processor deletes the
    message (duplicates and successes); False -> the processor leaves
    it alone (owned elsewhere -> stays on the queue for redelivery /
    takeover; failures -> route_error_fn has already moved and deleted
    it).

    Note: a SKIP_OWNED skip lands in the processor's "failed" bucket
    (its bool contract has no skip state). That is benign - the
    message is not error-routed and simply redelivers - but expect
    skip events to appear in failed_count during concurrent duplicate
    bursts.
    """

    def _idempotent_handler(message: Dict[str, Any]) -> bool:
        trace_id, retry_count = extract_idempotency_key(message)

        gate = idempotency_gate(client, trace_id, retry_count)
        if gate == SKIP_DUPLICATE:
            logger.info(
                "Duplicate %s already completed - deleting", trace_id
            )
            return True
        if gate == SKIP_OWNED:
            logger.info(
                "Message %s owned by another worker - left on queue",
                trace_id,
            )
            return False

        success = bool(process_fn(message))

        # MPS_END after the publish (inside process_fn), before the
        # delete; a failed END also clears START so retries are fast.
        mark_processing_end_safe(client, trace_id, retry_count, success)

        if not success:
            route_error_fn(message)

        return success

    return _idempotent_handler
