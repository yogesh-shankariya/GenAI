import os
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Final, List, Optional, TypedDict, Dict, Any
import ast


def _require_env(name: str) -> str:
    """Require environment variable to be set, fail loudly if missing."""
    value = os.environ.get(name)
    if value is None:
        raise EnvironmentError(
            f"Required environment variable {name} is not set. "
            f"Check deployment ConfigMap."
        )
    return value


def process_boolean_var(var_name: str) -> bool:
    return True if os.environ.get(var_name, os.environ.get("default_flag_state", "true")).strip().lower() == "true" else False

def process_date_var(var_name: str, default_value: date) -> date:
    raw_value = os.environ.get(var_name, "").strip()
    if not raw_value:
        return default_value
    try:
        return datetime.strptime(raw_value, "%Y-%m-%d").date()
    except ValueError as exc:
        raise ValueError(f"Invalid date for {var_name}: {raw_value}. Expected YYYY-MM-DD") from exc

def process_list_var(var_name: str) -> List[str]:
    raw_value = os.environ.get(var_name, "").strip()

    if not raw_value:
        return []

    try:
        parsed = ast.literal_eval(raw_value)
    except:
        return []

    if not isinstance(parsed, list):
        return []

    return [str(value).strip().upper() for value in parsed if str(value).strip()]


class Constant:

    LOG_LEVEL: Final[str] = os.getenv("LOG_LEVEL", "INFO").upper()

    @classmethod
    def logging_config(cls) -> Dict[str, Any]:
        """
        Build a logging dict that mirrors the former YAML and inserts
        run-time parameters coming from the Deploy ConfigMap.
        """
        return {
            "version": 1,
            "disable_existing_loggers": False,
            "formatters": {
                "simple": {
                    "format": "%(asctime)s - %(name)s - %(levelname)s - %(message)s"
                },
                "json": {
                    "()": "log_util.logger.CdiJsonFormatter",
                    "json_ensure_ascii": False,
                },
            },
            "handlers": {
                "console": {
                    "class": "logging.StreamHandler",
                    "level": cls.LOG_LEVEL,
                    "formatter": "json",
                    "stream": "ext://sys.stdout",
                }
            },
            "loggers": {
                "DocMetaLogger": {
                    "level": cls.LOG_LEVEL,
                    "propagate": True,
                }
            },
            "root": {
                "level": cls.LOG_LEVEL,
                "handlers": ["console"],
            },
        }

    SERVICE_NAME: Final[str] = os.getenv("SERVICE_NAME", "cdi-docmeta-py-service")
    SYNTHESIS_SERVICE_OPERATION : Final[str] = os.environ.get("SYNTHESIS_SERVICE_OPERATION")
    LAST_SERVICE : Final[str] = os.environ.get("LAST_SERVICE")
    DEBUG_MODE: bool = os.environ.get(
        'DEBUG_MODE', '0'
    ).strip().lower() in ('1', 'true', 'yes', 'on')
    MAX_SPAWN_PROCESSES: Final[int] = int(os.environ.get('MAX_SPAWN_PROCESSES', 4))
    MAX_SPAWN_THREADS: Final[int] = int(os.environ.get('MAX_SPAWN_THREADS', 1))
    S3_FETCH_FILE_URL: Final[str] = os.environ['S3_FETCH_FILE_URL']  # ?decrypt={os.environ['S3_DECRYPT']}"
    S3_DECRYPT: Final[str] = os.environ.get('S3_DECRYPT', 'true')
    COMMON_HEADERS = {
        "accept": "application/json",
        "Content-Type": "application/json",
    }
    # Kafka
    KAFKA_URL: Final[str] = os.environ["KAFKA_URL"]
    KAFKA_TOPIC_EXTR: Final[str] = os.environ["KAFKA_TOPIC_EXTR"]
    KAFKA_TOPIC_ERR: Final[str] = os.environ["KAFKA_TOPIC_ERR"]
    KAFKA_TOPIC_OUTPUT: Final[str] = os.environ["KAFKA_TOPIC_OUTPUT"]
    KAFKA_TOPIC_OUTPUT_ERR: Final[str] = os.environ["KAFKA_TOPIC_OUTPUT_ERR"]
    KAFKA_API_TIME_OUT: Final[int] = int(os.environ.get("KAFKA_API_TIME_OUT", 120))

    #LLM
    HORIZON_CLIENT_ID: Final[str] = os.environ["CLIENT_ID"]
    HORIZON_CLIENT_SECRET: Final[str] = os.environ["CLIENT_SECRET"]
    OPENAI_API_KEY: Final[str] = os.environ.get("OPENAI_API_KEY")

    # Thread Pool Configuration
    DEFAULT_WORKERS: Final[int] = int(os.environ.get("DEFAULT_WORKERS", "36"))
    OUTER_CONCURRENCY: Final[int] = 5
    INNER_CONCURRENCY: Final[int] = 5

    # LLM Model Parameters - Default (Mandatory)
    LLM_QOS: Final[str] = os.environ.get("LLM_QOS", "standard")
    LLM_REASONING: Final[str] = os.environ.get("LLM_REASONING", "balanced")
    LLM_PREVIEW: Final[str] = os.environ.get("LLM_PREVIEW", "false")

    # LLM Model Parameters - Phi Check Override (Mandatory)
    PHI_CHECK_QOS: Final[str] = os.environ.get("PHI_CHECK_QOS", "standard")
    PHI_CHECK_REASONING: Final[str] = os.environ.get("PHI_CHECK_REASONING", "balanced")
    PHI_CHECK_PREVIEW: Final[str] = os.environ.get("PHI_CHECK_PREVIEW", "false")

    # S3 Batch Download Configuration
    S3_BATCH_MAX_WORKERS: Final[int] = int(os.environ.get("S3_BATCH_MAX_WORKERS", "10"))
    S3_BATCH_CHUNK_SIZE: Final[int] = int(os.environ.get("S3_BATCH_CHUNK_SIZE", "50"))

    # Feature Flags
    DEFAULT_FLAG_STATE: Final[bool] = os.environ.get('default_flag_state', 'true').strip().lower() == "true"
    FLAGS: dict[str, bool] = {}
    URGENT_APPEAL_ENABLED: Final[bool] = os.environ.get('URGENT_APPEAL_ENABLED', 'true').strip().lower() == "true"

    # DOS Validation Configuration
    DOS_VALIDATION_ENABLED: Final[bool] = os.environ.get("DOS_VALIDATION_ENABLED", "false").strip().lower() == "true"
    DOS_VALIDATION_START_DATE: Final[date] = process_date_var("DOS_VALIDATION_START_DATE", date(date.today().year - 2, 1, 1))
    DOS_VALIDATION_WHITELIST_MNEMONICS: Final[List[str]] = process_list_var("DOS_VALIDATION_WHITELIST_MNEMONICS")

    #AWS
    AWS_S3_REGION: Final[str] = os.environ.get("AWS_S3_REGION")
    AWS_SQS_REGION: Final[str] = os.environ.get("AWS_SQS_REGION")  # Keep for backward compat
    AWS_S3_BUCKET: Final[str] = os.environ.get("AWS_S3_BUCKET")

    #SQS Basic Configuration (required)
    # TEMPORARY HARDCODE (2026-07-20): Emergency fix for incorrect ConfigMap value
    # TODO: Remove this fallback logic once ConfigMap is corrected to 'dev-HOSSYTH_rallm'
    _RAW_INPUT_QUEUE = os.environ.get("SQS_INPUT_QUEUE_NAME", "")
    if _RAW_INPUT_QUEUE == "dev-HOSSYTH_docmeta_history":
        # ConfigMap has wrong value, use hardcoded correct value
        SQS_INPUT_QUEUE_NAME: Final[str] = "dev-HOSSYTH_rallm"
        print(f"⚠️  WARNING: Using hardcoded SQS_INPUT_QUEUE_NAME=dev-HOSSYTH_rallm (ConfigMap has incorrect value)")
    elif _RAW_INPUT_QUEUE:
        # ConfigMap has been fixed or has different value, use it
        SQS_INPUT_QUEUE_NAME: Final[str] = _RAW_INPUT_QUEUE
    else:
        # No env var at all, use hardcoded
        SQS_INPUT_QUEUE_NAME: Final[str] = "dev-HOSSYTH_rallm"
        print(f"⚠️  WARNING: Using hardcoded SQS_INPUT_QUEUE_NAME=dev-HOSSYTH_rallm (no env var found)")

    SQS_OUTPUT_QUEUE_NAME: Final[str] = _require_env("SQS_OUTPUT_QUEUE_NAME")
    SQS_ERROR_QUEUE_NAME: Final[str] = _require_env("SQS_ERROR_QUEUE_NAME")
    SQS_AWS_REGION: Final[str] = _require_env("SQS_AWS_REGION")  # Primary SQS region

    # SQS Idempotency Configuration
    SQS_MPS_PATH: Final[str] = os.environ.get(
        "SQS_MPS_PATH",
        "/tmp/mps_markers",  # Temporary default - use shared volume in prod
    )
    # Idempotency storage backend: "file" (default), "memory" (testing), "redis"
    MPS_BACKEND: Final[str] = os.environ.get("MPS_BACKEND", "file")

    # Redis marker-store connection (used ONLY when MPS_BACKEND=redis;
    # values come from the client's ConfigMap/Secret). Deliberately NOT
    # validated here: import-time validation would crash EVERY pod on a
    # config typo - including file-backend pods that never touch Redis.
    # These constants exist for the startup config dump only;
    # RedisMarkerStore.from_env re-reads the environment itself and
    # validates loudly at boot of redis-opted-in pods.
    REDIS_HOST_NAME: Final[Optional[str]] = os.environ.get("REDIS_HOST_NAME")
    # Raw string on purpose (no int() at import - see above)
    REDIS_PORT_NUMBER: Final[str] = (
        os.environ.get("REDIS_PORT_NUMBER", "").strip() or "6379"
    )
    REDIS_AUTH_TOKEN: Final[Optional[str]] = os.environ.get("REDIS_AUTH_TOKEN")  # secret - never log
    # '' (templated-empty) means unset -> default true, matching from_env
    REDIS_SSL: Final[bool] = (
        (os.environ.get("REDIS_SSL", "").strip().lower() or "true") == "true"
    )

    # SQS Processing Mode
    # "serial" = one message at a time (default, safest)
    # "parallel" = pipelined thread workers (future - requires context-aware logging)
    SQS_PROCESSING_MODE: Final[str] = (
        os.environ.get("SQS_PROCESSING_MODE", "serial").strip().lower()
    )
    SQS_MAX_WORKERS: Final[int] = int(os.environ.get("SQS_MAX_WORKERS", "5"))

    # SQS Operational Settings
    # Must exceed worst-case doc-metadata processing time (no heartbeat)
    SQS_VISIBILITY_TIMEOUT: Final[int] = int(
        os.environ.get("SQS_VISIBILITY_TIMEOUT", "300")  # 5 minutes
    )
    SQS_MAX_RETRIES: Final[int] = int(os.environ.get("SQS_MAX_RETRIES", "2"))

    # SQS Advanced Features (keep existing for backward compatibility)
    SQS_ENABLE_IDEMPOTENCY: Final[bool] = os.environ.get(
        "SQS_ENABLE_IDEMPOTENCY", "false"
    ).strip().lower() == "true"
    SQS_ENABLE_PARALLEL_PROCESSING: Final[bool] = os.environ.get(
        "SQS_ENABLE_PARALLEL_PROCESSING", "false"
    ).strip().lower() == "true"
    SQS_ENABLE_BATCH_OPERATIONS: Final[bool] = os.environ.get(
        "SQS_ENABLE_BATCH_OPERATIONS", "false"
    ).strip().lower() == "true"
    SQS_MPS_STORAGE_PATH: Final[str] = SQS_MPS_PATH  # Alias for backward compat
    SQS_MPS_TIMEOUT_SECONDS: Final[float] = float(
        os.environ.get("SQS_MPS_TIMEOUT_SECONDS", str(4 * 60 * 60))
    )  # 4 hours default

    #DATADOG
    APP_NAME: Final[str] = os.environ["APP_NAME"]


    def __init__(self):
        self.FLAGS = self.get_flags()

    def get_flags(self):
        FLAGS = {}

        FLAGS["EncounterClassExtraction"]         = process_boolean_var("encounter_class_extraction_enabled")
        FLAGS["EncounterServiceExtraction"]       = process_boolean_var("encounter_service_extraction_enabled")
        FLAGS["ReasonForVisitExtraction"]         = process_boolean_var("reason_for_visit_enabled")
        FLAGS["EnctProviderExtraction"]           = process_boolean_var("encounter_providers_extraction_enabled")
        FLAGS["DeceasedDate"]                     = process_boolean_var("deceased_date_extraction_enabled")
        FLAGS["UrgentAppealPipeline"]             = process_boolean_var("urgent_appeal_pipeline_enabled")
        FLAGS["ValidatePatientAddress"]           = process_boolean_var("validate_patient_address_enabled")  # dependent on MemberPipeline
        FLAGS["ValidationPatientPhoneNumber"]     = process_boolean_var("validate_patient_phone_number_enabled")  # dependent on MemberPipeline
        FLAGS["DocClassification"]                = process_boolean_var("validate_doc_classification_enabled")  # parent to DOSOpIp and DOSExtractionLabRadiology
        FLAGS["MemberPipeline"]                   = process_boolean_var("validate_member_pipeline_enabled")  # parent to ValidatePatientAddress and ValidationPatientPhoneNumber
        FLAGS["DOSOpIp"]                          = process_boolean_var("validate_outpatient_inpatient_enabled")
        FLAGS["DOSExtractionLabRadiology"]        = process_boolean_var("validate_lab_radiology_enabled")
        FLAGS["PhiCheck"]                         = process_boolean_var("validate_phi_check")
        FLAGS["PatientNameIdentificationKeyword"] = process_boolean_var("patient_name_identification_keyword")
        FLAGS["NameFPFilter"]                     = process_boolean_var("name_fp_filter_enabled")

        return FLAGS

    @classmethod
    def get_s3_file_url(cls, file_path: str):
        return cls.S3_FETCH_FILE_URL + f"?decrypt={cls.S3_DECRYPT}" + "&filePath=" + file_path


class ErrorCodes(Enum):
    INTERNAL_SERVER_ERROR = 500
    S3_DOWNLOAD_FAILED = 501
    S3_UPLOAD_FAILED = 508
    LLM_EXECUTION_FAILED = 502
    LLM_RESPONSE_PROCESSING_FAILED = 503
    JAVA_API_FAILED = 504
    BAD_FILE_NAME = 505
    MISSING_PROFILE_FIELDS = 506
    MISSING_REQUIRED_FIELDS = 507

class ScriptResponsetoPy(TypedDict):
    trace_id: str
    status_code: int
    err_msg: str
    data: List[str]
