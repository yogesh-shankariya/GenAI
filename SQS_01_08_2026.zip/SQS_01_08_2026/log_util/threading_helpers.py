import contextvars
from concurrent.futures import ThreadPoolExecutor

class ContextThreadPoolExecutor(ThreadPoolExecutor):
    """Propagate ContextVars (e.g. trace_id) to every submitted job."""
    def submit(self, fn, *args, **kwargs):
        ctx = contextvars.copy_context()
        return super().submit(ctx.run, fn, *args, **kwargs)
