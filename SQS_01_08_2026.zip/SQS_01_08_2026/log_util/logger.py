# log_util/logger.py
# --------------------------------------------------------------------------- #
# Imports
# --------------------------------------------------------------------------- #
import logging
import logging.config
import os
from datetime import datetime
from typing import Optional, Dict, Any
import threading
import yaml
from contextvars import ContextVar
from pythonjsonlogger.json import JsonFormatter

from constant import Constant
from schema import (
    KafkaContextMapLog,
    KafkaMarkerEnum,
    KafkaLogFormat,
)

# --------------------------------------------------------------------------- #
# Context-local storage
# --------------------------------------------------------------------------- #

_CONTEXT_MAP_CTX: ContextVar[Optional[KafkaContextMapLog]] = ContextVar(
    "context_map", default=None
)


def set_context_map(ctx: KafkaContextMapLog) -> None:
    # ctx may legitimately be None/empty on early error paths - dict(None)
    # raised inside the error handler itself and skipped error routing
    # (review H2), so treat None as an empty context
    _CONTEXT_MAP_CTX.set(dict(ctx or {}))

def clear_context_map() -> None:
    _CONTEXT_MAP_CTX.set(None)

# --------------------------------------------------------------------------- #
# Filters
# --------------------------------------------------------------------------- #
class ContextFilter(logging.Filter):
    """
    Inject
        a) trace_id
        b) contextMap
    into every LogRecord.  The formatter then simply reads those attributes.
    """
    def filter(self, record: logging.LogRecord) -> bool:
        record.contextMap = _CONTEXT_MAP_CTX.get() or {}
        return True


# --------------------------------------------------------------------------- #
# Formatter
# --------------------------------------------------------------------------- #
class CdiJsonFormatter(JsonFormatter):
    """Create log lines that match the Java/Kafka structure."""
    def add_fields(self, log_record: dict, record: logging.LogRecord,
                   message_dict: dict) -> None:  # type: ignore[override]
        super().add_fields(log_record, record, message_dict)

        # ---- time --------------------------------------------------------- #
        epoch = record.created
        dt    = datetime.utcfromtimestamp(epoch)
        log_record["instant"]   = {"epochSecond": int(epoch)}
        log_record["timestamp"] = dt.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "+0000"
        log_record["timezone"]  = "UTC"

        # ---- meta --------------------------------------------------------- #
        log_record["level"]   = record.levelname
        log_record["thread"]  = getattr(record, "threadName",
                                        threading.current_thread().name)
        log_record["service"] = Constant.SERVICE_NAME

        # ---- context / trace ---------------------------------------------- #
        if getattr(record, "contextMap", {}):
            log_record["contextMap"] = dict(record.contextMap)

        log_record.pop("asctime", None)      # we supply our own timestamp

# --------------------------------------------------------------------------- #
# Helper
# --------------------------------------------------------------------------- #
def _attach_filter_to_logger_and_handlers(
    logger: logging.Logger, flt: logging.Filter
) -> None:
    """Make sure the filter is on the logger itself *and* on all handlers."""
    if flt not in logger.filters:
        logger.addFilter(flt)

    for h in logger.handlers:
        if flt not in h.filters:
            h.addFilter(flt)

# --------------------------------------------------------------------------- #
# Setup
# --------------------------------------------------------------------------- #
def setup_logger(config_dict: Optional[Dict[str, Any]] = None) -> logging.Logger:
    """
    Register the logging configuration and inject ContextFilter.
    If *config_dict* is omitted we fall back to Constant.logging_config().
    """
    try:
        # 1) configuration -------------------------------------------------- #
        if config_dict is None:
            config_dict = Constant.logging_config()

        logging.config.dictConfig(config_dict)

        # 2) attach ContextFilter everywhere -------------------------------- #
        ctx_filter = ContextFilter()

        root_logger = logging.getLogger()
        _attach_filter_to_logger_and_handlers(root_logger, ctx_filter)

        doc_logger = logging.getLogger("DocMetaLogger")
        _attach_filter_to_logger_and_handlers(doc_logger, ctx_filter)

    except Exception as exc:                                      # pragma: no cover
        logging.basicConfig(level=logging.INFO,
                            format="%(levelname)s: %(message)s")
        logging.getLogger(__name__).exception(
            "Failed to initialise logging configuration - fallback used: %s", exc
        )

    return logging.getLogger("DocMetaLogger")

# --------------------------------------------------------------------------- #
# Kafka-style helper
# --------------------------------------------------------------------------- #
def kafka_msg_logger(
    msg: str,
    context_map: KafkaContextMapLog,
    marker: KafkaMarkerEnum,        # Enum -> .value will be written below
) -> None:
    """
    Emit a log line for the Kafka collector.
    Envelope is identical to normal logs; only "marker" distinguishes it.
    """
    set_context_map(context_map)                             # keep ctx for rest of thread

    logger = logging.getLogger("DocMetaLogger")

    extra: KafkaLogFormat = {
        "contextMap": context_map,
        "marker": marker.value,                              # "KAFKA_MESSAGE_SUCCESS" etc.
    }

    logger.info(msg, extra=extra)
