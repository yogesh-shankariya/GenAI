from __future__ import annotations

import sys
import pathlib
import importlib
import concurrent.futures as _cf

# --------------------------------
#  Logger
# --------------------------------
from .logger import setup_logger
logger = setup_logger()


# --------------------------------
#  Thread-local context executor
# --------------------------------
from .threading_helpers import ContextThreadPoolExecutor
_cf.ThreadPoolExecutor = ContextThreadPoolExecutor         # global patch


# --------------------------------
#  Ensure  app/src  is importable
# --------------------------------
PACKAGE_DIR  = pathlib.Path(__file__).resolve().parent     # …/log_util
PROJECT_DIR  = PACKAGE_DIR.parent                          # project root
DOC_META_APP_DIR = PROJECT_DIR / "app"

if str(DOC_META_APP_DIR) not in sys.path:
    sys.path.insert(0, str(DOC_META_APP_DIR))

try:
    import src    # noqa: F401
except ModuleNotFoundError:
    src_pkg = importlib.import_module("app.src")
    sys.modules["src"] = src_pkg


# --------------------------------
#  Export
# --------------------------------
__all__ = ["logger"]
