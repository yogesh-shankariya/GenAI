# /v2/tool/chats fixtures

> **PROVISIONAL — hand-authored, NOT real captures.**
> The M0 probe (`src/horizon/probe_tool_chats.py`) has not been executed yet
> (client environment required). These fixtures encode the provisional wire
> contract documented in `docs/tool_chats_contract.md` and implemented in
> `src/horizon/adapters.py`, so `tests/test_chat_horizon.py` exercises the
> adapter logic today. After running the probe, REPLACE these files with the
> redacted real captures and reconcile the adapters + tests.

Each file is a full 200-response **body** as returned by the endpoint (the
probe script additionally wraps its captures as `{"status": ..., "body": ...}`;
unwrap when replacing these).

| File | Exercises |
|---|---|
| `probe_a_tool_call.json` | tool-call turn: assistant message with `tool_calls` array, dict arguments, explicit id (OPEN-1) |
| `probe_a_tool_call_string_args.json` | arguments as a JSON **string**, no id (adapter must `json.loads` and synthesize an id) |
| `probe_b_plain_text.json` | plain text turn, no tool calls |
| `probe_c_multi_tool_call.json` | two tool calls in one response (OPEN-3) |
| `malformed_tool_call.json` | degenerate tool call (missing name, garbage args) — adapter degrades to plain text, never raises |

No PHI: all fixtures use the harmless weather-tool probe conversation.
