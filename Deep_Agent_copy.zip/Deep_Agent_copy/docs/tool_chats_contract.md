# `/v2/tool/chats` Contract (Milestone 0 deliverable)

> **STATUS: PROVISIONAL — probe not yet executed.**
> The M0 probe (`src/horizon/probe_tool_chats.py`) requires the client
> environment (populated `.env`, network access to the Horizon gateway) and has
> **not** been run yet. The shapes below are the provisional contract currently
> implemented in `src/horizon/adapters.py` and mirrored by the fixtures in
> `tests/fixtures/tool_chats_samples/`. Finalize this document from the real
> probe captures before production use.

## How to finalize (client environment)

1. Populate `.env` (see `.env.example`).
2. Run `python -m src.horizon.probe_tool_chats` — it executes Probes A–D and
   writes redacted captures to `tests/fixtures/tool_chats_samples/`.
3. Fill in the **Confirmed** column below from the captures.
4. Update `src/horizon/adapters.py` (the ONLY module encoding these shapes)
   and the fixtures, then re-run `pytest tests/test_chat_horizon.py`.

## Contract items

| # | Question | Provisional answer (coded today) | Confirmed (after probe) |
|---|---|---|---|
| OPEN-1 | Message shape the model uses to **make a tool call** | Assistant message with a `tool_calls` array: `{"type": "message", "role": "assistant", "content": "", "tool_calls": [{"id": "call_…", "name": "…", "arguments": {…}}]}`. Parser also tolerates a standalone `{"type": "tool_call", …}` message and string-encoded `arguments`. | _pending probe A_ |
| OPEN-2 | Message shape accepted to **return a tool result** | `{"type": "tool_result", "tool_call_id": "call_…", "content": "…"}` (candidate 1). Candidate 2 (`role: "tool"` message) is tried by the probe if 1 fails. | _pending probe B_ |
| OPEN-3 | Can one response carry **multiple tool calls**? | Assumed yes (parser collects every well-formed call). If the probe shows only one call per response, fan-out degrades gracefully to serial; optionally add "Issue one task call per turn." to the orchestrator prompt. | _pending probe C_ |
| OPEN-4 | Is a **`system` role** accepted and respected? | Assumed yes (`SYSTEM_ROLE_SUPPORTED = True` in `adapters.py`). If not, flip the constant — system content is then merged into the first user message as `[SYSTEM]…[USER]…`. | _pending probe D_ |

## Additional wire facts (from internal docs, plan §2)

- Request body: `{"tools": [{"type": "adhoc", "name", "description", "parameters"}], "messages": [{"type": "message", "role", "content"}]}`.
- The docs sample `"parameters": {"^(.*)$": null}` is a placeholder meaning
  "any JSON-schema object" — a real JSON schema is sent.
- Query params `qos` / `reasoning` / `preview` follow the `llm_client.py`
  branching; defaults for this project: `qos=accurate, preview=false,
  reasoning=false`.
- Missing call ids: the adapter synthesizes `call_<uuid4-12hex>` — LangGraph
  requires `tool_call_id` round-tripping on the matching `ToolMessage`.

## Response-parsing heuristic (also provisional)

The adapter treats `raw["messages"][sent_count:]` as model-authored when the
API echoes the conversation, else the last message. Confirm which behavior the
API exhibits from the probe captures and simplify if possible.

## Fixture inventory (`tests/fixtures/tool_chats_samples/`)

All current fixtures are **hand-authored to the provisional contract** (see
that directory's README). Replace with redacted real captures after M0:

- `probe_a_tool_call.json` — tool-call turn (OPEN-1)
- `probe_a_tool_call_string_args.json` — same, arguments as a JSON string
- `probe_b_plain_text.json` — plain text continuation after a tool result
- `probe_c_multi_tool_call.json` — two tool calls in one response (OPEN-3)
- `malformed_tool_call.json` — degenerate tool call (parser must not raise)
