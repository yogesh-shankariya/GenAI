"""Pure adapters between LangChain messages/tools and the Horizon /v2/tool/chats wire format.

This module is the ONLY place in the codebase where the Milestone-0-dependent
message shapes live (plan §4, §5.3, §10):

- OPEN-1: the message shape the model uses to MAKE a tool call.
- OPEN-2: the message shape the API accepts for RETURNING a tool result.
- OPEN-4: whether a ``system`` role is accepted.

PROVISIONAL CONTRACT
--------------------
The probe (``src/horizon/probe_tool_chats.py``) has not been executed yet — it
requires the client environment. Until then this module encodes a provisional
contract, recorded in ``docs/tool_chats_contract.md``:

- Tool-call turn (OPEN-1): an assistant message carrying a ``tool_calls`` array::

      {"type": "message", "role": "assistant", "content": "",
       "tool_calls": [{"id": "call_abc", "name": "...", "arguments": {...}}]}

- Tool-result turn (OPEN-2)::

      {"type": "tool_result", "tool_call_id": "call_abc", "content": "..."}

- System role (OPEN-4): assumed supported (``SYSTEM_ROLE_SUPPORTED = True``).

After running the probe, update ONLY this module (plus the fixtures under
``tests/fixtures/tool_chats_samples/`` and the contract doc). Nothing outside
this module may depend on the wire shapes.

The response parser is deliberately tolerant: it accepts tool-call arguments as
a dict or a JSON string, accepts several id/argument key spellings, and NEVER
raises on a malformed tool call — it degrades to a plain text ``AIMessage`` so
the deep agent can re-prompt (plan §5.3).
"""

import json
import logging
import uuid
from typing import Any, Dict, List, Optional, Sequence

from langchain_core.messages import (
    AIMessage,
    BaseMessage,
    HumanMessage,
    SystemMessage,
    ToolMessage,
)
from langchain_core.utils.function_calling import convert_to_openai_tool

logger = logging.getLogger("llm_service")

# OPEN-4 (provisional): flip to False if Probe D shows the API rejects a
# system role; lc_messages_to_horizon then merges system content into the
# first user message.
SYSTEM_ROLE_SUPPORTED = True

# Key spellings tolerated when parsing tool calls out of a response.
_TOOL_CALL_ID_KEYS = ("id", "tool_call_id", "call_id")
_TOOL_CALL_ARGS_KEYS = ("arguments", "args", "input", "parameters")


def _generate_call_id() -> str:
    """LangGraph requires a tool_call_id; synthesize one if the API has none."""
    return f"call_{uuid.uuid4().hex[:12]}"


def _content_to_text(content: Any) -> str:
    """Flatten LangChain message content (str or content blocks) to plain text."""
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, str):
                parts.append(block)
            elif isinstance(block, dict):
                text = block.get("text")
                if isinstance(text, str):
                    parts.append(text)
        return "".join(parts)
    return str(content)


def lc_tool_to_adhoc(tool: Any) -> Dict[str, Any]:
    """Convert a LangChain tool (BaseTool / @tool fn / dict) to an adhoc tool dict.

    Uses ``convert_to_openai_tool`` to obtain ``{name, description, parameters}``
    and re-wraps into the Horizon ``adhoc`` shape (plan §5.3).
    """
    if isinstance(tool, dict) and tool.get("type") == "adhoc":
        return tool  # already in wire format

    function = convert_to_openai_tool(tool)["function"]
    return {
        "type": "adhoc",
        "name": function["name"],
        "description": function.get("description") or function["name"],
        "parameters": function.get(
            "parameters", {"type": "object", "properties": {}}
        ),
    }


def lc_message_to_horizon(msg: BaseMessage) -> Dict[str, Any]:
    """Convert one LangChain message to a Horizon wire message.

    System-role merging (when ``SYSTEM_ROLE_SUPPORTED`` is False) is a
    list-level concern handled by :func:`lc_messages_to_horizon`.
    """
    if isinstance(msg, SystemMessage):
        return {
            "type": "message",
            "role": "system",
            "content": _content_to_text(msg.content),
        }

    if isinstance(msg, HumanMessage):
        return {
            "type": "message",
            "role": "user",
            "content": _content_to_text(msg.content),
        }

    if isinstance(msg, AIMessage):
        if msg.tool_calls:
            # OPEN-1 (provisional): assistant message with a tool_calls array.
            return {
                "type": "message",
                "role": "assistant",
                "content": _content_to_text(msg.content),
                "tool_calls": [
                    {
                        "id": tc.get("id") or _generate_call_id(),
                        "name": tc["name"],
                        "arguments": tc.get("args") or {},
                    }
                    for tc in msg.tool_calls
                ],
            }
        return {
            "type": "message",
            "role": "assistant",
            "content": _content_to_text(msg.content),
        }

    if isinstance(msg, ToolMessage):
        # OPEN-2 (provisional): dedicated tool_result message carrying the id.
        return {
            "type": "tool_result",
            "tool_call_id": msg.tool_call_id,
            "content": _content_to_text(msg.content),
        }

    # Fallback for unknown message types: send as user text so the request
    # remains valid rather than failing the whole run.
    logger.warning("Unknown message type %s; sending as user text.", type(msg))
    return {
        "type": "message",
        "role": "user",
        "content": _content_to_text(msg.content),
    }


def lc_messages_to_horizon(messages: Sequence[BaseMessage]) -> List[Dict[str, Any]]:
    """Convert a LangChain message list to the Horizon ``messages`` array.

    If ``SYSTEM_ROLE_SUPPORTED`` is False (per Probe D), system content is
    merged into the first user message as::

        [SYSTEM]\\n<system>\\n\\n[USER]\\n<user>
    """
    if SYSTEM_ROLE_SUPPORTED:
        return [lc_message_to_horizon(m) for m in messages]

    system_texts = [
        _content_to_text(m.content) for m in messages if isinstance(m, SystemMessage)
    ]
    converted: List[Dict[str, Any]] = []
    system_pending = "\n\n".join(t for t in system_texts if t)
    for msg in messages:
        if isinstance(msg, SystemMessage):
            continue
        wire = lc_message_to_horizon(msg)
        if system_pending and wire.get("role") == "user":
            wire["content"] = (
                f"[SYSTEM]\n{system_pending}\n\n[USER]\n{wire['content']}"
            )
            system_pending = ""
        converted.append(wire)

    if system_pending:
        # No user message to merge into — prepend a synthetic one.
        converted.insert(
            0,
            {"type": "message", "role": "user", "content": f"[SYSTEM]\n{system_pending}"},
        )
    return converted


def _first_present(d: Dict[str, Any], keys: Sequence[str]) -> Any:
    for key in keys:
        if key in d:
            return d[key]
    return None


def _parse_tool_call(raw_call: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    """Parse one raw tool-call dict into LangChain's {name, args, id} shape.

    Returns None if the call is malformed (missing name, unparseable args) —
    callers degrade to a plain text message, never an exception.
    """
    if not isinstance(raw_call, dict):
        return None

    name = raw_call.get("name") or raw_call.get("tool_name")
    if not name or not isinstance(name, str):
        return None

    args = _first_present(raw_call, _TOOL_CALL_ARGS_KEYS)
    if args is None:
        args = {}
    if isinstance(args, str):
        # Arguments arriving as a JSON string must be json.loads-ed (plan §5.3).
        try:
            args = json.loads(args)
        except (json.JSONDecodeError, ValueError):
            logger.warning("Tool call '%s' has unparseable string arguments.", name)
            return None
    if not isinstance(args, dict):
        return None

    call_id = _first_present(raw_call, _TOOL_CALL_ID_KEYS)
    if not call_id or not isinstance(call_id, str):
        call_id = _generate_call_id()

    return {"name": name, "args": args, "id": call_id}


def _extract_raw_tool_calls(message: Dict[str, Any]) -> List[Dict[str, Any]]:
    """Collect candidate raw tool-call dicts from one wire message.

    Tolerates both provisional shapes: an assistant message with a
    ``tool_calls`` array, and a standalone ``{"type": "tool_call", ...}``
    message.
    """
    if message.get("type") == "tool_call":
        return [message]
    tool_calls = message.get("tool_calls")
    if isinstance(tool_calls, list):
        return [c for c in tool_calls if isinstance(c, dict)]
    return []


def horizon_response_to_ai_message(
    raw: Any, sent_count: Optional[int] = None
) -> AIMessage:
    """Convert a raw /v2/tool/chats response body into an ``AIMessage``.

    - Model-authored messages are ``raw["messages"][sent_count:]`` when the API
      echoes the conversation; otherwise the last message. (Provisional
      heuristic — pin down after M0.)
    - Plain text turn  → ``AIMessage(content=text)``.
    - Tool-call turn   → ``AIMessage(content=..., tool_calls=[...])`` with dict
      args and a call id (synthesized when the API supplies none).
    - Malformed/absent tool calls → plain ``AIMessage`` (deepagents will
      re-prompt); this function NEVER raises on response content.
    """
    if not isinstance(raw, dict) or not isinstance(raw.get("messages"), list):
        logger.warning("Unexpected /v2/tool/chats response shape; returning empty message.")
        return AIMessage(content="")

    messages = [m for m in raw["messages"] if isinstance(m, dict)]
    if not messages:
        return AIMessage(content="")

    if sent_count is not None and len(messages) > sent_count:
        model_messages = messages[sent_count:]
    else:
        model_messages = messages[-1:]

    texts: List[str] = []
    tool_calls: List[Dict[str, Any]] = []
    for message in model_messages:
        content = message.get("content")
        if isinstance(content, str) and content:
            texts.append(content)
        for raw_call in _extract_raw_tool_calls(message):
            parsed = _parse_tool_call(raw_call)
            if parsed is not None:
                tool_calls.append(parsed)
            else:
                logger.warning(
                    "Dropping malformed tool call in response; returning text only."
                )

    text = "\n".join(texts)
    if tool_calls:
        return AIMessage(content=text, tool_calls=tool_calls)
    return AIMessage(content=text)
