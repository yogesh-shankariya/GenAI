"""Diagnostic probe for /v2/tool/chats (plan §4 — Milestone 0).

Run ONCE against real infra **in the client environment only** (requires a
populated ``.env``); commit the captured (redacted) responses to
``tests/fixtures/tool_chats_samples/`` and record the resulting contract in
``docs/tool_chats_contract.md``. Then finalize ``src/horizon/adapters.py``.

The probe answers:

- OPEN-1 (Probe A): the exact message shape the model uses to make a tool call.
- OPEN-2 (Probe B): the message shape the API accepts for returning a tool
  result (candidates tried in order; check the internal API docs' message
  union first!).
- OPEN-3 (Probe C): whether one response can carry multiple tool calls.
- OPEN-4 (Probe D): whether a ``system`` role is accepted (200) and respected.

Usage::

    python -m src.horizon.probe_tool_chats [--output-dir tests/fixtures/tool_chats_samples]

The probe uses a harmless weather tool — no PHI is sent.
"""

import argparse
import json
import os
from pathlib import Path

import requests
from dotenv import load_dotenv

from src.config import build_token_manager, load_config

load_dotenv()

WEATHER_TOOL = {
    "type": "adhoc",
    "name": "get_weather",
    "description": "Get the current weather for a city",
    "parameters": {
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    },
}

# Candidate tool-result shapes for Probe B, tried in order until one returns
# 200 and a sensible natural-language continuation. Candidate 3 is whatever
# the internal API docs' message-union says — check them first and add it here.
TOOL_RESULT_CANDIDATES = [
    lambda call_id: {
        "type": "tool_result",
        "tool_call_id": call_id,
        "content": "72F, sunny",
    },
    lambda call_id: {"type": "message", "role": "tool", "content": "72F, sunny"},
]


def post(payload, token, base_url, params):
    r = requests.post(
        f"{base_url}/v2/tool/chats",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        params=params,
        json=payload,
        timeout=(10, 300),
    )
    print(r.status_code)
    try:
        body = r.json()
    except ValueError:
        body = {"_non_json_body": r.text[:2000]}
    print(json.dumps(body, indent=2))
    return r.status_code, body


def save_capture(output_dir: Path, name: str, status: int, body) -> None:
    """Persist a redacted capture (request ids / tokens never appear in bodies)."""
    output_dir.mkdir(parents=True, exist_ok=True)
    capture = {"status": status, "body": body}
    path = output_dir / f"{name}.json"
    path.write_text(json.dumps(capture, indent=2), encoding="utf-8")
    print(f"saved {path}")


def find_tool_call_message(body):
    """Best-effort search for the tool-call turn in a Probe A response.

    Shape is exactly what OPEN-1 asks; inspect the raw capture by hand as well.
    """
    for message in reversed(body.get("messages", [])):
        if not isinstance(message, dict):
            continue
        if message.get("type") == "tool_call" or message.get("tool_calls"):
            return message
    return None


def extract_call_id(tool_call_message):
    if tool_call_message is None:
        return None
    if tool_call_message.get("type") == "tool_call":
        return tool_call_message.get("id") or tool_call_message.get("tool_call_id")
    calls = tool_call_message.get("tool_calls") or []
    if calls and isinstance(calls[0], dict):
        return calls[0].get("id") or calls[0].get("tool_call_id")
    return None


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        default="tests/fixtures/tool_chats_samples",
        help="where to write the redacted captures",
    )
    args = parser.parse_args()
    output_dir = Path(args.output_dir)

    config = load_config()
    base_url = config["horizon_base_url"]
    token_manager = build_token_manager(config)
    token = token_manager.get_token()
    params = {"qos": config["qos"], "reasoning": config["reasoning"]}

    # ------------------------------------------------------------------
    # Probe A (answers OPEN-1): does the model emit a structured tool-call
    # message, and what does it look like?
    # ------------------------------------------------------------------
    payload_a = {
        "tools": [WEATHER_TOOL],
        "messages": [
            {
                "type": "message",
                "role": "user",
                "content": "What is the weather in Fresno right now? Use the tool.",
            }
        ],
    }
    status_a, body_a = post(payload_a, token, base_url, params)
    save_capture(output_dir, "probe_a_tool_call", status_a, body_a)

    tool_call_message = find_tool_call_message(body_a)
    call_id = extract_call_id(tool_call_message)
    print(f"Probe A tool-call message: {tool_call_message}")
    print(f"Probe A call id: {call_id}")

    # ------------------------------------------------------------------
    # Probe B (answers OPEN-2): append the captured tool-call message plus a
    # tool-result candidate; does the model consume it and answer naturally?
    # ------------------------------------------------------------------
    if tool_call_message is not None:
        for i, candidate in enumerate(TOOL_RESULT_CANDIDATES, start=1):
            payload_b = {
                "tools": [WEATHER_TOOL],
                "messages": payload_a["messages"]
                + [tool_call_message, candidate(call_id)],
            }
            status_b, body_b = post(payload_b, token, base_url, params)
            save_capture(output_dir, f"probe_b_tool_result_candidate_{i}", status_b, body_b)
            if status_b == 200:
                print(f"Probe B candidate {i} accepted (verify the continuation!)")
                break
    else:
        print("Probe B skipped: no tool-call message captured in Probe A.")

    # ------------------------------------------------------------------
    # Probe C (answers OPEN-3): does one response carry multiple tool calls?
    # ------------------------------------------------------------------
    payload_c = {
        "tools": [WEATHER_TOOL],
        "messages": [
            {
                "type": "message",
                "role": "user",
                "content": (
                    "What is the weather in Fresno AND in Sacramento right now? "
                    "Use the tool for each city."
                ),
            }
        ],
    }
    status_c, body_c = post(payload_c, token, base_url, params)
    save_capture(output_dir, "probe_c_multi_tool_call", status_c, body_c)

    # ------------------------------------------------------------------
    # Probe D (answers OPEN-4): is a system role accepted (200) and respected?
    # ------------------------------------------------------------------
    payload_d = {
        "tools": [WEATHER_TOOL],
        "messages": [
            {"type": "message", "role": "system", "content": "Answer in French."},
            {
                "type": "message",
                "role": "user",
                "content": "What is the capital of Spain?",
            },
        ],
    }
    status_d, body_d = post(payload_d, token, base_url, params)
    save_capture(output_dir, "probe_d_system_role", status_d, body_d)

    print(
        "\nNext steps: record findings in docs/tool_chats_contract.md, update "
        "src/horizon/adapters.py and the fixtures, then re-run the unit tests."
    )


if __name__ == "__main__":
    main()
