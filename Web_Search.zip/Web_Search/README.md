# Tavily Search

Reads a query from a text file and saves Tavily's complete response as JSON.
The JSON includes the generated `answer` and the supporting `results`.

## Setup

Install the Tavily Python package:

```bash
pip install tavily-python
```

Add the API key to `.env`:

```env
TAVILY_API_KEY=your_tavily_api_key
```

Add the search query to `input.txt`, for example:

```text
Identify the official hospital name associated with the following address and phone number: 4747 Arapahoe Avenue, Boulder, CO 80303-1131; 303-415-7200. Return only the hospital name.
```

## Run without a domain filter

Search the entire web:

```bash
python tavily_search.py
```

The response is written to `output.json`.

## Run with one domain

Search only the official NPPES NPI Registry:

```bash
python tavily_search.py \
  --domain npiregistry.cms.hhs.gov
```

## Run with multiple domains

Repeat `--domain` for each allowed website:

```bash
python tavily_search.py \
  --domain npiregistry.cms.hhs.gov \
  --domain medicare.gov \
  --domain data.cms.gov
```

## Use custom input and output files

```bash
python tavily_search.py my_query.txt my_response.json
```

Domain filters can also be used with custom files:

```bash
python tavily_search.py my_query.txt my_response.json \
  --domain npiregistry.cms.hhs.gov
```

