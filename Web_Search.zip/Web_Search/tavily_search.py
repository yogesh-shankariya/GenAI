import argparse
import json
import os
from pathlib import Path
from typing import Any

from tavily import TavilyClient


BASE_DIR = Path(__file__).resolve().parent
DEFAULT_ENV_FILE = BASE_DIR / ".env"
DEFAULT_INPUT_FILE = BASE_DIR / "input.txt"
DEFAULT_OUTPUT_FILE = BASE_DIR / "output.json"


def load_api_key(env_file: str | Path = DEFAULT_ENV_FILE) -> str:
    """Load TAVILY_API_KEY from the environment or a local .env file."""

    api_key = os.environ.get("TAVILY_API_KEY", "").strip()
    if api_key:
        return api_key

    path = Path(env_file)
    if not path.exists():
        raise FileNotFoundError(f"Environment file not found: {path}")

    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue

        name, value = line.split("=", 1)
        if name.strip() == "TAVILY_API_KEY":
            api_key = value.strip().strip("\"'")
            if api_key:
                return api_key

    raise ValueError(f"TAVILY_API_KEY was not found in {path}")


def search(
    query: str,
    api_key: str | None = None,
    include_domains: list[str] | None = None,
) -> dict[str, Any]:
    """Send one text query to Tavily and return its complete response."""

    query = query.strip()
    if not query:
        raise ValueError("The input query is empty.")

    client = TavilyClient(api_key=api_key or load_api_key())
    search_options: dict[str, Any] = {
        "query": query,
        "include_answer": "advanced",
        "search_depth": "advanced",
    }
    if include_domains:
        search_options["include_domains"] = include_domains

    return client.search(
        **search_options,
    )


def search_from_file(
    input_file: str | Path = DEFAULT_INPUT_FILE,
    output_file: str | Path = DEFAULT_OUTPUT_FILE,
    env_file: str | Path = DEFAULT_ENV_FILE,
    include_domains: list[str] | None = None,
) -> dict[str, Any]:
    """Read a query from text, search Tavily, and save the response as JSON."""

    input_path = Path(input_file)
    output_path = Path(output_file)
    query = input_path.read_text(encoding="utf-8").strip()

    response = search(
        query,
        api_key=load_api_key(env_file),
        include_domains=include_domains,
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    output_path.write_text(
        json.dumps(response, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    return response


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Read a Tavily query from a text file and write JSON output."
    )
    parser.add_argument(
        "input_file",
        nargs="?",
        default=DEFAULT_INPUT_FILE,
        help="Text file containing the query (default: input.txt)",
    )
    parser.add_argument(
        "output_file",
        nargs="?",
        default=DEFAULT_OUTPUT_FILE,
        help="JSON response file (default: output.json)",
    )
    parser.add_argument(
        "--domain",
        action="append",
        dest="domains",
        help=(
            "Restrict results to this domain. Repeat for multiple domains, "
            "for example: --domain npiregistry.cms.hhs.gov"
        ),
    )
    args = parser.parse_args()

    search_from_file(
        args.input_file,
        args.output_file,
        include_domains=args.domains,
    )
    print(f"Response saved to {Path(args.output_file).resolve()}")


if __name__ == "__main__":
    main()
