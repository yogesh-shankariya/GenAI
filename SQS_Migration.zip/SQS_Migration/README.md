# SQS Layer — cdi-docextract-py-service

SQS client library (`sqs_service/`), the doc-extract SQS/Kafka consumer
entrypoint (`main.py`), and a test harness for ingesting bulk test
messages (`test/ingest_messages.py`).

The consumer runs on Kubernetes in the client environment, where the
`log_util`, `schema`, `doc_extract_app`, and `logger_config.yaml`
dependencies exist. The `sqs_service/` library and the whole test suite
also run standalone on a developer machine (stdlib logging fallback,
moto-mocked SQS — **no real AWS calls**).

> A full production-readiness review with all fixed defects and open
> architecture decisions is in [REVIEW_FINDINGS.md](REVIEW_FINDINGS.md).
> The 2026-07-27 production-readiness review of the `sqs_service`
> library, with all fixes applied, is in
> [PROD_READINESS_REVIEW.md](PROD_READINESS_REVIEW.md).
> For the complete system documentation — architecture, idempotency
> explained from first principles with diagrams, current status, and
> industry best practices — see
> [IDEMPOTENT_SQS_PROCESSING.md](IDEMPOTENT_SQS_PROCESSING.md).

## Layout

| Path | What |
|------|------|
| `sqs_service/sqs_idempotent_processor.py` | `SQSClient` — send/receive/delete (+batch, chunked to AWS limits), queue attributes, purge, MPS-based idempotency |
| `sqs_service/mps_manager.py` | Marker-file idempotency (START/END markers, crash takeover, kernel fcntl locking) |
| `sqs_service/marker_store.py` | `MarkerStore` port + `InMemoryMarkerStore` — pluggable idempotency storage (files today, Redis/DynamoDB adapters drop in) |
| `sqs_service/sqs_parallel_processor.py` | Thread / process / asyncio parallel consumption helpers |
| `main.py` | Consumer entrypoint (client environment only) |
| `test/message_factory.py` | **Single source of truth** for a consumer-contract-valid test message |
| `test/ingest_messages.py` | The 100-message ingestion harness (mock + live modes) |
| `test/test_mps_manager.py`, `test/test_sqs_client_moto.py` | Local test suite (no AWS) |
| `test/purge_queue.py` | Purge a queue and wait until actually empty (`RUN_LIVE=1` gated) |

## Local setup (no AWS access needed)

```bash
python3 -m venv venv && source venv/bin/activate
pip install -r requirements-dev.txt
cp .env.example .env        # defaults are fine for local runs

# All tests run against moto (in-process fake SQS)
pytest test/ -v             # 105 pass, 7 live-only tests skip

# The 100-message ingestion test, fully local:
python test/ingest_messages.py --mode mock --count 100
```

Expected output: `Result: PASS - sent 100/100, failed 0`, with
100 messages drained back and every payload validated against the exact
key accesses `main.process_sqs_message` performs. A JSON report with all
trace_ids lands in `test/reports/`.

## The 100-message test against the real dev queue (client environment)

Live operations are double-gated so they cannot run by accident:
`RUN_LIVE=1` in the environment **and** `--yes-live` on the command line.

```bash
# 1. (optional) empty the queue first, then WAIT out the 60s purge window
RUN_LIVE=1 python test/purge_queue.py dev-HOSSYTH_rallm us-east-2

# 2. ingest 100 contract-valid messages
RUN_LIVE=1 python test/ingest_messages.py --mode live --count 100 \
    --queue dev-HOSSYTH_rallm --region us-east-2 --yes-live \
    --s3-key <s3 key of a real test PDF> --ra-mnemonic <mnemonic>

# 3. verify processing on the k8s consumer:
#    grep the trace_ids from test/reports/ingest_report_*.json in the
#    consumer logs / Datadog
```

`--s3-key` must point at a document that exists in the pipeline's S3
bucket; otherwise messages parse fine but doc-extract fails at download
(useful for testing the error-queue path, not the happy path).

## Consumer configuration (`main.py`)

| Env var | Meaning | Default |
|---------|---------|---------|
| `INPUT_QUEUE_TYPE` | `SQS` or `KAFKA` | required |
| `MODE` | `PROD` consumes `SQS_INPUT_QUEUE_NAME`; `TEST` posts one generated message to `SQS_TEST_QUEUE_NAME` and polls it back | `PROD` |
| `SQS_INPUT_QUEUE_NAME` / `SQS_OUTPUT_QUEUE_NAME` / `SQS_ERROR_QUEUE_NAME` | Queue **names** (not URLs) | required |
| `SQS_AWS_REGION` | Region for all SQS clients | required |
| `SQS_MPS_PATH` | Shared volume path for idempotency markers | `/data/main_resources/runtime_files_space` |
| `MPS_BACKEND` | Idempotency storage backend (`file` default; future adapters like `redis` select here with no code change) | `file` |
| `SQS_TEST_MSG_TO_SPAWN` | Default message count for the test harness | `100` |

Failure semantics: a message is deleted only after it has been
handled — either processed successfully, or copied to
`SQS_ERROR_QUEUE_NAME` — so poison messages cannot redeliver forever.
If the error-queue post — or the subsequent input-queue delete —
fails, the message stays for redelivery after the visibility timeout
(in the delete-failure case the error queue already holds a copy, so
the redelivery produces a duplicate there).

## Message contract

`main.process_sqs_message` and every producer/test share
`test/message_factory.build_message()`. If the consumer starts reading a
new `metadata` key, add it to the factory (and
`extract_consumer_fields`) in the same change — the moto test
`test_ingest_100_contract_valid_messages` will catch drift.
