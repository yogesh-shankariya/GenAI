import logging
from schema import KafkaMarkerEnum, KafkaContextMap, KafkaContextMapLog
import json
import os
from ddtrace import tracer
import uuid
from datetime import datetime

#from event_consumer import events

# Logging
from log_util.logger import setup_logger
from log_util.logger import kafka_msg_logger

logger = setup_logger("logger_config.yaml")

from log_util import logger as log_utils

#Import SQS library
from sqs_service import SQSClient

#Import shared test-message factory (single source of truth for the
#producer/consumer message contract)
from test.message_factory import build_message

import sys
import pathlib
import importlib
from doc_extract_app.execute_main import execute as doc_extract_execute
from constant import Constant

from time import sleep, time
import threading
import functools
from collections import defaultdict
from typing import Optional, Callable, Dict, Any
from concurrent.futures import ThreadPoolExecutor, as_completed
from log_util.logger import set_trace_id, clear_trace_id, clear_context_map
from copy import deepcopy

# PROD consumes SQS_INPUT_QUEUE_NAME; TEST posts one generated message
# to TESTQUEUE and polls it back.
MODE = os.environ.get("MODE", "PROD")
TESTQUEUE = os.environ.get("SQS_TEST_QUEUE_NAME", "dev-HOSSYTH_rallm")

INPUT_QUEUE_TYPE = Constant.INPUT_QUEUE_TYPE

# Env vars hold queue NAMES, not URLs
output_client = SQSClient(
    queue_name=Constant.SQS_OUTPUT_QUEUE_NAME,
    region_name=Constant.SQS_AWS_REGION,
)

error_client = SQSClient(
    queue_name=Constant.SQS_ERROR_QUEUE_NAME,
    region_name=Constant.SQS_AWS_REGION,
)


def run_pipeline_in_process(
    s3_key: str,
    trace_id: str,
    ra_mnemonic: str,
    base_location: str,
    doc_binary_path: str,
    logger_,
) -> Dict[str, Any]:
    """
    Set env vars (bucket/region) and call execute_main.execute().
    """
    with tracer.trace(
        service="doc-extract-py",
        name="run_pipeline_in_process",
    ) as span:
        span.set_tag("dd-trace-id", trace_id)
        span.set_tag("dd-s3-key", s3_key)

        response = doc_extract_execute(
            s3_key=s3_key,
            trace_id=trace_id,
            ra_nimonic=ra_mnemonic,
            base_location=base_location,
            docbinary_filepath=doc_binary_path if doc_binary_path else None,
            trace_logger=logger_,
        )
        logger_.info(
            "Response from Doc-Extract: status_code=%s",
            response.get("status_code")
            if isinstance(response, dict)
            else type(response).__name__,
        )
        if Constant.DEBUG_MODE:
            logger_.debug(f"Response from Doc-Extract: {response}")
        return response


def generate_full_message():
    """
    Generates a complete test message matching the consumer contract
    of process_sqs_message (see test/message_factory.py).
    """
    trace_id_val = str(uuid.uuid4())

    return json.dumps(build_message(trace_id=trace_id_val), indent=2)


def post_message_to_SQS_test(queue_name, message_body):
    """
    Function to test SQS functionaly by postting to a given queue
    """
    test_output_client = SQSClient(
        queue_name=queue_name,
        region_name=Constant.SQS_AWS_REGION,
    )

    try:
        test_output_client.send_message(message_body)
        logger.info("Message successfully posted to the queue")
    except Exception as e:
        logger.error(
            f"Error : {e} experienced while posting to the queue"
        )
        raise


def poll_from_sqs(queue_name):
    """
    Polls the AWS SQS queue indefinitely, processes messages, and deletes them.
    """
    test_input_client = SQSClient(
        queue_name=queue_name,
        region_name=Constant.SQS_AWS_REGION,
    )

    print(
        f"\n[*] Starting SQS Poller on {queue_name}. "
        "Press Ctrl+C to stop."
    )

    while True:
        try:
            # Long polling: waits up to 10 seconds for a message
            messages = test_input_client.receive_messages(
                max_messages=10,
                wait_time_seconds=10,
            )

            if not messages:
                print("No new messages, polling again...")
                continue

            for message in messages:
                message_body = message["Body"]
                receipt_handle = message["ReceiptHandle"]

                # --- Process the message ---
                try:
                    # Parse the nested JSON structure
                    outer_json = json.loads(message_body)
                    trace_id = outer_json.get("trace_id", "N/A")

                    print(
                        f" [x] Received message "
                        f"(Trace ID: {trace_id})... processing..."
                    )

                    print(f"Raw Body: {message_body[:100]}...")

                    # Delete Message
                    test_input_client.delete_msg(receipt_handle)

                    print(
                        f" [x] Message (Trace ID: {trace_id}) "
                        "processed and deleted."
                    )

                except json.JSONDecodeError:
                    print(
                        f"Error decoding JSON message body: {message_body}"
                    )
                    # Route unparseable messages to the error queue so
                    # they do not redeliver forever
                    try:
                        error_client.send_message(message_body)
                        test_input_client.delete_msg(receipt_handle)
                    except Exception as e:
                        print(f"Error routing to error queue: {e}")

                except Exception as e:
                    print(f"Error during message processing: {e}")

        except KeyboardInterrupt:
            print("\n[*] Poller stopped by user (Ctrl+C). Exiting.")
            break

        except Exception as e:
            print(f"\nAn error occurred during SQS polling: {e}")
            sleep(5)  # Wait before retrying connection/polling


def process_sqs_message(message_body) -> bool:
    """
    This wrapper extracts parameters from the SQS message and calls the
    doc_extract_execute function.

    Returns:
        bool: True if the message was fully processed and its output
            posted downstream; False on any failure (the caller decides
            whether to route to the error queue).
    """
    context_map = None
    success = False

    # Parse the SQS message
    try:
        body = json.loads(message_body["Body"])

        # Never log the full body at INFO: it can carry PHI (patient
        # document metadata/content) into the log platform
        if Constant.DEBUG_MODE:
            logger.debug(f"Message Body : {body}")

        #Extract parameters from the message
        data = json.loads(body["Message"]) if "Message" in body else body

        trace_id = data["metadata"]["traceId"]
        s3_key = data["metadata"]["file_path"]

        set_trace_id(trace_id)

        ra_mnemonic = data["metadata"]["RA_MNEMONIC"]
        base_location = data["metadata"]["baseLocation"]
        docbinary_filepath = data["metadata"]["docBinaryPath"]
        metadata_dict = data["metadata"]

        ctx = {
            "sourceQueue": metadata_dict["sourceQueue"],
            "queuePath": metadata_dict["queuePath"],  #add the current kafka topic
            "lastService": metadata_dict["lastService"],
            "status": metadata_dict["status"],
            "translationOutput": metadata_dict["translationOutput"],
            "sourceType": metadata_dict["sourceType"],
            "fileFormat": metadata_dict["fileFormat"],
            "rawFileLocation": metadata_dict["rawFileLocation"],
            "docAsciiPath": metadata_dict["docAsciiPath"],
            "docBinaryPath": metadata_dict["docBinaryPath"],
            "docMetadataPath": metadata_dict["docMetadataPath"],
            "contextHash": metadata_dict["contextHash"],
            "RA_MNEMONIC": metadata_dict["RA_MNEMONIC"],
            "baseLocation": metadata_dict["baseLocation"],
            "fileSize": metadata_dict["fileSize"],
            "priority": metadata_dict["priority"],
            "SYNTHESIS_SERVICE_OPERATION": (
                "com.elevance.cdi.documentmetadata.consumer."
                "ProcessDocumentExtraction"
            ),
            "X-Trace-ID": metadata_dict[
                "traceId"
            ],  # TODO: plz check if this is x-trace-id or just trace-id
            "X-REQUEST-ID": metadata_dict["xrequestID"],
            "TNNT_ID": metadata_dict["TNNT_ID"],
            "retryCount": metadata_dict["retryCount"],
            "CLNT_ID": metadata_dict["CLNT_ID"],
        }

        context_map: KafkaContextMapLog = {
            "FILE_FORMAT": ctx["fileFormat"],
            "RA_MNEMONIC": ra_mnemonic,
            "SYNTHESIS_SERVICE_OPERATION": ctx[
                "SYNTHESIS_SERVICE_OPERATION"
            ],
            "trace_id": trace_id,
            "trace_flags": "01",
            "X-Trace-ID": ctx["X-Trace-ID"],
            "X-REQUEST-ID": ctx["X-REQUEST-ID"],
        }

        log_utils.set_context_map(context_map)

        kafka_msg_logger(
            msg="Doc Extract pipeline started",
            marker=KafkaMarkerEnum.START,
            context_map=context_map,
        )

        logger.info(f"Processing trace_id: {trace_id}")

        try:
            result = run_pipeline_in_process(
                s3_key=s3_key,
                trace_id=trace_id,
                ra_mnemonic=ra_mnemonic,
                base_location=base_location,
                doc_binary_path=docbinary_filepath,
                logger_=logger,
            )

            data = result.get("data")
            status = result.get("status_code")
            err_msg = result.get("err_msg")

            if status != 200:
                logger.error(" Error %s encountered", err_msg)

                #Produce Error Message
                kafka_msg_logger(
                    msg=f"Error {err_msg} encountered",
                    marker=KafkaMarkerEnum.FAIL,
                    context_map=context_map,
                )

                final_output = {
                    "trace_id": trace_id,
                    "status_code": status,
                    "err_msg": err_msg,
                    "data": data,
                }

                logger.info(
                    "Final output - trace_id=%s status_code=%s "
                    "err_msg=%s",
                    trace_id,
                    status,
                    err_msg,
                )
                if Constant.DEBUG_MODE:
                    logger.debug(f"Final output - {final_output}")

            else:
                final_output = {
                    "trace_id": trace_id,
                    "status_code": status,
                    "err_msg": err_msg,
                    "data": data,
                }

                logger.info(
                    "Final output - trace_id=%s status_code=%s "
                    "err_msg=%s",
                    trace_id,
                    status,
                    err_msg,
                )
                if Constant.DEBUG_MODE:
                    logger.debug(f"Final output - {final_output}")

                kafka_msg_logger(
                    msg=(
                        f"Final data from Doc Extract : {final_output} "
                        "posting to SQS"
                    ),
                    marker=KafkaMarkerEnum.END,
                    context_map=context_map,
                )

                # list.append returns None - build the path first
                queue_path = list(ctx["queuePath"] or [])
                queue_path.append(Constant.SQS_OUTPUT_QUEUE_NAME)

                response_to_metadata: KafkaContextMap = {
                    "metadata": {
                        "sourceQueue": ctx["sourceQueue"],  #Current queue
                        "queuePath": queue_path,
                        "lastService": ctx["lastService"],
                        "status": ctx["status"],  #Working
                        "retryCount": ctx["retryCount"],  # 0
                        "traceId": trace_id,
                        "translationOutput": ctx["translationOutput"],
                        "sourceType": ctx["sourceType"],
                        "fileFormat": ctx["fileFormat"],
                        "rawFileLocation": ctx["rawFileLocation"],
                        "docAsciiPath": ctx["docAsciiPath"],
                        "docBinaryPath": ctx["docBinaryPath"],
                        "docMetadataPath": ctx["docMetadataPath"],
                        "contextHash": ctx["contextHash"],
                        "baseLocation": ctx["baseLocation"],
                        "fileSize": ctx["fileSize"],
                        "errorMessage": err_msg,
                        "xrequestID": ctx["X-REQUEST-ID"],
                        "priority": ctx["priority"],
                        "TNNT_ID": ctx["TNNT_ID"],
                        "CLNT_ID": ctx["CLNT_ID"],
                    },
                    "DOCBINARY_PATH": s3_key,
                    "DOCASCII_PATH": "",
                    "DOCENCOUNTER_PATHS": data,
                }

                logger.info(
                    "Posting doc-extract result to SQS - "
                    "trace_id=%s",
                    trace_id,
                )
                if Constant.DEBUG_MODE:
                    logger.debug(f"Posting {response_to_metadata}")

                # post to SQS queue
                output_client.send_message(response_to_metadata)

                kafka_msg_logger(
                    msg=(
                        f"Final data from Doc Extract : "
                        f"{response_to_metadata} posting to SQS."
                    ),
                    marker=KafkaMarkerEnum.PRODUCE,
                    context_map=context_map,
                )

                kafka_msg_logger(
                    msg="Doc Extract pipeline completed.",
                    marker=KafkaMarkerEnum.SUCCESS,
                    context_map=context_map,
                )

                success = True

        except Exception as exc:
            logger.exception(
                "Unexpected error in processing pipeline: %s",
                exc,
            )
            kafka_msg_logger(
                msg=f"Error {exc} encountered",
                marker=KafkaMarkerEnum.FAIL,
                context_map=context_map,
            )

    except Exception as err:
        ERROR_MSG = f"[CRITICAL ERROR] Unhandled Error in SQS consumer: {err}"
        logger.exception(ERROR_MSG)

        # context_map is None when the failure happened before it was
        # built (e.g. malformed message)
        if context_map is not None:
            kafka_msg_logger(
                msg=ERROR_MSG,
                marker=KafkaMarkerEnum.FAIL,
                context_map=context_map,
            )

    finally:
        clear_trace_id()
        clear_context_map()

    return success


def _route_to_error_queue(input_client, message) -> bool:
    """
    Post a failed message to the error queue, then delete it from the
    input queue so it cannot redeliver forever.

    Returns True if the message was routed (and deleted); False leaves
    it on the input queue for redelivery after the visibility timeout.
    """
    receipt_handle = message["ReceiptHandle"]

    try:
        error_client.send_message(message.get("Body", ""))
        input_client.delete_msg(receipt_handle)
        logger.info("Failed message routed to error queue and deleted")
        return True

    except Exception as exc:
        logger.exception(
            "Could not route message to error queue (%s) - leaving it "
            "for redelivery",
            exc,
        )
        return False


def main():
    """
    Main Entry Point
    """
    logger.info("Starting processing .....")

    if INPUT_QUEUE_TYPE.upper() == "SQS":
        if MODE.upper() == "TEST":
            generated_json_message = generate_full_message()
            logger.info(
                f"Generated test message : {generated_json_message}"
            )
            post_message_to_SQS_test(
                TESTQUEUE,
                generated_json_message,
            )

            #Test if the message was posted correct
            poll_from_sqs(TESTQUEUE)

        else:
            logger.info(
                f"SQS Queue : {Constant.SQS_INPUT_QUEUE_NAME}"
            )

            input_client = SQSClient(
                queue_name=Constant.SQS_INPUT_QUEUE_NAME,
                region_name=Constant.SQS_AWS_REGION,
            )

            while True:
                try:
                    # Long polling; up to 10 messages per request
                    messages = input_client.receive_messages(
                        max_messages=10,
                        wait_time_seconds=20,
                    )

                    if not messages:
                        logger.info("No messages received from SQS")
                        continue

                    for message in messages:
                        receipt_handle = message["ReceiptHandle"]

                        #Consume Message body
                        success = process_sqs_message(message)

                        if success:
                            #Delete message after successful consumption
                            input_client.delete_msg(receipt_handle)
                        else:
                            _route_to_error_queue(input_client, message)

                except KeyboardInterrupt:
                    logger.info("Consumer stopped by user")
                    break

                except Exception:
                    # Transient AWS/network errors must not kill the pod
                    logger.exception("SQS consumer loop error")
                    sleep(5)

    elif INPUT_QUEUE_TYPE.upper() == "KAFKA":
        # Process via kafka library
        logger.info("Processing via Kafka library ....")

        try:
            from pykafka import KafkaProcessor
        except ImportError as exc:
            raise RuntimeError(
                "INPUT_QUEUE_TYPE=KAFKA but the pykafka library is not "
                "available in this environment"
            ) from exc

        processor = KafkaProcessor(
            bootstrap_servers=Constant.KAFKA_BOOTSTRAP_SERVERS,
            input_topic=Constant.KAFKA_TOPIC_EXTR,
            success_topic=Constant.KAFKA_TOPIC_OUTPUT,
            error_topic=Constant.KAFKA_TOPIC_OUTPUT_ERR,
            group_id=(
                Constant.DOCUMENT_EXTRACT_KAFKA_CONSUMER_GROUP
                if Constant.DOCUMENT_EXTRACT_KAFKA_CONSUMER_GROUP != ""
                else Constant.PROVIDER_KAFKA_CONSUMER_GROUP
            ),
            processing_function=run_pipeline_in_process,
            max_workers=Constant.MAX_SPAWN_THREADS,
            max_queue_size=Constant.MAX_QUEUE_SIZE,
            kerberos_principal=Constant.KERBEROS_PRINCIPAL,
            kerberos_keytab=Constant.KERBEROS_KEYTAB,
            kerberos_service_name=Constant.KERBEROS_SERVICE_NAME,
            kerberos_renewal_interval=Constant.KERBEROS_RENEWAL_INTERVAL,
            sasl_mechanism=Constant.KAFKA_SASL,
            kafka_ca_cert=Constant.KAFKA_CA_CERT,
            security_protocol=Constant.KAFKA_SECURITY_PROTOCOL,
            kafka_security_pricipal=Constant.KAFKA_SECURITY_PRINCIPAL,
        )

        try:
            processor.start()
        except KeyboardInterrupt:
            logger.warning(
                "Processing interrupted by the user or system"
            )
        finally:
            processor.stop()
            logger.info("Process stopped")

    else:
        logger.error(
            f"Unsupported INPUT_QUEUE_TYPE: {INPUT_QUEUE_TYPE!r} "
            "(expected SQS or KAFKA)"
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
