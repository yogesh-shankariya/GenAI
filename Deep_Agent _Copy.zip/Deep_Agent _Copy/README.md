# Deep Agent — BP & HbA1c Extraction from OCR'd Health Assessments

A LangChain **deepagents**-based pipeline that, given one OCR'd
health-assessment document (markdown, multi-page), extracts **every
blood-pressure reading** and **every HbA1c reading** — including trend tables,
rechecks, and historical rows — each with its associated date and explicit
provenance. Output is one validated JSON object plus a `flags` list of
anything suspicious.

Implements the agreed plan in `deep_agent_bp_hba1c_extraction_plan.md`
(kept in the planning repo); section references (§) below point there.

## Hard quality rules (non-negotiable)

1. **Small contexts, always.** A standard extraction call contains exactly one
   PRIMARY page plus a small read-only overlap (the tail of the previous page,
   §3a). A flagged continuation stitch (§3a) may add adjacent context page(s),
   hard-capped at 3 pages per call. The whole document NEVER enters a single
   prompt.
2. **Never invent values.** A page with no BP/HbA1c yields empty results.
3. Every reading carries a verbatim `evidence` substring of its source page —
   enforced **twice**: by the verifier subagent AND by a programmatic gate in
   postprocessing (which matches against the RAW page text, never the
   decorated agent files).

## Architecture (§3 / §3a)

Python owns everything deterministic; the LLM owns only judgment.

```
input.md
   │  (Python regex splitter + overlap decorator, §3a)
   ▼
files = {"/pages/page_01.md": ..., ..., "/pages/page_NN.md": ...}
   │  each file = <CONTEXT_FROM_PREVIOUS_PAGE> tail of page N-1 (read-only)
   │              + <PAGE n="N"> the page itself </PAGE>
   │  agent.invoke(messages=[task + explicit worklist], files=files)
   ▼
MAIN AGENT (orchestrator — never reads pages itself)
   ├─ write_todos: one item per page + stitch pass + verify + write results
   ├─ task("metadata")   → visit_date, member info (page 1 only)
   ├─ task("extractor")  × N pages (one PRIMARY page per call, parallel turns)
   │      + boundary flags: starts_mid_table / ends_mid_table
   ├─ stitch pass (§3a): flagged adjacent pair + dateless table readings
   │      → ONE re-extraction naming primary + context page (≤3 pages)
   ├─ task("verifier")   × pages-with-findings (same context paths if stitched)
   └─ write_file("/results.json", merged final object) → replies "DONE"
   ▼
Python postprocess: pydantic validation → programmatic evidence gate
(RAW pages) → dedupe → sort → write output file
```

Cross-page tables (§3a) are handled in two layers: a deterministic read-only
overlap window (`HORIZON_OVERLAP_LINES`, default 20 non-empty lines) prepended
to every page file, plus a targeted stitch pass for headers a full page away —
extractors report `starts_mid_table`/`ends_mid_table`, and qualifying adjacent
pairs get ONE stitched re-extraction (primary + context, `confidence:
"medium"`, note `"date from previous page"`).

## Project layout (§7)

```
.
├── .env.example                        # Horizon credentials template
├── requirements.txt                    # pinned versions
├── docs/
│   └── tool_chats_contract.md          # M0 deliverable (PROVISIONAL until probe runs)
├── src/
│   ├── config.py                       # .env → config dict, TokenManager, logging
│   ├── horizon/
│   │   ├── token_manager.py            # existing module, copied unchanged
│   │   ├── adapters.py                 # LangChain ⇄ wire format; ONLY place OPEN-1/2/4 live
│   │   ├── chat_horizon.py             # BaseChatModel over POST /v2/tool/chats
│   │   └── probe_tool_chats.py         # M0 probe — run in the client environment only
│   ├── agent/
│   │   ├── prompts.py                  # orchestrator/extractor/verifier/metadata prompts
│   │   └── build_agent.py              # create_deep_agent assembly (deepagents 0.6.12)
│   └── pipeline/
│       ├── splitter.py                 # regex splitter + §3a overlap decorator → SplitResult
│       ├── schemas.py                  # pydantic v2 output contract + PageExtraction
│       ├── postprocess.py              # validation, evidence gate (RAW pages), dedupe, sort
│       └── run.py                      # entrypoint
└── tests/
    ├── fixtures/
    │   ├── sample_input.md             # 3-page repo sample
    │   ├── synthetic_pages/            # 8 acceptance fixtures (§8) + expected outcomes
    │   └── tool_chats_samples/         # PROVISIONAL wire fixtures (replace after M0)
    ├── helpers/trace_guard.py          # §3a page-path assertion hook (§8)
    ├── test_splitter.py
    ├── test_schemas.py
    ├── test_config.py                  # incl. llm_service direct-handler regression test
    ├── test_chat_horizon.py            # mocked HTTP — includes 401→refresh→retry
    ├── test_postprocess.py             # includes the programmatic evidence gate
    └── test_e2e.py                     # real LLM; @pytest.mark.integration
```

## Setup

```bash
pip install -r requirements.txt
cp .env.example .env       # fill in — client environment only
```

## Usage

Simplest: edit the `INPUT_PATH` / `OUTPUT_PATH` constants at the top of
[`main.py`](main.py) and run:

```bash
python main.py
```

Or via the CLI module with explicit arguments:

```bash
python -m src.pipeline.run --input path/to/input.md --output out/results.json
```

Input format: pages delimited by
`<ocr_service_page_start>N<ocr_service_page_start>` tags. Output: the
`ExtractionResult` JSON contract (§6) — see `src/pipeline/schemas.py`.

## Milestone status (§9)

| Milestone | Status |
|---|---|
| M0 — probe `/v2/tool/chats` | **OPEN — blocked on client environment.** Probe script and provisional contract are shipped; run `python -m src.horizon.probe_tool_chats`, then finalize `docs/tool_chats_contract.md`, `src/horizon/adapters.py`, and the wire fixtures. |
| M1 — ChatHorizon + adapters + unit tests | Implemented against the provisional M0 contract. |
| M2 — splitter + schemas + config | Implemented. |
| M3 — prompts + agent assembly | Implemented (deepagents pinned at 0.6.12; key names verified against that version's source). |
| M4 — postprocess + entrypoint + e2e | Implemented; e2e requires client environment. |
| M5 — hardening | Retries + structured logging + recursion-limit in place; `cheap` qos experiment pending. |

## Testing

```bash
pytest                     # unit tests only (mocked HTTP; no network, no PHI)
pytest -m integration      # e2e against the real gateway — CLIENT ENVIRONMENT ONLY
```

Acceptance criteria (§8) are encoded in `tests/test_e2e.py` and
`tests/fixtures/synthetic_pages/README.md`.

## PHI / privacy (§10)

- Input documents contain real patient data. INFO logs carry only counts, page
  numbers, and timings; page contents and extracted values appear at DEBUG
  only (`--verbose` — use strictly inside the PHI boundary).
- No third-party network calls anywhere in the pipeline besides the internal
  Horizon gateway.
- Pipeline outputs (`out/`, `results.json`) are git-ignored.

## Open questions

- **OPEN-1/2/3/4** — wire shapes & capabilities of `/v2/tool/chats`: resolved
  by the M0 probe (see `docs/tool_chats_contract.md`).
- **OPEN-5 (product decision)** — should readings dated >2 years before the
  visit be filtered? Current behavior: include everything and let downstream
  filter (a flag is the suggested mechanism once decided). Confirm with the team.
