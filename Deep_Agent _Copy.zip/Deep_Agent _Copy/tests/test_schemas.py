"""Unit tests for the pydantic output schemas (plan §5.2, §6)."""

import pytest
from pydantic import ValidationError

from src.pipeline.schemas import (
    BloodPressureReading,
    ExtractionResult,
    HbA1cReading,
    PageExtraction,
)


def _bp(**overrides):
    base = {
        "systolic": 140,
        "diastolic": 90,
        "date": "2025-05-14",
        "date_source": "visit_date",
        "source_page": 2,
        "found_in": "narrative",
        "evidence": "BP 140/90 sitting",
    }
    base.update(overrides)
    return base


def _hba1c(**overrides):
    base = {
        "value": 7.2,
        "unit": "%",
        "date": "2025-01-10",
        "date_source": "table_row",
        "source_page": 5,
        "found_in": "table",
        "evidence": "HbA1c 7.2 (01/10/25)",
    }
    base.update(overrides)
    return base


class TestReadings:
    def test_valid_bp_reading(self):
        reading = BloodPressureReading.model_validate(_bp())
        assert reading.type == "blood_pressure"
        assert reading.unit == "mmHg"
        assert reading.confidence == "high"  # default
        assert reading.note is None  # default

    def test_valid_hba1c_reading_mmol(self):
        reading = HbA1cReading.model_validate(_hba1c(unit="mmol/mol", value=55))
        assert reading.type == "hba1c"
        assert reading.value == 55.0

    def test_invalid_date_source_rejected(self):
        with pytest.raises(ValidationError):
            BloodPressureReading.model_validate(_bp(date_source="guessed"))

    def test_invalid_found_in_rejected(self):
        with pytest.raises(ValidationError):
            HbA1cReading.model_validate(_hba1c(found_in="footer"))

    def test_invalid_hba1c_unit_rejected(self):
        with pytest.raises(ValidationError):
            HbA1cReading.model_validate(_hba1c(unit="mg/dL"))

    def test_evidence_is_required(self):
        payload = _bp()
        del payload["evidence"]
        with pytest.raises(ValidationError):
            BloodPressureReading.model_validate(payload)

    def test_non_integer_systolic_rejected(self):
        with pytest.raises(ValidationError):
            BloodPressureReading.model_validate(_bp(systolic="abc"))


class TestExtractionResult:
    def test_defaults_are_empty(self):
        result = ExtractionResult()
        assert result.document_id is None
        assert result.visit_date is None
        assert result.blood_pressure == []
        assert result.hba1c == []
        assert result.flags == []

    def test_plan_section_6_example_parses(self):
        result = ExtractionResult.model_validate(
            {
                "document_id": "MNL000W2225120",
                "visit_date": "2025-05-14",
                "blood_pressure": [
                    {
                        "type": "blood_pressure",
                        "systolic": 140,
                        "diastolic": 90,
                        "unit": "mmHg",
                        "date": "2025-05-14",
                        "date_source": "visit_date",
                        "source_page": 2,
                        "found_in": "narrative",
                        "evidence": "BP 140/90 sitting",
                        "confidence": "high",
                        "note": "sitting",
                    }
                ],
                "hba1c": [
                    {
                        "type": "hba1c",
                        "value": 7.2,
                        "unit": "%",
                        "date": "2025-01-10",
                        "date_source": "table_row",
                        "source_page": 5,
                        "found_in": "table",
                        "evidence": "HbA1c 7.2 (01/10/25)",
                        "confidence": "high",
                        "note": None,
                    },
                    {
                        "type": "hba1c",
                        "value": 6.8,
                        "unit": "%",
                        "date": "2024-08-02",
                        "date_source": "table_row",
                        "source_page": 5,
                        "found_in": "table",
                        "evidence": "HbA1c 6.8 (08/02/24)",
                        "confidence": "high",
                        "note": None,
                    },
                ],
                "flags": [],
            }
        )
        assert len(result.hba1c) == 2  # multi-row trend table is the normal case
        assert result.hba1c[0].date_source == "table_row"

    def test_trend_table_rows_are_separate_readings(self):
        rows = [
            _hba1c(value=v, date=d)
            for v, d in [(7.2, "2025-01-10"), (6.8, "2024-08-02"), (6.4, "2024-02-14")]
        ]
        result = ExtractionResult.model_validate({"hba1c": rows})
        assert len(result.hba1c) == 3


class TestPageExtraction:
    def test_boundary_flags_default_false(self):
        page = PageExtraction.model_validate({"page": 2})
        assert page.starts_mid_table is False
        assert page.ends_mid_table is False
        assert page.readings == []
        assert page.page_flags == []

    def test_extractor_reply_shape_parses(self):
        page = PageExtraction.model_validate(
            {
                "page": 2,
                "starts_mid_table": True,
                "ends_mid_table": False,
                "readings": [_hba1c()],
                "page_flags": ["table continues from previous page"],
            }
        )
        assert page.starts_mid_table is True
        assert len(page.readings) == 1  # per-type validation happens after routing

    def test_failed_read_reply_shape_parses(self):
        page = PageExtraction.model_validate(
            {
                "page": None,
                "starts_mid_table": False,
                "ends_mid_table": False,
                "readings": [],
                "page_flags": ["could not read page"],
            }
        )
        assert page.page is None
