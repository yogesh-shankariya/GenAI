# /v2/tool/chats fixtures

> **Status: A / C / D CONFIRMED from the real probe run of 2026-07-06; B (tool
> result) still OPEN.** These fixtures mirror the real captured wire shapes
> (weather-tool probe conversation — no PHI). The probe script additionally
> wraps its captures as `{"status": ..., "body": ...}`; these unit-test
> fixtures are the response **body** only.

Confirmed contract facts encoded here (see `docs/tool_chats_contract.md`):

- A tool call is a **standalone message**: `{"type": "tool_call", "role":
  "assistant", "id": "call_…", "name": …, "input": {…}}`.
- Multiple tool calls = multiple `tool_call` messages in one response.
- The response contains ONLY model-authored messages (no echo of the sent
  conversation).

| File | Exercises |
|---|---|
| `probe_a_tool_call.json` | real captured tool-call turn (OPEN-1 confirmed) |
| `probe_a_tool_call_string_args.json` | synthetic: `input` as a JSON **string**, no id (adapter must `json.loads` and synthesize an id) |
| `probe_b_plain_text.json` | plain text turn, no tool calls |
| `probe_c_multi_tool_call.json` | real captured two-call response (OPEN-3 confirmed) |
| `malformed_tool_call.json` | synthetic degenerate tool call (missing name, garbage args) — adapter degrades to plain text, never raises |

Still to add after Probe B succeeds: the accepted tool-result request shape and
its 200 continuation (replace the OPEN-2 best guess in `adapters.py`).
