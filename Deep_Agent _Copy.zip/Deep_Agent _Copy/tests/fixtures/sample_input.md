<ocr_service_page_start>1<ocr_service_page_start>
Page 1
And
I
Health Assessment Report 025

Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5:14:25
PCP Name: ALLENDE, DIEGO G
Address: 7239 N RECREATION AVE
Carrier: BLUE CROSS SNP-SBCS Effective Date: 01/01/2025
Line 2:
Product: Senior
PCP: ALLENDE, DIEGO G
City: FRESNO
State: CA Zip: 93720
Member ID: MNL000W2225120
Phone: 8317765155
Fax:
CC/HPI:
Pertinent ROS: (detailed ROS in medical records)
MED LIST: (dose detail in the medical records)
ALLERGIES:
NSAIDS
SOCIAL/OTHER HISTORY:
(If yes, please document in the A/P to
PERTINENT PAST HISTORY
PERTINENT FAMILY HISTORY
highest level of specificity)


Date: 5/14/25
Proprietary & Confidential Annual Health Assessment 2016 rev

<ocr_service_page_start>2<ocr_service_page_start>
Page 2
Ann
I Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5.14.25
PCP Name: ALLENDE DIEGO
R:
PCO2 (if available):
BMI 30-39.9 (268.3
)
GENERAL
HEENT:
WNL
ABN
CARDIAC
WNL
ABN
Chest wall: AICD / PPM (circle if present)
PULM:
WNL
ABN
ABD:
WNL
ABN
EXT/Vascular: Pedal pulses: Strong/Weak/Not palpable (circle one)


Proprietary
sessifient
10

<ocr_service_page_start>3<ocr_service_page_start>
Page 3
Ann I Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5.14.25
PCP Name: ALLENDE. DIEGO G
request authorization and referral. Please coordinate
Patient Health Questionnaire-2 (PHQ-2): Depression screening as a “first-step” approach.
Over the last 2 weeks, how often have you been bothered by any of the following? |Not at All
|Several Days |More than half of the days |Nearly every day |Totals |
1. Little interest or pleasure in doing things?                                      |0
        |2                                 |3             |       |
2. Feeling down, depressed, or hopeless?                                           |0
        |2                                 |3             |       |

Note:
A PHQ-2 score ranges from to 6; patients with overall scores of 3 or more should be further
evaluated with a PHQ-9 other diagnostic
instrument(s) or a direct interview to determine whether they meet criteria for a depressive
disorder.
Pain Assessment
Check here if patient has no pain and proceed to next section
1. |is the pain acute?          Yes |No
2. |is the pain chronic?        Yes |No