<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Ann I Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5.14.25
PCP Name: ALLENDE. DIEGO G
request authorization and referral. Please coordinate
Patient Health Questionnaire-2 (PHQ-2): Depression screening as a “first-step” approach.
Over the last 2 weeks, how often have you been bothered by any of the following? |Not at All
|Several Days |More than half of the days |Nearly every day |Totals |
1. Little interest or pleasure in doing things?                                      |0
        |2                                 |3             |       |
2. Feeling down, depressed, or hopeless?                                           |0
        |2                                 |3             |       |

Note:
A PHQ-2 score ranges from to 6; patients with overall scores of 3 or more should be further
evaluated with a PHQ-9 other diagnostic
instrument(s) or a direct interview to determine whether they meet criteria for a depressive
disorder.
Pain Assessment
Check here if patient has no pain and proceed to next section
1. |is the pain acute?          Yes |No
2. |is the pain chronic?        Yes |No
