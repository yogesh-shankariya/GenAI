<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5.14.25
Member ID: MNL000W2225120

PROGRESS NOTE:
Patient seen for annual assessment. Vitals reviewed in office.
BP was 150/95 on 3/2/24, rechecked 142/90.
Patient tolerated exam well. Continue current medications.

Proprietary & Confidential Annual Health Assessment 2016 rev
