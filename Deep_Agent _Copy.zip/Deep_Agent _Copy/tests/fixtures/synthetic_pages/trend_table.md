<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5/14/25
Member ID: MNL000W2225120

LAB TRENDS (most recent first)
| Test | Result | Date |
| HbA1c | 7.2 % | 01:10:25 |
| HbA1c | 6.8 % | 08/02/24 |
| HbA1c | 6.4 % | 02/14/24 |

Proprietary & Confidential Annual Health Assessment 2016 rev
