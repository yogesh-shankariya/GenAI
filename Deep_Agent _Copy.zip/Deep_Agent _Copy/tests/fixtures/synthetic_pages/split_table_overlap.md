<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5/14/25
Member ID: MNL000W2225120

LAB RESULT HISTORY (most recent first)
| Test | 01/10/25 | 08/02/24 |
<ocr_service_page_start>2<ocr_service_page_start>
Page 2
| HbA1c | 7.2 % | 6.8 % |
| LDL Cholesterol | 101 | 99 |
| eGFR | 88 | 90 |

Assessment continues. Patient counseled on diet and exercise.

Proprietary & Confidential Annual Health Assessment 2016 rev
