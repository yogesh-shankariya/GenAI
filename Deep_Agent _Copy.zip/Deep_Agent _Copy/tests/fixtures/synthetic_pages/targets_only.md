<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5.14.25
Member ID: MNL000W2225120

CARE PLAN:
Goal: BP <130/80, A1c <7%.
Titration criteria: if SBP > 160 then increase lisinopril per protocol.
Reference range HbA1c (nondiabetic): 4.0 - 5.6 %.
Keep A1c under 7 at next review.

Proprietary & Confidential Annual Health Assessment 2016 rev
