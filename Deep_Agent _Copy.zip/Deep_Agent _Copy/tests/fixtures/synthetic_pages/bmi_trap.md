<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5.14.25
Member ID: MNL000W2225120

R:
PCO2 (if available):
BMI 30-39.9 (268.3
)
VITALS: BP: 128/76 sitting, left arm. Pulse 72.
GENERAL
HEENT:
WNL
ABN

Proprietary & Confidential Annual Health Assessment 2016 rev
