<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female Date of Visit:
5.14.25
Member ID: MNL000W2225120

VITALS / LAB HISTORY (OCR damaged)
| Test | Result | Date
| BP | 138/88 | 04/12/25 |
|| HbA1c 7.9 | % | 03/2
0/25 |
| | 6.9 | |
| Hb___ (illegible) | | 01/0
5/25

Proprietary & Confidential Annual Health Assessment 2016 rev
