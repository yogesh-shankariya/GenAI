<ocr_service_page_start>1<ocr_service_page_start>
Page 1
Health Assessment Report 025
Member Last Name: MURPHY
First Name: ELIZABETH Date of Birth: 06/06/1958 Gender: Female
Member ID: MNL000W2225120

COMPREHENSIVE LAB RESULT HISTORY (most recent first)
| Test | 01/10/25 | 08/02/24 |
| Sodium | 139 | 141 |
| Potassium | 4.2 | 4.4 |
| Chloride | 101 | 103 |
| CO2 | 24 | 26 |
| BUN | 18 | 17 |
| Creatinine | 0.9 | 1.0 |
| Calcium | 9.4 | 9.2 |
| Total Protein | 7.1 | 7.0 |
| Albumin | 4.3 | 4.1 |
| Total Bilirubin | 0.6 | 0.7 |
| Alk Phos | 88 | 92 |
| AST | 22 | 25 |
| ALT | 19 | 24 |
| LDL Cholesterol | 101 | 99 |
| HDL Cholesterol | 48 | 51 |
| Triglycerides | 148 | 160 |
| Total Cholesterol | 178 | 182 |
| TSH | 2.1 | 1.9 |
| Vitamin D | 31 | 28 |
| Hemoglobin | 13.2 | 13.4 |
| Hematocrit | 39.8 | 40.1 |
| WBC | 6.8 | 7.2 |
| Platelets | 244 | 251 |
| eGFR | 88 | 90 |
<ocr_service_page_start>2<ocr_service_page_start>
Page 2
| RDW | 13.1 | 12.9 |
| MCV | 90 | 89 |
| HbA1c | 7.4 % | 6.9 % |
| Microalbumin | 22 | 18 |

End of laboratory result history.

Proprietary & Confidential Annual Health Assessment 2016 rev
<ocr_service_page_start>3<ocr_service_page_start>
Page 3
Pain Assessment
Check here if patient has no pain and proceed to next section
1. |is the pain acute?          Yes |No
2. |is the pain chronic?        Yes |No

Proprietary & Confidential Annual Health Assessment 2016 rev
