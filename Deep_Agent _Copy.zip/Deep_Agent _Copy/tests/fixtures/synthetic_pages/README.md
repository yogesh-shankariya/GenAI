# Synthetic fixture pages (plan §8)

Each file is a document wrapped in the OCR page tags (fixtures 1–6 are one
page; 7 is two pages; 8 is three pages), used by the integration (e2e) tests.
Expected outcomes:

| Fixture | Expected result |
|---|---|
| `trend_table.md` | 3 HbA1c readings, `date_source=table_row`; the mangled `01:10:25` normalizes to `2025-01-10`. |
| `narrative_bp.md` | 2 BP readings: 150/95 with `date_source=inline` (2024-03-02), 142/90 with `date_source=visit_date` (2025-05-14). |
| `targets_only.md` | ZERO readings (goals/targets/reference ranges only). |
| `no_findings.md` | ZERO readings, zero hallucinations (PHQ-2 page from the repo sample). |
| `broken_table.md` | The pairable values extracted (BP 138/88 on 2025-04-12; HbA1c 7.9 % on 2025-03-20) + a `page_flag` for the orphan/illegible rows; no guesses for the unpaired `6.9`. |
| `bmi_trap.md` | ONLY the real BP 128/76; `BMI 30-39.9 (268.3)` is BMI/weight, not blood pressure. |
| `split_table_overlap.md` | Header row with two dates is the LAST line of page 1; value rows open page 2. Page-2 HbA1c readings (7.2 / 6.8) carry page-1's dates via the read-only overlap alone: `date_source=table_header`, note `"date from previous page"`, `source_page=2`, ZERO readings attributed to page 1, and NO stitch call fired. |
| `split_table_stitch.md` | Header with dates at the TOP of page 1; 24 rows fill the rest of page 1 so the header sits beyond the 20-line overlap reach of page 2, whose rows include HbA1c 7.4 / 6.9. Expect `ends_mid_table(1)` + `starts_mid_table(2)`, exactly ONE stitched re-extraction (page 2 PRIMARY, page 1 CONTEXT), and page-2 HbA1c readings resolved with the header dates at `confidence="medium"`. **Deliberately has NO visit date**: with one, the extractor's date rule 4 (`visit_date` fallback) would date the orphaned rows and the stitch trigger (readings with `date null`/`date_source "none"`) could never fire. The e2e test pins `HORIZON_OVERLAP_LINES=20` — the header sits 25 lines back, so larger windows would reach it. |
