"""Unit tests for configuration and logging setup (plan §5.7).

Includes the regression test for a critical finding from the implementation
audit: the verbatim-copied ``TokenManager.get_token()`` flushes
``self.logger.handlers[0]`` in its ``finally`` block, so the ``llm_service``
logger MUST carry a direct handler — root-logger propagation alone makes
``hasHandlers()`` True while ``handlers`` stays empty, turning every
``get_token()`` call into an ``IndexError``.
"""

import logging

import pytest

from src.config import configure_logging, load_config


@pytest.fixture(autouse=True)
def restore_llm_service_logger():
    """configure_logging mutates global logging state (handlers, propagate);
    snapshot and restore it so other test modules (e.g. caplog-based splitter
    tests) are unaffected by test ordering."""
    llm_logger = logging.getLogger("llm_service")
    saved = (list(llm_logger.handlers), llm_logger.propagate, llm_logger.level)
    yield
    llm_logger.handlers, llm_logger.propagate, llm_logger.level = saved


class TestConfigureLogging:
    def test_llm_service_logger_gets_a_direct_handler(self):
        configure_logging()
        llm_logger = logging.getLogger("llm_service")

        assert llm_logger.handlers, (
            "'llm_service' must have a DIRECT handler: TokenManager.get_token() "
            "flushes logger.handlers[0] in its finally block and would raise "
            "IndexError otherwise"
        )
        # The exact call TokenManager makes in its finally block must not raise.
        assert llm_logger.hasHandlers()
        llm_logger.handlers[0].flush()

    def test_configure_logging_is_idempotent(self):
        configure_logging()
        configure_logging()
        assert len(logging.getLogger("llm_service").handlers) == 1

    def test_verbose_sets_debug_level(self):
        configure_logging(verbose=True)
        assert logging.getLogger("llm_service").level == logging.DEBUG


class TestLoadConfig:
    def test_provides_every_key_token_manager_reads(self):
        config = load_config()
        # TokenManager.__init__/_fetch_new_token read exactly these (plan §5.7).
        for key in (
            "token_validity_seconds",
            "refresh_margin_seconds",
            "auth_url",
            "min_connection_timeout_seconds",
            "max_read_timeout_seconds",
        ):
            assert key in config

    def test_defaults_match_plan(self):
        config = load_config()
        assert config["qos"] in ("accurate", "cheap")
        assert config["reasoning"] in ("true", "false")
        assert config["preview"] in ("true", "false")
        assert config["token_validity_seconds"] >= 0
