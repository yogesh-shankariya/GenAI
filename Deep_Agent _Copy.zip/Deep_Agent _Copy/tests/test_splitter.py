"""Unit tests for the page splitter + §3a overlap decorator (plan §5.1)."""

from pathlib import Path

from src.pipeline.splitter import (
    CONTEXT_CLOSE,
    CONTEXT_OPEN,
    split_pages,
)

FIXTURES = Path(__file__).parent / "fixtures"


def _tag(n: int) -> str:
    return f"<ocr_service_page_start>{n}<ocr_service_page_start>"


class TestSampleDocument:
    def test_three_page_sample_splits_into_three_files(self):
        document = (FIXTURES / "sample_input.md").read_text(encoding="utf-8")
        split = split_pages(document)

        assert sorted(split.agent_files) == [
            "/pages/page_01.md",
            "/pages/page_02.md",
            "/pages/page_03.md",
        ]
        assert sorted(split.raw_pages) == [1, 2, 3]
        assert "Member ID: MNL000W2225120" in split.raw_pages[1]
        assert "BMI 30-39.9 (268.3" in split.raw_pages[2]
        assert "PHQ-2" in split.raw_pages[3]
        assert split.flags == []

    def test_raw_pages_are_kept_raw_and_undecorated(self):
        document = (FIXTURES / "sample_input.md").read_text(encoding="utf-8")
        split = split_pages(document)

        # 'Page N' banner lines and original whitespace must survive: the
        # evidence gate matches verbatim substrings against this text.
        assert split.raw_pages[1].startswith("\nPage 1\n")
        assert "5:14:25" in split.raw_pages[1]
        # No §3a decoration may leak into the raw view.
        for raw in split.raw_pages.values():
            assert CONTEXT_OPEN not in raw
            assert "<PAGE" not in raw


class TestOverlapDecoration:
    def test_page_one_context_section_is_present_but_empty(self):
        document = f"{_tag(1)}\nalpha\nbeta\n{_tag(2)}\ngamma\n"
        split = split_pages(document)

        page_1 = split.agent_files["/pages/page_01.md"]
        assert page_1.startswith(f"{CONTEXT_OPEN}\n{CONTEXT_CLOSE}\n")
        assert '<PAGE n="01">' in page_1
        assert page_1.rstrip().endswith("</PAGE>")

    def test_page_two_context_holds_page_one_tail_inside_markers(self):
        document = f"{_tag(1)}\nalpha\nbeta\n{_tag(2)}\ngamma\n"
        split = split_pages(document)

        page_2 = split.agent_files["/pages/page_02.md"]
        context = page_2.split(CONTEXT_CLOSE)[0]
        assert context.startswith(CONTEXT_OPEN)
        assert "alpha" in context and "beta" in context
        # The page body follows the context section.
        assert '<PAGE n="02">' in page_2
        assert "gamma" in page_2.split('<PAGE n="02">')[1]

    def test_overlap_takes_only_last_n_non_empty_lines(self):
        lines = "\n".join(f"line-{i:02d}" for i in range(1, 26))  # 25 non-empty
        document = f"{_tag(1)}\n{lines}\n\n\n{_tag(2)}\nbody\n"
        split = split_pages(document, overlap_lines=20)

        context = split.agent_files["/pages/page_02.md"].split(CONTEXT_CLOSE)[0]
        assert "line-06" in context and "line-25" in context
        assert "line-05" not in context  # beyond the 20-line window
        assert "\n\n" not in context.replace(CONTEXT_OPEN + "\n", "")  # blanks dropped

    def test_overlap_lines_read_from_env(self, monkeypatch):
        monkeypatch.setenv("HORIZON_OVERLAP_LINES", "2")
        document = f"{_tag(1)}\na\nb\nc\nd\n{_tag(2)}\nbody\n"
        split = split_pages(document)

        context = split.agent_files["/pages/page_02.md"].split(CONTEXT_CLOSE)[0]
        assert "c" in context and "d" in context
        assert "a\n" not in context and "b\n" not in context

    def test_explicit_argument_beats_env(self, monkeypatch):
        monkeypatch.setenv("HORIZON_OVERLAP_LINES", "1")
        document = f"{_tag(1)}\na\nb\nc\n{_tag(2)}\nbody\n"
        split = split_pages(document, overlap_lines=3)

        context = split.agent_files["/pages/page_02.md"].split(CONTEXT_CLOSE)[0]
        assert "a" in context and "b" in context and "c" in context


class TestTagVariants:
    def test_spaces_around_page_number(self):
        document = (
            f"{_tag(1)}\nfirst\n"
            "<ocr_service_page_start> 2 <ocr_service_page_start>\nsecond\n"
        )
        split = split_pages(document)
        assert sorted(split.agent_files) == ["/pages/page_01.md", "/pages/page_02.md"]
        assert split.raw_pages[2] == "\nsecond\n"

    def test_document_without_tags_becomes_single_page(self, caplog):
        document = "no tags here at all\njust text\n"
        with caplog.at_level("WARNING", logger="llm_service"):
            split = split_pages(document)

        assert list(split.agent_files) == ["/pages/page_01.md"]
        assert split.raw_pages == {1: document}
        # Decorated even in the fallback case; context section empty.
        assert split.agent_files["/pages/page_01.md"].startswith(
            f"{CONTEXT_OPEN}\n{CONTEXT_CLOSE}\n"
        )
        assert any("no page tags" in f for f in split.flags)
        assert any("No <ocr_service_page_start> tags" in r.message for r in caplog.records)


class TestDuplicatesAndPadding:
    def test_duplicate_page_numbers_get_suffix_and_flag(self):
        document = f"{_tag(1)}\nA\n{_tag(2)}\nB\n{_tag(2)}\nC\n"
        split = split_pages(document)

        assert sorted(split.agent_files) == [
            "/pages/page_01.md",
            "/pages/page_02.md",
            "/pages/page_02_b.md",
        ]
        assert any("duplicate page number 2" in f for f in split.flags)
        # BOTH copies must be visible to the evidence gate.
        assert "\nB\n" in split.raw_pages[2]
        assert "\nC\n" in split.raw_pages[2]

    def test_duplicate_context_comes_from_preceding_copy(self):
        document = f"{_tag(1)}\nA\n{_tag(2)}\nB\n{_tag(2)}\nC\n"
        split = split_pages(document)
        context = split.agent_files["/pages/page_02_b.md"].split(CONTEXT_CLOSE)[0]
        assert "B" in context  # previous page in document order

    def test_three_digit_padding_when_any_page_reaches_100(self):
        document = f"{_tag(1)}\nA\n{_tag(100)}\nB\n"
        split = split_pages(document)
        assert sorted(split.agent_files) == [
            "/pages/page_001.md",
            "/pages/page_100.md",
        ]
        assert '<PAGE n="100">' in split.agent_files["/pages/page_100.md"]
        assert sorted(split.raw_pages) == [1, 100]

    def test_two_digit_padding_below_100(self):
        document = f"{_tag(1)}\nA\n{_tag(99)}\nB\n"
        split = split_pages(document)
        assert sorted(split.agent_files) == ["/pages/page_01.md", "/pages/page_99.md"]
