"""Unit tests for postprocessing, incl. the programmatic evidence gate (plan §5.6).

The gate matches against ``SplitResult.raw_pages`` (page number → RAW text) —
NEVER the decorated agent files, whose <CONTEXT_FROM_PREVIOUS_PAGE> section
would let a neighboring page's text pass (§3a).
"""

import json

import pytest
from pydantic import ValidationError

from src.pipeline.postprocess import PostprocessError, postprocess
from src.pipeline.splitter import split_pages

RAW_PAGES = {
    1: "\nPage 1\nDate of Visit: 5:14:25\nMember ID: MNL000W2225120\n",
    2: "\nPage 2\nVITALS: BP 140/90    sitting\n",
    5: "\nPage 5\nLABS\nHbA1c 7.2 (01/10/25)\nHbA1c 6.8 (08/02/24)\n",
}


def bp_reading(**overrides):
    base = {
        "type": "blood_pressure",
        "systolic": 140,
        "diastolic": 90,
        "unit": "mmHg",
        "date": "2025-05-14",
        "date_source": "visit_date",
        "source_page": 2,
        "found_in": "narrative",
        "evidence": "BP 140/90 sitting",
        "confidence": "high",
        "note": "sitting",
    }
    base.update(overrides)
    return base


def hba1c_reading(**overrides):
    base = {
        "type": "hba1c",
        "value": 7.2,
        "unit": "%",
        "date": "2025-01-10",
        "date_source": "table_row",
        "source_page": 5,
        "found_in": "table",
        "evidence": "HbA1c 7.2 (01/10/25)",
        "confidence": "high",
        "note": None,
    }
    base.update(overrides)
    return base


def results_payload(**overrides):
    base = {
        "document_id": "MNL000W2225120",
        "visit_date": "2025-05-14",
        "blood_pressure": [bp_reading()],
        "hba1c": [hba1c_reading()],
        "flags": [],
    }
    base.update(overrides)
    return base


def agent_result(payload, last_message="DONE"):
    return {
        "files": {"/results.json": json.dumps(payload)},
        "messages": [{"content": last_message}],
    }


def out(tmp_path):
    return str(tmp_path / "out" / "results.json")


class TestHappyPath:
    def test_valid_results_written_and_returned(self, tmp_path):
        output_path = out(tmp_path)
        model = postprocess(agent_result(results_payload()), RAW_PAGES, output_path)

        assert model.document_id == "MNL000W2225120"
        assert len(model.blood_pressure) == 1
        assert len(model.hba1c) == 1
        assert model.flags == []

        on_disk = json.loads((tmp_path / "out" / "results.json").read_text())
        assert on_disk["visit_date"] == "2025-05-14"

    def test_state_backend_v2_filedata_dict_supported(self, tmp_path):
        result = {
            "files": {
                "/results.json": {
                    "content": json.dumps(results_payload()),
                    "encoding": "utf-8",
                }
            },
            "messages": [{"content": "DONE"}],
        }
        model = postprocess(result, RAW_PAGES, out(tmp_path))
        assert len(model.blood_pressure) == 1

    def test_extra_flags_are_merged(self, tmp_path):
        model = postprocess(
            agent_result(results_payload()),
            RAW_PAGES,
            out(tmp_path),
            extra_flags=["duplicate page number 2 in input; stored as /pages/page_02_b.md"],
        )
        assert any("duplicate page number 2" in f for f in model.flags)


class TestEvidenceGate:
    def test_evidence_not_on_page_is_dropped_and_flagged(self, tmp_path):
        payload = results_payload(
            blood_pressure=[bp_reading(evidence="BP 999/99 standing")]
        )
        model = postprocess(agent_result(payload), RAW_PAGES, out(tmp_path))

        assert model.blood_pressure == []
        assert (
            "dropped page 2 reading: evidence not found programmatically"
            in model.flags
        )

    def test_whitespace_is_normalized_before_matching(self, tmp_path):
        # Page has 'BP 140/90    sitting' (multiple spaces); evidence has one.
        model = postprocess(agent_result(results_payload()), RAW_PAGES, out(tmp_path))
        assert len(model.blood_pressure) == 1

    def test_reading_from_unknown_page_is_dropped(self, tmp_path):
        payload = results_payload(hba1c=[hba1c_reading(source_page=9)])
        model = postprocess(agent_result(payload), RAW_PAGES, out(tmp_path))
        assert model.hba1c == []
        assert any("page 9" in f for f in model.flags)

    def test_duplicate_page_copies_are_both_searched(self, tmp_path):
        # The splitter concatenates duplicate copies under one page number.
        raw_pages = dict(RAW_PAGES)
        raw_pages[2] = RAW_PAGES[2] + "\nPage 2 again\nRecheck BP 132/84 left arm\n"
        payload = results_payload(
            blood_pressure=[
                bp_reading(),
                bp_reading(systolic=132, diastolic=84, evidence="BP 132/84 left arm"),
            ]
        )
        model = postprocess(agent_result(payload), raw_pages, out(tmp_path))
        assert len(model.blood_pressure) == 2

    def test_evidence_from_overlap_context_never_passes(self, tmp_path):
        """§3a no-leak rule: evidence sitting only on the PREVIOUS page fails the
        gate for the claiming page, even though the decorated agent file for
        that page contains it inside <CONTEXT_FROM_PREVIOUS_PAGE>."""
        document = (
            "<ocr_service_page_start>1<ocr_service_page_start>\n"
            "Labs from 01/10/25:\nHbA1c 9.9 %\n"
            "<ocr_service_page_start>2<ocr_service_page_start>\n"
            "Assessment and plan. No labs on this page.\n"
        )
        split = split_pages(document)
        # Sanity: the decorated page-2 file DOES contain the page-1 text...
        assert "HbA1c 9.9 %" in split.agent_files["/pages/page_02.md"]

        payload = results_payload(
            blood_pressure=[],
            hba1c=[
                hba1c_reading(
                    value=9.9, source_page=2, evidence="HbA1c 9.9 %", date=None,
                    date_source="none",
                )
            ],
        )
        # ...but the gate, running on raw_pages, must drop the reading.
        model = postprocess(agent_result(payload), split.raw_pages, out(tmp_path))
        assert model.hba1c == []
        assert (
            "dropped page 2 reading: evidence not found programmatically"
            in model.flags
        )


class TestFailuresAreLoud:
    def test_missing_results_json_raises_with_last_message(self, tmp_path):
        result = {"files": {}, "messages": [{"content": "I could not finish"}]}
        with pytest.raises(PostprocessError, match="I could not finish"):
            postprocess(result, RAW_PAGES, out(tmp_path))

    def test_invalid_json_raises_with_last_message(self, tmp_path):
        result = {
            "files": {"/results.json": "{not json"},
            "messages": [{"content": "DONE"}],
        }
        with pytest.raises(PostprocessError, match="not valid JSON"):
            postprocess(result, RAW_PAGES, out(tmp_path))

    def test_schema_violation_raises_validation_error(self, tmp_path):
        payload = results_payload(
            blood_pressure=[bp_reading(systolic="not-a-number")]
        )
        with pytest.raises(ValidationError):
            postprocess(agent_result(payload), RAW_PAGES, out(tmp_path))


class TestDedupeAndSort:
    def test_exact_duplicates_collapse_to_first_and_flag(self, tmp_path):
        payload = results_payload(hba1c=[hba1c_reading(), hba1c_reading()])
        model = postprocess(agent_result(payload), RAW_PAGES, out(tmp_path))

        assert len(model.hba1c) == 1
        assert any("deduped exact duplicate" in f for f in model.flags)

    def test_same_value_different_evidence_is_kept(self, tmp_path):
        payload = results_payload(
            hba1c=[
                hba1c_reading(),
                hba1c_reading(
                    value=6.8, date="2024-08-02", evidence="HbA1c 6.8 (08/02/24)"
                ),
            ]
        )
        model = postprocess(agent_result(payload), RAW_PAGES, out(tmp_path))
        assert len(model.hba1c) == 2

    def test_sorted_by_date_then_page_nulls_last(self, tmp_path):
        payload = results_payload(
            hba1c=[
                hba1c_reading(
                    date=None, date_source="none", evidence="HbA1c 6.8 (08/02/24)", value=6.8
                ),
                hba1c_reading(),
            ]
        )
        model = postprocess(agent_result(payload), RAW_PAGES, out(tmp_path))
        assert [r.date for r in model.hba1c] == ["2025-01-10", None]
