"""Assertion hook for the §3a page-path rules on task calls (plan §3, §8).

Inspects a message trace (the ``messages`` list from an agent run) and fails
if any ``task`` tool call aimed at the metadata/extractor/verifier subagents
violates the agreed context rules:

- Every call names at least one page path (the PRIMARY page).
- A standard call names exactly ONE page path.
- Additional CONTEXT paths appear only in stitch-pass calls — recognized by an
  explicit CONTEXT designation in the instruction — and only for
  extractor/verifier, never metadata.
- Hard cap: never more than 3 page paths in one call.

Also exposes :func:`count_stitch_calls` for the §8 acceptance assertions
("no stitch call fired" / "exactly one stitched re-extraction").
"""

import re
from dataclasses import dataclass
from typing import Any, Iterable, List

PAGE_PATH_RE = re.compile(r"/pages/page_\d+(?:_[a-z])?\.md")
CONTEXT_MARKER_RE = re.compile(r"\bcontext\b", re.IGNORECASE)

SINGLE_PAGE_SUBAGENTS = {"metadata", "extractor", "verifier"}
MAX_PAGE_PATHS = 3


@dataclass
class TaskCallInfo:
    call_id: str
    subagent: str
    paths: List[str]
    is_stitch: bool  # 2+ paths with an explicit CONTEXT designation


def _tool_calls_of(message: Any) -> List[dict]:
    calls = getattr(message, "tool_calls", None)
    if calls is None and isinstance(message, dict):
        calls = message.get("tool_calls")
    return [c for c in (calls or []) if isinstance(c, dict)]


def _string_values(value: Any) -> Iterable[str]:
    """Yield every string nested anywhere inside a tool-call args structure."""
    if isinstance(value, str):
        yield value
    elif isinstance(value, dict):
        for v in value.values():
            yield from _string_values(v)
    elif isinstance(value, (list, tuple)):
        for v in value:
            yield from _string_values(v)


def _target_subagent(args: Any) -> str:
    """The single-page subagent this task call addresses, or '' if none.

    Robust to key naming across deepagents versions (``subagent_type``,
    ``name``, …): any string value that exactly equals a subagent name counts.
    """
    for s in _string_values(args):
        if s in SINGLE_PAGE_SUBAGENTS:
            return s
    return ""


def analyze_task_calls(messages: Iterable[Any]) -> List[TaskCallInfo]:
    """Collect every metadata/extractor/verifier task call with its page paths."""
    infos = []
    for message in messages:
        for call in _tool_calls_of(message):
            if call.get("name") != "task":
                continue
            args = call.get("args", {})
            subagent = _target_subagent(args)
            if not subagent:
                continue
            paths = set()
            has_context_marker = False
            for text in _string_values(args):
                paths.update(PAGE_PATH_RE.findall(text))
                if CONTEXT_MARKER_RE.search(text):
                    has_context_marker = True
            infos.append(
                TaskCallInfo(
                    call_id=str(call.get("id", "?")),
                    subagent=subagent,
                    paths=sorted(paths),
                    is_stitch=len(paths) > 1 and has_context_marker,
                )
            )
    return infos


def find_page_path_violations(messages: Iterable[Any]) -> List[str]:
    """Return one description per task call violating the §3a path rules."""
    violations = []
    for info in analyze_task_calls(messages):
        n = len(info.paths)
        where = f"task call {info.call_id} ({info.subagent})"
        if n == 0:
            violations.append(f"{where} names no page path")
        elif n > MAX_PAGE_PATHS:
            violations.append(
                f"{where} exceeds the {MAX_PAGE_PATHS}-path hard cap: {info.paths}"
            )
        elif n > 1 and info.subagent == "metadata":
            violations.append(
                f"{where} must name exactly one page path, got: {info.paths}"
            )
        elif n > 1 and not info.is_stitch:
            violations.append(
                f"{where} names {n} page paths without a CONTEXT designation "
                f"(only stitch-pass calls may carry context pages): {info.paths}"
            )
    return violations


def count_stitch_calls(messages: Iterable[Any], subagent: str = "extractor") -> int:
    """How many stitched calls (2+ paths, CONTEXT-designated) hit ``subagent``."""
    return sum(
        1
        for info in analyze_task_calls(messages)
        if info.subagent == subagent and info.is_stitch
    )


def assert_page_path_rules(messages: Iterable[Any]) -> None:
    violations = find_page_path_violations(messages)
    assert not violations, (
        "§3a page-path rules violated:\n" + "\n".join(violations)
    )
