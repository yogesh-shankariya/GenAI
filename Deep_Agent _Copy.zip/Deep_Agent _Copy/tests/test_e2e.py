"""End-to-end tests (plan §8).

Two layers:

- Trace-guard unit tests (always run): the assertion hook that enforces the
  §3a page-path rules (exactly one PRIMARY page per call, CONTEXT paths only
  in stitch calls, max 3 paths) on a message trace.
- Integration tests (``@pytest.mark.integration``, deselected by default):
  hit the REAL Horizon gateway. They run ONLY in the client environment with a
  populated ``.env`` — never elsewhere.
"""

import os
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

from tests.helpers.trace_guard import (
    assert_page_path_rules,
    count_stitch_calls,
    find_page_path_violations,
)

FIXTURES = Path(__file__).parent / "fixtures"

requires_horizon = pytest.mark.skipif(
    not os.getenv("HORIZON_BASE_URL"),
    reason="requires the client environment (populated .env with Horizon access)",
)


def task_call(instruction: str, subagent: str = "extractor", call_id: str = "c1"):
    return AIMessage(
        content="",
        tool_calls=[
            {
                "name": "task",
                "args": {"description": instruction, "subagent_type": subagent},
                "id": call_id,
            }
        ],
    )


class TestTraceGuardUnit:
    def test_single_primary_page_passes(self):
        messages = [
            task_call("Extract from /pages/page_01.md. visit_date=2025-05-14"),
            task_call("Verify on /pages/page_02.md: [...]", subagent="verifier"),
            task_call("Read /pages/page_01.md only.", subagent="metadata"),
        ]
        assert_page_path_rules(messages)
        assert count_stitch_calls(messages) == 0

    def test_two_paths_without_context_designation_is_a_violation(self):
        messages = [
            task_call("Extract from /pages/page_01.md and /pages/page_02.md")
        ]
        violations = find_page_path_violations(messages)
        assert len(violations) == 1
        with pytest.raises(AssertionError, match="CONTEXT designation"):
            assert_page_path_rules(messages)

    def test_stitch_call_with_context_designation_passes(self):
        messages = [
            task_call(
                "Stitched re-extraction. PRIMARY page: /pages/page_03.md. "
                "CONTEXT page: /pages/page_02.md. Read both as one continuous "
                "document; extract only values physically on the primary page. "
                "visit_date=2025-05-14"
            )
        ]
        assert_page_path_rules(messages)
        assert count_stitch_calls(messages) == 1

    def test_verifier_may_reuse_stitch_context_paths(self):
        messages = [
            task_call(
                "Verify. PRIMARY page: /pages/page_03.md (stitched with CONTEXT "
                "page /pages/page_02.md). Candidates: [...]",
                subagent="verifier",
            )
        ]
        assert_page_path_rules(messages)

    def test_four_paths_exceed_hard_cap_even_with_context(self):
        messages = [
            task_call(
                "Stitched re-extraction. PRIMARY: /pages/page_04.md. CONTEXT: "
                "/pages/page_03.md, /pages/page_02.md, /pages/page_01.md."
            )
        ]
        with pytest.raises(AssertionError, match="hard cap"):
            assert_page_path_rules(messages)

    def test_metadata_never_gets_context_pages(self):
        messages = [
            task_call(
                "Read /pages/page_01.md with CONTEXT /pages/page_02.md.",
                subagent="metadata",
            )
        ]
        with pytest.raises(AssertionError, match="exactly one page path"):
            assert_page_path_rules(messages)

    def test_call_without_any_page_path_is_a_violation(self):
        messages = [task_call("Extract everything. visit_date=2025-05-14")]
        with pytest.raises(AssertionError, match="no page path"):
            assert_page_path_rules(messages)

    def test_duplicate_suffix_paths_count_separately(self):
        messages = [
            task_call("Extract from /pages/page_02.md and /pages/page_02_b.md")
        ]
        assert len(find_page_path_violations(messages)) == 1

    def test_same_path_twice_is_not_a_violation(self):
        messages = [
            task_call("Read /pages/page_01.md. Only /pages/page_01.md, nothing else.")
        ]
        assert_page_path_rules(messages)

    def test_non_task_and_non_page_calls_are_ignored(self):
        messages = [
            AIMessage(
                content="",
                tool_calls=[
                    {"name": "write_todos", "args": {"todos": ["a", "b"]}, "id": "c9"}
                ],
            ),
            task_call("general research, no page files", subagent="general-purpose"),
        ]
        assert_page_path_rules(messages)


def _invoke_agent_on(document_path: Path):
    """Build the real agent, run it on one fixture, return (result, split)."""
    from src.agent.build_agent import build_agent
    from src.agent.prompts import USER_TASK_TEMPLATE
    from src.config import build_token_manager, load_config
    from src.horizon.chat_horizon import ChatHorizon
    from src.pipeline.splitter import split_pages

    document = document_path.read_text(encoding="utf-8")
    split = split_pages(document)

    config = load_config()
    model = ChatHorizon(
        base_url=config["horizon_base_url"],
        token_manager=build_token_manager(config),
        qos=config["qos"],
        reasoning=config["reasoning"],
        preview=config["preview"],
    )
    agent = build_agent(model)

    result = agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": USER_TASK_TEMPLATE.format(
                        worklist="\n".join(sorted(split.agent_files))
                    ),
                }
            ],
            "files": split.agent_files,
        },
        config={"recursion_limit": 1000},
    )
    return result, split


@pytest.mark.integration
class TestEndToEndRealModel:
    """Acceptance criteria on the repo sample (plan §8). Client environment only."""

    @requires_horizon
    def test_sample_document_acceptance(self, tmp_path):
        from src.pipeline.run import run

        result = run(
            str(FIXTURES / "sample_input.md"),
            str(tmp_path / "results.json"),
        )

        # The 3-page sample contains NO BP/HbA1c measurements — any reading
        # here is a hallucination.
        assert result.blood_pressure == []
        assert result.hba1c == []
        assert result.visit_date == "2025-05-14"
        assert result.document_id == "MNL000W2225120"

    @requires_horizon
    def test_message_trace_respects_page_path_rules(self):
        result, _split = _invoke_agent_on(FIXTURES / "sample_input.md")

        assert_page_path_rules(result["messages"])
        assert "/results.json" in (result.get("files") or {})

    @requires_horizon
    def test_split_table_overlap_resolved_without_stitch(self, tmp_path, monkeypatch):
        """§8 fixture 7: the overlap alone suffices; NO stitch call fires."""
        from src.pipeline.postprocess import postprocess

        # Pin the overlap window: fixture semantics are calibrated to 20 lines
        # and a client .env may legitimately tune HORIZON_OVERLAP_LINES (§10).
        monkeypatch.setenv("HORIZON_OVERLAP_LINES", "20")
        result, split = _invoke_agent_on(
            FIXTURES / "synthetic_pages" / "split_table_overlap.md"
        )

        assert_page_path_rules(result["messages"])
        assert count_stitch_calls(result["messages"]) == 0  # overlap was enough

        model = postprocess(
            result, split.raw_pages, str(tmp_path / "overlap.json"),
            extra_flags=split.flags,
        )
        assert sorted(r.value for r in model.hba1c) == [6.8, 7.2]
        for reading in model.hba1c:
            assert reading.source_page == 2  # zero readings attributed to page 1
            assert reading.date_source in ("table_header", "table_row")
            assert "date from previous page" in (reading.note or "")
        assert sorted(r.date for r in model.hba1c) == ["2024-08-02", "2025-01-10"]
        assert model.blood_pressure == []

    @requires_horizon
    def test_split_table_stitch_fires_exactly_one_re_extraction(self, tmp_path, monkeypatch):
        """§8 fixture 8: header beyond overlap reach → exactly ONE stitch."""
        from src.pipeline.postprocess import postprocess

        # Pin the overlap window: the fixture's header sits 25 non-empty lines
        # from page 1's tail, i.e. beyond reach ONLY for windows <= 24. A
        # client .env with a raised HORIZON_OVERLAP_LINES (§10) would
        # otherwise silently invert this test's semantics.
        monkeypatch.setenv("HORIZON_OVERLAP_LINES", "20")
        result, split = _invoke_agent_on(
            FIXTURES / "synthetic_pages" / "split_table_stitch.md"
        )

        assert_page_path_rules(result["messages"])
        assert count_stitch_calls(result["messages"]) == 1

        model = postprocess(
            result, split.raw_pages, str(tmp_path / "stitch.json"),
            extra_flags=split.flags,
        )
        page_2 = [r for r in model.hba1c if r.source_page == 2]
        assert sorted(r.value for r in page_2) == [6.9, 7.4]
        for reading in page_2:
            assert reading.confidence == "medium"  # stitched resolution
            assert reading.date_source in ("table_header", "table_row")
        assert sorted(r.date for r in page_2) == ["2024-08-02", "2025-01-10"]

    @requires_horizon
    @pytest.mark.parametrize(
        "fixture_name",
        ["trend_table", "narrative_bp", "targets_only", "no_findings", "broken_table", "bmi_trap"],
    )
    def test_synthetic_fixture_pages(self, tmp_path, fixture_name):
        """Expected outcomes per fixture are documented in synthetic_pages/README.md."""
        from src.pipeline.run import run

        result = run(
            str(FIXTURES / "synthetic_pages" / f"{fixture_name}.md"),
            str(tmp_path / f"{fixture_name}.json"),
        )

        if fixture_name == "trend_table":
            assert len(result.hba1c) == 3
            assert all(r.date_source == "table_row" for r in result.hba1c)
            assert "2025-01-10" in [r.date for r in result.hba1c]  # 01:10:25 normalized
        elif fixture_name == "narrative_bp":
            assert len(result.blood_pressure) == 2
            sources = sorted(r.date_source for r in result.blood_pressure)
            assert sources == ["inline", "visit_date"]
        elif fixture_name in ("targets_only", "no_findings"):
            assert result.blood_pressure == []
            assert result.hba1c == []
        elif fixture_name == "broken_table":
            # Pairable values must be extracted...
            assert [(r.systolic, r.diastolic) for r in result.blood_pressure] == [
                (138, 88)
            ]
            assert any(r.value == 7.9 and r.unit == "%" for r in result.hba1c)
            # ...the orphan 6.9 must NOT be guess-paired into a reading...
            assert 6.9 not in [r.value for r in result.hba1c]
            # ...and the mangled rows must be flagged.
            assert result.flags
        elif fixture_name == "bmi_trap":
            assert [(r.systolic, r.diastolic) for r in result.blood_pressure] == [
                (128, 76)
            ]
            assert result.hba1c == []
