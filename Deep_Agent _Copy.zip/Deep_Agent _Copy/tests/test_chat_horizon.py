"""Unit tests for ChatHorizon + adapters (plan §5.3), all against mocked HTTP.

Fixtures under ``tests/fixtures/tool_chats_samples/`` mirror the REAL wire
shapes captured by the M0 probe on 2026-07-06 (OPEN-1/3/4 confirmed). The
tool-RESULT shape (OPEN-2) is still open — its test pins the current
best-guess in ``adapters._tool_result_wire`` and must be updated together
with that function once Probe B finds the accepted shape.
"""

import json
from pathlib import Path

import pytest
import responses
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage, ToolMessage
from langchain_core.tools import tool

from src.horizon import adapters
from src.horizon.adapters import (
    horizon_response_to_ai_message,
    lc_message_to_horizon,
    lc_messages_to_horizon,
    lc_tool_to_adhoc,
)
from src.horizon.chat_horizon import ChatHorizon

FIXTURES = Path(__file__).parent / "fixtures" / "tool_chats_samples"
BASE_URL = "https://horizon.test"
ENDPOINT = f"{BASE_URL}/v2/tool/chats"


def load_fixture(name: str) -> dict:
    return json.loads((FIXTURES / name).read_text(encoding="utf-8"))


class FakeTokenManager:
    """Stands in for the TokenManager singleton (mirrors its interface)."""

    def __init__(self, tokens=("tok-1", "tok-2", "tok-3")):
        self._tokens = list(tokens)
        self._index = 0
        self.cleared = 0

    def get_token(self):
        return self._tokens[min(self._index, len(self._tokens) - 1)]

    def clear_cache(self):
        self.cleared += 1
        self._index += 1


@tool
def get_weather(city: str) -> str:
    """Get the current weather for a city"""
    return "72F, sunny"


def make_model(**overrides) -> ChatHorizon:
    params = {
        "base_url": BASE_URL,
        "token_manager": FakeTokenManager(),
        "max_retries": 3,
    }
    params.update(overrides)
    return ChatHorizon(**params)


class TestToolConversion:
    def test_tool_decorated_function_to_adhoc(self):
        adhoc = lc_tool_to_adhoc(get_weather)
        assert adhoc["type"] == "adhoc"
        assert adhoc["name"] == "get_weather"
        assert adhoc["description"] == "Get the current weather for a city"
        assert adhoc["parameters"]["properties"]["city"]["type"] == "string"
        assert "city" in adhoc["parameters"]["required"]

    def test_already_adhoc_dict_passes_through(self):
        adhoc = {"type": "adhoc", "name": "x", "description": "y", "parameters": {}}
        assert lc_tool_to_adhoc(adhoc) is adhoc


class TestMessageConversion:
    def test_ai_message_with_tool_call_becomes_standalone_tool_call_message(self):
        """OPEN-1 confirmed: one standalone tool_call wire message per call."""
        ai = AIMessage(
            content="",
            tool_calls=[
                {"name": "get_weather", "args": {"city": "Fresno"}, "id": "call_abc"}
            ],
        )
        assert lc_message_to_horizon(ai) == [
            {
                "type": "tool_call",
                "role": "assistant",
                "id": "call_abc",
                "name": "get_weather",
                "input": {"city": "Fresno"},
            }
        ]

    def test_ai_message_with_text_and_calls_emits_text_then_calls(self):
        ai = AIMessage(
            content="Checking two cities.",
            tool_calls=[
                {"name": "get_weather", "args": {"city": "Fresno"}, "id": "c1"},
                {"name": "get_weather", "args": {"city": "Sacramento"}, "id": "c2"},
            ],
        )
        wire = lc_message_to_horizon(ai)
        assert [m["type"] for m in wire] == ["message", "tool_call", "tool_call"]
        assert wire[0]["content"] == "Checking two cities."
        assert [m["id"] for m in wire[1:]] == ["c1", "c2"]

    def test_tool_message_emits_open2_best_guess_shape(self):
        """OPEN-2 STILL OPEN: pins adapters._tool_result_wire; update both
        together once Probe B identifies the accepted shape."""
        wire = lc_message_to_horizon(
            ToolMessage(content="72F, sunny", tool_call_id="call_abc")
        )
        assert wire == [adapters._tool_result_wire("call_abc", "72F, sunny")]
        assert wire[0]["type"] == "tool_result"

    def test_system_role_sent_when_supported(self):
        """OPEN-4 confirmed: system role accepted and respected (Probe D)."""
        wire = lc_messages_to_horizon([SystemMessage("rules"), HumanMessage("hi")])
        assert wire[0] == {"type": "message", "role": "system", "content": "rules"}

    def test_system_merged_into_first_user_when_unsupported(self, monkeypatch):
        monkeypatch.setattr(adapters, "SYSTEM_ROLE_SUPPORTED", False)
        wire = lc_messages_to_horizon([SystemMessage("rules"), HumanMessage("hi")])
        assert len(wire) == 1
        assert wire[0]["role"] == "user"
        assert wire[0]["content"] == "[SYSTEM]\nrules\n\n[USER]\nhi"


class TestResponseParsing:
    def test_real_capture_tool_call_response(self):
        """Probe A capture: standalone tool_call message, args under 'input'."""
        ai = horizon_response_to_ai_message(load_fixture("probe_a_tool_call.json"))
        assert ai.tool_calls == [
            {
                "name": "get_weather",
                "args": {"city": "Fresno"},
                "id": "call_eF0svVWiKOz0RSpK6sy9UxNl",
                "type": "tool_call",
            }
        ]

    def test_real_capture_multi_tool_call_response(self):
        """Probe C capture: two standalone tool_call messages in one response
        — BOTH must be parsed (a regression here loses whole pages of work)."""
        ai = horizon_response_to_ai_message(
            load_fixture("probe_c_multi_tool_call.json")
        )
        assert [c["args"]["city"] for c in ai.tool_calls] == ["Fresno", "Sacramento"]
        assert [c["id"] for c in ai.tool_calls] == [
            "call_NbMODtmT1ZFHwLGeNOdVljeI",
            "call_z3YIW2TlbfTGTNX8V6hz55KP",
        ]

    def test_string_args_parsed_and_id_synthesized(self):
        ai = horizon_response_to_ai_message(
            load_fixture("probe_a_tool_call_string_args.json")
        )
        assert len(ai.tool_calls) == 1
        call = ai.tool_calls[0]
        assert call["args"] == {"city": "Fresno"}  # json.loads-ed into a dict
        assert call["id"].startswith("call_")

    def test_plain_text_response(self):
        ai = horizon_response_to_ai_message(load_fixture("probe_b_plain_text.json"))
        assert ai.tool_calls == []
        assert "72F and sunny" in ai.content

    def test_malformed_tool_call_degrades_to_plain_message(self):
        ai = horizon_response_to_ai_message(load_fixture("malformed_tool_call.json"))
        assert isinstance(ai, AIMessage)
        assert ai.tool_calls == []
        assert ai.content == "I will look that up."

    def test_garbage_response_never_raises(self):
        for garbage in (None, {}, {"messages": "nope"}, {"messages": []}, "text"):
            ai = horizon_response_to_ai_message(garbage)
            assert isinstance(ai, AIMessage)


class TestTransport:
    @responses.activate
    def test_round_trip_payload_matches_contract(self):
        responses.add(
            responses.POST, ENDPOINT, json=load_fixture("probe_a_tool_call.json")
        )
        model = make_model()
        bound = model.bind_tools([get_weather])

        result = bound.invoke("What is the weather in Fresno right now? Use the tool.")

        body = json.loads(responses.calls[0].request.body)
        assert body["tools"] == [lc_tool_to_adhoc(get_weather)]
        assert body["messages"] == [
            {
                "type": "message",
                "role": "user",
                "content": "What is the weather in Fresno right now? Use the tool.",
            }
        ]
        request = responses.calls[0].request
        assert request.headers["Authorization"] == "Bearer tok-1"
        assert "qos=accurate" in request.url and "reasoning=false" in request.url

        assert isinstance(result, AIMessage)
        assert result.tool_calls[0]["name"] == "get_weather"
        assert result.tool_calls[0]["args"] == {"city": "Fresno"}
        assert result.tool_calls[0]["id"] == "call_eF0svVWiKOz0RSpK6sy9UxNl"

    @responses.activate
    def test_tool_loop_turn_sends_tool_call_and_result_messages(self):
        """A full agent turn: user → assistant tool_call → ToolMessage. The
        request must carry the confirmed standalone tool_call message and the
        (best-guess, OPEN-2) tool_result message."""
        responses.add(
            responses.POST, ENDPOINT, json=load_fixture("probe_b_plain_text.json")
        )
        model = make_model()
        result = model.invoke(
            [
                HumanMessage("What is the weather in Fresno? Use the tool."),
                AIMessage(
                    content="",
                    tool_calls=[
                        {"name": "get_weather", "args": {"city": "Fresno"},
                         "id": "call_abc"}
                    ],
                ),
                ToolMessage(content="72F, sunny", tool_call_id="call_abc"),
            ]
        )

        body = json.loads(responses.calls[0].request.body)
        assert [m["type"] for m in body["messages"]] == [
            "message", "tool_call", "tool_result",
        ]
        assert body["messages"][1]["input"] == {"city": "Fresno"}
        assert body["messages"][2] == adapters._tool_result_wire(
            "call_abc", "72F, sunny"
        )
        assert "72F and sunny" in result.content

    @responses.activate
    def test_401_clears_cache_and_retries_with_fresh_token(self):
        responses.add(responses.POST, ENDPOINT, json={"error": "unauthorized"}, status=401)
        responses.add(
            responses.POST, ENDPOINT, json=load_fixture("probe_b_plain_text.json")
        )
        fake = FakeTokenManager()
        model = make_model(token_manager=fake)

        result = model.invoke("hello")

        assert isinstance(result, AIMessage)
        assert fake.cleared == 1
        assert len(responses.calls) == 2
        assert responses.calls[0].request.headers["Authorization"] == "Bearer tok-1"
        assert responses.calls[1].request.headers["Authorization"] == "Bearer tok-2"

    @responses.activate
    def test_repeated_5xx_exhausts_retries_and_raises(self):
        import requests as requests_lib

        for _ in range(3):
            responses.add(responses.POST, ENDPOINT, json={}, status=503)
        model = make_model()

        with pytest.raises(requests_lib.exceptions.HTTPError):
            model.invoke("hello")
        assert len(responses.calls) == 3

    def test_query_params_preview_branch(self):
        assert make_model(preview="true")._query_params() == {
            "qos": "accurate",
            "preview": "true",
        }

    def test_query_params_reasoning_branch(self):
        assert make_model()._query_params() == {
            "qos": "accurate",
            "reasoning": "false",
        }
