# `/v2/tool/chats` Contract (Milestone 0 deliverable)

> **STATUS: OPEN-1 / OPEN-3 / OPEN-4 CONFIRMED** from the real probe run of
> **2026-07-06** (client environment). **OPEN-2 (tool-result shape) is STILL
> OPEN** — both plan candidates were rejected with 422; see below for the
> re-run procedure. The confirmed shapes are implemented in
> `src/horizon/adapters.py` and mirrored by `tests/fixtures/tool_chats_samples/`.

## Contract items

| # | Question | Answer | Status |
|---|---|---|---|
| OPEN-1 | Message shape the model uses to **make a tool call** | A **standalone message**: `{"type": "tool_call", "role": "assistant", "id": "call_<24 chars>", "name": "get_weather", "input": {…}}`. Arguments live under **`input`** as a JSON object. Echoing this message back verbatim in a follow-up request validates (Probe B's 422 pointed at index 2, not the echoed call at index 1). | **CONFIRMED** (Probe A) |
| OPEN-2 | Message shape accepted to **return a tool result** | **UNKNOWN.** Candidate 1 (`{"type": "tool_result", "tool_call_id", "content"}`) and candidate 2 (`{"type": "message", "role": "tool", "content"}`) both → 422 `ValidationError`: `[/messages/2] Property 'messages.2' should be one of: 'object', 'object', 'object'` — the message union has exactly **three** variants; `message` and `tool_call` are known, the third is the result shape we haven't matched. | **OPEN** |
| OPEN-3 | Can one response carry **multiple tool calls**? | **Yes** — as **multiple standalone `tool_call` messages** in one response (Probe C returned two, Fresno + Sacramento, each with its own id). | **CONFIRMED** (Probe C) |
| OPEN-4 | Is a **`system` role** accepted and respected? | **Yes** — 200, and the answer honored the system instruction (responded in French). `SYSTEM_ROLE_SUPPORTED = True` in `adapters.py`; the merge fallback remains implemented but dormant. | **CONFIRMED** (Probe D) |

## Additional confirmed facts

- **The 200 response body contains ONLY model-authored messages** — the sent
  conversation is NOT echoed back. The adapter therefore parses every message
  in the response (`horizon_response_to_ai_message`); the earlier
  "slice after sent_count" heuristic was wrong and has been removed (it would
  have dropped all but the last tool call on multi-call turns).
- Call ids are `call_` + 24 chars (OpenAI-style). The adapter still
  synthesizes `call_<uuid4-12hex>` if an id is ever absent.
- Query params `qos` / `reasoning` / `preview` follow the `llm_client.py`
  branching; defaults: `qos=accurate, preview=false, reasoning=false`.

## Closing OPEN-2 (do this next)

1. **Check the internal API docs' message-union schema first** — the validator
   says exactly three variants exist; the docs may name the third outright.
   If found, put that exact shape at the top of `TOOL_RESULT_CANDIDATES` in
   `src/horizon/probe_tool_chats.py`.
2. Run the expanded battery (8 labeled candidates, ordered by likelihood given
   the confirmed `id`/`input` naming):

   ```bash
   python -m src.horizon.probe_tool_chats --probes b
   ```

   It stops at the first 200 and prints the winning shape; captures land in
   `tests/fixtures/tool_chats_samples/probe_b_candidate_NN.json`.
3. Update **`_tool_result_wire()` in `src/horizon/adapters.py`** (the single
   place the result shape lives) and the pinned test
   `test_tool_message_emits_open2_best_guess_shape`, plus this table.
4. Re-run `pytest tests/test_chat_horizon.py`.

Until OPEN-2 is closed, the current best guess in `_tool_result_wire()` is
`{"type": "tool_result", "role": "tool", "id": <call id>, "content": …}` —
**the pipeline cannot complete a tool loop against the real gateway until the
accepted shape is confirmed**, because every deepagents step returns tool
results to the model.

## Fixture inventory (`tests/fixtures/tool_chats_samples/`)

See that directory's README. `probe_a_tool_call.json` and
`probe_c_multi_tool_call.json` mirror the real captures; the string-args and
malformed variants are synthetic tolerance tests; the Probe B captures from
the client environment should be committed alongside once OPEN-2 closes.
