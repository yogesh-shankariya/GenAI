"""Direct entrypoint — edit the paths below and run:  python main.py

Convenience wrapper around the pipeline (equivalent to
``python -m src.pipeline.run --input ... --output ...``). Relative paths are
resolved against this repo's root, so it works from any working directory.
"""

from pathlib import Path

# ---------------------------------------------------------------------------
# EDIT THESE
# ---------------------------------------------------------------------------
INPUT_PATH = "Input/input.md"          # OCR'd document (.md with page tags)
OUTPUT_PATH = "out/results.json"       # validated ExtractionResult JSON
VERBOSE = False                        # True = DEBUG logs (contain PHI — use
                                       # only inside the PHI boundary)
# ---------------------------------------------------------------------------

REPO_ROOT = Path(__file__).resolve().parent


def _resolve(path: str) -> str:
    p = Path(path)
    return str(p if p.is_absolute() else REPO_ROOT / p)


def main() -> None:
    from src.config import configure_logging
    from src.pipeline.run import run

    configure_logging(verbose=VERBOSE)

    input_path = _resolve(INPUT_PATH)
    output_path = _resolve(OUTPUT_PATH)

    result = run(input_path, output_path)

    # Counts only on stdout — the readings themselves are PHI and live in the
    # output file.
    print(
        f"Done: {len(result.blood_pressure)} BP reading(s), "
        f"{len(result.hba1c)} HbA1c reading(s), "
        f"{len(result.flags)} flag(s) -> {output_path}"
    )
    if result.flags:
        print("Review the 'flags' array in the output file before consuming results.")


if __name__ == "__main__":
    main()
