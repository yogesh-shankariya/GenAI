"""Deep agent assembly: orchestrator/subagent prompts and agent construction."""
