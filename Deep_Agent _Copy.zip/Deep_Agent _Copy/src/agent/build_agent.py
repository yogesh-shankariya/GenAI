"""Deep agent assembly (plan §5.4).

Version notes (verified against the pinned ``deepagents==0.6.12`` source):

- ``create_deep_agent(model=..., system_prompt=..., subagents=[...])`` — the
  subagent spec key IS ``system_prompt`` in this release.
- Subagents with no explicit ``tools`` entry inherit the main agent's tools
  (``SubAgent.tools``: "If not specified, inherits tools from the main agent"),
  which include the filesystem middleware tools — so extractor/verifier get
  ``read_file`` without extra configuration.
- The default backend is ``StateBackend`` (ephemeral, in agent state); files
  are pre-populated on invoke via ``agent.invoke({"messages": [...], "files":
  {...}})`` and read back from ``result["files"]``.
- If M0 (Probe C) shows the API returns only ONE tool call per response,
  fan-out degrades gracefully to serial; optionally append one line to the
  orchestrator prompt: "Issue one task call per turn."
"""

from deepagents import create_deep_agent

from src.agent.prompts import (
    EXTRACTOR_PROMPT,
    METADATA_PROMPT,
    ORCHESTRATOR_PROMPT,
    VERIFIER_PROMPT,
)


def build_agent(model):
    """Assemble the orchestrator + metadata/extractor/verifier deep agent."""
    subagents = [
        {
            "name": "metadata",
            "description": "Reads ONE page file and returns document-level metadata "
            "(visit date, member id) as JSON.",
            "system_prompt": METADATA_PROMPT,
        },
        {
            "name": "extractor",
            "description": "Reads ONE primary page file (plus optional read-only "
            "context pages when stitching) and returns every "
            "blood-pressure and HbA1c reading on the primary page, "
            "each with its date, plus boundary flags, as JSON.",
            "system_prompt": EXTRACTOR_PROMPT,
        },
        {
            "name": "verifier",
            "description": "Given ONE primary page path (plus any context pages) and "
            "candidate readings JSON, audits every candidate against "
            "the page and returns verified/rejected readings as JSON.",
            "system_prompt": VERIFIER_PROMPT,
        },
    ]
    return create_deep_agent(
        model=model,
        subagents=subagents,
        system_prompt=ORCHESTRATOR_PROMPT,
    )
