"""Configuration loading and process-wide singletons (plan §5.7).

``load_config()`` builds the dict shape :class:`TokenManager` already expects
(``token_validity_seconds``, ``refresh_margin_seconds``, ``auth_url``,
``min_connection_timeout_seconds``, ``max_read_timeout_seconds``) plus the
Horizon gateway settings used by :class:`ChatHorizon`.

PHI note (plan §10): logging is configured so INFO carries only counts, page
numbers, and timings. Page contents and extracted values may appear at DEBUG
only — never enable DEBUG in an environment where logs leave the PHI boundary.
"""

import logging
import os
from typing import Dict

from dotenv import load_dotenv

from src.horizon.token_manager import TokenManager


def load_config() -> Dict:
    """Read .env / environment variables into the shared config dict."""
    load_dotenv()

    return {
        # Horizon gateway
        "horizon_base_url": os.getenv("HORIZON_BASE_URL", ""),
        "auth_url": os.getenv("HORIZON_AUTH_URL", ""),
        # TokenManager contract
        "token_validity_seconds": int(os.getenv("TOKEN_VALIDITY_SECONDS", "3600")),
        "refresh_margin_seconds": int(os.getenv("REFRESH_MARGIN_SECONDS", "300")),
        "min_connection_timeout_seconds": float(
            os.getenv("MIN_CONNECTION_TIMEOUT_SECONDS", "10")
        ),
        "max_read_timeout_seconds": float(
            os.getenv("MAX_READ_TIMEOUT_SECONDS", "300")
        ),
        # Model quality parameters (defaults per plan §2)
        "qos": os.getenv("HORIZON_QOS", "accurate"),
        "reasoning": os.getenv("HORIZON_REASONING", "false"),
        "preview": os.getenv("HORIZON_PREVIEW", "false"),
    }


def build_token_manager(config: Dict) -> TokenManager:
    """Instantiate the TokenManager singleton once at process start.

    The same instance must be passed to every client that needs a token.
    """
    return TokenManager(
        config,
        os.getenv("HORIZON_CLIENT_ID", ""),
        os.getenv("HORIZON_CLIENT_SECRET", ""),
    )


def configure_logging(verbose: bool = False) -> None:
    """Set up structured logging for the pipeline.

    INFO: counts, page numbers, timings, request metadata (method/url/params).
    DEBUG: may contain page contents / extracted values — PHI. Only enable
    with ``verbose=True`` inside the PHI boundary.
    """
    level = logging.DEBUG if verbose else logging.INFO
    log_format = "%(asctime)s %(levelname)s %(name)s: %(message)s"
    logging.basicConfig(level=level, format=log_format)

    # The verbatim-copied TokenManager flushes self.logger.handlers[0] in
    # get_token()'s finally block. hasHandlers() is satisfied by root-logger
    # propagation, but handlers[0] requires a DIRECT handler on the
    # 'llm_service' logger — without one, every get_token() call raises
    # IndexError. Attach one here (propagate off to avoid double logging).
    llm_logger = logging.getLogger("llm_service")
    llm_logger.setLevel(level)
    if not llm_logger.handlers:
        handler = logging.StreamHandler()
        handler.setFormatter(logging.Formatter(log_format))
        llm_logger.addHandler(handler)
    llm_logger.propagate = False
