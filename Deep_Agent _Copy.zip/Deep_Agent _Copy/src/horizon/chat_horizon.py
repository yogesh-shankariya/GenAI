"""ChatHorizon — LangChain chat model over the Horizon ``/v2/tool/chats`` endpoint (plan §5.3).

This is a **format translation** layer, not an emulation layer: the endpoint
natively supports tool calling. All wire-shape knowledge lives in
``src/horizon/adapters.py``; this module owns only transport concerns
(auth, query params, timeouts, retries, 401 handling, logging).

Transport conventions mirror the existing ``llm_client.py``:

- Token via ``token_manager.get_token()`` per request;
  header ``Authorization: Bearer <token>``.
- Query params ``qos`` / ``reasoning`` / ``preview`` with the same branching
  logic (plan §2). Defaults: ``qos=accurate, preview=false, reasoning=false``.
- ``timeout=(connect_timeout, read_timeout)``.
- On 401: log a warning, ``token_manager.clear_cache()``, raise → the retry
  loop refetches with a fresh token.
- On other non-2xx: ``raise_for_status()``.

PHI note (plan §10): INFO logs carry method/url/params and message COUNT +
roles only. Page contents and extracted values are never logged above DEBUG.
"""

import logging
from typing import Any, Dict, List, Optional, Sequence

import httpx
import requests
from langchain_core.callbacks import (
    AsyncCallbackManagerForLLMRun,
    CallbackManagerForLLMRun,
)
from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import AIMessage, BaseMessage
from langchain_core.outputs import ChatGeneration, ChatResult
from pydantic import ConfigDict
from tenacity import (
    AsyncRetrying,
    Retrying,
    retry_if_exception_type,
    stop_after_attempt,
    wait_exponential,
)

from src.horizon.adapters import (
    horizon_response_to_ai_message,
    lc_messages_to_horizon,
    lc_tool_to_adhoc,
)

logger = logging.getLogger("llm_service")


class ChatHorizon(BaseChatModel):
    """Custom ``BaseChatModel`` over ``POST {base_url}/v2/tool/chats``."""

    model_config = ConfigDict(arbitrary_types_allowed=True)

    base_url: str
    token_manager: Any  # the shared TokenManager singleton
    qos: str = "accurate"
    reasoning: str = "false"
    preview: str = "false"
    connect_timeout: float = 10.0
    read_timeout: float = 300.0
    max_retries: int = 3

    @property
    def _llm_type(self) -> str:
        return "horizon-tool-chats"

    @property
    def _identifying_params(self) -> Dict[str, Any]:
        return {
            "base_url": self.base_url,
            "qos": self.qos,
            "reasoning": self.reasoning,
            "preview": self.preview,
        }

    # ------------------------------------------------------------------
    # Tool binding
    # ------------------------------------------------------------------

    def bind_tools(self, tools: Sequence[Any], **kwargs: Any):
        formatted = [lc_tool_to_adhoc(t) for t in tools]
        return self.bind(tools=formatted, **kwargs)

    # ------------------------------------------------------------------
    # Request plumbing (shared by sync and async paths)
    # ------------------------------------------------------------------

    @property
    def _endpoint(self) -> str:
        return f"{self.base_url}/v2/tool/chats"

    def _query_params(self) -> Dict[str, str]:
        """qos/reasoning/preview branching, replicated from ``llm_client.py`` (plan §2)."""
        params: Dict[str, str] = {}
        if self.preview == "true" and self.qos in ("accurate", "cheap"):
            params["qos"] = self.qos
            params["preview"] = self.preview
        elif self.qos in ("accurate", "cheap") and self.reasoning in ("true", "false"):
            params["qos"] = self.qos
            params["reasoning"] = self.reasoning
        return params

    def _build_payload(
        self, messages: List[BaseMessage], **kwargs: Any
    ) -> Dict[str, Any]:
        payload: Dict[str, Any] = {"messages": lc_messages_to_horizon(messages)}
        tools = kwargs.get("tools")
        if tools:
            payload["tools"] = list(tools)
        return payload

    def _log_request(self, payload: Dict[str, Any], params: Dict[str, str]) -> None:
        roles = [m.get("role", m.get("type", "?")) for m in payload["messages"]]
        logger.info(
            "POST %s params=%s messages=%d roles=%s tools=%d",
            self._endpoint,
            params,
            len(payload["messages"]),
            roles,
            len(payload.get("tools", [])),
        )
        # Full payload is PHI — DEBUG only (plan §10).
        logger.debug("Request payload: %s", payload)

    def _handle_401(self) -> None:
        logger.warning(
            "Received 401 unauthorized from /v2/tool/chats. Clearing token "
            "cache and re-raising for retry."
        )
        self.token_manager.clear_cache()

    # ------------------------------------------------------------------
    # Sync path (requests) — primary, matches the existing codebase
    # ------------------------------------------------------------------

    def _post_once(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        token = self.token_manager.get_token()
        params = self._query_params()
        self._log_request(payload, params)

        response = requests.post(
            self._endpoint,
            headers={
                "Authorization": f"Bearer {token}",
                "Content-Type": "application/json",
            },
            params=params or None,
            json=payload,
            timeout=(self.connect_timeout, self.read_timeout),
        )

        if response.status_code == 401:
            self._handle_401()

        response.raise_for_status()
        return response.json()

    def _post(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        """POST with retries: tries=max_retries, delay=1s, backoff=2 (plan §5.3)."""
        retryer = Retrying(
            stop=stop_after_attempt(self.max_retries),
            wait=wait_exponential(multiplier=1, min=1, max=30),
            retry=retry_if_exception_type(requests.exceptions.RequestException),
            reraise=True,
        )
        return retryer(self._post_once, payload)

    def _generate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[CallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        if stop:
            logger.debug("'stop' sequences are not supported by /v2/tool/chats; ignoring.")
        payload = self._build_payload(messages, **kwargs)
        raw = self._post(payload)
        # The response contains ONLY model-authored messages (M0 confirmed).
        ai: AIMessage = horizon_response_to_ai_message(raw)
        return ChatResult(generations=[ChatGeneration(message=ai)])

    # ------------------------------------------------------------------
    # Async path (httpx) — thin mirror of the sync path
    # ------------------------------------------------------------------

    async def _apost_once(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        token = self.token_manager.get_token()
        params = self._query_params()
        self._log_request(payload, params)

        timeout = httpx.Timeout(self.read_timeout, connect=self.connect_timeout)
        async with httpx.AsyncClient(timeout=timeout) as client:
            response = await client.post(
                self._endpoint,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                params=params or None,
                json=payload,
            )

        if response.status_code == 401:
            self._handle_401()

        response.raise_for_status()
        return response.json()

    async def _apost(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        retryer = AsyncRetrying(
            stop=stop_after_attempt(self.max_retries),
            wait=wait_exponential(multiplier=1, min=1, max=30),
            retry=retry_if_exception_type(httpx.HTTPError),
            reraise=True,
        )
        result: Dict[str, Any] = {}
        async for attempt in retryer:
            with attempt:
                result = await self._apost_once(payload)
        return result

    async def _agenerate(
        self,
        messages: List[BaseMessage],
        stop: Optional[List[str]] = None,
        run_manager: Optional[AsyncCallbackManagerForLLMRun] = None,
        **kwargs: Any,
    ) -> ChatResult:
        if stop:
            logger.debug("'stop' sequences are not supported by /v2/tool/chats; ignoring.")
        payload = self._build_payload(messages, **kwargs)
        raw = await self._apost(payload)
        ai: AIMessage = horizon_response_to_ai_message(raw)
        return ChatResult(generations=[ChatGeneration(message=ai)])
