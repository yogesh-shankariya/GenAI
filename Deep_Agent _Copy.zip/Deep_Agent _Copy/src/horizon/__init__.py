"""Horizon gateway integration: token management, adapters, and the ChatHorizon model."""
