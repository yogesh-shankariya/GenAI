"""Diagnostic probe for /v2/tool/chats (plan §4 — Milestone 0).

Run against real infra **in the client environment only** (requires a
populated ``.env``); commit the captured (redacted) responses to
``tests/fixtures/tool_chats_samples/`` and record the resulting contract in
``docs/tool_chats_contract.md``. Then finalize ``src/horizon/adapters.py``.

STATUS after the 2026-07-06 run:

- Probe A (OPEN-1) CONFIRMED: standalone ``{"type": "tool_call", "role":
  "assistant", "id", "name", "input": {...}}`` message; response carries ONLY
  model-authored messages.
- Probe C (OPEN-3) CONFIRMED: multiple calls = multiple tool_call messages.
- Probe D (OPEN-4) CONFIRMED: system role accepted and respected.
- Probe B (OPEN-2) STILL OPEN: both original candidates 422'd. The validator
  says the message union has exactly THREE variants — ``message``,
  ``tool_call``, and one unknown. This file now tries an expanded battery::

      python -m src.horizon.probe_tool_chats --probes b

  Also check the internal API docs' message-union schema first — if it names
  the third variant, put that shape at the TOP of TOOL_RESULT_CANDIDATES.

The probe uses a harmless weather tool — no PHI is sent.
"""

import argparse
import copy
import json
from pathlib import Path

import requests
from dotenv import load_dotenv

from src.config import build_token_manager, load_config

load_dotenv()

WEATHER_TOOL = {
    "type": "adhoc",
    "name": "get_weather",
    "description": "Get the current weather for a city",
    "parameters": {
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    },
}

RESULT_TEXT = "72F, sunny"


def _echo_with_output(tool_call_message):
    """Candidate: the tool_call message itself with the result attached."""
    echoed = copy.deepcopy(tool_call_message)
    echoed["output"] = RESULT_TEXT
    return echoed


# Tool-result candidates for Probe B, tried in order until one returns 200 AND
# a sensible natural-language continuation. Ordered by likelihood given the
# CONFIRMED tool_call naming (top-level "id", args under "input").
# If the internal API docs name the third message-union variant, insert that
# exact shape at the top.
TOOL_RESULT_CANDIDATES = [
    ("tool_result role=tool id content", lambda cid, tc: {
        "type": "tool_result", "role": "tool", "id": cid, "content": RESULT_TEXT}),
    ("tool_result id content", lambda cid, tc: {
        "type": "tool_result", "id": cid, "content": RESULT_TEXT}),
    ("tool_result id output", lambda cid, tc: {
        "type": "tool_result", "id": cid, "output": RESULT_TEXT}),
    ("tool_result role=tool id name content", lambda cid, tc: {
        "type": "tool_result", "role": "tool", "id": cid,
        "name": "get_weather", "content": RESULT_TEXT}),
    ("tool_result id name output", lambda cid, tc: {
        "type": "tool_result", "id": cid, "name": "get_weather",
        "output": RESULT_TEXT}),
    ("tool_call echoed with output", lambda cid, tc: _echo_with_output(tc)),
    ("tool_result tool_call_id content (plan candidate 1)", lambda cid, tc: {
        "type": "tool_result", "tool_call_id": cid, "content": RESULT_TEXT}),
    ("message role=tool (plan candidate 2)", lambda cid, tc: {
        "type": "message", "role": "tool", "content": RESULT_TEXT}),
]


def post(payload, token, base_url, params):
    r = requests.post(
        f"{base_url}/v2/tool/chats",
        headers={
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json",
        },
        params=params,
        json=payload,
        timeout=(10, 300),
    )
    print(r.status_code)
    try:
        body = r.json()
    except ValueError:
        body = {"_non_json_body": r.text[:2000]}
    print(json.dumps(body, indent=2))
    return r.status_code, body


def save_capture(output_dir: Path, name: str, status: int, body, request=None) -> None:
    """Persist a redacted capture (tokens never appear in bodies)."""
    output_dir.mkdir(parents=True, exist_ok=True)
    capture = {"status": status, "body": body}
    if request is not None:
        capture["request_messages"] = request
    path = output_dir / f"{name}.json"
    path.write_text(json.dumps(capture, indent=2), encoding="utf-8")
    print(f"saved {path}")


def find_tool_call_message(body):
    """Locate the tool-call turn in a response (confirmed standalone shape)."""
    for message in reversed(body.get("messages", [])):
        if not isinstance(message, dict):
            continue
        if message.get("type") == "tool_call" or message.get("tool_calls"):
            return message
    return None


def extract_call_id(tool_call_message):
    if tool_call_message is None:
        return None
    if tool_call_message.get("type") == "tool_call":
        return tool_call_message.get("id") or tool_call_message.get("tool_call_id")
    calls = tool_call_message.get("tool_calls") or []
    if calls and isinstance(calls[0], dict):
        return calls[0].get("id") or calls[0].get("tool_call_id")
    return None


def run_probe_a(token, base_url, params, output_dir):
    """OPEN-1: capture the model's tool-call message shape."""
    payload = {
        "tools": [WEATHER_TOOL],
        "messages": [
            {
                "type": "message",
                "role": "user",
                "content": "What is the weather in Fresno right now? Use the tool.",
            }
        ],
    }
    status, body = post(payload, token, base_url, params)
    save_capture(output_dir, "probe_a_tool_call", status, body)
    tool_call_message = find_tool_call_message(body)
    print(f"Probe A tool-call message: {tool_call_message}")
    return payload, tool_call_message


def run_probe_b(token, base_url, params, output_dir):
    """OPEN-2: find the accepted tool-result shape (candidate battery)."""
    payload_a, tool_call_message = run_probe_a(token, base_url, params, output_dir)
    if tool_call_message is None:
        print("Probe B skipped: no tool-call message captured.")
        return

    call_id = extract_call_id(tool_call_message)
    print(f"Probe B using call id: {call_id}")

    winner = None
    for i, (label, build) in enumerate(TOOL_RESULT_CANDIDATES, start=1):
        candidate = build(call_id, tool_call_message)
        print(f"\n--- Probe B candidate {i}: {label} ---")
        print(json.dumps(candidate, indent=2))
        payload_b = {
            "tools": [WEATHER_TOOL],
            "messages": payload_a["messages"] + [tool_call_message, candidate],
        }
        status, body = post(payload_b, token, base_url, params)
        save_capture(
            output_dir,
            f"probe_b_candidate_{i:02d}",
            status,
            body,
            request=[tool_call_message, candidate],
        )
        if status == 200:
            winner = (i, label, candidate)
            print(
                f"\n*** Candidate {i} ACCEPTED ({label}). Check the continuation "
                "above actually uses the weather value (72F / sunny). ***"
            )
            break

    if winner is None:
        print(
            "\nNo candidate accepted. Check the internal API docs' message-union "
            "schema for the third variant and add it to TOOL_RESULT_CANDIDATES."
        )
    else:
        print(
            "\nNext: record the winning shape in docs/tool_chats_contract.md and "
            "update _tool_result_wire() in src/horizon/adapters.py."
        )


def run_probe_c(token, base_url, params, output_dir):
    """OPEN-3: does one response carry multiple tool calls?"""
    payload = {
        "tools": [WEATHER_TOOL],
        "messages": [
            {
                "type": "message",
                "role": "user",
                "content": (
                    "What is the weather in Fresno AND in Sacramento right now? "
                    "Use the tool for each city."
                ),
            }
        ],
    }
    status, body = post(payload, token, base_url, params)
    save_capture(output_dir, "probe_c_multi_tool_call", status, body)


def run_probe_d(token, base_url, params, output_dir):
    """OPEN-4: is a system role accepted (200) and respected?"""
    payload = {
        "tools": [WEATHER_TOOL],
        "messages": [
            {"type": "message", "role": "system", "content": "Answer in French."},
            {
                "type": "message",
                "role": "user",
                "content": "What is the capital of Spain?",
            },
        ],
    }
    status, body = post(payload, token, base_url, params)
    save_capture(output_dir, "probe_d_system_role", status, body)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--output-dir",
        default="tests/fixtures/tool_chats_samples",
        help="where to write the redacted captures",
    )
    parser.add_argument(
        "--probes",
        nargs="+",
        choices=["a", "b", "c", "d"],
        default=["a", "b", "c", "d"],
        help="which probes to run (default: all). Probe B re-runs A internally.",
    )
    args = parser.parse_args()
    output_dir = Path(args.output_dir)
    probes = set(args.probes)

    config = load_config()
    base_url = config["horizon_base_url"]
    token_manager = build_token_manager(config)
    token = token_manager.get_token()
    params = {"qos": config["qos"], "reasoning": config["reasoning"]}

    if "b" in probes:
        # B subsumes A (it needs a fresh tool-call capture).
        run_probe_b(token, base_url, params, output_dir)
    elif "a" in probes:
        run_probe_a(token, base_url, params, output_dir)
    if "c" in probes:
        run_probe_c(token, base_url, params, output_dir)
    if "d" in probes:
        run_probe_d(token, base_url, params, output_dir)

    print(
        "\nRecord findings in docs/tool_chats_contract.md, update "
        "src/horizon/adapters.py and the fixtures, then re-run the unit tests."
    )


if __name__ == "__main__":
    main()
