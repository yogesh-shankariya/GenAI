import functools
import logging
import sys
import time

import requests


class TokenManager:
    _instance = None
    _initialized = False  # Flag to ensure __init__ runs only once

    def __new__(cls, *args, **kwargs):
        if not cls._instance:
            cls._instance = super().__new__(cls)

        return cls._instance

    def __init__(self, config, client_id, client_secret):
        if TokenManager._initialized:
            # Prevent re-initialization
            return

        self.client_id = client_id
        self.client_secret = client_secret

        self.token_validity_seconds = config["token_validity_seconds"]
        self.refresh_margin_seconds = config["refresh_margin_seconds"]

        self.logger = logging.getLogger("llm_service")
        self.config = config

        self.MIN_CONNECTION_TIMEOUT = config.get("min_connection_timeout_seconds")
        self.MAX_READ_TIMEOUT = config.get("max_read_timeout_seconds")

        # The _fetch_new_token method is wrapped by lru_cache.
        # This happens only once due to the _initialized guard.
        self._fetch_new_token = functools.lru_cache(maxsize=1)(
            self._fetch_new_token
        )

        TokenManager._initialized = True

    def _fetch_new_token(self):
        """
        Fetch a new token from the auth server.

        This method is internally cached by __init__.
        """

        self.logger.info("Fetching new token from auth server...")

        response = requests.post(
            self.config["auth_url"],
            data={
                "grant_type": "client_credentials",
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            },
            timeout=(self.MIN_CONNECTION_TIMEOUT, self.MAX_READ_TIMEOUT),
        )

        response.raise_for_status()

        token_data = response.json()

        access_token = token_data["access_token"]
        token_created_time = time.time()

        return access_token, token_created_time

    def get_token(self):
        """
        Get a valid token, refreshing if necessary.
        """

        try:
            # Retrieve token and creation time.
            # This calls the lru_cache-wrapped version.
            token, created_time = self._fetch_new_token()

            token_age = time.time() - created_time

            if token_age > (
                self.token_validity_seconds - self.refresh_margin_seconds
            ):
                self.logger.info(
                    f"Token expired or near expiry "
                    f"(age: {token_age:.1f}s) - refreshing..."
                )

                self._fetch_new_token.cache_clear()
                token, _ = self._fetch_new_token()

            else:
                self.logger.info(
                    f"Using token (age: {token_age:.1f}s). "
                    f"Cache info: {self._fetch_new_token.cache_info()}"
                )

            return token

        except requests.exceptions.Timeout as e:
            self.logger.error(
                f"LLM query timed out after 5 minutes in token generation: {e}"
            )

            if hasattr(self, "_fetch_new_token") and hasattr(
                self._fetch_new_token,
                "cache_clear",
            ):
                self._fetch_new_token.cache_clear()

            raise

        except Exception as e:
            self.logger.error(f"Error getting token: {e}")

            # Ensure cache is cleared on error to prevent using bad tokens
            if hasattr(self, "_fetch_new_token") and hasattr(
                self._fetch_new_token,
                "cache_clear",
            ):
                self._fetch_new_token.cache_clear()

            raise

        finally:
            sys.stderr.flush()

            if self.logger.hasHandlers():
                self.logger.handlers[0].flush()

    def clear_cache(self):
        """
        Clear the token cache.
        """

        self.logger.info("Clearing token cache.")

        if hasattr(self, "_fetch_new_token") and hasattr(
            self._fetch_new_token,
            "cache_clear",
        ):
            self._fetch_new_token.cache_clear()

        else:
            self.logger.warning(
                "Attempted to clear cache, but token fetching mechanism "
                "is not cached or not initialized."
            )