"""Pydantic v2 schemas for the extraction output contract (plan §5.2 / §6).

Multiple values with different dates are the *normal case*: each reading is one
list element with its own ``date`` + ``date_source``. A five-row HbA1c trend
table produces five ``HbA1cReading`` items.
"""

from typing import List, Literal, Optional

from pydantic import BaseModel, Field

DateSource = Literal["inline", "table_row", "table_header", "visit_date", "none"]
FoundIn = Literal["table", "narrative", "form"]
Confidence = Literal["high", "medium", "low"]


class ReadingBase(BaseModel):
    date: Optional[str] = Field(None, description="ISO YYYY-MM-DD")
    date_source: DateSource
    source_page: int
    found_in: FoundIn
    evidence: str = Field(..., description="verbatim substring of the source page")
    confidence: Confidence = "high"
    note: Optional[str] = None


class BloodPressureReading(ReadingBase):
    type: Literal["blood_pressure"] = "blood_pressure"
    systolic: int
    diastolic: int
    unit: Literal["mmHg"] = "mmHg"


class HbA1cReading(ReadingBase):
    type: Literal["hba1c"] = "hba1c"
    value: float
    unit: Literal["%", "mmol/mol"]


class ExtractionResult(BaseModel):
    document_id: Optional[str] = None  # member id if found, else None
    visit_date: Optional[str] = None  # ISO
    blood_pressure: List[BloodPressureReading] = []
    hba1c: List[HbA1cReading] = []
    flags: List[str] = []


class PageExtraction(BaseModel):
    """Internal: shape of an extractor subagent's reply (not part of final output).

    Used in tests and, optionally, by the orchestrator-trace assertions.
    """

    page: Optional[int]
    starts_mid_table: bool = False  # §3a boundary flag
    ends_mid_table: bool = False  # §3a boundary flag
    readings: List[dict] = []  # per-type validation happens after routing
    page_flags: List[str] = []
