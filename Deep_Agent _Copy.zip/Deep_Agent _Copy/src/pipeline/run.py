"""Pipeline entrypoint (plan §5.6).

Usage::

    python -m src.pipeline.run --input Input/input.md --output out/results.json

Flow: split the document into per-page files (Python regex) → hand the agent
the explicit worklist + files → the deep agent extracts/verifies one page per
LLM call and writes ``/results.json`` → deterministic postprocess (validation,
programmatic evidence gate, dedupe) → final JSON on disk.
"""

import argparse
import logging
from pathlib import Path

from src.agent.build_agent import build_agent
from src.agent.prompts import USER_TASK_TEMPLATE
from src.config import build_token_manager, configure_logging, load_config
from src.horizon.chat_horizon import ChatHorizon
from src.pipeline.postprocess import postprocess
from src.pipeline.schemas import ExtractionResult
from src.pipeline.splitter import split_pages

logger = logging.getLogger("llm_service")


def run(input_path: str, output_path: str) -> ExtractionResult:
    """Run the full extraction pipeline on one OCR'd document."""
    document = Path(input_path).read_text(encoding="utf-8")

    # load_config() runs load_dotenv() and MUST precede split_pages(): the
    # splitter's overlap window reads HORIZON_OVERLAP_LINES from the
    # environment (§3a), which may be set only in .env.
    config = load_config()
    split = split_pages(document)  # SplitResult (§5.1 / §3a)

    token_manager = build_token_manager(config)
    model = ChatHorizon(
        base_url=config["horizon_base_url"],
        token_manager=token_manager,
        qos=config["qos"],
        reasoning=config["reasoning"],
        preview=config["preview"],
        connect_timeout=config["min_connection_timeout_seconds"],
        read_timeout=config["max_read_timeout_seconds"],
    )
    agent = build_agent(model)

    worklist = "\n".join(sorted(split.agent_files))
    logger.info("Invoking deep agent on %d page(s).", len(split.agent_files))

    result = agent.invoke(
        {
            "messages": [
                {
                    "role": "user",
                    "content": USER_TASK_TEMPLATE.format(worklist=worklist),
                }
            ],
            "files": split.agent_files,  # decorated files (§3a)
        },
        # 30 pages of tool calls blows past the default recursion limit.
        config={"recursion_limit": 1000},
    )

    # Evidence gate runs against RAW pages, never the decorated agent files.
    return postprocess(result, split.raw_pages, output_path, extra_flags=split.flags)


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Extract BP & HbA1c readings from an OCR'd health assessment."
    )
    parser.add_argument("--input", required=True, help="path to the OCR'd .md document")
    parser.add_argument("--output", required=True, help="path for the validated JSON output")
    parser.add_argument(
        "--verbose",
        action="store_true",
        help="enable DEBUG logging (contains PHI — use only inside the PHI boundary)",
    )
    args = parser.parse_args()

    configure_logging(verbose=args.verbose)
    result = run(args.input, args.output)
    logger.info(
        "Done: %d BP, %d HbA1c, %d flag(s) → %s",
        len(result.blood_pressure),
        len(result.hba1c),
        len(result.flags),
        args.output,
    )


if __name__ == "__main__":
    main()
