"""Deterministic page splitter + §3a overlap decorator for OCR'd health-assessment markdown.

Pages are delimited by a doubled tag with the page number between two identical
tags::

    <ocr_service_page_start>1<ocr_service_page_start>
    ...page 1 OCR text...
    <ocr_service_page_start>2<ocr_service_page_start>
    ...page 2 OCR text...

Two views of every page are produced (plan §5.1 / §3a):

- ``agent_files`` — the decorated form handed to the deep agent: a read-only
  ``<CONTEXT_FROM_PREVIOUS_PAGE>`` section holding the tail of the previous
  RAW page, followed by the page itself inside ``<PAGE n="NN">`` markers.
- ``raw_pages`` — page number → RAW text, exactly as it appears between the
  OCR tags. The programmatic evidence gate matches against THIS, never the
  decorated files (whose context section would let a neighboring page's text
  pass).
"""

import logging
import os
import re
import string
from dataclasses import dataclass, field
from typing import Dict, List, Optional

logger = logging.getLogger("llm_service")

PAGE_TAG = re.compile(r"<ocr_service_page_start>\s*(\d+)\s*<ocr_service_page_start>")

# Default size of the read-only overlap window (§3a): the last N NON-EMPTY
# lines of the previous raw page. Overridable via env HORIZON_OVERLAP_LINES or
# the overlap_lines argument.
OVERLAP_LINES = 20

CONTEXT_OPEN = '<CONTEXT_FROM_PREVIOUS_PAGE read_only="true">'
CONTEXT_CLOSE = "</CONTEXT_FROM_PREVIOUS_PAGE>"


@dataclass
class SplitResult:
    agent_files: Dict[str, str]  # decorated files handed to the agent (§3a format)
    raw_pages: Dict[int, str]  # page number -> RAW text; evidence gate uses THIS
    # Pipeline flags for suspicious input conditions (duplicate page numbers,
    # missing page tags); merged into ExtractionResult.flags by the entrypoint.
    flags: List[str] = field(default_factory=list)


def _resolve_overlap_lines(overlap_lines: Optional[int]) -> int:
    if overlap_lines is not None:
        return overlap_lines
    env_value = os.getenv("HORIZON_OVERLAP_LINES")
    if env_value is not None:
        try:
            return int(env_value)
        except ValueError:
            logger.warning(
                "Invalid HORIZON_OVERLAP_LINES=%r; using default %d.",
                env_value,
                OVERLAP_LINES,
            )
    return OVERLAP_LINES


def _tail_non_empty_lines(raw_text: str, count: int) -> str:
    """The last ``count`` non-empty lines of a raw page, raw, newline-joined."""
    non_empty = [line for line in raw_text.splitlines() if line.strip()]
    return "\n".join(non_empty[-count:]) if count > 0 else ""


def _decorate(page_label: str, raw_text: str, previous_raw: Optional[str], overlap: int) -> str:
    """Wrap one raw page in the §3a two-section format.

    Page 1 (``previous_raw is None``) gets a context section that is present
    but empty.
    """
    context = _tail_non_empty_lines(previous_raw, overlap) if previous_raw else ""
    context_block = f"{CONTEXT_OPEN}\n{context}\n{CONTEXT_CLOSE}" if context else f"{CONTEXT_OPEN}\n{CONTEXT_CLOSE}"
    return f'{context_block}\n<PAGE n="{page_label}">\n{raw_text}\n</PAGE>\n'


def split_pages(document: str, overlap_lines: Optional[int] = None) -> SplitResult:
    """Split raw OCR markdown into per-page units (plan §5.1).

    - Page number comes from the tag; pad to 2 digits (3 if any page >= 100).
    - ``raw_pages[n]``: everything from the end of a tag to the start of the
      next tag (or EOF), RAW — do not strip 'Page N' lines or normalize
      whitespace; evidence matching later depends on the raw text.
    - ``agent_files['/pages/page_NN.md']``: the §3a decorated form — the last
      ``overlap_lines`` non-empty lines of the previous RAW page inside
      ``<CONTEXT_FROM_PREVIOUS_PAGE read_only="true">`` markers, followed by
      ``<PAGE n="NN">`` + the raw page text + ``</PAGE>``. Page 1's context
      section is present but empty.
    - If NO tags are found, treat the whole document as page 01 and log a
      warning (plus a pipeline flag).
    - Duplicate page numbers: suffix '_b' and add a pipeline flag. Their raw
      text is appended to ``raw_pages[n]`` so the evidence gate covers every
      copy of the page.
    """
    overlap = _resolve_overlap_lines(overlap_lines)
    flags: List[str] = []
    matches = list(PAGE_TAG.finditer(document))

    if not matches:
        logger.warning(
            "No <ocr_service_page_start> tags found; treating the whole "
            "document as a single page."
        )
        flags.append("no page tags found; treated entire document as page 1")
        return SplitResult(
            agent_files={"/pages/page_01.md": _decorate("01", document, None, overlap)},
            raw_pages={1: document},
            flags=flags,
        )

    width = 3 if any(int(m.group(1)) >= 100 for m in matches) else 2

    agent_files: Dict[str, str] = {}
    raw_pages: Dict[int, str] = {}
    previous_raw: Optional[str] = None
    for i, match in enumerate(matches):
        page_number = int(match.group(1))
        start = match.end()
        end = matches[i + 1].start() if i + 1 < len(matches) else len(document)
        # Keep the text RAW: the programmatic evidence gate and the verifier
        # both match verbatim substrings against this exact content.
        raw_text = document[start:end]

        page_label = f"{page_number:0{width}d}"
        base = f"/pages/page_{page_label}"
        path = f"{base}.md"
        if path in agent_files:
            for suffix in string.ascii_lowercase[1:]:  # _b, _c, ...
                candidate = f"{base}_{suffix}.md"
                if candidate not in agent_files:
                    path = candidate
                    break
            flags.append(
                f"duplicate page number {page_number} in input; stored as {path}"
            )

        agent_files[path] = _decorate(page_label, raw_text, previous_raw, overlap)
        if page_number in raw_pages:
            # Both copies must be visible to the evidence gate.
            raw_pages[page_number] += "\n" + raw_text
        else:
            raw_pages[page_number] = raw_text
        previous_raw = raw_text

    logger.info(
        "Split document into %d page file(s) (overlap window: %d lines).",
        len(agent_files),
        overlap,
    )
    return SplitResult(agent_files=agent_files, raw_pages=raw_pages, flags=flags)
