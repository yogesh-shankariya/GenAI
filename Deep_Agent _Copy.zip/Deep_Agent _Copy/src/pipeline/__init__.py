"""Deterministic pipeline: page splitting, schemas, postprocessing, entrypoint."""
