"""Deterministic postprocessing of the agent's /results.json (plan §5.6).

Order of operations:

1. Read ``/results.json`` from ``result["files"]`` (state backend). Missing or
   invalid JSON → raise a clear error including the agent's last message
   (never a silent fallback).
2. Validate with ``ExtractionResult.model_validate``.
3. Programmatic evidence gate (independent of the verifier — defense in
   depth): every reading's whitespace-normalized ``evidence`` must be a
   substring of the whitespace-normalized ``raw_pages[source_page]`` — the RAW
   page text kept by the splitter, NEVER the decorated agent file, whose
   <CONTEXT_FROM_PREVIOUS_PAGE> section would let a neighboring page's text
   pass (§3a). Failing readings are dropped and flagged.
4. Dedupe exact duplicates (same type + numeric values + date + source_page +
   evidence) — keep first, flag the collapse.
5. Sort each list by ``(date or "9999", source_page)``.
6. Write validated JSON to ``output_path``, return the model instance.
"""

import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from src.pipeline.schemas import ExtractionResult

logger = logging.getLogger("llm_service")

RESULTS_PATH = "/results.json"


class PostprocessError(RuntimeError):
    """Raised when the agent run did not yield a usable /results.json."""


def _normalize_ws(text: str) -> str:
    """Collapse all whitespace runs to single spaces (evidence-gate comparison)."""
    return " ".join(text.split())


def _file_text(value: Any) -> Optional[str]:
    """Extract text from a state-backend file value.

    Tolerates the formats deepagents may store in the ``files`` channel:
    plain ``str``, v2 ``FileData`` dicts (``{"content": "<str>", ...}``), and
    v1 dicts whose content is a list of lines.
    """
    if isinstance(value, str):
        return value
    if isinstance(value, dict):
        content = value.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list) and all(isinstance(x, str) for x in content):
            return "\n".join(content)
    return None


def _last_agent_message(result: Dict[str, Any]) -> str:
    messages = result.get("messages") or []
    if not messages:
        return "<no messages in agent result>"
    last = messages[-1]
    content = getattr(last, "content", None)
    if content is None and isinstance(last, dict):
        content = last.get("content")
    return str(content)[:2000]


def _load_results_json(result: Dict[str, Any]) -> Dict[str, Any]:
    files = result.get("files") or {}
    raw = _file_text(files.get(RESULTS_PATH))
    if raw is None:
        raise PostprocessError(
            f"Agent did not write {RESULTS_PATH}. Files present: "
            f"{sorted(files)}. Last agent message: {_last_agent_message(result)}"
        )
    try:
        return json.loads(raw)
    except json.JSONDecodeError as exc:
        raise PostprocessError(
            f"{RESULTS_PATH} is not valid JSON ({exc}). "
            f"Last agent message: {_last_agent_message(result)}"
        ) from exc


def _evidence_gate(
    model: ExtractionResult, raw_pages: Dict[int, str]
) -> ExtractionResult:
    """Drop any reading whose evidence is not verbatim on its RAW source page.

    ``raw_pages`` must be ``SplitResult.raw_pages`` — undecorated text. Gating
    against the decorated agent files would let evidence sitting in a page's
    read-only context section (i.e. the PREVIOUS page's text) pass wrongly.
    """
    normalized_pages: Dict[int, str] = {}

    def _passes(reading) -> bool:
        n = reading.source_page
        if n not in normalized_pages:
            normalized_pages[n] = _normalize_ws(raw_pages.get(n, ""))
        evidence = _normalize_ws(reading.evidence)
        return bool(evidence) and evidence in normalized_pages[n]

    for field in ("blood_pressure", "hba1c"):
        kept = []
        for reading in getattr(model, field):
            if _passes(reading):
                kept.append(reading)
            else:
                model.flags.append(
                    f"dropped page {reading.source_page} reading: "
                    f"evidence not found programmatically"
                )
                logger.info(
                    "Evidence gate dropped a %s reading from page %d.",
                    field,
                    reading.source_page,
                )
        setattr(model, field, kept)
    return model


def _dedupe_key(reading) -> Tuple:
    if reading.type == "blood_pressure":
        values: Tuple = (reading.systolic, reading.diastolic)
    else:
        values = (reading.value, reading.unit)
    return (reading.type, values, reading.date, reading.source_page, reading.evidence)


def _dedupe(model: ExtractionResult) -> ExtractionResult:
    """Collapse exact duplicates — keep first, flag the collapse."""
    for field in ("blood_pressure", "hba1c"):
        seen = set()
        kept = []
        for reading in getattr(model, field):
            key = _dedupe_key(reading)
            if key in seen:
                model.flags.append(
                    f"deduped exact duplicate {reading.type} reading on "
                    f"page {reading.source_page} (evidence: {reading.evidence!r})"
                )
            else:
                seen.add(key)
                kept.append(reading)
        setattr(model, field, kept)
    return model


def _sort(model: ExtractionResult) -> ExtractionResult:
    key = lambda r: (r.date or "9999", r.source_page)  # noqa: E731
    model.blood_pressure.sort(key=key)
    model.hba1c.sort(key=key)
    return model


def postprocess(
    result: Dict[str, Any],
    raw_pages: Dict[int, str],
    output_path: str,
    extra_flags: Optional[List[str]] = None,
) -> ExtractionResult:
    """Validate, gate, dedupe, sort, and persist the agent's output.

    ``raw_pages`` is ``SplitResult.raw_pages`` (page number → RAW text) —
    never pass the decorated ``agent_files`` here.
    """
    data = _load_results_json(result)

    model = ExtractionResult.model_validate(data)

    if extra_flags:
        model.flags.extend(extra_flags)

    model = _evidence_gate(model, raw_pages)
    model = _dedupe(model)
    model = _sort(model)

    output = Path(output_path)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(model.model_dump_json(indent=2), encoding="utf-8")
    logger.info(
        "Wrote %s: %d BP reading(s), %d HbA1c reading(s), %d flag(s).",
        output_path,
        len(model.blood_pressure),
        len(model.hba1c),
        len(model.flags),
    )
    return model
