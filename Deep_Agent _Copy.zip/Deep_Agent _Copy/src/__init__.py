"""Deep Agent pipeline for BP & HbA1c extraction from OCR'd health assessments."""
